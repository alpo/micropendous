File Format: Gerber RS-274-X
Plot Origin: Absolute

	Micropendous-DIP-SoldP_Front.gtp	: Top/Front Layer Solder Paste

	Micropendous-DIP-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Micropendous-DIP-Mask_Front.gts		: Top/Front Layer Green Solder Mask
	Micropendous-DIP-Front.gtl		: Top/Front Copper Layer
	Micropendous-DIP-Back.gbl		: Bottom/Back Copper Layer
	Micropendous-DIP-Mask_Back.gbs		: Bottom/Back Layer Green Solder Mask

	Micropendous-DIP-PCB_Edges.gto		: PCB Edge Outline


Drill File: Micropendous-DIP.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 234
	Notes:  - No axis mirroring and only standard vias
