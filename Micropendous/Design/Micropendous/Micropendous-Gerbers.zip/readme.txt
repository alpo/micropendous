File Format: Gerber RS-274-X
Plot Origin: Absolute

	Micropendous-SoldP_Front.gtp	: Top/Front Solder Paste Stencil

	Micropendous-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Micropendous-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Micropendous-Front.gtl		: Top/Front Copper Layer
	Micropendous-Back.gbl		: Bottom/Back Copper Layer
	Micropendous-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	Micropendous-PCB_Edges.oln	: PCB Edge Outline

Drill File: Micropendous.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : None
	Type : ASCII
	Drill Holes (Pads and Vias): 344
	Notes:  - No axis mirroring and only standard vias
		- All holes are plated
