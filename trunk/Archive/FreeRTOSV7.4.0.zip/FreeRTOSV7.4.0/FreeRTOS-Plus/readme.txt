Directories:

+ FreeRTOS-Plus/CyaSSL contains the CyaSSL source files.  See 
  http://www.FreeRTOS.org/ssl for license information and a description of the
  demo application.  The demo application is located in
  FreeRTOS-Plus/Demo_Projects_Using_FreeRTOS_Simulator/FreeRTOS_Plus_CyaSSL

+ FreeRTOS-Plus/FreeRTOS-Plus-CLI contains the FreeRTOS+CLI source files.  See
  http://www.FreeRTOS.org/cli for license information and a description of
  FreeRTOS windows simulator demo application that is located in the
  FreeRTOS-Plus/Demo_Projects_Using_FreeRTOS_Simulator/FreeRTOS_Plus_CLI_with_Trace
  directory.
  
+ FreeRTOS-Plus/FreeRTOS-Plus-IO contains the FreeRTOS+Trace recorder code.
  See http://www.FreeRTOS.org/trace for license information, links to the
  Windows tool used to view recorded traces, and a description of the demo
  application that is located in the 
  FreeRTOS-Plus/Demo_Projects_Using_FreeRTOS_Simulator/FreeRTOS_Plus_CLI_with_Trace
  directory.
  
+ FreeRTOS-Plus/FreeRTOS-Plus-IO contains a link to the FreeRTOS+IO source code.
  Information on the FreeRTOS+IO featured demo is presented on
  http://www.freertos.org/FreeRTOS-Plus/FreeRTOS_Plus_IO/Demo_Applications/LPCXpresso_LPC1769/NXP_LPC1769_Demo_Description.shtml

+ FreeRTOS-Plus/Demo_Projects_Using_FreeRTOS_Simulator contains pre-configured
  demo projects for the FreeRTOS-Plus components, as described in the bullet
  points above for each component.  See http://www.FreeRTOS.org/plus

Further readme files are contains in sub-directories as appropriate.
  
