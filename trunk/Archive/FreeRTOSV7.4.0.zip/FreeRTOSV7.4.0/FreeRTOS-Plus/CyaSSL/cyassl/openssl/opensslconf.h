/* opensslconf.h for openSSL */


#ifndef OPENSSL_THREADS
    #define OPENSSL_THREADS
#endif


