/* unit.h unit tests driver */

#ifndef CyaSSL_UNIT_H
#define CyaSSL_UNIT_H

#include <cyassl/test.h>    /* thread and tcp stuff */

int ApiTest(void);
int SuiteTest(void);
int HashTest(void);


#endif /* CyaSSL_UNIT_H */