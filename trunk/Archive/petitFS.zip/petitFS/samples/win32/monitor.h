#include "integer.h"
#define xputc(chr)	putc(chr)

int xatoi (const char**, long*);
void xputs (const char*);
void xitoa (long, char, char);
void xprintf (const char*, ...);
void put_dump (const BYTE*, DWORD ofs, int cnt);

