ASHIELD Board, v2.2
3/25/2011

Route board out on 0-mil perimeter in top silk.

Standard .062" FR4, 1oz Cu, RoHS, HASL

Board is 2 layers, plus unusual silk screen (see notes below)

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
NOTE: VENDOR MARK AND TEST STAMP SHOULD BE PLACED WITHIN JOY1 RECTANGLE.
      MARK AND STAMP MUST NOT BE VISIBLE ONCE BOARD IS ASSEMBLED.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Other Notes:

Board is WHITE SMOBC

ashield_blk.plc         BLACK primary (first applied) silk, component side
                        This is a base silk.  Colored silks go on top of this one.

ashield_blk.pls         BLACK silk for bottom (solder) side of board

ashield.drl             Drill rack
ashield.drd             Excellon drill file

ashield.cmp             Component side copper
ashield.stc             Component side stop mask

ashield.sol             Solder side copper
ashield.sts             Solder side stop mask

All components on TOP side of board, EXCEPT for 6 single-row in-line headers
on left and right edges.  There is 1 6-pin header and 5 8-pin headers.  These
mount from the bottom, and are soldered from the top.

Through-hole leads should be trimmed flush.

