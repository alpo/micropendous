/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file dev/adc2.c
 *
 * \date 16.05.2006
 *
 * \author bosterm
 *
 * \brief adc driver to sample multiple channels by different components
 */
 
#include <hardware/btn-hardware.h>
#include <sys/atom.h>
#include <dev/adc2.h> 

// ----------------------------------------------------------------------------
// ADC Stuff
// ----------------------------------------------------------------------------

#if defined(__BTN_UNIX__)
u_short adc2_init( adc2_mode_t mode, 
                   adc2_interrupt_t use_interrupt, 
                   adc2_prescaler_t prescaler, 
                   adc2_channel_t channel, 
                   adc2_ref_t reference )
{
    return 0;
};

u_short adc2_read( u_short handle )
{
    return 0;
}

#else

u_short adc2_init( adc2_mode_t mode, 
				adc2_interrupt_t use_interrupt, 
				adc2_prescaler_t prescaler, 
				adc2_channel_t channel, 
				adc2_ref_t reference )
{
	u_char admux_new = 0;
	u_char adcsr_new = 0;
    
    adcsr_new |= mode;
    adcsr_new |= use_interrupt;
    adcsr_new |= prescaler;
    
    admux_new |= channel;
    admux_new |= reference;   		
	
	NutEnterCritical();
	
	/* disable ADC */
    cbi(ADCSR, ADEN);
    
    ADCSR = adcsr_new;
    ADMUX = admux_new;
    
    /* enable ADC */
    sbi(ADCSR, ADEN);
    
   	NutExitCritical();

   	return admux_new << 8 | adcsr_new;
}

u_short adc2_read( u_short handle )
{

	u_char  admux_new = handle >> 8;
	u_char  adcsr_new = handle & 0xFF; // | 1 << 7;
	u_char  admux_old = 0;
	u_char  adcsr_old = 0;
	u_short result = 0;
	
	NutEnterCritical();
	
	admux_old = ADMUX; // mask out Bits 7 and 4
	adcsr_old = ADCSR & 0x6F;

	// check if the ADC registers have changed...
	if ( admux_old != admux_new || adcsr_old != adcsr_new )
	{
		/* disable ADC */
	    cbi(ADCSR, ADEN);		
	    
	    ADCSR = adcsr_new;
	    ADMUX = admux_new;
	    
	    /* enable ADC */
	    sbi(ADCSR, ADEN);
	}
	
	sbi(ADCSR, ADSC);
    while (bit_is_set(ADCSR, ADSC));
	result = ADCL | (ADCH << 8);  	

   	NutExitCritical();
   	
   	return result;
}
#endif

