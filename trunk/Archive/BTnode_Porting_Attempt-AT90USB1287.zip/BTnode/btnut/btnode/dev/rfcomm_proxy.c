/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/*!
 * $Log: rfcomm_proxy.c,v $
 * Revision 1.5  2006/11/06 11:32:51  yuecelm
 * move my email address to a permanent one
 *
 * Revision 1.4  2006/06/23 13:13:04  yuecelm
 * add connection callback, re-add application example, disable debug
 *
 * Revision 1.3  2006/03/23 07:22:20  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.2.2.2  2006/02/01 16:33:20  dyerm
 * copied from head
 *
 * Revision 1.2  2006/01/16 16:17:35  yuecelm
 * merge of branch rfcomm_dev: add rfcomm device drivers
 *
 */

/**
 * @file dev/rfcomm_proxy.c - 
 * @brief 
 *
 * 2006.01.15 Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 *
 */

#include <dev/rfcomm_proxy.h>

#include <io.h>
#include <stdio.h>

#include <bt/bt_rfcomm.h>
#include <dev/rfcomm.h>
#include <dev/usartavr.h>

#include <hardware/btn-hardware.h>

#include <sys/heap.h>
#include <sys/thread.h>

#define MAX_BUFFER 128

#define TDEBUG 0
#if TDEBUG>0
#define INFO(text, ...) printf_P(PSTR(text "\n"),## __VA_ARGS__);
#define WARN(text, ...) printf_P(PSTR("WARN: " text "\n"),## __VA_ARGS__);
#define ERROR(text, ...) printf_P(PSTR("ERROR: " text "\n"),## __VA_ARGS__);
#else
#define INFO(text, ...)
#define WARN(text, ...)
#define ERROR(text, ...)
#endif

typedef struct proxy_files {
    FILE * src;
    FILE * dst;    
} proxy_files_t;

THREAD(PROXY, arg)
{
    proxy_files_t * proxy_files_sd = arg;
    int readed;
    u_char * buffer = NutHeapAlloc(MAX_BUFFER);
    int fd_src = _fileno(proxy_files_sd->src);
    int fd_dst = _fileno(proxy_files_sd->dst);
    
    for (;;)
    {
        readed = _read(fd_src, buffer, MAX_BUFFER);
        _write(fd_dst, buffer, readed);
    }
}

char rfcomm_proxy_init(struct bt_rfcomm_stack * rfcomm_stack,
                       u_char rfcomm_channel, u_long serialport_baud, 
                       RFCOMM_PROXY_CON_CB)
{
    FILE * serialport;
    NUTDEVICE * devRFComm;
    FILE * rfcomm;
    proxy_files_t * proxy_files_serialport_rfcomm;
    proxy_files_t * proxy_files_rfcomm_serialport;
    
    // init serial app uart
    NutRegisterDevice(&APP_UART, 0, 0);
    serialport = fopen(APP_UART.dev_name, "r+b");
    _ioctl(_fileno(serialport), UART_SETSPEED, &serialport_baud);
    
    devRFComm = RFCommCreate(rfcomm_stack, rfcomm_channel, con_cb);
    if (devRFComm == NULL)
    {
        ERROR("devRFComm is NULL");
        return -1;
    }
    NutRegisterDevice(devRFComm, 0, 0);
    
    rfcomm = fopen(devRFComm->dev_name, "r+b");
    if (rfcomm == NULL)
    {
        ERROR("open rfcomm failed");
        return -2;
    }
    
    proxy_files_serialport_rfcomm = NutHeapAlloc(sizeof(proxy_files_t));
    if (proxy_files_serialport_rfcomm == NULL)
    {
        ERROR("not enough ressources");
        return -3;
    }
    proxy_files_rfcomm_serialport = NutHeapAlloc(sizeof(proxy_files_t));
    if (proxy_files_rfcomm_serialport == NULL)
    {
        ERROR("not enough ressources");
        return -3;
    }
    proxy_files_serialport_rfcomm->src = serialport;
    proxy_files_serialport_rfcomm->dst = rfcomm;
    proxy_files_rfcomm_serialport->src = rfcomm;
    proxy_files_rfcomm_serialport->dst = serialport;

    NutThreadCreate("proxy_sr", PROXY, proxy_files_serialport_rfcomm, 256);
    NutThreadCreate("proxy_rs", PROXY, proxy_files_rfcomm_serialport, 256);
    
    return 0;
}
