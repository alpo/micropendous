/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/*!
 * $Log: stream_buffer.c,v $
 * Revision 1.6  2006/11/06 11:32:51  yuecelm
 * move my email address to a permanent one
 *
 * Revision 1.5  2006/03/23 07:22:20  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.3.2.3  2006/03/22 14:07:39  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.4  2006/02/14 17:56:05  yuecelm
 * fixed bug (BTnode hangs when reconnect RFCOMM), cosmetic changes
 *
 * Revision 1.3.2.2  2006/02/01 16:33:20  dyerm
 * copied from head
 *
 * Revision 1.3  2006/01/25 00:46:04  yuecelm
 * using a ringbuffer structure (to avoid heap allocation on each put)
 *
 * Revision 1.2  2006/01/16 16:17:35  yuecelm
 * merge of branch rfcomm_dev: add rfcomm device drivers
 *
 *
 */

/** 
 * @file dev/stream_buffer.c - a BTnut stream buffer
 * @brief A buffer for stream-oriented protocols like RFCOMM
 *
 * 2005.12.27 Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 *
 */

#include <string.h>
#include <sys/heap.h>
#include <sys/mutex.h>
#include <dev/stream_buffer.h>

#define MIN(x,y) ((x>y)?y:x)

#define TDEBUG 0
#if TDEBUG>0
#include <stdio.h>
#define INFO(text, ...) printf_P(PSTR(text "\n"),## __VA_ARGS__);
#define WARNING(text, ...) printf_P(PSTR("WARNING: " text "\n"),## __VA_ARGS__);
#define ERROR(text, ...) printf_P(PSTR("ERROR: " text "\n"),## __VA_ARGS__);
#else
#define INFO(text, ...)
#define WARNING(text, ...)
#define ERROR(text, ...)
#endif

stream_buffer_t * stream_buffer_init(u_short max_payload)
{
    u_char * payload;
    MUTEX * mutex;
    stream_buffer_t * sb;
    
    payload = NutHeapAlloc(max_payload);
    if (!payload)
    {
        return NULL;   
    }
    
    mutex = NutHeapAlloc(sizeof(MUTEX));
    if (mutex)
    {
        NutMutexInit(mutex);
    }
    else
    {
        NutHeapFree(payload);
        return NULL;
    }
    
    sb = NutHeapAlloc(sizeof(stream_buffer_t));
    if (sb)
    {
        sb->payload = payload;
        sb->head = 0;
        sb->tail = 0;
        sb->total_payload = 0;
        sb->max_payload = max_payload;
        sb->mutex = mutex;
    }
    else
    {
        NutHeapFree(payload);
        NutMutexDestroy(mutex);
        NutHeapFree(mutex); 
    }
    
    return sb;
}

u_short stream_buffer_put(stream_buffer_t * sb, u_char * buffer, u_short len)
{
    u_short size = 0;
        
    NutMutexLock(sb->mutex);

    // reach maximum?
    if (!buffer || len + sb->total_payload > sb->max_payload)
    {
        WARNING("discard put");
        goto end;
    }
    
    if (sb->tail + len > sb->max_payload)
    {
        INFO("consider gap");

        // *misuse* size for gap
        size = (sb->tail + len) % (sb->max_payload);
        INFO("gap: %u", size);
        memcpy(sb->payload + sb->tail, buffer, len - size);
        memcpy(sb->payload, buffer + len - size, size);
        sb->tail = size;
        
    }
    else
    {
        memcpy(sb->payload + sb->tail, buffer, len);
        sb->tail = (sb->tail + len) % sb->max_payload; 
    }

    INFO("tail: %u", sb->tail);
    
    sb->total_payload += len;
    
    INFO("total_payload: %u", sb->total_payload);

    size = len;
    
end:
    
    NutMutexUnlock(sb->mutex);

    return size;
}

u_short stream_buffer_get(stream_buffer_t * sb, u_char * buffer, u_short len)
{
    // len = 0, means flush all data (buffer will be neglected)

    u_short size = 0;
    
    NutMutexLock(sb->mutex);
        
    // is data available?
    if (sb->total_payload == 0)
    {
        return size;
    }
        
    if (len == 0)
    {
        INFO("flush all");
        sb->head = 0;
        sb->tail = 0;
        sb->total_payload = 0;
    }
    else
    {
        size = MIN(len, sb->total_payload);
            
        if (sb->head + size > sb->max_payload)
        {
            INFO("consider gap");
            u_short gap;

            gap = (sb->head + size) % (sb->max_payload);
                
            INFO("gap: %u", gap);
            if (buffer)
            {
                memcpy(buffer, sb->payload + sb->head, size - gap);
                memcpy(buffer + size - gap, sb->payload, gap);
            }
            sb->head = gap;
        }
        else
        {
            if (buffer)
            {
                memcpy(buffer, sb->payload + sb->head, size);
            }
            sb->head = (sb->head + size) % sb->max_payload;
        }
         
        INFO("head: %u", sb->head);
            
        sb->total_payload -= size;
           
        INFO("total_payload: %u", sb->total_payload);    
    }
       
    NutMutexUnlock(sb->mutex);

    return size;
}

u_short stream_buffer_size(stream_buffer_t * sb)
{
    u_short size;
    
    NutMutexLock(sb->mutex);
    
    size = sb->total_payload;
    
    NutMutexUnlock(sb->mutex);
    
    return size;
}


void stream_buffer_destroy(stream_buffer_t * sb)
{
    NutMutexDestroy(sb->mutex);
    NutHeapFree(sb->mutex);
    NutHeapFree(sb->payload);    
    NutHeapFree(sb);
}
