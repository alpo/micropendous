/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/*!
 * $Log: rfcomm.c,v $
 * Revision 1.10  2006/11/06 11:32:51  yuecelm
 * move my email address to a permanent one
 *
 * Revision 1.9  2006/10/27 14:59:34  yuecelm
 * Changed signedness of strings in order to compile with avr-gcc >4.0
 *
 * Revision 1.8  2006/06/23 13:06:54  yuecelm
 * now provides raw and cooked mode (append "b" for raw/binary mode)
 *
 * Revision 1.7  2006/06/18 19:48:59  yuecelm
 * remove RFCommDestroy, replace raw mode
 * with cooked mode ("\n" --> "\r\n")
 *
 * Revision 1.6  2006/03/23 07:22:20  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.4.2.3  2006/03/22 14:07:39  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.5  2006/02/14 17:56:05  yuecelm
 * fixed bug (BTnode hangs when reconnect RFCOMM), cosmetic changes
 *
 * Revision 1.4.2.2  2006/02/01 16:33:20  dyerm
 * copied from head
 *
 * Revision 1.4  2006/01/27 15:53:13  yuecelm
 * flush receive buffer on disconnect
 *
 * Revision 1.3  2006/01/24 00:00:02  yuecelm
 * corrected bug (triggers a hardware error event), some cosmetic changes
 *
 * Revision 1.2  2006/01/16 16:17:35  yuecelm
 * merge of branch rfcomm_dev: add rfcomm device drivers
 *
 *
 */

/**
 * @file dev/rfcomm.c - a BTnut RFCOMM device driver
 * @brief A RFCOMM device driver for BTnut
 *
 * 2005.12.15 Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 *
 */

#include <string.h>
#include <fcntl.h>

#include <sys/atom.h>
#include <sys/event.h>
#include <sys/file.h>
#include <sys/device.h>
#include <sys/heap.h>
#include <sys/mutex.h>
#include <sys/timer.h>

#include <dev/rfcomm.h>
#include <dev/stream_buffer.h>

#include <bt/bt_rfcomm.h>

#define MIN_CREDITS 10
#define MAX_CREDITS 40

#define DEFAULT_MAX_BUFFER 1024

#define RFCOMM_DEV_COOKED_MODE 1
#define RFCOMM_DEV_RAW_MODE    0

#define TDEBUG 0
#if TDEBUG>0
#include <io.h>
#include <stdio.h>
#define INFO(text, ...) printf_P(PSTR(text "\n"),## __VA_ARGS__);
#define WARN(text, ...) printf_P(PSTR("WARN: " text "\n"),## __VA_ARGS__);
#define ERROR(text, ...) printf_P(PSTR("ERROR: " text "\n"),## __VA_ARGS__);
#else
#define INFO(text, ...)
#define WARN(text, ...)
#define ERROR(text, ...)
#endif

/*!
 * \addtogroup xgDevice
 */
/*@{*/

// skeleton for RFCOMM devices, definition is at bottom
static NUTDEVICE devRFComm;

// control block for NUTDEVICE
typedef struct rfcomm_cb {
    u_char channel; // RFCOMM channel
    RFCOMM_CON_CB; // connection callback
    u_char dlci; // DLCI of RFCOMM channel (unconnected: BT_RFCOMM_DLCI_INVALID)
    u_short max_recv_buffer; // maximum receive buffer size
    u_char access_mode; // access mode (read/write)
    u_char proceed_mode; // cooked or raw mode
    stream_buffer_t * rsb; // receive stream buffer (NULL if not used)
    HANDLE rs; // receive signalling
//    stream_buffer_t * ssb; // send stream buffer
} rfcomm_cb_t;

static u_char halfbytetohex(u_char halfbyte)
{
    if (halfbyte<10)
    {
        return (48 + halfbyte);        
    }
    else
    {
        return (55 + halfbyte);
    }  
}

/**
 * order of use:
 *   create -> register -> (open -> (print/get)* -> close)*
 *     (unregister is not available in Nut/OS)
 */

/*!
 * \brief Create RFCOMM device. RFCOMM is multiplexed by channel (1-30).
 *        Each device is assigned to a specific channel.
 *
 * \param rfcomm_stack Pointer to (initialized) RFCOMM stack 
 * \param channel RFCOMM channel (1-30)
 * \param con_cb Connection callback. Will be called on connect/disconnect
 *          (commit NULL, if you didnt use it)
 * 
 * \return Pointer to a NUTDEVICE structure (or NULL on error)
 */
NUTDEVICE * RFCommCreate(struct bt_rfcomm_stack * rfcomm_stack, u_char channel,
    RFCOMM_CON_CB)
{
    NUTDEVICE * nd;
    rfcomm_cb_t * cb;

    // check params (checks to prevent bt_rfcomm_listen failing)
    if (channel > rfcomm_stack->max_channel)
    {
        ERROR("channel is greater than allowed");
        return NULL;
    }

    cb = NutHeapAlloc(sizeof(rfcomm_cb_t));
    if (!cb)
        return NULL;
        
    // enter data (control block)
    cb->channel = channel;
    cb->con_cb = con_cb;
    cb->dlci = BT_RFCOMM_DLCI_INVALID;
    cb->max_recv_buffer = DEFAULT_MAX_BUFFER;
    cb->rsb = NULL;
    cb->rs = NULL;

    nd = NutHeapAlloc(sizeof(NUTDEVICE));
    if (!nd)
        return NULL;

    memcpy(nd, &devRFComm, sizeof(NUTDEVICE));

    // genererate unique device name: rfcomm<%02X,channel>
    nd->dev_name[6] = halfbytetohex(channel >> 4);
    nd->dev_name[7] = halfbytetohex(channel & 15);

    INFO("unique RFCOMM device name: %.9s", nd->dev_name);
    
    nd->dev_dcb = cb;

    INFO("created RFCOMM device with channel %02X", channel);

    return nd;
}

/*!
 * \brief Set maximum size of receive buffer (default is DEFAULT_MAX_BUFFER)
 *
 * \param devRFComm Pointer to a RFCOMM NUTDEVICE structure
 */
void RFCommRecvBufferSize(NUTDEVICE * devRFComm, u_short max_recv_buffer)
{
    rfcomm_cb_t * cb = devRFComm->dev_dcb;
    cb->max_recv_buffer = max_recv_buffer;
}

static void _rfcomm_con_cb(u_char dlci, u_char type, void *arg)
{
    rfcomm_cb_t * cb;

    cb = arg;
    
    INFO("connection callback of RFCOMM device %02X", cb->channel);
        
    if (type == BT_RFCOMM_CONNECT)
    {
        INFO("connect type");
        
        cb->dlci = dlci;
        
        // give some credits at connect
        bt_rfcomm_send_credits(dlci, MAX_CREDITS - BT_RFCOMM_DEF_CREDITS);

        // call connect callback from RFCommCreate
        if (cb->con_cb)
        {
            INFO("call external connection callback: connect");
            cb->con_cb(cb->channel, BT_RFCOMM_CONNECT);
        }

        INFO("connected RFCOMM device %02X with DLCI 0x%02X",
            cb->channel, dlci);
    }
    else
    {
        INFO("disconnect type");

        cb->dlci = BT_RFCOMM_DLCI_INVALID;

        // call connect callback from RFCommCreate
        if (cb->con_cb)
        {              
            INFO("call external connection callback: disconnect");
            cb->con_cb(cb->channel, 0);
        }
        
        INFO("disconnected RFCOMM device %02X with DLCI 0x%02X",
            cb->channel, dlci);
    }
}

static void _rfcomm_rcv_cb(u_char dlci, u_char *payload, u_short len, void *arg)
{
    rfcomm_cb_t * cb;
    u_short size;

    cb = arg;

    INFO("receive callback of RFCOMM device %02X", cb->channel);
    
    if (cb->rsb != NULL)
    {
        INFO("put %u bytes to receive buffer of RFCOMM device %02X",
            len, cb->channel);
        
        INFO("stream buffer size: %u", stream_buffer_size(cb->rsb));
        
        size = stream_buffer_put(cb->rsb, payload, len);
        
        if (!size)
            WARN("buffer full, no put to receive buffer");

        INFO("stream buffer size: %u", stream_buffer_size(cb->rsb));
        
        NutEventPostAsync(&cb->rs);
    }
}

/* will never be called (20060124)
static void _rfcomm_line_cb(u_char dlci, u_char flags, void *arg)
{
    INFOF("line callback of RFCOMM device %02X", BT_RFCOMM_DLCI2CH(dlci));
}
*/

static void _rfcomm_credit_cb(u_char dlci, u_char credits, void *arg)
{
    INFO("credit callback of RFCOMM device %02X", BT_RFCOMM_DLCI2CH(dlci));

    INFO("credits running low to %d, so send new credits: %d",
            credits, MAX_CREDITS - credits);

    bt_rfcomm_send_credits(dlci, MAX_CREDITS - credits);
}


/*!
 * \brief Open RFCOMM device.
 *
 * This function is called by the low level open routine of the C runtime
 * library, using the _NUTDEVICE::dev_open entry.
 *
 * \param dev Pointer to the \ref _NUTDEVICE structure.
 * \param name Ignored, should point to an empty string.
 * \param mode Operation mode:
 * - \ref _O_RDONLY
 * - \ref _O_WRONLY
 * - \ref _O_RDWR
 * - \ref _O_BINARY
 * \param acc Ignored, should be zero.
 *
 * \return Pointer to a NUTFILE structure if successful or NUTFILE_EOF otherwise.
 */
static NUTFILE *RFCommOpen(NUTDEVICE * dev, CONST char * name, int mode,
    int acc)
{
    NUTFILE * nf;
    rfcomm_cb_t * cb;
    u_char res;

    cb = dev->dev_dcb;

    INFO("open RFCOMM device %02X", cb->channel);

    // line callback will be never called 
    res = bt_rfcomm_listen(cb->channel, _rfcomm_con_cb, _rfcomm_rcv_cb, NULL,
                           _rfcomm_credit_cb, MIN_CREDITS, cb, 
                           BT_RFCOMM_NO_TIMEOUT);

    if (res != BT_RFCOMM_ERR_SUCCESS)
    {
        ERROR("cannot registering RFCOMM service for channel %02X (%02X)",
            cb->channel, res);            
        return NUTFILE_EOF;
    }

    // initialize receive buffer if not write-only
    if ((mode & 0x0003) != _O_WRONLY)
    {
        cb->rsb = stream_buffer_init(cb->max_recv_buffer);
        
        if (cb->rsb == NULL)
        {
            cb->access_mode = _O_WRONLY;
            WARN("cannot initialize receive buffer, set write-only");
        }
        else
        {
            cb->access_mode = 0x0003 & mode;
        }

        INFO("max buffer size: %u", cb->max_recv_buffer);
    }
    else
    {
        cb->access_mode = _O_WRONLY;
        INFO("write-only: no receive buffer necessary");   
    }

    if ((mode & 0xC000) == _O_BINARY)
    {
        cb->proceed_mode = RFCOMM_DEV_RAW_MODE;
    }
    else
    {
        cb->proceed_mode = RFCOMM_DEV_COOKED_MODE;
    }

    nf = NutHeapAlloc(sizeof(NUTFILE));

    if (nf)
    {
        // enter data
        nf->nf_next = 0;
        nf->nf_dev = dev;
        nf->nf_fcb = 0;
    }
    else
    {
        return NUTFILE_EOF;
    }

    return nf;
}

/*!
 * \brief Close RFCOMM device.
 *
 * This function is called by the low level close routine of the C runtime
 * library, using the _NUTDEVICE::dev_close entry.
 *
 * \param fp Pointer to a \ref _NUTFILE structure, obtained by a previous call
 *           to UsartOpen().
 *
 * \return 0 on success or -1 otherwise.
 */
static int RFCommClose(NUTFILE * nf)
{
    rfcomm_cb_t * cb;
    u_char res;

    if (nf)
    {
        cb = nf->nf_dev->dev_dcb;

        INFO("close RFCOMM device %02X", cb->channel);

        INFO("disconnect RFCOMM-connection with channel %02X", cb->channel);        
        res = bt_rfcomm_disconnect(cb->dlci);
        if (res != BT_RFCOMM_ERR_SUCCESS)
                WARN("disconnecting unsuccessful (%02X)", res);

        // (flush and) destroy receive buffer
        if (cb->rsb)
        {
            stream_buffer_destroy(cb->rsb);
            cb->rsb = NULL;
        }
                
        NutHeapFree(nf);
    }

    return 0;
}

/*!
 * \brief Write to RFCOMM device. If unconnected, the data will be discarded.
 *
 * \param dev    Pointer to \ref _NUTDEVICE structure.
 * \param buffer Pointer the data to write.
 * \param len    Number of data bytes to write.
 *
 * \return The number of bytes written (always len, no timeout due discarding)
 *         or error due access mode.
 */
static int RFCommPut(NUTDEVICE * dev, CONST void *buffer, int len)
{
    rfcomm_cb_t * cb;
    int i , pos;

    u_char res = BT_RFCOMM_ERR_SUCCESS;
    
    cb = dev->dev_dcb;
    
    if (cb->access_mode == _O_RDONLY)
    {
        return -1;
    }
    
    if (buffer == NULL || len == 0)
    {
        return 0;
    }
    
#if TDEBUG>0
    INFO("write %d bytes to RFCOMM device %02X", len, cb->channel);

    /*
    int i;
    for (i=0; i<len; i++)
    {
        INFO("%02X", ((u_char *) (buffer))[i]);
    }
    */
    _write(_fileno(stdout), buffer, len);
    _write(_fileno(stdout), "\n", 1);
#endif

    if (cb->dlci != BT_RFCOMM_DLCI_INVALID)
    {
        INFO("sending data over RFCOMM channel %02X with DLCI 0x%02X...",
            cb->channel, cb->dlci);

        if (cb->proceed_mode == RFCOMM_DEV_COOKED_MODE)
        {
            // ugly hack for cooked mode ("\n" --> "\r\n")
            pos = 0;
            for (i=0; i<len; i++)
            {
                if (((u_char *) buffer)[i] == '\n')
                {
                    if ((i - pos) > 0)
                    {
                        res = bt_rfcomm_send(cb->dlci, ((u_char *) buffer) + pos,
                                             (i - pos));
                        NutThreadYield();                
                        if (res != BT_RFCOMM_ERR_SUCCESS)
                        {
                            pos = len;
                            break;   
                        }
                    }
                    
                    res = bt_rfcomm_send(cb->dlci, (u_char *) "\r\n", 2);
                    NutThreadYield();
                    if (res != BT_RFCOMM_ERR_SUCCESS)
                    {
                        pos = len;
                        break;   
                    }
                    
                    pos = i+1;                        
                }
            }       
    
            if (pos < len)
            {
                res = bt_rfcomm_send(cb->dlci, ((u_char *) buffer) + pos,
                                     (len - pos));
                NutThreadYield();                
            }
        }   
        else /* cb->cooked_mode == RFCOMM_DEV_RAW_MODE */
        {
            res = bt_rfcomm_send(cb->dlci, (u_char *) buffer, len);
            // give other threads (especially the hci, l2cap and rfcomm thread)
            // the time to proceed incomming packets (and avoid hardware error event)
            NutThreadYield();
        }

        if (res != BT_RFCOMM_ERR_SUCCESS)
        {
            WARN("sending unsuccessful (%02X)", res);            
            return 0;
        }
    }
    else
    {
        INFO("not connected, discard packet");
    }

    return len;
}

/*!
 * \brief Write a RFCOMM device.
 *
 * This function is called by the low level output routines of the
 * \ref xrCrtLowio "C runtime library", using the
 * \ref _NUTDEVICE::dev_write entry.
 *
 * The function may block the calling thread.
 *
 * \param fp     Pointer to a \ref _NUTFILE structure, obtained by a previous
 *               call to UsartOpen().
 * \param buffer Pointer to the data to be written. If zero, then the
 *               output buffer will be flushed.
 * \param len    Number of bytes to write.
 *
 * \return The number of bytes written, which may be less than the number
 *         of bytes specified if a timeout occured. A return value of -1
 *         indicates an error.
 */
static int RFCommWrite(NUTFILE * nf, CONST void *buffer, int len)
{
    return RFCommPut(nf->nf_dev, buffer, len);
}

#ifdef __HARVARD_ARCH__
/*!
 * \brief Write a device or file.
 *
 * Similar to UsartWrite() except that the data is located in program
 * memory.
 *
 * This function is called by the low level output routines of the
 * \ref xrCrtLowio "C runtime library", using the _NUTDEVICE::dev_write_P
 * entry.
 *
 * The function may block the calling thread.
 *
 * \param fp     Pointer to a \ref _NUTFILE structure, obtained by a previous
 *               call to UsartOpen().
 * \param buffer Pointer to the data in program space to be written.
 * \param len    Number of bytes to write.
 *
 * \return The number of bytes written, which may be less than the number
 *         of bytes specified if a timeout occured. A return value of -1
 *         indicates an error.
 */
static int RFCommWriteP(NUTFILE * nf, PGM_P buffer, int len)
{
    return RFCommPut(nf->nf_dev, (CONST void *) buffer, len);
}
#endif

/*!
 * \brief Retrieves the number of characters in receive buffer.
 *
 * This function is called by the low level size routine of the C runtime
 * library, using the _NUTDEVICE::dev_size entry.
 *
 * \param fp     Pointer to a \ref _NUTFILE structure, obtained by a
 *               previous call to UsartOpen().
 *
 * \return The number of bytes currently stored in receive buffer.
 */
static long RFCommSize(NUTFILE * nf)
{
    rfcomm_cb_t * cb;
    u_short size;
    
    cb = nf->nf_dev->dev_dcb;
    
    size = stream_buffer_size(cb->rsb);

    INFO("%u bytes size of RFCOMM device %02X", size, cb->channel);

    return size;
}
 
/*!
 * \brief Read from RFCOMM device.
 *
 * This function is called by the low level input routines of the
 * \ref xrCrtLowio "C runtime library", using the _NUTDEVICE::dev_read
 * entry.
 *
 * The function may block the calling thread until at least one
 * character has been received or a timeout occurs.
 *
 * \param fp     Pointer to a \ref _NUTFILE structure, obtained by a
 *               previous call to RFCommOpen().
 * \param buffer Pointer to the buffer that receives the data. If zero,
 *               then all characters in the receive buffer will be
 *               flushed.
 * \param size   Maximum number of bytes to read. If zero, then all
 *               characters in the receive buffer will be flushed. 
 *
 * \return The number of bytes read, which may be less than the number
 *         of bytes specified. A return value of -1 indicates an error,
 *         while zero is returned in case of a timeout.
 */
static int RFCommRead(NUTFILE * nf, void *buffer, int len)
{
    rfcomm_cb_t * cb;
    u_short size;
    
    cb = nf->nf_dev->dev_dcb;

    if (cb->access_mode == _O_WRONLY)
    {
        return -1;
    }

    INFO("read %d bytes from RFCOMM device %02X", len, cb->channel);
    
    // len=0 means flush
    if (len == 0)
    {
        // flush receive buffer
        INFO("flush RFCOMM device %02X", cb->channel);
        stream_buffer_get(cb->rsb, NULL, len);
    }
    else
    {
        for (;;)
        {
            // is something in receive buffer?
            if (RFCommSize(nf))
            {
                break;   
            }

            INFO("wait until receive...");
    
            // else wait until receive callback fills receive buffer
            NutEventWait(&cb->rs, NUT_WAIT_INFINITE);
        }
    }
    
    INFO("stream buffer size: %u", stream_buffer_size(cb->rsb));

    size = stream_buffer_get(cb->rsb, buffer, len);

    INFO("stream buffer size: %u", stream_buffer_size(cb->rsb));

    INFO("readed %u bytes from RFCOMM device %02X", size, cb->channel);

    return size;
}

/*!
 * \brief Perform control functions.
 *
 * This function is called by the ioctl() function of the C runtime
 * library.
 *
 * \param dev  Identifies the device that receives the device-control
 *             function.
 * \param req  Requested control function. We do return ok for any function
 * \param conf Points to a buffer that contains any data required for
 *             the given control function or receives data from that
 *             function.
 * 
 * \return 0 on success, -1 otherwise.
 */
int RFCommIOCTL(NUTDEVICE * dev, int req, void *conf)
{
    // some timeout controls???
    return 0;
}

static NUTDEVICE devRFComm = {
    0,                          /*!< Pointer to next device. */
    {'r', 'f', 'c', 'o', 'm', 'm', 0, 0, 0},
                                /*!< Unique device name. */
    IFTYP_STREAM,               /*!< Type of device. */
    0,                          /*!< Base address. */
    0,                          /*!< First interrupt number. */
    0,                          /*!< Interface control block. */

    0,                          /*!< Driver control block. */
    0,                          /*!< Driver initialization routine. */
    RFCommIOCTL,                /*!< Driver specific control function. */
    RFCommRead,
    RFCommWrite,
#ifdef __HARVARD_ARCH__
    RFCommWriteP,
#endif
    RFCommOpen,
    RFCommClose,
    RFCommSize
};

/*@}*/
