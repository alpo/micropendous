/*!
 * \file cm_xtc.c
 *
 * \brief Implementation of the XTC Connection Manager
 *  
 * \author Kevin Martin <kevmarti@ee.ethz.ch>
 * 
 * \date 2005/06/13
 *
 */
#include <eepromdb/btn-eepromdb.h>
#include <led/btn-led.h>
#include <terminal/btn-terminal.h>
#include <sys/timer.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_transport_uart.h>
#include <bt/bt_hci_dispatch.h>
#include <sys/types.h>
#include <sys/event.h>
#include <sys/thread.h>
#include <sys/heap.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mutex.h>
#include <debug/logging.h>
#include <debug/toolbox.h>
#include <terminal/eeprom_cmds.h>
#include <cm/con_event_buffer.h>
#include <cm/btnet_adapter.h>
#include <bt/bt_acl_defs.h>
#include <bt/l2cap_cl.h>

#include <cm/cm_xtc_defs.h>
#include "cm_watchdog.c"

// EEPROM parameters
#define READ_EEPROM 0

#define PARAMS(y) void _cm_eeprom_params_init(void) {y}
#define PARAMS_INIT() _cm_eeprom_params_init()

#if READ_EEPROM > 0
#define EEPROM_PARAM(param_name, param_id, param_val, param_default_val) \
	eeprom_cmds_param_ext_read(param_id, &param_val, param_default_val); \
	eeprom_cmds_add_param(param_name, param_id, &param_val, param_default_val);
// if "normal" parameter initialization
#else
#define EEPROM_PARAM(param_name, param_id, param_val, param_default_val) \
	param_val = param_default_val;
#endif // READ_EEPROM

#define CM_MAX_ORDER_SIZE 15

/// Maximal size of neighbor order
#define CM_MAX_NEIGHBORS 25
/// Maximal number of devices in inquiry result
#define CM_MAX_INQ_DEVS 25
/// Number of inquiries before expiration
#define CM_EXPIRATION 10

#define CM_LINK_TIMEOUT 8000 // *0.625ms = 5s

/**
 * \name CM Packet Types
 * payload of acl_pkt:
 \verbatim -------------------------------
 | type | packet               |
 -------------------------------
 .  1    BT_MAX_ACL_COM_PAYLOAD-1\endverbatim
 * cm packet types (cm_stack->payload[0])
 */
//@{
/// Neighbor order packet, con rqst
#define CM_PKT_CON_RQST 1
/// Neighbor order packet, con rqst reply
#define CM_PKT_CON_RQST_REPLY 2
/// 'Device lost' packet
#define CM_PKT_DEV_LOSS 3
//@}

/**
 * \name Connection Info Packet (CIP) Defines
 * 
 * These are the defines and paramters of the connection info packet.
 */
//@{
/// Max number of neighbor devices
#define CIP_MAX_ENTRIES 23
/// No connection to the neighbor
#define CIP_NEIGH_UNCON 0
/// Connected, neighbor's role: master
#define CIP_NEIGH_IS_MY_MASTER 1
/// Connected, neighbor's role: slave
#define CIP_NEIGH_IS_MY_SLAVE 2
/// No connection to neighbor because there were not enough resources available
#define CIP_NEIGH_BLOCKED 3
//@}

/** \name Automatic inquiry
 * @{
 */
/// automatic inquiry off
#define CM_AUTINQ_OFF 0
/// automatic inquiry on
#define CM_AUTINQ_ON 1
/** @} */

/// XTC Link Selection on
#define CM_XTC_ON 1
/// XTC Link Selection off
#define CM_XTC_OFF 0

/// Heartbeat Pause
#define CM_LED_HB_PAUSE 50
/// Heartbeat Duration
#define CM_LED_HB_DURATION 2


/// Bit Mask used to determine which bits of the CM_COD parameter
/// are �don�t care�: Zero-value bits in the mask indicate the �don�t care� bits
/// of the connection manager Class of Device.
/// Note: long format required
#define CM_COD_MASK 0xFFFFFFl

/**
 * \name EEPROM Default Parameters
 * 
 * These are the default values of the paramteres that are obtained from the
 * EEPROM at startup.
 */
//@{
/// Maximal inquiry period [msec] (default value)
#define CM_AI_MAX_PERIOD_DEFAULT 60000
/// Minimal inquiry period [msec] (default value)
#define CM_AI_MIN_PERIOD_DEFAULT 5000
/// Number of initial inquiries (default value)
#define CM_AI_INIT_DEFAULT 4
/// Number of transitional inquiries (default value)
#define CM_AI_TRANS_DEFAULT 5           
/// Maximal random inquiry period deviation [msec] (default value)
#define CM_AI_PERIOD_DEVIATION_DEFAULT 5000
/// Duration of an inquiry (x*1.28 sec), default value
#define CM_AI_TIME_DEFAULT 2
/// Automatic inquiries after startup (default value)
#define CM_AUTINQ_DEFAULT CM_AUTINQ_ON
/// Minimal RSSI difference (Id mode)
#define CM_RSSI_ID_DEFAULT 0
/// RSSI update threshold
#define CM_RSSI_TH_DEFAULT 20
/// Maximal connection establishment period deviation (default value)
#define CM_CON_PERIOD_DEFAULT 4000
/// Minimal visibility time [msec] (default value)
#define CM_MIN_VTIME_DEFAULT 2000
/// IIR low pass filter coefficient alpha (default value)
#define CM_LPF_ALPHA_DEFAULT 1
/// IIR low pass filter coefficient beta (default value)
#define CM_LPF_BETA_DEFAULT 3
/// Page timeout (x*0.625msec), default value
#define CM_PTIME_DEFAULT 2048
/// Max page Retrials
#define CM_MAX_CON_RETRIES 4
/// XTC Link Selection
/** Defines if XTC link selection is done or not. If turned off, links established 
 * won't be closed, i.e. all incoming connections are accepted. This switch
 * has actually been used for debugging local resource sharing and was not
 * intended to be turned off in "normal" mode.
 */
#define CM_XTC_DEFAULT CM_XTC_ON
//@}


// xtc parameter definition
PARAMS(
	EEPROM_PARAM("xtc", "xtcs", cm_stack->xtc, CM_XTC_DEFAULT)
	EEPROM_PARAM("aimax", "aima", cm_stack->ai_max_period, CM_AI_MAX_PERIOD_DEFAULT)
	EEPROM_PARAM("aimin", "aimi", cm_stack->ai_min_period, CM_AI_MIN_PERIOD_DEFAULT)
	EEPROM_PARAM("ainit", "aini", cm_stack->ai_init, CM_AI_INIT_DEFAULT)
	EEPROM_PARAM("aitrans", "aitr", cm_stack->ai_trans, CM_AI_TRANS_DEFAULT)
	EEPROM_PARAM("aidev", "aidv", cm_stack->ai_period_deviation, CM_AI_PERIOD_DEVIATION_DEFAULT)
	EEPROM_PARAM("aitime", "aiti", cm_stack->ai_time, CM_AI_TIME_DEFAULT)
	EEPROM_PARAM("autinq", "ainq", cm_stack->autinq, CM_AUTINQ_DEFAULT)
	EEPROM_PARAM("rssid", "rsid", cm_stack->rssi_id, CM_RSSI_ID_DEFAULT)
	EEPROM_PARAM("rssith", "rsit", cm_stack->rssi_th, CM_RSSI_TH_DEFAULT)
	EEPROM_PARAM("cper", "cper", cm_stack->con_period, CM_CON_PERIOD_DEFAULT)
	EEPROM_PARAM("vtime", "vtim", cm_stack->min_vtime, CM_MIN_VTIME_DEFAULT)
	EEPROM_PARAM("lpfa", "lpfa", cm_stack->lpf_alpha, CM_LPF_ALPHA_DEFAULT)
	EEPROM_PARAM("lpfb", "lpfb", cm_stack->lpf_beta, CM_LPF_BETA_DEFAULT)
	EEPROM_PARAM("ptime", "ptmo", cm_stack->ptime, CM_PTIME_DEFAULT)
)

/**
 * \brief Compares two BT addresses
 *
 * Determines if the BT address 'lhs' is less or equal than the BT address 'rhs'
 *
 * \param lhs considered BT address
 * \param rhs BT address to compare to
 * 
 * \return
 *  - 1 if 'lhs' < 'rhs'
 *  - 0 if 'lhs' > 'rhs'
 *  - -1 if 'lhs' = 'rhs'
 */
signed char bt_addr_leq(bt_addr_t lhs, bt_addr_t rhs) {
   u_char i;
    for (i=BD_ADDR_LEN; i>0; i--) {
       if (lhs[i-1] < rhs[i-1]) return 1;
       if (lhs[i-1] > rhs[i-1]) return 0;
    }
    return -1;
}

/**
 * \brief Returns a random sleep time.
 * 
 * Returns a random sleep time (unsigned long) in [0, max_sleep].
 */
u_long _cm_get_rnd_sleep_time(u_long max_sleep) {
    return ((((max_sleep*rand())/RAND_MAX))/125)*125;
}

/**
 * \name Neighbor Order Implementation
 */
//@{
/**
 * \brief Defines the sorting criteria of the neighbor order
 * 
 * Compares two neighbor devices in the following way: if the absolute RSSI
 * difference of 'lhs' and 'rhs'
 * is greater than rssi_id (see #cm_stack_t), 'lhs' is greater than 'rhs' if the
 * RSSI value of 'lhs' is greater than the RSSI value of 'rhs'.
 * If the absolute RSSI difference is not greater than rssi_id, the neighbor
 * with the lower BT address is considered as the "better" neighbor.
 * 
 * \param lhs considered neighbor
 * \param rhs neighbor to compare to
 * 
 * \return
 *  - 1 if 'lhs' greater than 'rhs'
 *  - -1 if 'lhs' is less than 'rhs'
 */
signed char _cm_neighbor_cmp(void* lhs, void* rhs) {
	cm_neigh_t* l_neigh = (cm_neigh_t*)lhs;
	cm_neigh_t* r_neigh = (cm_neigh_t*)rhs;
    // check if rssi difference is big enough
    if (abs(l_neigh->rssi - r_neigh->rssi) <= cm_stack->rssi_id) {
        // if no, lhs is greater than rhs if its bd address is smaller
        // than the bd address of rhs
        if (bt_addr_leq(l_neigh->addr, r_neigh->addr)) return 1;
        else return -1;
    }
    // if the rssi difference is big enough, lhs is greater than rhs if
    // the rssi of lhs is greater than the rssi of rhs
    else if (l_neigh->rssi > r_neigh->rssi) return 1;
    else return -1;
}

/**
 * \brief Initializes an instance of a #cm_neighbor struct
 * 
 * Initializes the fields of a #cm_neighbor struct. This function is called
 * each time a new neighbor is added to the neighbor order using the
 * #srtd_list_add function.
 * 
 * \param elem pointer to the #cm_neighbor struct
 * \param args pointer to the neighbor's parameters
 * \param arg_len number parameters passed
 */
void _cm_neighbor_init(void* elem, void* args, u_char arg_len) {
	cm_neigh_t* neigh = (cm_neigh_t*)elem;
	struct bt_hci_inquiry_result* inqres =
		(struct bt_hci_inquiry_result*)args;
    // store the values needed
    memcpy(neigh->addr, inqres->bdaddr, BD_ADDR_LEN);
    neigh->rssi = inqres->rssi;
    neigh->dev_params.clock_offset = inqres->clock_offset;
    neigh->dev_params.page_scan_rep_mode = inqres->page_scan_rep_mode;
    // init remainder of neighbor
    neigh->better_com_neigh = NULL;
    neigh->con_handle = BT_HCI_HANDLE_INVALID;
    neigh->last_seen = 0;
    neigh->page_trials = 0;
    neigh->reduced = NULL;
}

/**
 * \brief Sets the fields of a #cm_neighbor struct
 * 
 * This function defines how the values of a 'neighbor' struct have to be set,
 * given some arguments. This function is called each time the parameters of
 * a neighbor in the neighbor order are updated using the #srtd_list_set
 * funtion.
 * 
 * \param elem pointer to the #cm_neighbor struct
 * \param args pointer to the neighbor's parameters
 * \param arg_len number of parameters passed
 */
void _cm_neighbor_set(void* elem, void* args, u_char arg_len) {
    // set current rssi value to value passed
	((cm_neigh_t*)elem)->rssi = *((short*)args);
}


/**
 * \brief Checks if the BT address passed equals the BT address of the neighbor
 * passed.
 * 
 * This funtion is needed by the sorted list to return the index of a specific
 * neighbor device.
 * 
 * \param elem pointer to the #cm_neighbor struct
 * \param args pointer to the BT address
 * \param arg_len number of parameters passed (1)
 * 
 * \return
 *  - 1 if args equals BT address of neighbor passed
 *  - 0 else
 */
u_char _cm_neighbor_is(void* elem, void* args, u_char arg_len) {
    return (BD_ADDR_CMP(((cm_neigh_t*)elem)->addr, *(bt_addr_t*)args));
}

/**
 * \brief Called if a device loss occurred.
 * 
 * This function is called each time a device loss is observed by the
 * #con_table_change_cb callback. The function evaluates new candidates, and
 * adds them to the connection establishment buffer cm_stack_t::con_buf.
 * 
 * \return 1 if the removal was successfull, zero else
 */
u_char _cm_neighbor_remove(short index) {
    u_char i;
    // if neighbor was not found on neighbor list, return
    if ((index < 0) || (index >= cm_stack->nr_neighbors)) return 0;
    // reset common better neighbor for all unconnected devices with
    // better common neighbor == neigh
    // reset reduced
    for (i=0; i<cm_stack->nr_neighbors; i++) {
        if (cm_stack->neighbors[i]->better_com_neigh ==
        		cm_stack->neighbors[index]) {
            // reset better common neighbor
            cm_stack->neighbors[i]->better_com_neigh = NULL;
        }
        if(cm_stack->neighbors[i]->reduced == 
           cm_stack->neighbors[index]){
            cm_stack->neighbors[i]->reduced = NULL;
        }
    }
    // remove neighbor from neighbor list
    return srtd_list_remove(cm_stack->order, index);
}
//@}

/**
 * \name Connection manager wait queues
 */
//@{
/**
 * \brief Removes a neighbor from the specified queue.
 * 
 * \param neigh the neighbor to remove
 * 
 * \return
 *  - 1 if neighbor was removed successfully
 *  - 0 else
 */
u_char _cm_queue_remove(cm_que_t* que, cm_neigh_t* neigh) {
	cm_neigh_t* current = que;
    while (current->next != NULL) {
        if (current->next == neigh) {
            current->next = neigh->next;
            neigh->next = NULL;
            return 1;
        }
        else current = current->next;
    }
    return 0;
}

/**
 * \brief Adds a neighbor to the beginning of the specified queue.
 * 
 * Note: if the queue already contains the neighbor passed, the neighbor
 * will be moved to the head of the wait queue.
 * 
 * \param neigh the neighbor to add
 */
void _cm_queue_add_first(cm_que_t* que, cm_neigh_t* neigh) {
	// try to remove the neighbor passed
	_cm_queue_remove(que, neigh);
	// add neighbor passed
    neigh->next = que->next;
    que->next = neigh;
}

/**
 * \brief Adds a neighbor to the end of the specified queue.
 * 
 * Note: if the queue already contains the neighbor passed, the neighbor
 * will not be added to the queue.
 * 
 * \param neigh the neighbor to add
 */
void _cm_queue_add_last(cm_que_t* que, cm_neigh_t* neigh) {
	cm_neigh_t* current = que;
    while (current->next != NULL) {
        // if neighbor is already in the buffer, stop
        if (current == neigh) return;
        current = current->next;
    }
    current->next = neigh;
    neigh->next = NULL;
}

/**
 * \brief Gets the first neighbor the specified queue contains.
 * 
 * Note: the neighbor is removed from the queue
 * 
 * \return First neighbor in queue
 */
cm_neigh_t* _cm_queue_get_first(cm_que_t* que) {
	// remove first neighbor from queue
	cm_neigh_t* first = que->next;
	que->next = first->next;
	// return first neighbor
    return first;
}

/**
 * \brief Determines if the queue passed is empty.
 * 
 * \return
 *  - 1 if wait queue is empty
 *  - 0 else
 */
u_char _cm_queue_is_empty(cm_que_t* que) {
    return (que->next == NULL);
}

/**
 * \name Inquiring
 */
//@{
/**
 * \brief The IIR filter function.
 * 
 * Updates the current RSSI value passed, given a new one.
 * 
 * \param curr_val Pointer to the current RSSI value
 * \param new_val Actually measured RSSI value
 * 
 * \return the resulting RSSI value is written to the current RSSI value passed
 */
void _cm_inq_filter_rssi(short* curr_val, short new_val) {
    *curr_val =
        (new_val*cm_stack->lpf_alpha + (*curr_val)*cm_stack->lpf_beta) /
        	(cm_stack->lpf_alpha + cm_stack->lpf_beta);
}

	
/** \brief Determines a new period for the inquiry thread
 */
u_long _cm_inq_get_ai_period(u_char nr_inqs) {
    if (nr_inqs <= cm_stack->ai_init) return cm_stack->ai_min_period;
    if (nr_inqs >= (cm_stack->ai_init + cm_stack->ai_trans))
        return cm_stack->ai_max_period;
    return ((cm_stack->ai_max_period - cm_stack->ai_min_period) /
    	cm_stack->ai_trans)*(nr_inqs - cm_stack->ai_init) + cm_stack->ai_min_period;
}

/**
 * \brief This function filters invalid devices from the inquiry result
 * passed and updates the neighbor order accordingly.
 * 
 * If an inquiry result is valid or not can be defined in #_cm_inqres_valid
 * 
 * \param inqres Pointer to the inquiry results
 * \param nr_devs Nr of devices the inquiry result contains
 */
void _cm_inq_order_update(struct bt_hci_inquiry_result* inqres, u_char nr_devs) {
    short idx;
    short new_idx;
    cm_neigh_t* neigh;
    u_char i;
    u_char j;
    // update neighbor list
    for (i=0; i<nr_devs; i++) {
    	// try to get index of neighbor
    	idx = srtd_list_index_of(cm_stack->order, inqres[i].bdaddr, 1);
    	new_idx = cm_stack->nr_neighbors;
    	// if neighbor is unknown, add it to the neighbor order
    	if (idx < 0) {
    		// set index of device to index of last element in the order (see below)
    		idx = cm_stack->nr_neighbors;
    		new_idx = srtd_list_add(cm_stack->order, &inqres[i], 1);
    	}
    	else {
    		neigh = cm_stack->neighbors[idx];
			// if no connection exists
			if (neigh->con_handle == BT_HCI_HANDLE_INVALID) {
				// filter rssi value
				_cm_inq_filter_rssi(&inqres[i].rssi, neigh->rssi);
				// if rssi difference is too small don't update rssi value
				if (abs(neigh->rssi - inqres[i].rssi) < cm_stack->rssi_th) {
					inqres[i].rssi = neigh->rssi;
    			}
    			// store new inqres values
    			neigh->dev_params.page_scan_rep_mode = inqres[i].page_scan_rep_mode;
    			neigh->dev_params.clock_offset = inqres[i].clock_offset;
    			new_idx = srtd_list_set(cm_stack->order, idx, &inqres[i].rssi, 1);
			}
            // reset last seen
            neigh->last_seen = 0;
    	}
    	
    	/** Move connected neighbors with index j (idx < j <= old_idx) to the send queue **/
    	if (new_idx < idx) {
    		for (j=new_idx; j<=idx; j++) {
    			if (cm_stack->neighbors[j]->con_handle != BT_HCI_HANDLE_INVALID) {
    				_cm_queue_add_first(&cm_stack->send_que, cm_stack->neighbors[j]);
    			}
    		}
    	}
    }
}

/**
 * \brief Checks whether a node has expiered and deletes it from the neighbor
 * table.
 * 
 * If a node has not been seen in the inquiry results for more than 
 * #CM_EXPIRATION inquiries, it will be deleted from the neighbor table.
 */
void _cm_check_expiration(void){
    u_char i;
    cm_neigh_t* neigh;
    for(i=0;i<cm_stack->nr_neighbors;i++){
        neigh = cm_stack->neighbors[i];
        if(neigh->con_handle == BT_HCI_HANDLE_INVALID){ // not connected?
            if(neigh->last_seen >= CM_EXPIRATION){
                _cm_neighbor_remove(i);
                INFO("neigh exp: " SADDR_FMT "\n", SADDR(neigh->addr));
            }
            else{
                neigh->last_seen++;
            }
        }
        else{
            neigh->last_seen = 0;
        }
    }
}
//@}


/**
 * \name Communication
 * 
 * These functions are used to create the packets needed by the XTC
 * 2-way handshake protocol.
 */
//@{
/**
 * \brief Broadcasts (i.e. forwards) the packet passed to all connected
 * neighbor devices, except the con handle passed.
 * Note: to do a broadcast, pass BT_HCI_HANDLE_INVALID
 */
void _cm_com_forward_broadcast(u_char* data, u_short len, bt_hci_con_handle_t con_handle) {
	u_char i;
	// set LED's
    btn_led_set(0);
    btn_led_set(1);
	for (i=0; i<cm_stack->nr_neighbors; i++) {
		if ((cm_stack->neighbors[i]->con_handle != BT_HCI_HANDLE_INVALID) &&
			(cm_stack->neighbors[i]->con_handle != con_handle)) {
			// send the packet
			l2cap_cl_send(data,
							len,
							cm_stack->neighbors[i]->con_handle,
							cm_stack->psm);
			}
	}
	// clear LED's
    btn_led_clear(0);
    btn_led_clear(1);
}
/**
 * \brief Creates a packet out of the neighbor order. 
 * 
 * Packet format (payload of acl_pkt):
 \verbatim ---------------------------------------------------------------
 | type | RSSI | nr. neighbors | BT Addr 1  | BT Addr 2   | ... |
 ---------------------------------------------------------------
 .  1      1           1         BD_ADDR_LEN  BD_ADDR_LEN \endverbatim
\verbatim ------------------------------------------------------------------------------------
 | type | RSSI | nr. neighbors | short addr 1  | RSSI 1  | short addr 2 | RSSI 2 | ...
 -------------------------------------------------------------------------------------
 .  1      1           1               2            1 \endverbatim
 *  - type: #CM_PKT_ORDER
 *  - Sender: BT address of the device this order belongs to
 *  - RSSI: RSSI value of the link, measured by the sender of this order
 *  - nr. neighbors: The number of neighbors this order contains
 *  - BT Addr i: BT address of the i-th neighbor
 * 
 * \param pkt pointer to the ACL packet
 *
 * \return size of the created packet.
 */
u_short _cm_com_create_order_pkt(u_char* data_buf, u_char type, cm_neigh_t* neigh) {
    u_char i;
    
    // set CM type of order packet
    *data_buf++ = type;
    // write rssi value to order
    *data_buf++ = neigh->rssi;
    // write nr of neighbors
    *data_buf++ = cm_stack->nr_neighbors;
    // fill the rest of the packet with the bt-addresses and the rssi values
    // of the neighbors (descending order)
    for (i=0; i<cm_stack->nr_neighbors; i++) {
    	// write the bt address of the i-th neighbor
    	memcpy(data_buf, cm_stack->neighbors[i]->addr, 2);
    	data_buf += 2;
        *data_buf++ = cm_stack->neighbors[i]->rssi;
    }
    // return pkt size
    return 3 + cm_stack->nr_neighbors*3;
}


/**
 * \brief Creates a 'device lost' packet.
 * Packet format (payload of acl_pkt):
 \verbatim ---------------------
 | type | BT addr     |
 ---------------------
 .  1     BD_ADDR_LEN\endverbatim
 *  - type: #CM_PKT_DEV_LOSS
 *  - BT addr: The BT address of the lost device
 * 
 * \param acl_stack Pointer to the ACL COM Stack
 * \param pkt Pointer to the ACL packet
 * \param neighbor Pointer to the lost neighbor
 * 
 * \return size of the created packet.
 */
u_short _cm_com_create_dev_lost_pkt(u_char* data_buf, cm_neigh_t* neighbor) {
    
    // set CM type of packet
    *data_buf++ = CM_PKT_DEV_LOSS;
    // write address of lost device to the packet
    memcpy(data_buf, neighbor->addr, BD_ADDR_LEN);
    return BD_ADDR_LEN + 1;
}
//@}



/**
 * \name XTC Algorithm
 */
//@{
/**
 * \brief Processes an incoming order packet, and decides if a connection
 * to the sending device is desired or not.
 * 
 * This is the implementation of the XTC link selection procedure. If a
 * a connection should be dropped, the corresponding better common neighbor
 * is determined, and the pointer to the better common neighbor
 * #cm_neighbor::better_com_neigh is set.
 * 
 * \param order_pkt pointer to the start of the received order packet
 * \param sender pointer to the neighbor (obtained from neighbor list) the
 * order passed has been received from 
 * 
 * \return
 *  - 0 if a connection to the device is not desired
 *  - 1 if a connection to the device is desired
 */
short _cm_xtc_process_order_pkt_old(u_char* remote_order, cm_neigh_t* sender) {
	u_char i,j;
	u_char remote_order_size = *remote_order++;
	// for debugging purposes
	if (cm_stack->xtc == CM_XTC_OFF) return 1;
	else {
	    // check for each entry in the order received if it is a better
	    // common neighbor (i.e. if the entry appears in our order before
	    // the adress of the sending device)
	    for (i=0; i<remote_order_size; i++) {
	    	// if our address appears, accept connection
	        if (BD_SADDR_CMP(cm_stack->my_addr, remote_order)) {
	        	sender->better_com_neigh = NULL;
	        	DEBUG("con ack!\n");
	        	return 1;
	        }
	        // check if entry appears in our order before address of the
	        // sending device
	        for (j=0; cm_stack->neighbors[j] != sender; j++) {
	            // if yes, stop
	            if (BD_SADDR_CMP(cm_stack->neighbors[j]->addr, remote_order)) {
	            	sender->better_com_neigh = cm_stack->neighbors[j];
	            	DEBUG("con nack! Better neigh: " SADDR_FMT "\n",
	            		SADDR(sender->better_com_neigh->addr));
	            	return 0;
	            }
	        }
	        remote_order += 3;
	    }
	    ERROR("processing order packet!\n");
	    return 0;
	}
}

short _cm_xtc_process_order_pkt(u_char* remote_order, cm_neigh_t* sender) {
    u_char i,j;
    u_char i_me, j_sender;
    u_char remote_order_size = *remote_order++;
    
    // for debugging purposes
    if (cm_stack->xtc == CM_XTC_OFF) return 1;
  
    j_sender = 0xff;
    // find position of sender in local order
    for(j=0; j< cm_stack->nr_neighbors; j++){
        if(cm_stack->neighbors[j] == sender){
            j_sender = j;
            break;
        }
    }

    i_me = 0xff;
    sender->better_com_neigh = NULL;
    // iterate through remote order
    for (i=0; i<remote_order_size; i++) {
        // find my possition in remote order
        if (BD_SADDR_CMP(cm_stack->my_addr, remote_order)){
            i_me = i;
            continue;
        }
        // iterate through local order
        for (j=0; j < cm_stack->nr_neighbors; j++){
            if(BD_SADDR_CMP(cm_stack->neighbors[j]->addr, remote_order)){
                // check for better common neighbor
                if(i < i_me && j < j_sender && 
                        sender->better_com_neigh == NULL){
                    sender->better_com_neigh = cm_stack->neighbors[j];
                }
                // do reduction               
            }
        } 
        remote_order += 3;
    }
    if(sender->better_com_neigh == NULL){
        DEBUG("con ack!\n");
    }
    else{
        DEBUG("con nack! Better neigh: " SADDR_FMT "\n",
            SADDR(sender->better_com_neigh->addr));                    
    }
    return (sender->better_com_neigh == NULL);    
}


/**
 * \brief Evaluates new candidates.
 * 
 * This function determines if there are neighbors in the neighbor order to
 * which a connection should be established. Candidates found are added to
 * the connection establishment buffer (see #_cm_stack::con_buf).
 * 
 * \return Index of the next candidate.
 */
void _cm_xtc_get_new_candidates(void) {
    u_char i,j;
    for (i=0; i<cm_stack->nr_neighbors; i++) {
        // if there is no connection to the neighbor
        if (cm_stack->neighbors[i]->con_handle == BT_HCI_HANDLE_INVALID) {
        	// if there is no better common neighbor return i
        	if (cm_stack->neighbors[i]->better_com_neigh == NULL) {
        		// add neighbor to the connection establishment buffer
        		_cm_queue_add_last(&cm_stack->con_buf, cm_stack->neighbors[i]);
        	}
        	else {
	            // else, check if i-th neighbor appears before its
	            // better common neighbor
	            for (j=i; j<cm_stack->nr_neighbors; j++) {
	                if (cm_stack->neighbors[i]->better_com_neigh ==
	                			cm_stack->neighbors[j]) {
	                	// add neighbor to the connection establishment buffer
	                	_cm_queue_add_last(&cm_stack->con_buf, cm_stack->neighbors[i]);
	                	break;
	                }
	            }
        	}
        }
        // if a connection to the neighbor exists, re-send order
    }
}
//@}


/**
 * \brief Signals the application layer that a new reliable connection has been
 * established.
 * 
 * The application layer is signaled by calling the callback registered using
 * the #con_mgr_register_rel_con_change_cb function.
 * 
 * \param neighbor the neighbor device to which a reliable connection has been
 * established.
 */
void _cm_rel_con_add(cm_neigh_t* neigh, bt_hci_con_handle_t handle) {
	u_char role;
	if (neigh->con_handle == BT_HCI_HANDLE_INVALID) {
		// set con_handle
		neigh->con_handle = handle;
	    // reset blocking node
	    neigh->better_com_neigh = NULL;
	    // set link supervision timeout
	    bt_hci_write_link_supervision_timeout(cm_stack->bt_stack,
	    	BT_HCI_SYNC,
	    	neigh->con_handle,
	    	CM_LINK_TIMEOUT);
	    // get role of this device
	    role =
	    	bt_hci_local_role_discovery(cm_stack->bt_stack, neigh->con_handle);
	    // inform higher layer
	    if (role == BT_HCI_MY_ROLE_MASTER)
	        con_mgr_stack.con_table_cb(BT_HCI_CONNECTION,
	        	BT_HCI_CONNECTION_ACTIVE,
	        	neigh->con_handle,
	        	con_mgr_stack.con_table_cb_arg);
	    else
	        con_mgr_stack.con_table_cb(BT_HCI_CONNECTION,
	        							BT_HCI_CONNECTION_PASSIVE,
	        							neigh->con_handle,
	        							con_mgr_stack.con_table_cb_arg);
	   	INFO("new rel con! handle: %d\n", neigh->con_handle);
	   	DEBUG_STR("%s\n",
	   		_cm_dbg_rel_cons_to_string(cm_stack->neighbors, cm_stack->nr_neighbors));
	}
}


/* Here comes the code for handling changes in the connection table.
 */
void _con_table_change_cb(u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg)
{
    cm_neigh_t* neighbor = NULL;
    u_char i;
    short index;
    u_short data_len;
    bt_addr_t dev_addr;
    
    // init
    neighbor = NULL;
    
    // lock neighbor list
    NutMutexLock(&cm_stack->data_mutex);
    // swich on red led
    btn_led_set(1);
    switch (type) {
    case BT_HCI_DISCONNECTION:
    	INFO("discon event! handle: %d, detail: %d\n", con_handle, detail);
        // check if the disconnecting device is a valid, connected neighbor device
        for (i=0; i<cm_stack->nr_neighbors; i++) {
            if (cm_stack->neighbors[i]->con_handle == con_handle) {
                neighbor = cm_stack->neighbors[i];
                index = i;
                break;
            }
        }
        
        // if no, we're done
        if (neighbor == NULL) break;
        // else, set con handle to invalid
        neighbor->con_handle = BT_HCI_HANDLE_INVALID;
    	// signal higher layer
    	con_mgr_stack.con_table_cb(BT_HCI_DISCONNECTION,
    							detail,
    							con_handle,
    							con_mgr_stack.con_table_cb_arg);
        INFO("rel con removed! dev: " SADDR_FMT ", hdl: %d, detail: 0x%.2x\n",
        	SADDR(neighbor->addr), con_handle, detail);
        // if connection loss
        if (detail == BT_HCI_DISCON_LINK_LOST) {
			// remove device from neighbor list
			_cm_neighbor_remove(index);
			// broadcast link loss packet
			data_len = _cm_com_create_dev_lost_pkt(cm_stack->data_buf, neighbor);
			_cm_com_forward_broadcast(cm_stack->data_buf, data_len, BT_HCI_HANDLE_INVALID);
            // start con buf
            NutEventPostAsync(&cm_stack->con_mgr_start);
        }
        break;
    case BT_HCI_CONNECTION:
    	// debug output
    	bt_hci_get_remote_bt_addr(cm_stack->bt_stack, con_handle, dev_addr);
        DEBUG("new con: " SADDR_FMT ", index: %d, hdl: %d, detail: 0x%.2x\n",
        	SADDR(dev_addr),
        	srtd_list_index_of(cm_stack->order, dev_addr, 1),
        	con_handle,
        	detail);
        break;
    default:;
    }
    // turn off red led
    btn_led_clear(1);
    // unlock the neighbor list
    NutMutexUnlock(&cm_stack->data_mutex);
}


/**
 * \name Threads
 */
//@{
/**
 * \brief Inquiry Thread
 * 
 * This thread is responsible for doing regular inquiries and updating the
 * neighbor order. The frequency of the inquiry thread can be controlled.
 */
THREAD(CM_INQ, arg) {
    u_long rnd_sleep;
//    u_short data_len;
//	u_char i;
//	long result;

    // init
    NutThreadSetPriority(95);
       
    while(1) {
        // if autinq is turned off, we have to wait
        if (cm_stack->autinq == CM_AUTINQ_OFF) {
	        NutSleep(1000);
            continue;
        }

        // sleep
        rnd_sleep =
        	cm_stack->ai_period_deviation + _cm_inq_get_ai_period(cm_stack->nr_inqs);
        rnd_sleep -= 2*_cm_get_rnd_sleep_time(cm_stack->ai_period_deviation);
        if (rnd_sleep > 100) NutSleep(rnd_sleep);

        // if inq has been disabled during sleep
        if(cm_stack->autinq == CM_AUTINQ_OFF){
            continue;
        }

        // check if device is paging
        NutMutexLock(&cm_stack->bt_module);
//        if (NutMutexTrylock(&cm_stack->bt_module)) {
//        	// if yes, wait until paging is done
//        	NutMutexLock(&cm_stack->bt_module);
//	        // sleep for that we are visible for remote devices
//			NutSleep(cm_stack->min_vtime);
//        }
        
        /*** start a new inquiry ***/
        // start watchdog (reset if inq takes longer than 10x it should)
        _cm_watchdog_start(cm_stack->ai_time * 1280 * 10);
        // switch on green led
        btn_led_set(3);
        // do inquiry
        cm_stack->nr_inq_devs = (u_char)bt_hci_inquiry(cm_stack->bt_stack,
        	BT_HCI_SYNC,
        	(u_char)cm_stack->ai_time,
        	CM_MAX_INQ_DEVS,
        	cm_stack->inqres);
        // turn off green led
        btn_led_clear(3);
        _cm_watchdog_stop();
        cm_stack->nr_inqs++;
        
        // dump inqres for debugging
		DEBUG_STR("inqres:%s\n", _cm_dbg_inqres_to_str());
		
        // update neighbor list
    	NutMutexLock(&cm_stack->data_mutex);
        _cm_inq_order_update(cm_stack->inqres, cm_stack->nr_inq_devs);
        _cm_check_expiration();
        
        // dump neighbor order if debugging
		DEBUG_STR("order:\n%s\n", _cm_dbg_order_to_str());
		
		// dump send queue
		DEBUG_STR("send que: %s\n", _cm_dbg_que_to_str(&cm_stack->send_que));

        // broadcast order packet
//        for (i=0; i<cm_stack->nr_neighbors; i++) {
//        	if (cm_stack->neighbors[i]->con_handle != BT_HCI_HANDLE_INVALID) {
//		        data_len = _cm_com_create_order_pkt(cm_stack->data_buf,
//		        									CM_PKT_CON_RQST,
//		        									cm_stack->neighbors[i]);
//		        result = l2cap_cl_send(cm_stack->data_buf,
//		        						data_len,
//		        						cm_stack->neighbors[i]->con_handle,
//		        						cm_stack->psm);
//		        if (result) ERROR("inq: sending con rqst pkt (0x%.2x)\n",
//		        	-result);
//        	}
//        }
        // unlock mutexes
        NutMutexUnlock(&cm_stack->data_mutex);
        NutMutexUnlock(&cm_stack->bt_module);
        // sleep for that we are visible to other devices
        NutSleep(cm_stack->min_vtime);
        // wake up connection establishment thread
        NutEventPostAsync(&cm_stack->con_mgr_start);
    }
}

/**
 * \brief Connection Establishment Thread
 * 
 * This thread establishes a connection to each neighbor in the connection
 * establishment buffer, and sends the order packet to it. After each
 * connection establishment, the send buffer is emptied.
 */
THREAD(CON_MGR, arg) {
    long result;
    long con_hdl;
    u_long rnd_sleep;
    cm_neigh_t* candidate;
    cm_neigh_t* neigh;
    u_short data_len;
    
    // init
    NutThreadSetPriority(90);
    
    while (1) {
        NutEventWait(&cm_stack->con_mgr_start, NUT_WAIT_INFINITE);
        // get new candidates
        _cm_xtc_get_new_candidates();
        candidate = NULL;
        
        // lock bt module
        NutMutexLock(&cm_stack->bt_module);

		/** First, process the con establishment queue **/
        while(!_cm_queue_is_empty(&cm_stack->con_buf)) {
            // if autinq is turned off, we have to wait
            if (cm_stack->autinq == CM_AUTINQ_OFF) {
                NutSleep(1000);
                continue;
            }            
            // lock data mutex
            NutMutexLock(&cm_stack->data_mutex);
            // get next candidate
            // dump con buf if debugging
            DEBUG_STR("cm: con buf: %s\n", _cm_dbg_que_to_str(&cm_stack->con_buf));

            candidate = _cm_queue_get_first(&cm_stack->con_buf);
            NutMutexUnlock(&cm_stack->data_mutex);
            // start watchdog (reset if page takes longer than 10x it should)
            _cm_watchdog_start(cm_stack->ptime * 625 * 10);
            // set yellow led
            btn_led_set(2);
            // establish connection
            result = bt_hci_create_connection(cm_stack->bt_stack,
            	BT_HCI_SYNC,
            	candidate->addr,
                BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DH1 | BT_HCI_PACKET_TYPE_DM3,
                candidate->dev_params.page_scan_rep_mode,
                candidate->dev_params.clock_offset,
                BT_HCI_ROLE_SWITCH_CHANGE);
            // clear yellow led
            btn_led_clear(2);
            _cm_watchdog_stop();
                        
	        /*
	         * send order if:
	         * - a connection has been created
	         * - a connection already exists,
	         * i.e. if the bt-stack has a connection entry of the candidate device
	         */
			con_hdl = bt_hci_get_con_handle(cm_stack->bt_stack, candidate->addr);
	        if (con_hdl >= 0) {
	            data_len = _cm_com_create_order_pkt(cm_stack->data_buf,
	            									CM_PKT_CON_RQST,
	            									candidate);
		        result = l2cap_cl_send(cm_stack->data_buf,
		        						data_len,
		        						con_hdl,
		        						cm_stack->psm);
		        // if error, disconnect
		        if (result) {
		        	ERROR("cm: sending con rqst pkt (0x%.2x)\n", -result);
	                bt_hci_disconnect(cm_stack->bt_stack,
	                	BT_HCI_SYNC,
	                	con_hdl,
	                	BT_HCI_DISCONNECT_USER_ENDED);
		        }
		        // else, reset nr of page trials
		        else {
		        	DEBUG("cm: con rqst pkt sent to " SADDR_FMT ".\n", SADDR(candidate->addr));
		        	candidate->page_trials = 0;
		        }
	        }
            // if there's no connection to the candidate, re-add it to the con buf if max
            // nr of page trials has not been reached yet
	        else {
            	WARNING("cm: create con! Error code: 0x%.2x\n", -result);
            	// increment page trials
            	candidate->page_trials++;
            	// re-add candidate if max nr of page trials has not been reached yet
                if(candidate->page_trials < CM_MAX_CON_RETRIES){
                    _cm_queue_add_last(&cm_stack->con_buf, candidate);
                }
                // else, kick candidate out of the neighbor order
                else {
                	INFO("cm: removing neigh from order...\n");
                	_cm_neighbor_remove(srtd_list_index_of(cm_stack->order, candidate->addr, 1));
                }
	        }
        
            // if there is a next candidate, sleep for that this device is visible
            if (!_cm_queue_is_empty(&cm_stack->con_buf)) {
	            rnd_sleep = _cm_get_rnd_sleep_time(cm_stack->con_period);
	            if (rnd_sleep > 100) NutSleep(rnd_sleep);
            }
        }
        
        /** Next, empty the send buffer **/
        DEBUG_STR("cm: send que: %s\n", _cm_dbg_que_to_str(&cm_stack->send_que));
        
        while(!_cm_queue_is_empty(&cm_stack->send_que)) {
        	// get next neighbor
        	neigh = _cm_queue_get_first(&cm_stack->send_que);
        	// send order
            data_len = _cm_com_create_order_pkt(cm_stack->data_buf,
            									CM_PKT_CON_RQST,
            									neigh);
	        result = l2cap_cl_send(cm_stack->data_buf,
	        						data_len,
	        						neigh->con_handle,
	        						cm_stack->psm);
	        // if error, disconnect
	        if (result) {
	        	ERROR("cm: sending con rqst to: " ADDR_FMT " %li: (0x%.2x)\n",
	        		  neigh->addr, -result);
	        }
	        else {
	        	DEBUG("cm: con rqst sent to: " SADDR_FMT ".\n", SADDR(neigh->addr));
	        }
        }
        
        // let inquiry thread continue
        NutMutexUnlock(&cm_stack->bt_module);
        NutThreadYield();
    }
}

THREAD(CON_EVENT_BUF, arg)
{
	NutThreadSetPriority(80);
	while (1) {
		con_event_listen();
	}
}

/**
 * \brief callback handling incoming packets
 * 
 * Waits for incoming packets and processes them. Thus, XTC link selection is
 * done by this callback function.
 */
bt_acl_pkt_buf* _cm_l2cap_cl_cb(bt_acl_pkt_buf* pkt_buf,
								u_char* data,
								u_short data_len,
								u_short service_nr,
								void* cb_arg)
{
	u_char i;
    short idx;
    short new_idx;
    short con_accepted;
    long result;
    bt_hci_con_handle_t con_handle;
    cm_neigh_t* sender;
    struct bt_hci_inquiry_result inqres;
    
    // lock neighbor list
    NutMutexLock(&cm_stack->data_mutex);
    btn_led_set(0);
    btn_led_set(3);
    // get con handle of sending device
    con_handle = bt_acl_get_con_handle(pkt_buf->pkt);
    // get addr of the sending device
    result = bt_hci_get_remote_bt_addr(cm_stack->bt_stack, con_handle, inqres.bdaddr);
    // return if the handle is not valid
    if (result) {
    	WARNING("rcvd pkt with invalid hdl: %d, res: %li\n", con_handle, result);
    	NutMutexUnlock(&cm_stack->data_mutex);
    	return pkt_buf;
    }
    // dump received packet if debugging
    INFO("pkt rcvd from dev " SADDR_FMT "\n", SADDR(inqres.bdaddr));
   	DEBUG_STR("%s\n", dbg_str_to_hex_str(_cm_dbg_buf, data, data_len));
    // switch packet type
    switch (data[0]) {
    //if packet received is a 'con rqst' packet or a 'con rqst reply' pkt
    case CM_PKT_CON_RQST:
    	// get pointer to the sending device
    	idx = srtd_list_index_of(cm_stack->order, inqres.bdaddr, 1);
    	
    	/*** update neighbor order ***/
    	// add device to neighbor list if it is not yet known
    	if (idx < 0) {
			inqres.rssi = data[1];
    		inqres.clock_offset = 0;
    		inqres.page_scan_period_mode = 0;
			inqres.page_scan_rep_mode = 0;
			// if neighbor list is full, remove last entry
			if (cm_stack->nr_neighbors == CM_MAX_NEIGHBORS) {
				srtd_list_remove(cm_stack->order, CM_MAX_NEIGHBORS-1);
			}
			// set index of device to index of last element in the order (see below)
			idx = cm_stack->nr_neighbors;
			// add device to neighbor order
			new_idx = srtd_list_add(cm_stack->order, &inqres, 1);
    	}
    	else {
    		// make link symmetric, i.e. adopt the link quality measure
    		// received
    		inqres.rssi = (short)data[1];
			new_idx = srtd_list_set(cm_stack->order, idx, &inqres.rssi, 1);
    	}
    	// add connected devices with idex i (new_idx < j <= idx) to send queue
    	if (new_idx < idx) {
    		for (i=new_idx; i<=idx; i++) {
    			if (cm_stack->neighbors[i]->con_handle != BT_HCI_HANDLE_INVALID)
    				_cm_queue_add_first(&cm_stack->send_que, cm_stack->neighbors[i]);
    		}
    	}
    	// dump send queue
    	DEBUG_STR("send que: %s\n", _cm_dbg_que_to_str(&cm_stack->send_que));
    	
    	/*** process order pkt ***/
    	sender = cm_stack->neighbors[new_idx];
    	con_accepted = _cm_xtc_process_order_pkt(&data[2], sender);
        // remove sending device from con buf
//        _cm_queue_remove(sender);
        // try to send back our order. There's no need for sending our
        // order if the link is accepted but already reliable, thus we
        // don't send it in that case
        if (!(con_accepted && (sender->con_handle != BT_HCI_HANDLE_INVALID))) {
            // try to send the pkt
        	data_len = _cm_com_create_order_pkt(cm_stack->data_buf,
        										CM_PKT_CON_RQST_REPLY,
        										sender);
            result = l2cap_cl_send(cm_stack->data_buf,
            						data_len,
            						con_handle, 
            						cm_stack->psm);
            if (result) {
            	// if we could not send the packet, disconnect
                ERROR("sending con rqst reply (0x%.2x)\n\n", (-result));
                // disconnect & return
                bt_hci_disconnect(cm_stack->bt_stack,
                	BT_HCI_SYNC,
                	con_handle,
                	BT_HCI_DISCONNECT_USER_ENDED);
            }
            // if we accepted the connection signal higher layer
            // (if necessary)
            else if (con_accepted) _cm_rel_con_add(sender, con_handle);
        }
        // start con_mgr (since we may have modified the neighbor order)
        NutEventPostAsync(&cm_stack->con_mgr_start);
        break;
    case CM_PKT_CON_RQST_REPLY:
    	// get the index of the sending device
    	idx = srtd_list_index_of(cm_stack->order, inqres.bdaddr, 1);
    	// if device is not yet known, an error occured
    	if (idx < 0) {
    		ERROR("dev unknown!\n\n");
    		break;
    	}
    	// store pointer to neighbor.
    	// Note: this is necessary, since the index of the neighbor may
    	// have changed after processing the received order packet
    	sender = cm_stack->neighbors[idx];
    	// process order pkt
    	con_accepted = _cm_xtc_process_order_pkt(&data[2], sender);
        // remove neighbor from con buf
//        _cm_queue_remove(sender);
        // if we accepted the connection set link state to reliable con
        if (con_accepted) _cm_rel_con_add(sender, con_handle);
       	// if we don't accept the connection we have to disconnect
       	else  {
       		// disconnect
            bt_hci_disconnect(cm_stack->bt_stack,
            	BT_HCI_SYNC,
            	con_handle,
            	BT_HCI_DISCONNECT_USER_ENDED);
       	}
    	break;
    case CM_PKT_DEV_LOSS:
        // try to get index of lost device
        idx = srtd_list_index_of(cm_stack->order, &data[1], 1);
        // if device is a neighbor of this node
        if (idx >= 0) {
            // if we do not have a reliable connection to it
            if (cm_stack->neighbors[idx]->con_handle == BT_HCI_HANDLE_INVALID) {
                // remove neighbor from neighbor list
                // TODO: just penalty the link would be much better
                _cm_neighbor_remove(idx);
            	// forward the packet to all connected neighbors
            	_cm_com_forward_broadcast(data, data_len, con_handle);
            }
        }
        break;            
    default:
        WARNING("unknown CM packet type %d\n\n", data[0]);
    }
    // clear LED's
    btn_led_clear(2);
    btn_led_clear(3);  
    // unlock neighbor list
    NutMutexUnlock(&cm_stack->data_mutex);
    return pkt_buf;
}



unsigned int _RSHash(u_char *str, unsigned int len)
{

    unsigned long int b = 378551;
    unsigned long int a = 63689;
    unsigned int hash = 0;
    unsigned int i = 0;

    for (i = 0; i < len; str++, i++) {
        hash = hash * a + (*str);
        a = a * b;
    }

    return (hash & 0x7FFFFFFF);

}


void cm_xtc_inq_enable(void) {
    cm_stack->autinq = CM_AUTINQ_ON;
    INFO("aut. inq. on.\n");
}

void cm_xtc_inq_disable(void) {
	cm_stack->autinq = CM_AUTINQ_OFF;
    INFO("aut. inq. off.\n");
}

void cm_xtc_register_cmds(void)
{
   CM_DEBUG_REG_CMDS(); 
}

short cm_xtc_fill_con_info(u_char* args, u_char* param){
    u_char i;
    u_char max_nr_neighs;
    u_char nr_neighs=0;
    u_char role;
    
    NutMutexLock(&cm_stack->data_mutex);
    // make at most CIP_MAX_ENTRIES
    if (cm_stack->nr_neighbors > CIP_MAX_ENTRIES)
        max_nr_neighs = CIP_MAX_ENTRIES;
    else max_nr_neighs = cm_stack->nr_neighbors;
    
    // write nr of entries to first byte later
    u_char* p_nr_neighs = args++;
    
    // for each neighbor copy bd addr, connection state and RSSI.
    // First, write connected neighbors
    for (i=0; i<cm_stack->nr_neighbors; i++) {
        if (cm_stack->neighbors[i]->con_handle != BT_HCI_HANDLE_INVALID) {
            nr_neighs++;
            // copy bd addr (only the 2 lowest bytes)
            memcpy(args, cm_stack->neighbors[i]->addr, 2);
            args += 2;
            // get role of this device
            role = bt_hci_local_role_discovery(cm_stack->bt_stack,
            	cm_stack->neighbors[i]->con_handle);
            // write role of this device to the packet
            switch (role) {
                case BT_HCI_MY_ROLE_MASTER:
                    *args++ = CIP_NEIGH_IS_MY_SLAVE;
                    break;
                case BT_HCI_MY_ROLE_SLAVE:
                    *args++ = CIP_NEIGH_IS_MY_MASTER;
                    break;
                default:
                    // error occured
                    WARNING("fill con info. Handle: %d, role:\n",
                        cm_stack->neighbors[i]->con_handle, role);
                    *args++ = CIP_NEIGH_IS_MY_SLAVE;
            }
            // last, make an entry for the rssi
            *args++ = (signed char)cm_stack->neighbors[i]->rssi;
        }
    }
    if(*param){
        // Now, make entries for unconnected neighbors
        for (i=0; i<cm_stack->nr_neighbors; i++) {
            if (cm_stack->neighbors[i]->con_handle == BT_HCI_HANDLE_INVALID) {
                if (nr_neighs == max_nr_neighs) break;
                else nr_neighs++;
                // copy bd addr
                memcpy(args, cm_stack->neighbors[i]->addr, 2);
                args += 2;
                // write connection state
                *args++ = CIP_NEIGH_UNCON;
                // last, make an entry for the rssi
                *args++ = (signed char)cm_stack->neighbors[i]->rssi;
            }
        }
    }
    *p_nr_neighs = nr_neighs;
    NutMutexUnlock(&cm_stack->data_mutex);
    return (nr_neighs*4 + 1);
}

u_char cm_xtc_get_rel_cons(bt_hci_con_handle_t *rel_cons)
{
    u_char i;
    u_char n = 0;
    for (i=0; i<cm_stack->nr_neighbors; i++) {
        if (cm_stack->neighbors[i]->con_handle != BT_HCI_HANDLE_INVALID) {
            rel_cons[n] = cm_stack->neighbors[i]->con_handle;
            n++;
        }
    }
    return n;
}

char* cm_xtc_get_info(void){
    return "XTC";
}

void cm_xtc_init(struct btstack *bt_stack,
					bt_psm_t* psmux,
					u_short cm_psm,
					HCI_CON_TABLE_CB_REGISTRATION,
					u_long cod)
{
    long retval;
    
    //dyn alloc cm stack
    cm_stack = NutHeapAllocClear(sizeof(cm_stack_t));
    cm_stack->bt_stack = bt_stack;
    cm_stack->psmux = psmux;
    cm_stack->psm = cm_psm;
    cm_stack->cod = cod;
       
	// init con event buffer
    con_event_buffer_init(bt_stack, con_table_cb_reg);

    // init btnet adapter
    btnet_adapter_init(bt_stack, psmux, con_event_buffer_register_con_table_cb);
    
    // register con table change callback at btnet adapter   
    btnet_register_con_table_cb(bt_stack, _con_table_change_cb, NULL);

	// init eeprom cmds if desired
#ifdef USE_EEPROM_CMDS
    // init eeprom cmds
    // TODO: remove at least init function (not really necessary)
    eeprom_cmds_init();
	// register eeprom cmds
	eeprom_cmds_register_cmds();
#endif

    // init XTC parameters
	PARAMS_INIT();
    
    // allocate memory for inquiry results
    cm_stack->inqres =
        NutHeapAllocClear(CM_MAX_INQ_DEVS*sizeof(struct bt_hci_inquiry_result));
    // init neighbor order
    cm_stack->order =
    	srtd_list_init(&cm_stack->nr_neighbors, CM_MAX_NEIGHBORS, sizeof(cm_neigh_t));
    cm_stack->neighbors = (cm_neigh_t**)cm_stack->order->elems;
    // register callbacks of sorted list
    srtd_list_register_cbs(cm_stack->order, _cm_neighbor_cmp,
        _cm_neighbor_init, _cm_neighbor_set, _cm_neighbor_is);

    // set/get parameters of bt module
    // get bt-address of this device
    bt_hci_get_local_bt_addr(cm_stack->bt_stack, cm_stack->my_addr);
    // write link policy
    retval = bt_hci_write_default_link_policy_settings(cm_stack->bt_stack,
        BT_HCI_SYNC, BT_HCI_LINK_POLICY_ROLE_SWITCH | BT_HCI_LINK_POLICY_ALL_DISABLED);
    // write local COD
    bt_hci_write_local_cod(cm_stack->bt_stack, BT_HCI_SYNC, cod);
    // inquiry filter on device class
	bt_hci_set_event_filter(cm_stack->bt_stack, BT_HCI_SYNC, 0x01, 0x01, cod, CM_COD_MASK);
	// only allow connections from devices of class CM_COD_MIN
	bt_hci_set_event_filter(cm_stack->bt_stack, BT_HCI_SYNC, 0x02, 0x01, cod, CM_COD_MASK, 0x01);
    // set page timeout
    bt_hci_write_page_timeout(cm_stack->bt_stack, BT_HCI_SYNC, cm_stack->ptime);

    // set random seed
    srand(_RSHash(cm_stack->my_addr, BD_ADDR_LEN));
    
    // init mutexes
    NutMutexInit(&cm_stack->data_mutex);
    NutMutexInit(&cm_stack->bt_module);
    
    // start heartbeat
    btn_led_heartbeat(CM_LED_HB_PAUSE, 1, CM_LED_HB_DURATION);
	
	// register connection manager at l2cap cl layer
	retval =
		bt_psm_service_register(cm_stack->psmux, cm_psm, _cm_l2cap_cl_cb, NULL);
	if (retval < 0) {
		ERROR("registering data cb (%li)!\n", retval);
		return;
	}
	
	// buffer setup: create own buffers
	cm_stack->buf_que = bt_acl_pkt_queue_create(bt_stack, 6);
	retval = bt_psm_service_set_buffers(cm_stack->psmux, retval, &cm_stack->buf_que);
	if (retval) {
		ERROR("buffer setup (%li)!\n", retval);
		return;
	}
	
	// initialize con mgr interface
	con_mgr_stack.cm_fill_con_info = cm_xtc_fill_con_info;
	con_mgr_stack.cm_inq_disable = cm_xtc_inq_disable;
	con_mgr_stack.cm_inq_enable = cm_xtc_inq_enable;
	con_mgr_stack.cm_reg_cmds = cm_xtc_register_cmds;
	con_mgr_stack.cm_get_rel_cons = cm_xtc_get_rel_cons;
	con_mgr_stack.cm_get_info = cm_xtc_get_info;
    
	DEBUG("con mgr initialized.\n");
	NutSleep(250);

    // start threads
    NutThreadCreate("CON_MGR", CON_MGR, 0, NUT_DEFAULT_STACKSIZE);
    NutThreadCreate("CM_INQ", CM_INQ, 0, NUT_DEFAULT_STACKSIZE);
    NutThreadCreate("CON_BUF", CON_EVENT_BUF, 0, NUT_DEFAULT_STACKSIZE);
}

//@}
