/*!
 * \file con_event_buffer.c
 * \brief buffers conection table change events comming from btstack.
 * 
 * This file provides a mechanism to buffer connection-table-change-events from
 * the btstack. This is needed since the callback call from the btstack should
 * return as soon as possible, running on the high priority btstack thread.
 * Further event handling is done in a seperate thread which calls 
 * #con_event_listen(). 
 */

#include <stdio.h>
#include <string.h>
#include <io.h>
#include <stdlib.h>
#include <sys/thread.h>
#include <bt/bt_hci_cmds.h>
#include <terminal/btn-terminal.h>
#include <led/btn-led.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/timer.h>
#include <cm/con_event_buffer.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CM
#define LOG_LEVEL SYSLOG_LEVEL_CM
#include <debug/log_set.h>

#define MAX_CON_CHANGE_EVENT_ENTRY 10   //what size has to be???

typedef struct _event_entry {
    u_char type;
    u_char detail;
    bt_hci_con_handle_t con_handle;
} event_entry_t;

typedef struct _event_fifo {
   event_entry_t event_list[MAX_CON_CHANGE_EVENT_ENTRY];
   u_char rd_idx;
   u_char wr_idx;
   u_char isfull;
} event_fifo_t;

typedef struct _con_event_info {
    HANDLE table_changed_event;
    event_fifo_t event_fifo;
    HCI_CON_TABLE_CB;
    void* cb_arg;
    char debug_open_con;
    struct btstack* bt_stack;
} con_event_info_t;

con_event_info_t* _con_event_info;

void con_event_buffer_register_con_table_cb(struct btstack* bt_stack, HCI_CON_TABLE_CB, void* cb_arg)
{
    _con_event_info->con_table_cb = con_table_cb;
    _con_event_info->cb_arg = cb_arg;
}

void _con_change_add_to_list(u_char type, u_char detail, bt_hci_con_handle_t con_handle)
{
    event_fifo_t* fifo = &_con_event_info->event_fifo;
    
    if (!fifo->isfull){
      fifo->event_list[fifo->wr_idx].con_handle = con_handle;
      fifo->event_list[fifo->wr_idx].type = type;
      fifo->event_list[fifo->wr_idx].detail = detail;
      fifo->wr_idx++;
      if(fifo->wr_idx == MAX_CON_CHANGE_EVENT_ENTRY){
        fifo->wr_idx = 0;
      } 
      if(fifo->wr_idx == fifo->rd_idx){
        fifo->isfull = 1;
      }
    }
    else {
        ERROR("CEB: event entry list overflow!!\n");
    }
}

/*!
 * \brief gets an entry from event fifo.
 * \param[out] ptype
 * \param[out] pdetail
 * \param[out] pcon_handle
 * \return 1 on success, 0 if fifo empty.
 */
u_char _con_change_get_from_list(u_char* ptype, u_char* pdetail, bt_hci_con_handle_t* pcon_handle){
    event_fifo_t* fifo = &_con_event_info->event_fifo;
    if((fifo->rd_idx == fifo->wr_idx) && !fifo->isfull){
        return 0;
    }
    *ptype = fifo->event_list[fifo->rd_idx].type;
    *pdetail = fifo->event_list[fifo->rd_idx].detail;
    *pcon_handle = fifo->event_list[fifo->rd_idx].con_handle;
    fifo->rd_idx++;
    if(fifo->rd_idx == MAX_CON_CHANGE_EVENT_ENTRY){
        fifo->rd_idx = 0;
    }
    fifo->isfull = 0;
    return 1;        
}

void con_event_listen(void)
{
    u_char type, detail;
    bt_hci_con_handle_t con_handle;
    while (1) {
        //wait for a change
        NutEventWait(&_con_event_info->table_changed_event, NUT_WAIT_INFINITE);

        // handle all events in event fifo queue
        while(_con_change_get_from_list(&type,&detail,&con_handle)){
        	//tprintf("CEB: handeling event type %d of handle %d\n", type, con_handle);
            //call callback functions
            _con_event_info->con_table_cb(type, detail, con_handle, _con_event_info->cb_arg);
        	//tprintf("CEB: handeling done: event type %d of handle %d\n", type, con_handle);
        }
        //btn_terminal_refresh();
    }
}

/*!
 * \brief callback function registered in the btstack.
 * This function runs in the context of the high priority btstack thread. It 
 * handles connection-table-change-events from the btstack. It adds the events 
 * to a event queue and wakes up the con_event_listen thread. 
 */
void _con_event_cb(u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg) 
{
    //tprintf("CEB: Table changed handle %d state %d\n", con_handle, type);
/*    if (type == BT_HCI_CONNECTION)
        _jaws_stack->debug_open_con++;
    if (type == BT_HCI_DISCONNECTION)
        _jaws_stack->debug_open_con--;
    //check nr of con for ERROR DEBUGGING
    if (_jaws_stack->debug_open_con != bt_hci_get_con_handles(_jaws_stack->bt_stack, NULL)) {
        tprintf("ERROR!!!! con-nr not equal stack con\n");
        btn_led_clear_pattern_queue();
        btn_led_add_pattern(BTN_LED_PATTERN_UP, 0, 1, 10);
        btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 12, 1, BTN_LED_INFINITE);
    }
*/    
	_con_change_add_to_list(type, detail, con_handle);
    //wake up listening thread for table changes
    NutEventPostAsync(&_con_event_info->table_changed_event);
}

void _con_buf(char * arg) {
  u_char i,nr;
  event_fifo_t* fifo = &_con_event_info->event_fifo;
  if (fifo->isfull) {
    nr = MAX_CON_CHANGE_EVENT_ENTRY;
  } else {
    nr = ((fifo->wr_idx + MAX_CON_CHANGE_EVENT_ENTRY) - fifo->rd_idx) % 
         MAX_CON_CHANGE_EVENT_ENTRY;
  }
  tprintf("con event buffer with %d entries:\n",nr);
  event_entry_t* event;
  for (i=0; i<nr; i++) {
    event = &fifo->event_list[(fifo->rd_idx+i)%MAX_CON_CHANGE_EVENT_ENTRY];
    tprintf("type %d, detail %d, handle %d\n", event->type, event->detail, event->con_handle);
  }
}

/*!
 * \brief Default callback handler.
 * This callback is called when no other callback was registered.
 */
void _null_con_table_change_cb(u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg)
{
#if LOG_LEVEL >= LOG_INFO
    if ((type == BT_HCI_CONNECTION) || (type == BT_HCI_DISCONNECTION))
        INFO("CEB: con change null cb called!\n");
#endif
}

void con_event_buffer_init(struct btstack *bt_stack, HCI_CON_TABLE_CB_REGISTRATION)
{
    // alloc info struct
    _con_event_info = NutHeapAllocClear(sizeof(con_event_info_t));
    _con_event_info->con_table_cb = _null_con_table_change_cb;

    // hci connection callback
    con_table_cb_reg(bt_stack, _con_event_cb, NULL);
   
    // terminal commands
    btn_terminal_register_cmd("con_buf", _con_buf);
}

