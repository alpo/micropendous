/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: cm_tree.c,v 1.44 2006/11/23 17:03:40 yuecelm Exp $
 * 
 */

/*!
 * $Log: cm_tree.c,v $
 * Revision 1.44  2006/11/23 17:03:40  yuecelm
 * 'cm root' did not return the state (fix SF bug #1601794)
 *
 * Revision 1.43  2006/10/27 13:59:31  yuecelm
 * last merge was imperfectly, its now fixed
 *
 * Revision 1.42  2006/10/27 13:30:15  yuecelm
 * merge changes in revision 1.39:
 * fix unclean use of eepromdb: uses u_long instead of string feature,
 * cosmetic changes
 *
 * Revision 1.41  2006/10/26 13:27:32  kevmarti
 * - Adaption to obsolete typedef 'bt_msg'
 * - Included syslog debug definitions
 *
 * Revision 1.40  2006/10/24 16:07:23  yuecelm
 * revert temporary back to previous version
 * due to set a new CVS tag on 2006-10-25/tomorrow
 *
 * Revision 1.38  2006/10/23 11:37:23  kevmarti
 * - New concept: Defined a 'root-id': As soon as own tree ID equals the root ID, the con mgr disables inquiries. If a node is the root node or not is read from the EEPROM at startup. The user can set / clear this EEPROM value using the con mgr terminal command "cm root"
 * - bugfix: to prevent bug #1581308 I introduced a sleep after a new node has created a connection (before the neg. pkt is sent)
 * - code cleanup
 *
 * Revision 1.37  2006/10/23 10:45:18  kevmarti
 * Adapted to new interface of function 'bt_psm_service_set_buffers()' provided by 'bt/bt_psm.h'
 *
 * Revision 1.36  2006/10/23 09:08:10  kevmarti
 * Removed some printf's used for debugging
 *
 * Revision 1.35  2006/10/16 14:27:03  kevmarti
 * Fixed hci set event filter setup during initialization (clear & set was necessary)
 *
 * Revision 1.34  2006/10/12 13:43:20  kevmarti
 * - enabling inquiries if no connection to id-giving device exists
 * - extended 'cm_tree_disconnect_all()'
 * - code clean-up
 *
 * Revision 1.33  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * 
 */ 

/*!
 * \file con_mgr.c
 * 
 * \date 2006/03/29 
 *
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch.ch>
 *
 * \brief Implementation of the Connection Manager
 * 
 * This is the simplified version of the connection manager.
 * See singleroot_conmgr.c for an alternative version.
 * 
 * The connection manager builds and
 * maintains a connected network in a distributed fashion.
 * 
 * For now, a BTnode that has reached its maximum number of master and slave
 * roles does not participate in connection-building anymore.
 * 
 * The connection manager consists of two threads:
 * 
 * One thread performs inquiries and connects to
 * neighboring nodes with the same class of device. The thread waits
 * rand()/RAND_MAX times sleep_period seconds between inquiries.
 * 
 * A second thread reacts to events (connect, disconnect) and handles incoming
 * packets (tree-id, negotiation, negotiation-response).
 * 
 * When two nodes connect, the node with a lower tree ID takes over the other
 * node's tree ID and broadcasts it to its former tree. Like this, the new tree
 * ID is distributed to all nodes in the new tree.
 * 
 * A node also sends (i.e. initiates) such a broadcast if
 * - it received a tree-ID broadcast with a lower ID than its own MAC address:
 * the node's MAC address is broadcast.
 * - one of its connections was unvoluntarily dropped: the node's MAC address is
 * broadcast.
 * A node forwards a received broadcast if and only if
 * - the tree-ID in the broadcast is higher than its own MAC address
 * - the broadcast message was not previously received from another link; in
 * this case, the link over which the message just arrived is dropped. This
 * removes cycles from the graph and thus maintains a tree structure.
 * 
 * The master and slave roles for the connection are decided based on balancing
 * criteria.
 * 
 * Further ideas:
 * - A node inquires less if its tree ID has been raised many times (this
 * means that many connections have already been established). If the ID is
 * lowered, there has been a disconnect and the node inquires more frequently.
 * - Use class-of-device bits to give information about available master/slave
 * roles and the tree ID; these bits are transferred during inquiry at no cost!
 * 
 * 
 */

#include <led/btn-led.h>
#include <sys/timer.h>
#include <stdlib.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_defs.h>
#include <bt/bt_acl_defs.h>
#include <terminal/btn-terminal.h>
#include <sys/types.h>
#include <sys/event.h>
#include <sys/thread.h>
#include <sys/heap.h>
#include <sys/mutex.h>
#include <eepromdb/btn-eepromdb.h>
#include <string.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <debug/logging.h>
#include <debug/toolbox.h>
#include <cm/con_event_buffer.h>
#include <cm/_con_mgr.h>
#ifdef __AVR__
#include <avr/wdt.h>
#endif
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CM
#define LOG_LEVEL SYSLOG_LEVEL_CM
#include <debug/log_set.h>

// maximum slave roles that a node is willing to take
#define CM_MAX_SLAVE_ROLES            1
#define CM_MAX_SLAVES                 6
#define CM_AUTINQ          CM_AUTINQ_ON
#define CM_AIPERIOD                  20
#define CM_AITIME                     3
#define CM_MAX_INQ_DEVICES           10

//pkt types
#define CM_PKT_TYPE_TREE_ID           0
#define CM_PKT_TYPE_NEGOT             1
#define CM_PKT_TYPE_NEGOT_RESP        2


//heartbeat (only showing if device is not connected)
#define CM_LED_HB_PAUSE              50
#define CM_LED_HB_DURATION            2

// minimum sleep time between inquiries [seconds]
#define CM_MIN_SLEEP                  5

//autinq vals
#define CM_AUTINQ_OFF                 0
#define CM_AUTINQ_ON                  1

/// link supervision timeout (1600 slots = 1s)
#define CM_LINK_TIMEOUT           11200

/// page timeout (default value)
#define CM_PAGE_TIMEOUT			 0x2000

#define CM_COD_MASK 0xFFFFFFul

typedef struct _cm_stack {
    bt_addr_t tree_ID;
    bt_addr_t my_addr;
    bt_hci_con_handle_t tree_id_handle;
    bt_hci_con_handle_t reliable_cons[BT_HCI_MAX_NUM_CON];
    struct btstack *bt_stack;   // pointer to lower level hci stack 
    bt_psm_t* psmux;
    u_short psm;
    bt_acl_pkt_buf* buf_que;		///< Pointer to the packet buffers
    u_char num_of_reliable_cons;
    u_long sleep_period;
    u_long ai_time;
    u_long page_timeout; // page_time = page_timeout * 0.625msec (1 Baseband slot) range: 0x0001 - 0xEFFF
    u_char data_buf[115];
    struct bt_semaphore rel_con_cb_mutex;
    u_long cod;
    HANDLE inq_enable;
    HANDLE inq_stop;
    u_char inq_disable;
} cm_stack_t;

cm_stack_t* cm_stack;


// definition of the root id
bt_addr_t cm_tree_root_id = { 0xF8, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };


void cm_tree_inq_disable(void);

void cm_tree_inq_enable(void);

//// read autinq from EEPROM and set it; if EEPROM is empty, use val
//u_char cm_tree_set_autinq_to_EEPROM(u_char val) {
//		unsigned int len, read_EEPROM = 0;
//
//        len = btn_eepromdb_get(FOURCC('A', 'I', 'N', '='), sizeof(unsigned int), &read_EEPROM);
//        if (len == 0) {
//          cm_stack->aut_inquiry = val;
//        }
//        else {
//          cm_stack->aut_inquiry = read_EEPROM;
//        }
//        return cm_stack->aut_inquiry;
//}
//
//void cm_tree_set_autinq(u_char val) {
//        cm_stack->aut_inquiry = val;
//}

void _bt_cm_print_reliable_cons(void)
{
    u_char i;
    tprintf("reliable connections:\n");
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (cm_stack->reliable_cons[i] != BT_HCI_HANDLE_INVALID){
            tprintf("%u, ", cm_stack->reliable_cons[i]);
        }
    }
    tprintf("\n");
}

void _bt_cm_print_tree_ID(void)
{
    tprintf("Local tree ID: "ADDR_FMT"\n", ADDR(cm_stack->tree_ID));
}

u_char _bt_cm_get_nr_reliable_cons(void)
{
    u_char nr_open_con = 0, i;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (cm_stack->reliable_cons[i] != BT_HCI_HANDLE_INVALID)
            nr_open_con++;
    }
    return nr_open_con;
}

long _cm_inquiry(struct btstack* bt_stack,
				 u_char time,
				 u_char number,
				 struct bt_hci_inquiry_result* inqres)
{
	long res;
	struct bt_hci_cmd_response cmd_resp;
	
    // do inquiry (async)
   	res = bt_hci_inquiry(bt_stack, &cmd_resp, time, number, inqres);
   		
	/*
	 * temporary solution: reset the btnode (using watchdog timer) in case of a timeout
	 * fixme: does this correctely reboot the bt module?
	 */
	if (NutEventWait(&cmd_resp.block, cm_stack->ai_time * 1280 + 10000))
	{
		btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 15, 1, 10);
		INFO("watchdog reset (inq failed!)\n");
#ifdef __AVR__
    	wdt_enable(WDTO_2S);
#endif
	}
	else
	{
		res = cmd_resp.response;
	}
    return res;
}

/*
 * To deal with ZEEVO bug: sometimes, the ZEEVO does not send a
 * connection complete event, although the specified page timeout has been reached.
 * Therefore, do an async call to 'bt_hci_create_connection()', and
 * send a create connection cancel command if the paging takes
 * longer than specified
 */
long _cm_create_connection(struct btstack* bt_stack,
						   bt_addr_t addr,
						   u_short packet_type,
						   u_char page_scan_rep_mode,
						   u_short clock_offset,
						   u_char allow_role_switch)
{
	long res;
	struct bt_hci_cmd_response cmd_resp;
	
	// establish connection (async call!)
	DEBUG("connecting to: "SADDR_FMT"\n", SADDR(addr));
	res = bt_hci_create_connection(bt_stack,
								   &cmd_resp,
								   addr,
								   packet_type,
								   page_scan_rep_mode,
								   clock_offset,
								   allow_role_switch);
    if (res < 0)
    { 
        INFO("error con create: (0x%2x)!\n", -res);
        return res;
	}
	
	/*
	 * temporary solution: reset the btnode (using watchdog timer) in case of a timeout
	 * fixme: does this correctely reboot the bt module?
	 */
	if (NutEventWait(&cmd_resp.block, (cm_stack->page_timeout * 63)/100 + 10000))
	{
		WARNING("watchdog reset (con failed!\n");
		btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 12, 1, 10);
#ifdef __AVR__
    	wdt_enable(WDTO_2S);
#endif
	}
	else
	{
		res = cmd_resp.response;
	}
	return res;
}


/* The following function is for sending a broadcast packet (containing a new tree ID)
 */
void _bt_cm_broadcast(u_char* data, bt_hci_con_handle_t except_con_handle, u_short len)
{
    u_char i;
    // send packet to all reliable connections
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if ((cm_stack->reliable_cons[i] != BT_HCI_HANDLE_INVALID)
             && (cm_stack->reliable_cons[i] != except_con_handle)) { // incoming 
            if(l2cap_cl_send(data, len, cm_stack->reliable_cons[i], cm_stack->psm)) {
                ERROR("cannot send to device with handle %u\n", cm_stack->reliable_cons[i]);
            }
        }
    }
}


/*
 * checks if the connection with this handle is a reliable connection
 */
u_char _bt_cm_is_reliable_con( bt_hci_con_handle_t con_handle)
{
    u_char i;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (cm_stack->reliable_cons[i] == con_handle) {
            break;
        }
    }
    return (i != BT_HCI_MAX_NUM_CON);
}

void _bt_cm_add_reliable_con( bt_hci_con_handle_t con_handle)
{
    u_char i;
    DEBUG("adding con\n");
    if (cm_stack->num_of_reliable_cons == 0) {
     
        //first connection
        btn_led_heartbeat(0, 0, 0);
    }
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (cm_stack->reliable_cons[i] == con_handle)
            return;
        if (cm_stack->reliable_cons[i] == BT_HCI_HANDLE_INVALID) {
            cm_stack->reliable_cons[i] = con_handle;
            break;
        }
    }
    cm_stack->num_of_reliable_cons++;
    //INFO("writing new cod\n");
    //bt_hci_write_local_cod(cm_stack->bt_stack, BT_HCI_SYNC, CM_INIT_COD + cm_stack->num_of_reliable_cons);
    //turn off heartbeat by passing 0,0,0
    INFO("reliable connection (handle %u) added\n", con_handle);
}

void _bt_cm_remove_reliable_con( bt_hci_con_handle_t con_handle)
{
    u_char i;

    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (cm_stack->reliable_cons[i] == con_handle) {
            cm_stack->reliable_cons[i] = BT_HCI_HANDLE_INVALID;
            cm_stack->num_of_reliable_cons--;
            break;
        }
    }
    if (i == BT_HCI_MAX_NUM_CON)
        return;
    if (cm_stack->num_of_reliable_cons == 0) {
        btn_led_heartbeat(CM_LED_HB_PAUSE, 1, CM_LED_HB_DURATION);
    }
    //bt_hci_write_local_cod(cm_stack->bt_stack, BT_HCI_SYNC, CM_INIT_COD + cm_stack->num_of_reliable_cons);
}

u_char _bt_cm_lower_bt_addr(bt_addr_t id1, bt_addr_t id2)
{
    int i;
    u_char retvalue = 0;
    for (i = BD_ADDR_LEN - 1; i >= 0; i--) {
        if (id1[i] < id2[i]) {
            retvalue = 1;
            break;
        } else if (id1[i] > id2[i]) {
            retvalue = 0;
            break;
        }
    }
    return retvalue;
}

void _bt_cm_show_tree_ID(void)
{
    if (cm_stack->tree_ID[0] & 0x1)
        btn_led_set(0);
    else
        btn_led_clear(0);
    if (cm_stack->tree_ID[0] & 0x2)
        btn_led_set(1);
    else
        btn_led_clear(1);
    if (cm_stack->tree_ID[0] & 0x4)
        btn_led_set(2);
    else
        btn_led_clear(2);
    if (cm_stack->tree_ID[0] & 0x8)
        btn_led_set(3);
    else
        btn_led_clear(3);
}

/*!
 * \brief processes a received tree id.
 * \param[in] received_tree_ID
 * \param[in] con_handle
 * \param[in] type
 * \return 0 on success, 1 if received_tree_ID matches our own tree id.
 */
u_char _bt_cm_process_tree_ID(bt_addr_t received_tree_ID, bt_hci_con_handle_t con_handle, char type)
{
    u_char *payload;

    if (_bt_cm_lower_bt_addr(cm_stack->tree_ID, received_tree_ID)) {
        // a higher ID was received, copy received_tree_ID to tree_ID
        DEBUG("_bt_cm_process_tree_ID: a higher tree ID ("SADDR_FMT") " \
                "was received (handle %u)\n",
                SADDR(received_tree_ID),
                con_handle);
        // store new id, and show it
        memcpy(cm_stack->tree_ID, received_tree_ID, BD_ADDR_LEN);        // overwrite my old tree ID
        cm_stack->tree_id_handle = con_handle;
        _bt_cm_show_tree_ID();
        // if this is the id of the root, disable inquiries
        if (BD_ADDR_CMP(cm_stack->tree_ID, cm_tree_root_id))
        {
        	cm_tree_inq_disable();
        }
        // create tree ID pkt
        payload = cm_stack->data_buf;
        payload[0] = CM_PKT_TYPE_TREE_ID;       // set packet type
        memcpy(payload + 1, cm_stack->tree_ID, BD_ADDR_LEN);
        // broadcast packet
        _bt_cm_broadcast(payload, con_handle, BD_ADDR_LEN + 1);
        return 0;
    } else if (_bt_cm_lower_bt_addr(received_tree_ID, cm_stack->tree_ID)) {
        // a lower ID was received
        DEBUG("_bt_cm_process_tree_ID: a lower tree ID ("SADDR_FMT") " \
                "was received (handle %u)\n",
                SADDR(received_tree_ID),
                con_handle);
        if (con_handle == cm_stack->tree_id_handle)
        {    // a connection was lost
            memcpy(cm_stack->tree_ID, received_tree_ID, BD_ADDR_LEN);
            _bt_cm_show_tree_ID();
            payload = cm_stack->data_buf;
            payload[0] = CM_PKT_TYPE_TREE_ID;   // set packet type
            memcpy(payload + 1, cm_stack->tree_ID, BD_ADDR_LEN);
            _bt_cm_broadcast(payload, con_handle, BD_ADDR_LEN + 1);
            // re-enable inquiries
            cm_tree_inq_enable();
        }
        return 0;
    } else {
        /* received_tree_ID == tree_ID, i.e. there's a cycle */
        if (type != CM_PKT_TYPE_NEGOT_RESP)
        {
        	DEBUG("_bt_cm_process_tree_ID: identical tree ID ("SADDR_FMT") " \
                 "was received, disconnecting (handle %u)\n",
                 SADDR(received_tree_ID),
                 con_handle);
        	/* TODO add error check */
        	bt_hci_disconnect(cm_stack->bt_stack, BT_HCI_SYNC, con_handle, BT_HCI_DISCONNECT_USER_ENDED);
        	return 1;
        }
        return 0;
    }
}

//void _change_con_pkt_type(bt_hci_con_handle_t con_handle)
//{
//    long res;
//    DEBUG("changing conpkt type\n");
//    res = bt_hci_change_con_pkt_type(cm_stack->bt_stack, BT_HCI_SYNC, con_handle, BT_HCI_PACKET_TYPE_DM3);
//    if (res < 0) {
//        ERROR("con pkt change: error %d\n",res);
//    }
//}


void _change_disconnect_timeout( bt_hci_con_handle_t handle)
{
    long res;
    bt_hci_con_handle_t con_handle;
    con_handle = handle;
    // TODO add error check
    //bt_l2cap_get_hci_connection_handle( handle, &con_handle);
    DEBUG("changing disc timeout\n");
    res = bt_hci_write_link_supervision_timeout(cm_stack->bt_stack, BT_HCI_SYNC, con_handle, CM_LINK_TIMEOUT);
    if (res < 0) {
        ERROR("error changing disc timeout %d\n",res);
    }
}

u_char _bt_cm_count_reliable_roles(u_char role)
{
    u_char i, right_role = 0;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (cm_stack->reliable_cons[i] != BT_HCI_HANDLE_INVALID) {
            bt_hci_con_handle_t con_handle;
            con_handle = cm_stack->reliable_cons[i];
            if (bt_hci_local_role_discovery(cm_stack->bt_stack, con_handle) == role) {
                right_role++;
            }
        }
    }
    return right_role;
}

/* Here comes the code for handling changes in the connection table.
 */
void _con_table_change_cb(u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg)
{
    u_char *data;
    bt_addr_t addr;
    long res;
    
    DEBUG("con table cb!\n");
    
    // change connection properties
    if (type == BT_HCI_CONNECTION)
    {
	    res = bt_hci_write_link_supervision_timeout(cm_stack->bt_stack, BT_HCI_SYNC, con_handle, CM_LINK_TIMEOUT);
	    if (res < 0)
	    {
	        ERROR("error changing disc timeout %d\n",res);
	    }
//        _change_con_pkt_type(con_handle);
        //change_link_policy(con_handle); //for rolechange
    }

    switch (type) {
    case BT_HCI_DISCONNECTION:
        /* if the link was lost (i.e. no voluntary disconnect) and we
         * received our tree ID over this link, we have to reset our
         * tree ID to our BT MAC address.
         */
        if (detail == BT_HCI_DISCON_LINK_LOST) {
        	btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 1, 1, 10);
        }
        
        INFO("DISCONNECTION (hdl %u)\n", con_handle);
        
        // invalidate tree ID handle & send tree ID packet
        if (con_handle == cm_stack->tree_id_handle)
        {
        	INFO("ID-giving link loss! invalidating tree id hdl.\n");
        	memcpy(cm_stack->tree_ID, cm_stack->my_addr, BD_ADDR_LEN);
        	cm_stack->tree_id_handle = BT_HCI_HANDLE_INVALID;
        	_bt_cm_show_tree_ID();
        	// send new tree id to all neighbors
            data = cm_stack->data_buf;
            data[0] = CM_PKT_TYPE_TREE_ID;   // set packet type
            memcpy(data + 1, cm_stack->tree_ID, BD_ADDR_LEN);
            _bt_cm_broadcast(data, con_handle, BD_ADDR_LEN + 1);
            // re-enable inquiries
            cm_tree_inq_enable();
        }
        
        _bt_semaphore_wait(&(cm_stack->rel_con_cb_mutex));
        DEBUG("rc mux entered!\n");
        if (_bt_cm_is_reliable_con(con_handle))
        {
        	_bt_cm_remove_reliable_con(con_handle);
        	// singal higher layer - only if available
        	if (con_mgr_stack.con_table_cb)
        	{
            	con_mgr_stack.con_table_cb(type, detail, con_handle, con_mgr_stack.con_table_cb_arg);
        	}
        }
        _bt_semaphore_post(&(cm_stack->rel_con_cb_mutex));
        break;
    case BT_HCI_CONNECTION:
        /* A connection was just established; if we initiated it, then we
         * send a negotiation packet. Otherwise the
         * connection-manager thread will take care of the incoming
         * negotiation packet and perform all further steps.
         */
        bt_hci_get_remote_bt_addr(cm_stack->bt_stack, con_handle, addr);
        INFO("CONNECTION: " SADDR_FMT ", hdl: %u, detail: %d\n", SADDR(addr), con_handle, detail);
        break;
    default:
        WARNING("other type than con/discon\n!");
    }
    DEBUG("con_table_change_cb: done\n");
}



/*
 * data callback function
 */
bt_acl_pkt_buf* _cm_data_cb(bt_acl_pkt_buf* pkt_buf,
							u_char* data,
							u_short len,
							u_short service_nr,
							void* cb_arg)
{
	bt_hci_con_handle_t con_handle;
    bt_addr_t received_ID;
    u_char my_slave_roles, received_slave_roles;

	// get con handle
	con_handle = bt_acl_get_con_handle(pkt_buf->pkt);
	// if con handle is not valid anymore, do not process the packet
	
    switch (data[0]) {   // type
        //------------------------------------------------------------------
    case CM_PKT_TYPE_TREE_ID:
        DEBUG("received tree-ID packet (handle %u)\n", con_handle);
        memcpy(received_ID, data+1, BD_ADDR_LEN);
        _bt_cm_process_tree_ID(received_ID, con_handle, CM_PKT_TYPE_TREE_ID);
        break;
        //------------------------------------------------------------------
    case CM_PKT_TYPE_NEGOT:
        // we assume that this node is the slave, this might change
        // with BTnode rev3!
        DEBUG("CM: received neg. packet (handle %u)\n", con_handle);
        
	    _bt_semaphore_wait(&(cm_stack->rel_con_cb_mutex));
        DEBUG("CM:thread enter mutex\n");
        my_slave_roles = _bt_cm_count_reliable_roles(BT_HCI_MY_ROLE_MASTER);
//                              if (my_slave_roles <= CM_MAX_SLAVE_ROLES) {
//                      //DEBUG("CM: one slave role still available (handle %d)\n", con_handle);
        memcpy(received_ID, data+1, BD_ADDR_LEN);
        received_slave_roles = data[BD_ADDR_LEN + 1];
        
        // TODO why?
        // check if this con handle is still in stack con table or it connection just disconnected!
         if (bt_hci_is_con_open(cm_stack->bt_stack, con_handle) != 0) {
            ERROR("con handle %d not in stack anymore!!\n", con_handle);
            _bt_semaphore_post(&(cm_stack->rel_con_cb_mutex));
            DEBUG("thread exit mutex\n");
            break;
         }
        
        DEBUG("processing tree ID (handle %u)\n", con_handle);
        if( _bt_cm_process_tree_ID( received_ID,
                                    con_handle,
                                    CM_PKT_TYPE_NEGOT) == 0) {
            _bt_cm_add_reliable_con(con_handle);
            DEBUG("call jaws\n");
            // signal higher layer - only if available
            if (con_mgr_stack.con_table_cb)
            {
            	con_mgr_stack.con_table_cb(BT_HCI_CONNECTION,
            							   BT_HCI_CONNECTION_PASSIVE,
            							   con_handle,
            							   con_mgr_stack.con_table_cb_arg);
            }
            data = cm_stack->data_buf;
            data[0] = CM_PKT_TYPE_NEGOT_RESP;        // set packet type
            memcpy( data + 1, cm_stack->tree_ID, BD_ADDR_LEN);
            if (l2cap_cl_send(data, BD_ADDR_LEN+1, con_handle, cm_stack->psm)) {
                ERROR("could not send neg-resp pkt, disconnecting.\n");
                // TODO add error check
                bt_hci_disconnect(cm_stack->bt_stack, BT_HCI_SYNC, con_handle, BT_HCI_DISCONNECT_USER_ENDED);
                _bt_semaphore_post(&(cm_stack->rel_con_cb_mutex));
                DEBUG("thread exit mutex\n");
                break;
               
            }
        }
        
        _bt_semaphore_post(&(cm_stack->rel_con_cb_mutex));
        DEBUG("CM:thread exit mutex\n");
        break;
        //------------------------------------------------------------------
    case CM_PKT_TYPE_NEGOT_RESP:
        
        DEBUG("CM: received neg.-response pkt (handle %u)\n", con_handle);
	    _bt_semaphore_wait(&(cm_stack->rel_con_cb_mutex));
        DEBUG("CM:thread enter mutex\n");
       
        memcpy(received_ID, data + 1, BD_ADDR_LEN);
        // TODO why?
        // check if this con handle is still in stack con table or it connection just disconnected!
        if (bt_hci_is_con_open(cm_stack->bt_stack, con_handle) != 0) {
            ERROR("con handle not in stack anymore!!\n");
            _bt_semaphore_post(&(cm_stack->rel_con_cb_mutex));
            DEBUG("CM:thread exit mutex\n");
            break;
        }
        DEBUG("processing tree ID (handle %u)\n", con_handle);
        if( _bt_cm_process_tree_ID( received_ID,
                                    con_handle,
                                    CM_PKT_TYPE_NEGOT_RESP) == 0) {
            _bt_cm_add_reliable_con(con_handle);
            // signal higher layer - only if available
            if (con_mgr_stack.con_table_cb)
            {
            	con_mgr_stack.con_table_cb(BT_HCI_CONNECTION,
            							   BT_HCI_CONNECTION_ACTIVE,
            							   con_handle,
            							   con_mgr_stack.con_table_cb_arg);
            }
        }
        _bt_semaphore_post(&(cm_stack->rel_con_cb_mutex));
        DEBUG("thread exit mutex\n");
        break;
        //------------------------------------------------------------------
    default:
        WARNING("unknown CM packet type %u\n", data[0]);
        break;
        //------------------------------------------------------------------
    }// end switch
    return pkt_buf;
}

/*
 * inquiry thread
 * This thread is responsible for doing regular inquiries and connecting to one
 * of the compatible devices (CoD). The behavior can be controlled from the
 * command line with the "cm autinq" and "cm aiperiod" commands.
 */
THREAD(CONMGR_INQUIRY_T, arg)
{
    u_long sleep_period;
    long retval;
    u_char i, j;
    int idx;
    u_char* data;
    bt_hci_con_handle_t con_handle;
    
    struct bt_hci_inquiry_result inqres[CM_MAX_INQ_DEVICES];
    u_char inq_devs;
    struct bt_hci_inquiry_result* candidates[CM_MAX_INQ_DEVICES];
    u_char nr_candidates;
    struct bt_hci_inquiry_result* chosen_dev;
    u_short nr_inqs = 0;
    
    // Note (KM): introduced this initial sleep because a node that resetted
    // itself should not start doing new inquiries before _all_ nodes of the
    // remaining network do know about the node loss
    NutSleep(1000*CM_MIN_SLEEP);
    
    while (1)
    {	
    	/* Sleep random amount of time.
    	 * Note: do not sleep if inquiry start event has been received */
        if (!cm_stack->inq_disable)
        {	
        	// calculate sleep period
        	sleep_period = ((1000 * cm_stack->sleep_period) * rand()) / RAND_MAX;
        	sleep_period += (1000 * CM_MIN_SLEEP);
        	INFO("cm: inq sleep %lu\n", sleep_period);
        	// wait 'til interrupted or 'til sleep period is over
        	if (NutEventWaitNext(&cm_stack->inq_stop, sleep_period))
        	{
        		DEBUG("cm: starting inq...\n");
        	}
        	else
        	{
        		INFO("cm: inq pause interrupted!\n");
        	}
        }
    	
        /*
         * Do inquiry and filter inquiry results.
         * - omitt devices with wrong COD
         * - omitt already connected devices
         */
        nr_candidates = 0;
        if (!cm_stack->inq_disable)
        {
	        INFO("cm: inq started!\n");
	        btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 1, 0xFF);
	        inq_devs = _cm_inquiry(cm_stack->bt_stack, (u_char) cm_stack->ai_time, CM_MAX_INQ_DEVICES, inqres);
	        btn_led_clear_pattern_queue();
	        nr_inqs++;
	        
	        // filter inquiry results
	        for (i=0; i<inq_devs; i++)
	        {
            	DEBUG_STR("addr: " SADDR_FMT " rep: %d, period: %d, cod: 0x%06lX, clk: %ud, rssi: %d\n",
            		  	  SADDR(inqres[i].bdaddr), inqres[i].page_scan_rep_mode,
            		  	  inqres[i].page_scan_period_mode,
            		  	  inqres[i].cod, inqres[i].clock_offset, inqres[i].rssi);
	        		  	  
	        	if (inqres[i].cod == cm_stack->cod)
	        	{
	        		// only add device if not connected
	        		if (bt_hci_get_con_handle(cm_stack->bt_stack, inqres[i].bdaddr) < 0)
	        		{
	        			candidates[nr_candidates++] = &inqres[i];
	        		}
	        	}
	        }
	        INFO("cm: inq done. found: %d devs, candidates: %d\n", inq_devs, nr_candidates);
	        INFO("Nut: Heap Available = %u bytes.\n", NutHeapAvailable());
        }
        
        /**
         * Walk through filtered inquiry results & try to connect to all of them.
         * Devices with better RSSI values are considered first.
         */
        for (i=0; i<nr_candidates; i++)
        {
        	idx = -1;
    		
        	// find next best candidate
        	for (j=0; j<nr_candidates; j++)
        	{
        		if (candidates[j])
        		{
            		if ((idx == -1) || (candidates[j]->rssi > candidates[idx]->rssi))
            		{
            			// store index of currently best candidate
            			idx = j;
            		}
        		}
        	}
        	chosen_dev = candidates[idx];
        	candidates[idx] = NULL;

            // wait before trying to establish the connection
        	sleep_period = 1000*CM_MIN_SLEEP;
        	// wait 'til interrupted or 'til sleep period is over
        	if (!NutEventWaitNext(&cm_stack->inq_stop, sleep_period))
        	{
        		INFO("cm: con pause interrupted!\n");
        	}
        	// stop processing if inquiries shall be disabled
        	if (cm_stack->inq_disable)
        	{
        		break;
        	}
        	// else, try to establish the connection
        	btn_led_add_pattern(BTN_LED_PATTERN_HALF, 0, 1, 1);
        	INFO("cm: estbl. con to: " SADDR_FMT "\n", SADDR(chosen_dev->bdaddr));
            retval = _cm_create_connection (cm_stack->bt_stack,
                							chosen_dev->bdaddr,
                							BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DH1 | BT_HCI_PACKET_TYPE_DM3,
                							chosen_dev->page_scan_rep_mode,
                							chosen_dev->clock_offset,
                							BT_HCI_ROLE_SWITCH_CHANGE);
            btn_led_clear_pattern_queue();
            INFO("cm: con created: " SADDR_FMT ", retval: %d\n", SADDR(chosen_dev->bdaddr), retval);
            // send neg. packet if success
            if (retval >= 0)
            {
            	INFO("sending pkt!\n");
            	// temp store con handle
            	con_handle = retval;
            	// create neg packet
            	data = cm_stack->data_buf;
            	data[0] = CM_PKT_TYPE_NEGOT;     // set packet type
            	memcpy(data + 1, cm_stack->tree_ID, BD_ADDR_LEN);
            	data[BD_ADDR_LEN + 1] = _bt_cm_count_reliable_roles(BT_HCI_MY_ROLE_MASTER);
            	// Note (KM): this delay is really necessary: on the remote
            	// side, it is possible that a packet arrives before
            	// the corresponding connectin complete event arrives
            	// (see bug #1581308 on sf.net).
            	// BTW: i'm not shure about the necessary delay
            	NutSleep(200);
            	// send the neg packet
            	retval = l2cap_cl_send(data, BD_ADDR_LEN + 1, con_handle, cm_stack->psm);
            	if(retval) {
                	INFO("cm: err sending neg pkt (hdl %d): %li.\n", con_handle, retval);
                	retval = bt_hci_disconnect(cm_stack->bt_stack, BT_HCI_SYNC, con_handle, BT_HCI_DISCONNECT_USER_ENDED);
                	if (retval)
                	{
                		WARNING("disconnecting (hdl %d): %li\n", con_handle, retval);
                	}
            	}
            	else
            	{
            		INFO("cm: neg pkt sent. type %u handle %u psm %u\n", data[0], con_handle, cm_stack->psm);
            	}
            }
    	}
    	
    	// wait as long as inquiries shall be disabled
    	if (cm_stack->inq_disable)
    	{
    		INFO("cm: inq disabled\n");
    		// wait until inquiries are re-enabled
    		NutEventWait(&cm_stack->inq_enable, NUT_WAIT_INFINITE);
    		INFO("cm: inq enabled!\n");
    		nr_inqs = 0;
    	}
	}
}

THREAD(CON_EVENT_BUF, arg)
{
	while (1) {
		con_event_listen();
	}
}

unsigned int _RSHash(u_char *str, unsigned int len)
{

    unsigned long int b = 378551;
    unsigned long int a = 63689;
    unsigned int hash = 0;
    unsigned int i = 0;

    for (i = 0; i < len; str++, i++) {
        hash = hash * a + (*str);
        a = a * b;
    }

    return (hash & 0x7FFFFFFF);

}


void _cm_cmds_print_usage(void)
{
    tprintf("cm: err: usage:\n"
            "id\n"
            "relcons\n"
            "autinq [ 0|1 [0|1] ]\n"
            "aiperiod [ SECONDS [0|1] ]\n"
            "aitime [ SECONDS [0|1] ]\n"
            "blink\n"
            "root [0|1]\n"
            "disconall\n");
}

void _cm_cmd_aiperiod(char * arg)
{
    u_char len;
    u_long sleep_period;
    u_int eeprom_write = 0;

    if (sscanf(arg, "%lu%u", &sleep_period, &eeprom_write) >= 1)
    {
        cm_stack->sleep_period = sleep_period;
        if (eeprom_write)
        {
            btn_eepromdb_store(FOURCC('A', 'I', 'S', 'P'), sizeof(u_long), &sleep_period);
        }
    }
    else
    {
        tprintf("Autinq period: %lu.", cm_stack->sleep_period);
        len = btn_eepromdb_get(FOURCC('A', 'I', 'S', 'P'), sizeof(u_long), &sleep_period);
        if (len > 0)
        {
            tprintf(" Stored in EEPROM: %lu", sleep_period);
        }
        tprintf("\n");
    }
}

void _cm_cmd_root(char * arg)
{
    u_char len;
    u_long is_root = 0;
	
    if (sscanf(arg, "%lu", &is_root) == 1)
    {
        btn_eepromdb_store(FOURCC('R', 'O', 'O', 'T'), sizeof(u_long), &is_root);
    }
    else
    {
        // if this device is the root device
        if (BD_ADDR_CMP(cm_stack->my_addr, cm_tree_root_id))
        {
            is_root = 1;
        }
        tprintf("Root: %u.", is_root);

        len = btn_eepromdb_get(FOURCC('R', 'O', 'O', 'T'), sizeof(u_long), &is_root);
        if (len > 0)
        {
            tprintf(" Stored in EEPROM: %lu", is_root);
        }
        tprintf("\n");
    }
}


void _cm_cmd_autinq(char * arg)
{
    u_int enable = 0;
    
    if (sscanf(arg, "%u", &enable) == 1)
    {
        if (enable)
        {
            cm_tree_inq_enable();
        }
        else
        {
            cm_tree_inq_disable();
        }
    }
}

void _cm_cmd_aitime(char* arg)
{
	u_char len;
    u_long inquiry_time;
    u_int eeprom_write = 0;

    if (sscanf(arg, "%lu%u", &inquiry_time, &eeprom_write) >= 1)
    {
        cm_stack->ai_time = inquiry_time;
        if (eeprom_write)
        {
            btn_eepromdb_store(FOURCC('A', 'I', 'T', 'M'), sizeof(u_long), &inquiry_time);
        }
    }
    else
    {
        tprintf("Autinq length: %lu.", cm_stack->ai_time);
        len = btn_eepromdb_get(FOURCC('A', 'I', 'T', 'M'), sizeof(u_long), &inquiry_time);
        if (len > 0)
        {
            tprintf(" Stored in EEPROM: %lu", inquiry_time);
        }
        tprintf("\n");
    }
}

void cm_tree_inq_disable(void)
{
	cm_stack->inq_disable = 1;
	NutEventPostAsync(&cm_stack->inq_stop);
	DEBUG("inq disabled!\n");
}

void cm_tree_inq_enable(void)
{
	cm_stack->inq_disable = 0;
	NutEventPostAsync(&cm_stack->inq_enable);
	DEBUG("inq enabled!\n");
}

void cm_tree_inq_set_period(u_short val)
{
	cm_stack->sleep_period = (u_long) val;
}

// TODO: this is not a proper interface: the caller should pass the maximal
// amount of data the con mgr can write to the buffer
short cm_tree_fill_con_info(u_char* args, u_char* param){    
    u_char i;
    bt_addr_t addr;
    long role;
    char rssi;

    *args++ = cm_stack->num_of_reliable_cons;
    
    for( i = 0 ; i < BT_HCI_MAX_NUM_CON; i++) {
        if( cm_stack->reliable_cons[i] != BT_HCI_HANDLE_INVALID) {
            /* copy bd addr */
            bt_hci_con_handle_t con_handle;
            con_handle = cm_stack->reliable_cons[i];
            bt_hci_get_remote_bt_addr( cm_stack->bt_stack,
                                       con_handle,
                                       addr);
            memcpy(args, addr, 2);
            args += 2;
            /* copy role */
            role = bt_hci_local_role_discovery( cm_stack->bt_stack,
                                                con_handle);
            if (role == BT_HCI_MY_ROLE_MASTER){
                *args++ = 2; // neighbor is my slave
            } 
            else{
                *args++ = 1; // neighbor is my master
            }
            /* copy rssi */
            bt_hci_read_abs_rssi(cm_stack->bt_stack, BT_HCI_SYNC, con_handle, &rssi);
            *args++ = rssi;
        }
    }
    return (1 + cm_stack->num_of_reliable_cons*4);
}

u_char cm_tree_get_rel_cons(bt_hci_con_handle_t *rel_cons)
{
    u_char i;
    u_char n = 0;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (cm_stack->reliable_cons[i] != BT_HCI_HANDLE_INVALID){
            rel_cons[n] = cm_stack->reliable_cons[i];
            n++;
        }
    }
    return n;
}

char* cm_tree_get_info(void){
    return "Tree";
}

void cm_tree_reset(void)
{
    u_char i;
    //disconn all, except tree id handle
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++)
    {
        if (cm_stack->reliable_cons[i] != BT_HCI_HANDLE_INVALID)
        {
        	if (cm_stack->reliable_cons[i] != cm_stack->tree_id_handle)
        	{
            	DEBUG("discon handle %u\n", cm_stack->reliable_cons[i]);
            	if(bt_hci_disconnect(cm_stack->bt_stack,
                               		 BT_HCI_SYNC,
                               	 	 cm_stack->reliable_cons[i],
                               		 BT_HCI_DISCONNECT_USER_ENDED))
            	{
                		ERROR("can not disconnect handle %u\n", cm_stack->reliable_cons[i]);
            	}
        	}
            DEBUG("done\n");
        }
    }
    
    if (cm_stack->tree_id_handle != BT_HCI_CON_HANDLE_OWN)
    {
    	// disconnect con corresponding to tree_id_handle
    	if (cm_stack->tree_id_handle != BT_HCI_HANDLE_INVALID)
    	{
    		bt_hci_disconnect(cm_stack->bt_stack,
    					  	BT_HCI_SYNC,
    					  	cm_stack->tree_id_handle,
    					  	BT_HCI_DISCONNECT_USER_ENDED);
    	}
    	// reset tree id
    	memcpy(cm_stack->tree_ID, cm_stack->my_addr, BD_ADDR_LEN);
    	cm_stack->tree_id_handle = BT_HCI_HANDLE_INVALID;
    	cm_tree_inq_enable();
    }
}

void _cm_cmds_cm_cmd(char * arg)
{
    if (!strncmp(arg, "relcons", 7)) {
        _bt_cm_print_reliable_cons();
    } else if (!strncmp(arg, "blink", 5)) {
        btn_led_clear_pattern_queue();
        btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 15, 2, 4);
        btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, _bt_cm_get_nr_reliable_cons(), 3, 2);
        btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 15, 2, 4);
    } else if (!strncmp(arg, "disconall", 9)) {
        cm_tree_reset();
    } else if (!strncmp(arg, "id", 2)) {
        _bt_cm_print_tree_ID();
    } else if (!strncmp(arg, "autinq", 6)) {
        _cm_cmd_autinq(arg+6);
    } else if (!strncmp(arg, "aiperiod", 8)) {
        _cm_cmd_aiperiod(arg+8);
    } else if (!strncmp(arg, "aitime", 6)){
    	_cm_cmd_aitime(arg+6);
    } else if (!strncmp(arg, "root", 4)) {
    	_cm_cmd_root(arg+4);
    } else {
        _cm_cmds_print_usage();
    }
}

void cm_tree_register_cmds(void)
{
    btn_terminal_register_cmd("cm", _cm_cmds_cm_cmd);
}

void _cm_tree_id_init(void)
{
    u_long is_root;
    
    // check if this device is the root device
    
    // if not yet initialized, initialize eeprom
    if (btn_eepromdb_get(FOURCC('R', 'O', 'O', 'T'), sizeof(u_long), &is_root) == 0)
    {
    	is_root = 0;
        btn_eepromdb_store(FOURCC('R', 'O', 'O', 'T'), sizeof(u_long), &is_root);
    }
    
    // if this is the root device, set my_addr & tree_ID accordingly
    if (is_root)
    {
    	memcpy(cm_stack->my_addr, cm_tree_root_id, BD_ADDR_LEN);
    	memcpy(cm_stack->tree_ID, cm_tree_root_id, BD_ADDR_LEN);
    	cm_stack->tree_id_handle = BT_HCI_CON_HANDLE_OWN;
    	// disable inquiries
    	cm_stack->inq_disable = 1;
    }
    // else, set addr of this device
    else
    {
    	bt_hci_get_local_bt_addr(cm_stack->bt_stack, cm_stack->my_addr);
    	memcpy(cm_stack->tree_ID, cm_stack->my_addr, BD_ADDR_LEN);
    	cm_stack->tree_id_handle = BT_HCI_HANDLE_INVALID;
    	// make shure that inquiries are running
    	cm_stack->inq_disable = 0;
    }
    // show tree ID on LEDs
    _bt_cm_show_tree_ID();
}


void cm_tree_init(struct btstack *bt_stack,
					bt_psm_t* psmux,
					u_short psm,
					HCI_CON_TABLE_CB_REGISTRATION,
					u_long cod)
{
    u_char i;
    long retval;
    //dyn alloc tp stack
    cm_stack = NutHeapAllocClear(sizeof(cm_stack_t));
    
    // stack init
    cm_stack->bt_stack = bt_stack;
    cm_stack->psmux = psmux;
    cm_stack->psm = psm;
    cm_stack->inq_stop = NULL;
    cm_stack->inq_enable = NULL;
    cm_stack->sleep_period = CM_AIPERIOD;
    cm_stack->ai_time = CM_AITIME;
    
    // init reliable connections table
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        cm_stack->reliable_cons[i] = BT_HCI_HANDLE_INVALID;
    }
    cm_stack->num_of_reliable_cons = 0;
    
    // init own tree id
    _cm_tree_id_init();

    // init con_event buffer
    con_event_buffer_init(bt_stack, con_table_cb_reg);
    
    // register con table change callback at con_event buffer   
    con_event_buffer_register_con_table_cb(bt_stack, _con_table_change_cb, NULL);    

    // seed random number generator with my MAC
    srand(_RSHash(cm_stack->tree_ID, BD_ADDR_LEN));
    DEBUG("seed for rand() was %d, first random numbers are %d, %d, %d, %d, %d\n",
         _RSHash(cm_stack->tree_ID, BD_ADDR_LEN), rand(), rand(), rand(), rand(), rand());
    
    // start heartbeat
    btn_led_heartbeat(CM_LED_HB_PAUSE, 1, CM_LED_HB_DURATION);
    
    // store cod & setup controller
    cm_stack->cod = cod;
    bt_hci_write_local_cod(cm_stack->bt_stack, BT_HCI_SYNC, cod);

    // clear event filter & set inquiry & page COD
    retval = bt_hci_set_event_filter(cm_stack->bt_stack, BT_HCI_SYNC, 0x00, 0x00);
    // inquiry filter on device class
	retval = bt_hci_set_event_filter(cm_stack->bt_stack, BT_HCI_SYNC, 0x01, 0x01, cod, CM_COD_MASK);
	// only allow connections from devices of class CM_COD_MIN
	retval = bt_hci_set_event_filter(cm_stack->bt_stack, BT_HCI_SYNC, 0x02, 0x01, cod, CM_COD_MASK, 0x02);
	
	// set page timeout
	cm_stack->page_timeout = CM_PAGE_TIMEOUT;
    bt_hci_write_page_timeout(cm_stack->bt_stack, BT_HCI_SYNC, cm_stack->page_timeout);
    
    //init automatic inquiry
//    len = btn_eepromdb_get(FOURCC('A', 'I', 'N', '='), sizeof(u_char), &val);
//    if (val!=CM_AUTINQ_ON && val!=CM_AUTINQ_OFF){
//	    val = CM_AUTINQ;
//        btn_eepromdb_store(FOURCC('A', 'I', 'N', '='), sizeof(u_char), &val);    
//    }

//    len = btn_eepromdb_get(FOURCC('A', 'I', 'P', '='), sizeof(u_char), &val);
//    if(len==0){
//	    val = CM_AIPERIOD;	
//	    ++val;	
//        btn_eepromdb_store(FOURCC('A', 'I', 'P', '='), sizeof(u_char), &val);
//    }        
//    cm_stack->sleep_period = (u_char) --val;
    
//    len = btn_eepromdb_get(FOURCC('A', 'I', 'T', '='), sizeof(u_char), &val);
//    if ((len==0) || (val==0)){
//	    val = CM_AITIME;	
//	    ++val;
//        btn_eepromdb_store(FOURCC('A','I','T','='), sizeof(u_char), &val);
//    }        
//    cm_stack->ai_time = (u_char) --val;
    
//    len = btn_eepromdb_get(FOURCC('C', 'M', 'S', '='), sizeof(u_char), &val);
//    if (len==0){
//	    val = CM_MAX_SLAVES;	
//        btn_eepromdb_store(FOURCC('C','M','S','='), sizeof(u_char), &val);
//    }        
//    cm_stack->max_slaves = (u_char) val;
//    val = CM_MAX_SLAVES;

	// initialize mutex
    _bt_semaphore_init(&(cm_stack->rel_con_cb_mutex), 1);
    INFO("rel_con_cb_mutex: %p\n", &(cm_stack->rel_con_cb_mutex));

    // set default link policy (disable all)
    retval = bt_hci_write_default_link_policy_settings(cm_stack->bt_stack, BT_HCI_SYNC, 0x0000);
    DEBUG("link policy changed = %d\n", retval);

	// register cm on l2cap_cl layer
	retval =
		bt_psm_service_register(psmux, psm, _cm_data_cb, NULL);
	if (retval < 0) {
        ERROR("could not register data callback\n");
        return;
    }

	// create pkt buffer queue
	cm_stack->buf_que = bt_acl_pkt_queue_create(bt_stack, 6);
	bt_psm_service_set_buffers(psmux, retval, &cm_stack->buf_que);
	
	// initialize con mgr interface
	con_mgr_stack.cm_fill_con_info = cm_tree_fill_con_info;
	con_mgr_stack.cm_inq_disable = cm_tree_inq_disable;
	con_mgr_stack.cm_inq_enable = cm_tree_inq_enable;
	con_mgr_stack.cm_reg_cmds = cm_tree_register_cmds;
	con_mgr_stack.cm_get_rel_cons = cm_tree_get_rel_cons;
    con_mgr_stack.cm_get_info = cm_tree_get_info;
    con_mgr_stack.cm_inq_set_period = cm_tree_inq_set_period;
    con_mgr_stack.cm_reset = cm_tree_reset;
    con_mgr_stack.con_table_cb = NULL;
    con_mgr_stack.con_table_cb_arg = NULL;
	
    // start con event buffer
    NutThreadCreate("CON_BUF", CON_EVENT_BUF, 0, NUT_DEFAULT_STACKSIZE);
	
    // start conmgr thread
    NutThreadCreate("ConmgrI", CONMGR_INQUIRY_T, 0, NUT_DEFAULT_STACKSIZE);
}
