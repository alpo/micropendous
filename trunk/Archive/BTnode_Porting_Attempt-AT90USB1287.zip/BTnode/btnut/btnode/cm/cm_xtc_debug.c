#include <stdio.h>
#include <string.h>
#include <debug/toolbox.h>
#include <bt/bt_hci_api.h>
#include <terminal/btn-terminal.h>
#include <cm/cm_xtc_defs.h>

char _cm_dbg_buf[400]; 

//const char* _cm_dbg_inqres_to_string_old(struct bt_hci_inquiry_result* inqres)
//{
//	char* ptr = _cm_dbg_buf;
//    sprintf(ptr, "%s 0x%.8lx %4.d", dbg_bt_addr_to_str(inqres->bdaddr), inqres->cod, inqres->rssi);
//    return _cm_dbg_buf;
//}

//void _cm_dbg_dump_inqres_old(void) {
//	u_char i;
//	DEBUG("bt_addr           cod         RSSI\n");
//	for (i=0; i<cm_stack->nr_inq_devs; i++) {
//    	DEBUG_STR("%s\n", _cm_dbg_inqres_to_string_old(&cm_stack->inqres[i]));
//	}
//}

//const char* _cm_dbg_neigh_to_string(cm_neigh_t* neigh) {
//	char* ptr = _cm_dbg_buf;
//    ptr += sprintf(ptr, "%s %4.d %3.d ",
//        dbg_bt_addr_to_str(neigh->addr),
//        neigh->rssi,
//        neigh->con_handle);
//    if (neigh->better_com_neigh != NULL) {
//    	ptr += sprintf(ptr, "%s ", dbg_bt_addr_to_str(neigh->better_com_neigh->addr));
//    }
//    ptr += sprintf(ptr, "%d", neigh->last_seen);
//	return _cm_dbg_buf;
//}

const char* _cm_dbg_rel_cons_to_string(cm_neigh_t** order, u_char size) {
	u_char i;
	char* ptr = _cm_dbg_buf;
	ptr += sprintf(ptr, "rel cons:");
	for (i=0; i<size; i++) {
		if (order[i]->con_handle != BT_HCI_HANDLE_INVALID)
			ptr += sprintf(ptr, "%d, ", order[i]->con_handle);
	}
	return _cm_dbg_buf;
}

const char* _cm_dbg_master_devs_to_string(cm_neigh_t** order, u_char size) {
	u_char i;
	char* ptr = _cm_dbg_buf;
	ptr += sprintf(ptr, "master devs:\n");
	for (i=0; i<size; i++) {
		if (bt_hci_local_role_discovery(cm_stack->bt_stack, order[i]->con_handle) == BT_HCI_MY_ROLE_SLAVE)
			ptr += sprintf(ptr, "%uli, ", order[i]->con_handle);
	}
	return _cm_dbg_buf;
}

//void _cm_dbg_dump_neighbor_order(void) {
//	u_char i;
//	DEBUG("bt_addr           RSSI hdl better_neigh last_seen\n");
//	for (i=0; i<cm_stack->nr_neighbors; i++) {
//    	DEBUG_STR("%s\n", _cm_dbg_neigh_to_string(cm_stack->neighbors[i]));
//	}
//}

const char* _cm_dbg_order_to_str(void)
{
	u_char i;
	char* ptr = _cm_dbg_buf;
	cm_neigh_t* neigh;
	
	// initialize the debug buffer
	_cm_dbg_buf[0] = 0;
	
	for (i=0; i<cm_stack->nr_neighbors; i++) {
		neigh = cm_stack->neighbors[i];
		ptr += sprintf(ptr, "\t" SADDR_FMT " %d %.d ", SADDR(neigh->addr), neigh->rssi, neigh->con_handle);
		if (neigh->better_com_neigh)
			ptr += sprintf(ptr, SADDR_FMT, SADDR(neigh->better_com_neigh->addr));
		else
			ptr += sprintf(ptr, "00:00");
		ptr += sprintf(ptr, " %d\n", neigh->last_seen);
	}
	return _cm_dbg_buf;
}

const char* _cm_dbg_inqres_to_str(void)
{
	u_char i;
	char* ptr = _cm_dbg_buf;
	struct bt_hci_inquiry_result* inqres;

	// initialize the debug buffer
	_cm_dbg_buf[0] = 0;
		
	for (i=0; i<cm_stack->nr_inq_devs; i++) {
		inqres = &cm_stack->inqres[i];
		ptr += sprintf(ptr, "|" SADDR_FMT " %d ", SADDR(inqres->bdaddr), inqres->rssi);
	}
	return _cm_dbg_buf;
}

const char* _cm_dbg_que_to_str(cm_que_t* que)
{
	char* ptr = _cm_dbg_buf;

	// initialize the debug buffer
	_cm_dbg_buf[0] = 0;
			
	while (que->next != NULL) {
		ptr += sprintf(ptr, "|" SADDR_FMT " ", SADDR(que->next->addr));
		que = que->next;
	}
	return _cm_dbg_buf;
}

///** \brief Does an inquiry and dates up the neighbor order accordingly
// * 
// * Command: cm inq
// */
//void _cm_cmd_inquiry(void) {
//    long nr_devs;
//    tprintf("Starting sync inquiry for %d secs...\n", cm_stack->ai_time);
//    // do inquiry
//    nr_devs = bt_hci_inquiry(cm_stack->bt_stack,
//    	BT_HCI_SYNC,
//    	cm_stack->ai_time,
//    	CM_MAX_INQ_DEVS,
//    	cm_stack->inqres);
//    tprintf("Done.\n");
//    cm_print_neighbors();
//    tprintf("Found %d new device(s)!\n", nr_devs);
//}
//
//
///** \brief Sends an order packet to the neighbor specified.
// * 
// * This function sends an order packet to the neighbor specified by the index
// * passed (can be obtained by printing the neighbor order). Note that this
// * may cause the connection to be dropped.
// * 
// * Command: cm check
// */
//void _cm_cmd_con_check(u_char* arg) {
//    long res;
//    int index=-1;
//    cm_neigh_t* neighbor;
//    
//    if (sscanf(arg, "check%u", &index)==1) {
//        // if invalid index
//        if (index >= cm_stack->nr_neighbors) {
//            tprintf("cm con: error: device index out of bounds\n");
//            return;
//        }
//        tprintf("checking connection to dev: ");
//        if (index > -1) { //call with addr in neighbor struct (in neighbor list)
//            neighbor = cm_stack->neighbors[index];
//            //bt_addr_to_string(cm_stack->addr_buf, neighbor->inqres.bdaddr);
//            tprintf("\n");
//            res = _cm_send_order_pkt(cm_stack->acl_com_stack,
//                &cm_stack->acl_pkt, neighbor);
//            if (res < 0) { //error
//                tprintf("cm check: error: cannot send packet. (0x%.2x)\n",-res);
//            }
//            else {
//                tprintf("cm check: packet sent! %d\n", neighbor->con_handle);
//            }
//        }
//        else tprintf("cm check: error: device index out of bounds\n");
//    }
//    else {
//        tprintf("cm check: error: usage: con <index>\n");
//    }
//}
//
///** \brief Empties the queue specified
// * 
// * 0: Connection establishment queue
// * 1: Send queue
// * 
// * Command: cm flush [queue]
// */
//void _cm_cmd_flush_queue(u_char* arg) {
//    int val;
//    if (sscanf(arg, "flush%u", &val)==1) {
//    	switch (val) {
//    	case 0: NutEventPost(&cm_stack->con_mgr_start); break;
//    	case 1: _cm_empty_send_buf(); break;
//    	default:
//			tprintf("cm queue: error: invalid argument! use:\n"
//				   "	0: connection establishment queue\n"
//				   "	1: send queue\n");
//		}
//    }
//    else {
//        tprintf("cm flush: error: usage: cm flush <queue>\n");
//    }
//}

void _cm_cmds_print_usage(void)
{
	tprintf(" cm inqres\n"
           " cm neighbors\n"
           " cm conbuf\n"
           " cm masters\n"
           " cm rc\n"
		   " cm inq\n"
           " cm con [INDEX]\n"
           " cm check [INDEX]\n"
           " cm flush [QUEUE]\n");
}

void _cm_cmds_cm_cmd(char * arg)
{
    if (!strncmp(arg, "neighbors", 9)) {
        tprintf( "order: %s\n", _cm_dbg_order_to_str());
    } else if (!strncmp(arg, "inqres", 6)) {
        tprintf( "inqres: %s\n", _cm_dbg_inqres_to_str());
    } else if (!strncmp(arg, "conbuf", 6)) {
		cm_neigh_t* current = &cm_stack->con_buf;
		tprintf( "con buf: ");
		while (current->next != NULL) {
			tprintf( "%s, ", dbg_bt_addr_to_str(current->next->addr));
			current = current->next;
		}
		tprintf("\n");
    } else if (!strncmp(arg, "masters", 7)) {
        puts(_cm_dbg_master_devs_to_string(cm_stack->neighbors, cm_stack->nr_neighbors));
    } else if (!strncmp(arg, "rc", 2)) {
        puts(_cm_dbg_rel_cons_to_string(cm_stack->neighbors, cm_stack->nr_neighbors));
//    } else if (!strncmp(arg, "inq", 3)) {
//        _cm_cmd_inquiry();
//    } else if (!strncmp(arg, "con", 3)) {
//    } else if (!strncmp(arg, "check", 5)) {
//        _cm_cmd_con_check(arg);
//    } else if (!strncmp(arg, "flush", 5)) {
//        _cm_cmd_flush_queue(arg);
    } else {
        _cm_cmds_print_usage();
    }
}

void cm_xtc_register_dbg_cmds(void)
{
    btn_terminal_register_cmd("cm", _cm_cmds_cm_cmd);
}
