/*!
 * \file abstract_con_mgr.c
 * \brief Template for the Connection Manager
 * 
 * This is the simplified version of the connection manager.
 */

#include <terminal/btn-terminal.h>
#include <led/btn-led.h>
#include <stdlib.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_defs.h>
#include <bt/l2cap_cl.h>
#include <sys/types.h>
#include <sys/event.h>
#include <sys/thread.h>
#include <sys/heap.h>
#include <eepromdb/btn-eepromdb.h>
#include <string.h>
#include <cm/_con_mgr.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CM
#define LOG_LEVEL SYSLOG_LEVEL_CM
#include <debug/log_set.h>

#define CM_LINK_TIMEOUT 8000 ///< link supervision timeout (8000 slots = 5s)

//heartbeat (only showing if device is not connected)
#define CM_LED_HB_PAUSE 50
#define CM_LED_HB_DURATION 2

typedef struct _cm_stack {
    bt_addr_t my_addr;
    struct bt_hci_cmd_response response;
    struct btstack *bt_stack;   // pointer to lower level hci stack 
    u_long cod;
} cm_stack_t;

cm_stack_t* cm_stack;

void _cm_change_disconnect_timeout(bt_hci_con_handle_t con_handle)
{
    long res;
    INFO("CM: changing disc timeout ...");
    res = bt_hci_write_link_supervision_timeout(cm_stack->bt_stack, BT_HCI_SYNC, con_handle, CM_LINK_TIMEOUT);
    INFO("done\n");      
    if (res < 0){
        WARNING("write link superv. timeout failed\n");
    }
}


/* Here comes the code for handling changes in the connection table.
 */
void _con_table_change_cb(u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg)
{
    // change connection properties
    if (type == BT_HCI_CONNECTION) {
        if (detail == BT_HCI_CONNECTION_ACTIVE){
            _cm_change_disconnect_timeout(con_handle);
        }
    }
    con_mgr_stack.con_table_cb(type, detail, con_handle, con_mgr_stack.con_table_cb_arg);
}

void cm_abstract_inq_disable(void) {
}

void cm_abstract_inq_enable(void) {
}

void _cm_cmds_print_usage(void)
{
    tprintf("cm: no commands registered\n");
//    INFO(LOG_TERMINAL,"cm: error: usage: cm ...\n");
}

void _cm_cmds_cm_cmd(char * arg)
{
        _cm_cmds_print_usage();
}

void cm_abstract_register_cmds(void)
{
    btn_terminal_register_cmd("cm", _cm_cmds_cm_cmd);
}

short cm_abstract_fill_con_info(u_char* args, u_char* param){    
    bt_hci_con_handle_array con_handles;
    u_char nr_open_con,i;
    bt_addr_t addr;
    long role;
    char rssi;

    nr_open_con = (u_char)bt_hci_get_con_handles(cm_stack->bt_stack, con_handles);

    // write nr of entries to first byte
    *args++ = nr_open_con;

    for (i=0; i<nr_open_con; i++) {
        // copy bd addr
        bt_hci_get_remote_bt_addr(cm_stack->bt_stack, con_handles[i], addr);
        memcpy(args, addr, 2);
        args += 2;
        // copy role         
        role = bt_hci_local_role_discovery(cm_stack->bt_stack, con_handles[i]);
        if (role == BT_HCI_MY_ROLE_MASTER){
          *args++ = 2; // neighbor is my slave
        } 
        else{
          *args++ = 1; // neighbor is my master
        }
        // copy rssi
        bt_hci_read_abs_rssi(cm_stack->bt_stack, BT_HCI_SYNC, con_handles[i], &rssi);
        *args++ = rssi;
    }
    return (1 + nr_open_con*4);
}

u_char cm_abstract_get_rel_cons(bt_hci_con_handle_t *rel_cons)
{
    return bt_hci_get_con_handles(cm_stack->bt_stack, rel_cons);
}

char* cm_abstract_get_info(void){
    return "Abstract";
}

void cm_abstract_init(struct btstack *bt_stack,
						bt_psm_t* psmux,
						u_short cm_psm,
						HCI_CON_TABLE_CB_REGISTRATION,
						u_long cod)
{
    long retval;
    //dyn alloc tp stack
    cm_stack = NutHeapAllocClear(sizeof(cm_stack_t));
    cm_stack->bt_stack = bt_stack;
    cm_stack->cod = cod;
    bt_hci_get_local_bt_addr(cm_stack->bt_stack, cm_stack->my_addr);
    // register con table change callback
    con_table_cb_reg(bt_stack, _con_table_change_cb, NULL);

    // seed random number generator with my MAC
    btn_led_heartbeat(CM_LED_HB_PAUSE, 1, CM_LED_HB_DURATION);
    bt_hci_write_local_cod(cm_stack->bt_stack, BT_HCI_SYNC, cod);
    
	// initialize con mgr interface
	con_mgr_stack.cm_fill_con_info = cm_abstract_fill_con_info;
	con_mgr_stack.cm_inq_disable = cm_abstract_inq_disable;
	con_mgr_stack.cm_inq_enable = cm_abstract_inq_enable;
	con_mgr_stack.cm_reg_cmds = cm_abstract_register_cmds;
	con_mgr_stack.cm_get_rel_cons = cm_abstract_get_rel_cons;
    con_mgr_stack.cm_get_info = cm_abstract_get_info;
    
    // set default link policy (enable roleswitch, disable all others)
    retval = bt_hci_write_default_link_policy_settings(cm_stack->bt_stack, BT_HCI_SYNC, BT_HCI_LINK_POLICY_ROLE_SWITCH);
    DEBUG("link policy changed = %d\n", retval);
}
