/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: con_mgr.c,v 1.8 2006/10/23 11:25:11 kevmarti Exp $
 * 
 */

/*!
 * $Log: con_mgr.c,v $
 * Revision 1.8  2006/10/23 11:25:11  kevmarti
 * Added interface for resetting the connection manager
 *
 * Revision 1.7  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * 
 */ 

/*
 * @file con_mgr.c
 *
 * \date 2006/03/29 
 *
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch.ch>
 * 
 */

#include <cm/_con_mgr.h>

/**
 * \brief Registers terminal commands of the connection manager.
 * Call this function if you need the debug and control commands of the 
 * connection manager.
 */
void con_mgr_register_cmds(void)
{
	if (con_mgr_stack.cm_reg_cmds)
		con_mgr_stack.cm_reg_cmds();
}

/**
 * \brief Disables BT inquiries.
 * Blocks if an inquiry is already in progress.
 */
void con_mgr_inq_disable(void)
{
	if (con_mgr_stack.cm_inq_disable)
		con_mgr_stack.cm_inq_disable();
}

/**
 * \brief Reenables BT inquiries.
 * 
 * Note: inquiries are enabled iff nr of calls to 'con_mgr_inq_enable()'
 * (including this call) equals nr of calls to 'con_mgr_inq_disable()'.
 * Ex: if two threads both call 'con_mgr_inq_disable()' inquiries won't be
 * re-enabled until both threads called 'con_mgr_inq_enable()'.
 */
void con_mgr_inq_enable(void)
{
	if (con_mgr_stack.cm_inq_enable)
		con_mgr_stack.cm_inq_enable();
}

/**
 * \brief Sets inquiry period.
 */
void con_mgr_inq_set_period(u_short val)
{
	if (con_mgr_stack.cm_inq_set_period)
		con_mgr_stack.cm_inq_set_period(val);
}

short con_mgr_fill_con_info(u_char* args, u_char* param)
{
	if (con_mgr_stack.cm_fill_con_info)
		return con_mgr_stack.cm_fill_con_info(args, param);
	else
		return 0;
}

u_char con_mgr_get_rel_cons(bt_hci_con_handle_t *rel_cons)
{
	if (con_mgr_stack.cm_get_rel_cons)
		return con_mgr_stack.cm_get_rel_cons(rel_cons);
	else
		return 0;
}

char* con_mgr_get_info(void)
{
	if (con_mgr_stack.cm_get_info)
    	return con_mgr_stack.cm_get_info();
    else
    	return 0;
}

void con_mgr_reset(void)
{
	if (con_mgr_stack.cm_reset)
		con_mgr_stack.cm_reset();
}


void con_mgr_register_con_table_cb(struct btstack* bt_stack, HCI_CON_TABLE_CB, void* cb_arg)
{
	con_mgr_stack.con_table_cb = con_table_cb;
	con_mgr_stack.con_table_cb_arg = cb_arg;
}
