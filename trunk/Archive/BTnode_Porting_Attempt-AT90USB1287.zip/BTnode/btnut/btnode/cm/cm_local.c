/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * @file cm_local.c
 *
 * @brief Implementation of a simple connection manager
 *  
 * \author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 * 
 * \date 2006/04/06
 *
 * $Log: cm_local.c,v $
 * Revision 1.14  2006/11/06 11:32:51  yuecelm
 * move my email address to a permanent one
 *
 * Revision 1.13  2006/10/26 13:27:32  kevmarti
 * - Adaption to obsolete typedef 'bt_msg'
 * - Included syslog debug definitions
 *
 * Revision 1.12  2006/09/25 14:43:25  kevmarti
 * Removed con accept filter callback
 *
 * Revision 1.11  2006/07/28 16:46:37  yuecelm
 * minor changes
 *
 * Revision 1.10  2006/07/28 16:44:47  yuecelm
 * remove unused variable `dead_counter'
 *
 * Revision 1.9  2006/07/28 16:35:41  yuecelm
 * revert inquiry and page requests to use BT_HCI_SYNC
 *
 * Revision 1.8  2006/07/18 14:01:36  kevmarti
 * removed duplicated inclusion of 'avr/wdt.h'
 *
 * Revision 1.7  2006/07/18 13:14:13  kevmarti
 * Use watchdog-timer only if we are on AVR (i.e. don't use it on UNIX)
 *
 * Revision 1.6  2006/06/18 19:37:43  yuecelm
 * refactoring, includes the CPM
 *
 * Revision 1.5  2006/05/15 12:29:35  yuecelm
 * comment out LOG_LEVEL macro
 *
 * Revision 1.4  2006/05/15 12:19:32  yuecelm
 * set log level to 0, corrected bug in eeprom macro
 *
 * Revision 1.3  2006/05/13 01:39:25  yuecelm
 * corrected debug logging macros (closes CruiseControls Build Failed)
 *
 * Revision 1.2  2006/05/13 01:14:40  yuecelm
 * cm_local in usable state
 *
 * Revision 1.1  2006/04/21 12:50:35  yuecelm
 * add first version of my connection manager,
 * corrections in connection power manager
 *
 */

#include <cm/cm_local.h>
#include <stdlib.h>
#include <string.h>
#include <bt/bt_defs.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_psm.h>
#include <cm/_con_mgr.h>
#include <debug/toolbox.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/mutex.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CM
#define LOG_LEVEL SYSLOG_LEVEL_CM
#include <debug/log_set.h>

// Connection Power Manager
#define USE_CPM 1

// EEPROM parameters
#define READ_EEPROM 0

// LED signalling
#define CM_LED_SIGNALLING 1


#if USE_CPM > 0
#include <cm/con_power_mgr.h>
#include <terminal/btn-terminal.h>
static u_char cm_cpm_registered = 0;
#endif

#if READ_EEPROM > 0
#include <terminal/eeprom_cmds.h>
#endif

#if CM_LED_SIGNALLING > 0
#include <led/btn-led.h>
#define BLUE   0
#define RED    1
#define ORANGE 2
#define GREEN  3
#define CM_LED_SET(c) btn_led_set(c)
#define CM_LED_CLEAR(c) btn_led_clear(c)
#else
#define CM_LED_SET(c)
#define CM_LED_CLEAR(c)
#endif

#define CM_SCAN_MODE_INQUIRY_PAGE              1
#define CM_SCAN_MODE_TIMEOUT_THEN_PAGE         BT_HCI_SCAN_MODE_PAGE /* 2 */
#define CM_SCAN_MODE_TIMEOUT_THEN_INQUIRY_PAGE BT_HCI_SCAN_MODE_INQUIRY_PAGE /* 3 */ 

#define CM_NEIGH_ROLE_MASTER                   BT_HCI_MY_ROLE_MASTER + 1
#define CM_NEIGH_ROLE_SLAVE                    BT_HCI_MY_ROLE_SLAVE + 1
#define CM_SNIFF_MODE                          4

// shift prev and entry
#define _CM_SHIFT_ENTRY(prev, entry) \
    prev = entry; \
    entry = entry->next; \

// set next pointer from previous_entry to next_entry
// free entry
// set entry to next_entry (shift)
#define _CM_DELETE_AND_SHIFT_ENTRY(head, prev, entry) \
    if (prev == NULL) { \
        head = entry->next; \
        NutHeapFree(entry); \
        entry = head; \
    } else { \
        prev->next = entry->next; \
        NutHeapFree(entry); \
        entry = prev->next; \
    } \

// temporary store second_last_entry
// set tail pointer to entry
// if head == 0,
//   set head pointer to entry (only one entry in list, second_last_entry is anywas NULL)
// else
//   set next pointer of second_last_entry to entry (=last_entry)
//   set next pointer to NULL (termination) 
#define _CM_APPEND_ENTRY(head, tail, entry) \
    entry->next = tail; \
    tail = entry; \
    if (head == NULL) { head = entry; } \
    else { \
        entry->next->next = entry; \
        entry->next = NULL; } \

// shift prev, entry1 and entry2
// used in bubblesort function
#define _CM_SHIFT_ENTRIES(prev, entry1, entry2) \
    prev = entry1; \
    entry1 = entry2; \
    entry2 = entry2->next; \

// swap entry1 and entry2, considering all next pointers (incl. head and tail)
// shift prev and entry2 (entry1 already shifted by swapping)
// used in bubblesort function
#define _CM_SWAP_AND_SHIFT_ENTRIES(index, head, prev, entry1, entry2) \
    if (index == 0) { head = entry2; } else { prev->next = entry2; } \
    entry1->next = entry2->next; \
    entry2->next = page_list_entry1; \
    prev = entry2; \
    entry2 = entry1->next; \

#define PARAMS(y) void _cm_eeprom_params_init(void) {y}
#define PARAMS_INIT() _cm_eeprom_params_init()

#if READ_EEPROM > 0
#define EEPROM_PARAM(param_name, param_id, param_val, param_default_val) \
    eeprom_cmds_param_ext_read(param_id, &param_val, param_default_val); \
    eeprom_cmds_add_param(param_name, param_id, &param_val, param_default_val);
#else  // READ_EEPROM <= 0
#define EEPROM_PARAM(param_name, param_id, param_val, param_default_val) \
    param_val = param_default_val;
#endif // READ_EEPROM

// entry of page_list
typedef struct _cm_local_page_list_entry {
    u_short saddr;
    bt_addr_t addr;
    u_char page_scan_rep_mode;
    u_short clock_offset;
    short rssi;
    u_char inq_counts;
    u_char page_attempts;
    u_long timestamp;
    struct _cm_local_page_list_entry * next;
} cm_local_page_list_entry_t;

// entry of page_blacklist
typedef struct _cm_local_page_blacklist_entry {
    u_short saddr;
    u_long timestamp;
    struct _cm_local_page_blacklist_entry * next;
} cm_local_page_blacklist_entry_t;

// Connection Manager (CM) stack
typedef struct _cm_local_stack {
    struct btstack * bt_stack; 
    u_long cod;    
    u_long thread_priority;  // (u_short)
    u_long sleep_time;
    u_long min_sleep_time;
    u_long max_sleep_time;
    u_long step_sleep_time;
    struct bt_hci_cmd_response async_response;
    struct bt_hci_inquiry_result inq_results[CM_INQ_MAX_DEVS];
    u_char inq_counts;
    u_long inq_duration; // (u_char)
    MUTEX accept_con_cb_mutex;
    MUTEX change_scan_mode_mutex;
    MUTEX hci_mutex;
    u_long page_timeout; // (u_short)
    cm_local_page_list_entry_t * page_list_head;
    cm_local_page_list_entry_t * page_list_tail;
    u_long page_list_time_out; // (u_short)
    u_long page_max_page_attempts; // (u_char)
    cm_local_page_blacklist_entry_t * page_blacklist_head;
    cm_local_page_blacklist_entry_t * page_blacklist_tail;
    u_long page_blacklist_off_time; // (u_char)
    u_char cur_scan_mode;
    u_char scan_mode;
    u_char next_scan_mode;
    u_long scan_mode_timeout;
    u_long inq_scan_mode; // (u_char)
    u_long page_scan_mode; // (u_char)
    u_long my_role_master_max_own_devices; // (u_char)
    u_char my_role_master_own_devices;
    u_long my_role_master_max_foreign_devices; // (u_char)
    u_char my_role_master_foreign_devices;
    u_long my_role_slave_max_own_devices; // (u_char)
    u_char my_role_slave_own_devices;
    u_long my_role_slave_max_foreign_devices; // (u_char)
    u_char my_role_slave_foreign_devices;
    u_char inq_disabled;
} cm_local_stack_t;

// global pointer to the CM stack
static cm_local_stack_t * cm_stack;

PARAMS(
    EEPROM_PARAM("cm_tp", "cmtp", cm_stack->thread_priority, CM_DEFAULT_THREAD_PRIORITY)
    EEPROM_PARAM("cm_tmaxst", "cms-", cm_stack->min_sleep_time, CM_DEFAULT_MIN_SLEEP_TIME)
    EEPROM_PARAM("cm_tminst", "cms+", cm_stack->max_sleep_time, CM_DEFAULT_MAX_SLEEP_TIME)
    EEPROM_PARAM("cm_tsst", "cmss", cm_stack->step_sleep_time, CM_DEFAULT_STEP_SLEEP_TIME)
    EEPROM_PARAM("cm_id", "cmid", cm_stack->inq_duration, CM_DEFAULT_INQ_DURATION)
    EEPROM_PARAM("cm_ism", "cmis", cm_stack->inq_scan_mode, CM_DEFAULT_INQ_SCAN_MODE)
    EEPROM_PARAM("cm_pt", "cmpt", cm_stack->page_timeout, CM_DEFAULT_PAGE_TIMEOUT)
    EEPROM_PARAM("cm_psm", "cmps", cm_stack->page_scan_mode, CM_DEFAULT_PAGE_SCAN_MODE)
    EEPROM_PARAM("cm_smt", "cmst", cm_stack->scan_mode_timeout, CM_DEFAULT_SCAN_MODE_TIMEOUT)
    EEPROM_PARAM("cm_pbot", "cmbo", cm_stack->page_blacklist_off_time, CM_DEFAULT_PAGE_BLACKLIST_EXP_TIME)
    EEPROM_PARAM("cm_plto", "cmto", cm_stack->page_list_time_out, CM_DEFAULT_PAGE_LIST_EXP_TIME)
    EEPROM_PARAM("cm_pmpa", "cmmp", cm_stack->page_max_page_attempts, CM_DEFAULT_PAGE_MAX_PAGE_ATTEMPTS)
    EEPROM_PARAM("cm_mrmmod", "cmmo", cm_stack->my_role_master_max_own_devices, CM_DEFAULT_MY_ROLE_MASTER_MAX_OWN_DEVICES)
    EEPROM_PARAM("cm_mrmmfd", "cmmf", cm_stack->my_role_master_max_foreign_devices, CM_DEFAULT_MY_ROLE_MASTER_MAX_FOREIGN_DEVICES)
    EEPROM_PARAM("cm_mrsmod", "cmso", cm_stack->my_role_slave_max_own_devices, CM_DEFAULT_MY_ROLE_SLAVE_MAX_OWN_DEVICES)
    EEPROM_PARAM("cm_mrsmfd", "cmsf", cm_stack->my_role_slave_max_foreign_devices, CM_DEFAULT_MY_ROLE_SLAVE_MAX_FOREIGN_DEVICES)
)

/**
 * \brief Returns a random sleep time
 * 
 * Returns a random sleep time in [0, max_sleep]
 */
u_long _cm_local_get_random_sleep_time(u_long max_sleep)
{
    return ((max_sleep*rand())/RAND_MAX);
}

/**
 * \brief Sets scan mode
 * 
 * Scan mode will only setted if different from actual scan mode
 */
void _cm_local_write_scan_mode(u_char scan_mode)
{
    if (scan_mode == cm_stack->cur_scan_mode)
    {
        return;   
    }
    
    long res;
    
    DEBUG("set scan mode to %d\n", scan_mode);
    res = bt_hci_write_scan_enable(cm_stack->bt_stack, BT_HCI_SYNC, scan_mode);
    if (res < 0)
    {
        WARNING("cannot write scan mode (%d)\n", res);   
    }
    else
    {
        cm_stack->cur_scan_mode = scan_mode;   
    }
}

/**
 * \brief Seeks short address in page_blacklist
 * 
 * Returns 0 if not found, else negative value 
 */
char _cm_local_check_page_blacklist(u_short saddr)
{
    cm_local_page_blacklist_entry_t * page_blacklist_entry =
                                      cm_stack->page_blacklist_head;
    while (page_blacklist_entry != NULL)
    {
        if (saddr == page_blacklist_entry->saddr)
        {
            return -1;
        }
        page_blacklist_entry = page_blacklist_entry->next;
    }
    
    return 0;
}

/**
 * \brief Seeks short address in the connection table
 * 
 * Returns 0 if not found, else negative value 
 */
char _cm_local_check_contable(u_short saddr)
{
    bt_hci_con_handle_array con_handles;
    bt_addr_t addr;
    u_char nr_open_con, j;
    
    nr_open_con = (u_char) bt_hci_get_con_handles(cm_stack->bt_stack,
                                                  con_handles);
    for (j=0; j<nr_open_con; j++)
    {
        if (bt_hci_get_remote_bt_addr(cm_stack->bt_stack, con_handles[j],
                                      addr) != 0)
        {
            // BT_ERR_NO_CON returned
            continue;
        }
        
        if (saddr == (addr[1] << 8 | addr[0]) + 1)
        {
            return -1;
        }
    }
    
    return 0;
}

/**
 * \brief Updates page_list with new or existing entry
 * 
 * Updates entry (inq_counts, clock_offset, rssi, timestamp) if found in page_list,
 *   else appends to page_list
 */
void _cm_local_update_page_list(u_short saddr, 
                                struct bt_hci_inquiry_result inq_result)
{
    cm_local_page_list_entry_t * page_list_entry = cm_stack->page_list_head;
    while (page_list_entry != NULL)
    {
        if (saddr == page_list_entry->saddr)
        {
            // update entry
            page_list_entry->inq_counts++;
            page_list_entry->clock_offset = inq_result.clock_offset;
            page_list_entry->rssi = inq_result.rssi;
            page_list_entry->timestamp = NutGetSeconds();
            
            DEBUG("\t\tcandidate %d updated in pagelist (counts: %d)\n",
                  saddr, page_list_entry->inq_counts);
            
            return;
        }
        page_list_entry = page_list_entry->next;
    }
    
    // append entry
    page_list_entry = NutHeapAlloc(sizeof(cm_local_page_list_entry_t));
    page_list_entry->saddr = saddr;
    memcpy(page_list_entry->addr, inq_result.bdaddr, sizeof(bt_addr_t));
    page_list_entry->page_scan_rep_mode = inq_result.page_scan_rep_mode;
    page_list_entry->clock_offset = inq_result.clock_offset;
    page_list_entry->rssi = inq_result.rssi;
    page_list_entry->inq_counts = 1;
    page_list_entry->page_attempts = 0;
    page_list_entry->timestamp = NutGetSeconds();

    _CM_APPEND_ENTRY(cm_stack->page_list_head, cm_stack->page_list_tail, 
                     page_list_entry);

    DEBUG("\t\tcandidate %d added to pagelist\n", saddr,
          page_list_entry->rssi);
}

/**
 * \brief Updates page_blacklist with new or existing entry
 * 
 * Updates entry (timestamp) if found in page_blacklist,
 *   else appends to page_blacklist
 */
void _cm_local_update_page_blacklist(u_short saddr)
{
    cm_local_page_blacklist_entry_t * page_blacklist_entry =
                                      cm_stack->page_blacklist_head;
    while (page_blacklist_entry != NULL)
    {
        if (saddr == page_blacklist_entry->saddr)
        {
            // update entry
            page_blacklist_entry->timestamp = NutGetSeconds();
            
            DEBUG("\t\tcandidate %d updated in backlist\n", saddr);
            
            return;            
        }
        page_blacklist_entry = page_blacklist_entry->next;
    }

    // append entry
    page_blacklist_entry = NutHeapAlloc(sizeof(cm_local_page_blacklist_entry_t));
    page_blacklist_entry->saddr = saddr;
    page_blacklist_entry->timestamp = NutGetSeconds();

    _CM_APPEND_ENTRY(cm_stack->page_blacklist_head, 
                     cm_stack->page_blacklist_tail, 
                     page_blacklist_entry);

    DEBUG("\t\tcandidate %d added to blacklist\n", saddr);    
}

/**
 * \brief Removes expired entries in page_list
 * 
 * Expired: enough long time not discovered or paged too much
 */
inline void _cm_local_cleanup_page_list(void)
{
    cm_local_page_list_entry_t * page_list_prev = NULL;
    cm_local_page_list_entry_t * page_list_entry = cm_stack->page_list_head;
    while (page_list_entry != NULL)
    {
        if ((page_list_entry->timestamp + 
             cm_stack->page_list_time_out) < NutGetSeconds() ||
             page_list_entry->page_attempts > cm_stack->page_max_page_attempts)
        {
            if ((page_list_entry->timestamp + cm_stack->page_list_time_out) <
                 NutGetSeconds())
            {
                DEBUG("\tcandidate %d was not longer discovered!\n",
                      page_list_entry->saddr);
            }
            if (page_list_entry->page_attempts >
                     cm_stack->page_max_page_attempts)
            {
                DEBUG("\tcandidate %d was paged too much!\n",
                      page_list_entry->saddr);
                // add entry to blacklist
                _cm_local_update_page_blacklist(page_list_entry->saddr);                
            }

            // remove entry from list and shift by one
            _CM_DELETE_AND_SHIFT_ENTRY(cm_stack->page_list_head,
                                       page_list_prev, page_list_entry);
        }
        else
        {
            DEBUG("\tcandidate %d remains in pagelist\n",
                  page_list_entry->saddr);

            // shift by one in list
            _CM_SHIFT_ENTRY(page_list_prev, page_list_entry);
        }     
    }
    
    cm_stack->page_list_tail = page_list_prev;
}

/**
 * \brief Removes expired entries in page_blacklist
 * 
 * Expired: enough long time not blacklisted
 */
inline void _cm_local_cleanup_page_blacklist(void)
{
    cm_local_page_blacklist_entry_t * page_blacklist_prev = NULL;
    cm_local_page_blacklist_entry_t * page_blacklist_entry = cm_stack->page_blacklist_head;
    while (page_blacklist_entry != NULL)
    {
        if ((page_blacklist_entry->timestamp +
             cm_stack->page_blacklist_off_time) < NutGetSeconds())
        {
            DEBUG("\tcandidate %d is off-time in blacklist!\n",
                  page_blacklist_entry->saddr);

            // delete entry and shift by one
            _CM_DELETE_AND_SHIFT_ENTRY(cm_stack->page_blacklist_head,
                                       page_blacklist_prev,
                                       page_blacklist_entry);
            
            DEBUG("\t\tcandidate %d removed from blacklist!\n",
                  page_blacklist_entry->saddr);
        }
        else
        {
            DEBUG("\tcandidate %d remains in blacklist\n",
                  page_blacklist_entry->saddr);

            // shift one in list
            _CM_SHIFT_ENTRY(page_blacklist_prev, page_blacklist_entry);
        }        
    }    

    cm_stack->page_blacklist_tail = page_blacklist_prev;
}

/**
 * \brief Bubblesorting entries in page_list
 * 
 * Sort criteria: RSSI
 */
void _cm_local_sorting_page_list(void)
{
    // skip if no more than 1 entry
    if (cm_stack->page_list_head == NULL ||
        cm_stack->page_list_head->next == NULL)
    {
        DEBUG("\tno sorting necessary!\n");
        return;
    }
    
    DEBUG("\tlets BUBBLEsort!\n");
    
    u_char i;
    u_char count = 0;
    cm_local_page_list_entry_t * page_list_prev = NULL;
    cm_local_page_list_entry_t * page_list_entry1 = cm_stack->page_list_head;
    cm_local_page_list_entry_t * page_list_entry2 = page_list_entry1->next;
    while (page_list_entry2 != NULL)
    {
        if (page_list_entry1->rssi < page_list_entry2->rssi)
        {
            DEBUG("\tswap %d (%d) and %d (%d)\n",
                  page_list_entry1->saddr, page_list_entry1->rssi,
                  page_list_entry2->saddr, page_list_entry2->rssi);
            
            // swap
            _CM_SWAP_AND_SHIFT_ENTRIES(count, cm_stack->page_list_head,
                                       page_list_prev,
                                       page_list_entry1, page_list_entry2);
        }
        else
        {
            DEBUG("\t%not swap %d (%d) and %d (%d)\n",
                  page_list_entry1->saddr, page_list_entry1->rssi,
                  page_list_entry2->saddr, page_list_entry2->rssi);

            // shift
            _CM_SHIFT_ENTRIES(page_list_prev,
                              page_list_entry1, page_list_entry2);
        }
        
        count++;
    }
    
    cm_stack->page_list_tail = page_list_entry1;
    
    count--;

    while (count>0)
    {
        DEBUG("\tnew iteration\n");
        page_list_prev = NULL;
        page_list_entry1 = cm_stack->page_list_head;
        page_list_entry2 = page_list_entry1->next;
        for(i=0; i<count; i++)
        {
            if (page_list_entry1->rssi < page_list_entry2->rssi)
            {
                DEBUG("\tswap %d (%d) and %d (%d)\n",
                      page_list_entry1->saddr, page_list_entry1->rssi,
                      page_list_entry2->saddr, page_list_entry2->rssi);
                
                //  swap
                _CM_SWAP_AND_SHIFT_ENTRIES(i, cm_stack->page_list_head,
                                           page_list_prev,
                                           page_list_entry1,
                                           page_list_entry2);
            }
            else
            {
                DEBUG("\t%not swap %d (%d) and %d (%d)\n",
                      page_list_entry1->saddr, page_list_entry1->rssi,
                      page_list_entry2->saddr, page_list_entry2->rssi);
                
                // shift by one in list               
                _CM_SHIFT_ENTRIES(page_list_prev,
                                  page_list_entry1, page_list_entry2);
            }
        }
        count--;
    }
}

/**
 * \brief Returns size of page_list (#entries)
 */
u_char _cm_local_count_page_list_entries(void)
{
    u_char i = 0;
    cm_local_page_list_entry_t * page_list_entry = cm_stack->page_list_head;
    while (page_list_entry != NULL)
    {
        i++;
        page_list_entry = page_list_entry->next;
    }
    
    return i;
}

/**
 * \brief Returns size of page_blacklist (#entries)
 */
u_char _cm_local_count_page_blacklist_entries(void)
{
    u_char i = 0;
    cm_local_page_blacklist_entry_t * page_blacklist_entry =
                                      cm_stack->page_blacklist_head;
    while (page_blacklist_entry != NULL)
    {
        i++;
        page_blacklist_entry = page_blacklist_entry->next;
    }
    
    return i;
}

/**
 * \brief Compares address with prefix value (CM_BT_ADDR?)
 * 
 * Returns 0 if matched, else negative value 
 */
char _cm_local_check_mac_prefix(bt_addr_t addr)
{
    if (addr[5]==CM_BT_ADDR5 && addr[4]==CM_BT_ADDR4 && 
        addr[3]==CM_BT_ADDR3 && addr[2]==CM_BT_ADDR2)
    {
        return 0;
    }
    else
    {    
        return -1;
    }
}

// mutex lock
void _cm_local_mutex_lock(void)
{
    NutMutexLock(&cm_stack->hci_mutex);
#if USE_CPM > 0
    cpm_pause();
#endif       
}

// mutex unlock
void _cm_local_mutex_unlock(void)
{
#if USE_CPM > 0
    cpm_resume();
#endif
    NutMutexUnlock(&cm_stack->hci_mutex);
}

/**
 * \brief Compares CoD with the declared CoD on init 
 * 
 * Returns 0 if matched, else negative value
 */
char _cm_local_check_cod(u_long cod)
{
    if (cod == cm_stack->cod)
    {
        return 0;
    }
    else
    {
        return -1;
    }
}

#if LOG_LEVEL >= LOG_DEBUG

/**
 * \brief Prints out page_list entries with short address 
 */
void _cm_local_show_page_list(void)
{
    cm_local_page_list_entry_t * page_list_entry = cm_stack->page_list_head;
    while (page_list_entry != NULL)
    {
        DEBUG("PAGElisted: %d (%d)\n", page_list_entry->saddr,
              page_list_entry->rssi);
              
        // shift by one in list
        page_list_entry = page_list_entry->next;        
    }
}

/**
 * \brief Prints out page_blacklist entries with short address 
 */
void _cm_local_show_page_blacklist(void)
{
    cm_local_page_blacklist_entry_t * page_blacklist_entry = 
        cm_stack->page_blacklist_head;
    while (page_blacklist_entry != NULL)
    {
        DEBUG("BLACKlisted: %d\n", page_blacklist_entry->saddr);
        
        // shift by one in list
        page_blacklist_entry = page_blacklist_entry->next;        
    }
}

#endif // LOG_LEVEL >= LOG_DEBUG

/**
 * \brief Tries to connect to the devices in page_list 
 */
inline void _cm_local_proceed_page_list_entries(void)
{
    long res;
    cm_local_page_list_entry_t * page_list_prev = NULL;    
    cm_local_page_list_entry_t * page_list_entry = cm_stack->page_list_head;
    while (page_list_entry != NULL)
    {
        DEBUG("proceed page entry %d:\n", page_list_entry->saddr);

        // check limit
        if (cm_stack->my_role_master_own_devices >=
                cm_stack->my_role_master_max_own_devices)
        {
            DEBUG("\treach limit of connections\n");
            break;
        }
        
        NutSleep(_cm_local_get_random_sleep_time(cm_stack->min_sleep_time));

        /*
        // filter blacklist            
        if (_cm_local_check_page_blacklist(page_list_entry->saddr))
        {
            DEBUG("\tfiltered out due of blacklist\n");
            _CM_DELETE_AND_SHIFT_ENTRY(cm_stack->page_list_head,
                                       page_list_prev, page_list_entry);
            DEBUG("\tdelete entry %d from pagelist\n", page_list_entry->saddr);
            continue;
        }
        */
        
        // filter contable
        if (_cm_local_check_contable(page_list_entry->saddr))
        {
            DEBUG("\tfiltered out due of conlist\n");
            _CM_DELETE_AND_SHIFT_ENTRY(cm_stack->page_list_head,
                                       page_list_prev, page_list_entry);
            DEBUG("\tdelete entry %d from pagelist\n", page_list_entry->saddr);
            continue;
        }     

        _cm_local_mutex_lock();
        
        // set aedaquate scan mode for paging
        _cm_local_write_scan_mode(cm_stack->page_scan_mode);
        
        INFO("Try to connect to "ADDR_FMT"...\n",
             ADDR(page_list_entry->addr));

        CM_LED_SET(ORANGE);

        page_list_entry->page_attempts++;
        
        res = bt_hci_create_connection(cm_stack->bt_stack,
                                       BT_HCI_SYNC,
                                       page_list_entry->addr,
                                       BT_HCI_PACKET_TYPE_DM3, 
                                       page_list_entry->page_scan_rep_mode, 
                                       page_list_entry->clock_offset, 
                                       BT_HCI_ROLE_SWITCH_CHANGE);

        CM_LED_CLEAR(ORANGE);
        
        if (res < 0)
        {
            WARNING("Connect error (%d)\n", res);
            
            if (res == BT_ERR_CON_EXIST || res == BT_ERR_CON_PEND_PASSIVE)
            {
                // remove from page_list
                _CM_DELETE_AND_SHIFT_ENTRY(cm_stack->page_list_head,
                                           page_list_prev,
                                           page_list_entry);
            }
            else
            {
                _CM_SHIFT_ENTRY(page_list_prev, page_list_entry);                
            }            
        }
        else
        {
            INFO("Connect successful!\n", res);        

            DEBUG("\tdelete entry %d from pagelist\n",
                  page_list_entry->saddr);                
            
            // remove from page_list
            _CM_DELETE_AND_SHIFT_ENTRY(cm_stack->page_list_head,
                                       page_list_prev, page_list_entry);                                       
        }
        
        _cm_local_write_scan_mode(cm_stack->scan_mode);

        _cm_local_mutex_unlock();        
    }    
}

/**
 * \brief The main thread (inquiry, regenerate page_list, pages, sleep)
 */
THREAD(CM_LOCAL, arg)
{
    long res;
    u_short saddr;
    u_char i;
    
    NutThreadSetPriority(cm_stack->thread_priority);
    
    NutSleep(2000);

    while (1)
    {
        _cm_local_mutex_lock();

        // set aedaquate scan mode for inquiry
        _cm_local_write_scan_mode(cm_stack->inq_scan_mode);

        // async inquiry
        bt_hci_inquiry(cm_stack->bt_stack, &cm_stack->async_response,
                       cm_stack->inq_duration, CM_INQ_MAX_DEVS,
                       cm_stack->inq_results);
        
        CM_LED_SET(BLUE);
        
        INFO("Inquiry started...\n");
 
        INFO("Clean up lists (pagelist, blacklist)...\n");       
        _cm_local_cleanup_page_blacklist();
        _cm_local_cleanup_page_list();
        INFO("Clean up finished.\n");       
        
        INFO("Presorting pagelist...\n");
        _cm_local_sorting_page_list();
        INFO("Presorting finished.\n");
        
        res = NutEventWait(&cm_stack->async_response.block, NUT_WAIT_INFINITE);
        
        INFO("Inquiry finished.\n");

        res = cm_stack->async_response.response;

        _cm_local_write_scan_mode(cm_stack->scan_mode);
         
        if (res < 0)
        {
            ERROR("inquiry error (%d)\n", res);
            _cm_local_mutex_unlock();
            NutSleep(cm_stack->min_sleep_time);
            continue;
        }

        cm_stack->inq_counts = res;

        _cm_local_mutex_unlock();

        INFO("Found %d devices:\n", cm_stack->inq_counts);                
        for (i=0; i<cm_stack->inq_counts; i++)
        {
            DEBUG("\t"ADDR_FMT" 0x%.8lx %d\n",
                  ADDR(cm_stack->inq_results[i].bdaddr),
                  cm_stack->inq_results[i].cod, cm_stack->inq_results[i].rssi);

            // filter mac prefix
            if (_cm_local_check_mac_prefix(cm_stack->inq_results[i].bdaddr))
            {
                DEBUG("\t\tfiltered out due of mac prefix rule\n");
                continue;
            }

            // filter CoD
            if (_cm_local_check_cod(cm_stack->inq_results[i].cod))
            {
                DEBUG("\t\tfiltered out due of cod rule\n");
                continue;
            }
            
            saddr = (cm_stack->inq_results[i].bdaddr[1] << 8 | 
                     cm_stack->inq_results[i].bdaddr[0]) + 1;
            
            // filter blacklist            
            if (_cm_local_check_page_blacklist(saddr))
            {
                DEBUG("\t\tfiltered out due of blacklist\n");
                continue;
            }
            
            // filter contable
            if (_cm_local_check_contable(saddr))
            {
                DEBUG("\t\tfiltered out due of conlist\n");
                continue;
            }
            
            // add or update
            _cm_local_update_page_list(saddr, cm_stack->inq_results[i]);
        }

#if LOG_LEVEL >= LOG_DEBUG
        _cm_local_show_page_list();
        _cm_local_show_page_blacklist();
#endif // LOG_LEVEL >= LOG_DEBUG

        INFO("Sorting pagelist...\n");
        _cm_local_sorting_page_list();
        INFO("Sorting finished.\n");        

#if LOG_LEVEL >= LOG_DEBUG
        _cm_local_show_page_list();
        _cm_local_show_page_blacklist();
#endif // LOG_LEVEL >= LOG_DEBUG

        INFO("%d entries in pagelist\n",
             _cm_local_count_page_list_entries());
        INFO("%d entries in blacklist\n",
             _cm_local_count_page_blacklist_entries());
        
        cm_stack->sleep_time += cm_stack->step_sleep_time;
        if (cm_stack->sleep_time > cm_stack->max_sleep_time)
        {
            DEBUG("\tsleep time is at maximum!\n");
            cm_stack->sleep_time = cm_stack->max_sleep_time;
        }

        if (cm_stack->page_list_head != NULL)
        {
            _cm_local_proceed_page_list_entries();            
        }

        if (cm_stack->my_role_master_own_devices == 0 &&
            cm_stack->my_role_slave_own_devices == 0)
        {
            DEBUG("no connections: set sleep time to minimum\n");
            cm_stack->sleep_time = cm_stack->min_sleep_time;
        }

        DEBUG("sleep time: %d s\n", cm_stack->sleep_time / 1000);
        NutSleep(cm_stack->sleep_time);        
    }
}

/// implementation of the interface _con_mgr.h

/**
 * \brief Fills variables (addr, cod, role) over con_handle 
 */
char _cm_local_get_con_handle_info(bt_hci_con_handle_t con_handle,
                                   bt_addr_t addr, u_long * cod, u_char * role)
{
    long res;
    
    if (bt_hci_get_remote_bt_addr(cm_stack->bt_stack, con_handle, addr))
    {
        return -1;
    }
    
    res = bt_hci_get_remote_cod(cm_stack->bt_stack, con_handle);
    if (res < 0)
    {
        return -2;
    }
    *cod = (u_long) res;
    
    res = bt_hci_local_role_discovery(cm_stack->bt_stack, con_handle);
    if (res < 0)
    {
        return -3;
    }
    *role = (u_char) (res & 0xff);

    return 0;
}

/**
 * \brief Fills variables (addr, cod, role, mode, rssi) over con_handle 
 */
char _cm_local_get_con_handle_info_ext(bt_hci_con_handle_t con_handle,
                                       bt_addr_t addr, u_long * cod,
                                       u_char * role, u_char * mode,
                                       char * rssi)
{
    long res;
    
    if (_cm_local_get_con_handle_info(con_handle, addr, cod, role) < 0)
    {
        return -10;   
    }
    
    res = bt_hci_local_mode_discovery(cm_stack->bt_stack, con_handle);
    if (res < 0)
    {
        return -11;
    }
    *mode = (u_char) (res & 0xff);
    
    // under unknown circumstainces, next command may block
    //res = bt_hci_read_abs_rssi(cm_stack->bt_stack, BT_HCI_SYNC, con_handle,
    //                           rssi);
    *rssi = -127;
    if (res < 0)
    {
        return -12;  
    }
    
    return 0;
}

/**
 * \brief Generates coninfo packet
 * 
 * -----------------------------
 * |    saddr    | type | rssi |
 * -----------------------------
 *        2          1      1     Bytes
 * 
 * saddr: address without prefix
 * type: 0:"unconnected",
 *       1:"neighbour role is slave", 2:"neighbour role is master",
 *       +4:"connection is on sniff mode"
 * 
 */
short cm_local_fill_con_info(u_char * args, u_char * param)
{
    DEBUG("cm_local_fill_con_info\n");

    bt_hci_con_handle_array con_handles;
    bt_addr_t addr;
    u_long cod;
    u_char nr_neighs=0;
    u_char i;
    u_char mode;
    u_char role;
    char rssi;
    u_char nr_con_handles;
    
    nr_con_handles =
           (u_char) bt_hci_get_con_handles(cm_stack->bt_stack, con_handles);

    // write nr of entries to first byte later
    u_char * p_first = args++;

    for (i=0; i<nr_con_handles; i++)
    {
        if (_cm_local_get_con_handle_info_ext(con_handles[i], addr, &cod,
                                              &role, &mode, &rssi) == 0)
        {
            if (cod == cm_stack->cod)
            {
                // copy bd addr (only the 2 lowest bytes)
                memcpy(args, addr, 2);
                args += 2;
                // write mode and role of this device to the packet
                // same as XTC/Tree, attach one bit if link is in sniff mode
                if (role == BT_HCI_MY_ROLE_MASTER)
                {
                    // connection to a slave
                    *args = CM_NEIGH_ROLE_SLAVE;
                }
                else if (role == BT_HCI_MY_ROLE_SLAVE)
                {
                    // connection from a master
                    *args = CM_NEIGH_ROLE_MASTER;
                }
                else
                {
                    *args = 0;
                }
                
                if (mode == BT_HCI_CONN_MODE_SNIFF)
                {
                    *args = *args + CM_SNIFF_MODE;
                }
                args++;
                                
                // write rssi
                *args++ = rssi;
                nr_neighs++;
            }
        }
    }
    
    *p_first = nr_neighs;
    return (nr_neighs * 4 + 1);
}

void cm_local_inq_disable(void)
{
    if (!cm_stack->inq_disabled)
    {
        _cm_local_mutex_lock();
        cm_stack->inq_disabled = 1;
        INFO("CM manager paused\n");
    }
    else
    {
        WARNING("CM manager was not resumed\n");        
    }
}

void cm_local_inq_enable(void)
{
    if (cm_stack->inq_disabled)
    {
        cm_stack->inq_disabled = 0;
        _cm_local_mutex_unlock();
        INFO("CM manager resumed\n");
    }
    else
    {
        WARNING("CM manager was not paused\n");
    }
}

#if USE_CPM > 0
void _cm_local_register_cmds(char * arg)
{
    int cpm;
    int args = sscanf(arg, "%u", &cpm); 
    
    if (args == 1 && (cpm == 0 || cpm == 1))
    {
        NutSleep(_cm_local_get_random_sleep_time(cm_stack->min_sleep_time));

        switch (cpm)
        {
            case (0):
            {
                cpm_stop();
                break;
            }
            case (1):
            {
                cpm_start();
                break;
            }   
        }
    }
    else
    {
        tprintf("cpm: error: usage:\n"
                "  cpm <0=off, 1=on>\n");
    }
}
#endif

void cm_local_register_cmds(void)
{
    DEBUG("cm_local_register_cmds\n");
#if USE_CPM > 0
    if (!cm_cpm_registered)
    {
        cm_cpm_registered = 1;
        btn_terminal_register_cmd("cpm", _cm_local_register_cmds);
    }
#endif
}

u_char cm_local_get_rel_cons(bt_hci_con_handle_t * rel_cons)
{
    DEBUG("cm_local_get_rel_cons\n");
    return (u_char) bt_hci_get_con_handles(cm_stack->bt_stack, rel_cons);
}

char * cm_local_get_info(void)
{
    DEBUG("cm_local_get_info\n");
    return "LOCAL";   
}

/**
 * \brief Forked very short-time living thread to set the link policy  
 */
THREAD(CM_WRITE_LP, arg)
{
    long res;
    
    bt_hci_con_handle_t con_handle = *(bt_hci_con_handle_t *)arg;
    
    NutHeapFree(arg);
    
    INFO("set link policy for con_handle %d\n", con_handle);

    _cm_local_mutex_lock();
    
    res = bt_hci_write_link_policy_settings(cm_stack->bt_stack, BT_HCI_SYNC,
                                            con_handle, CM_DEFAULT_LINK_POLICY);

    _cm_local_mutex_unlock();

    if (res < 0)
    {
        WARNING("cannot overwrite link policy setting!\n");   
    }
    else
    {
        DEBUG("link policy for con_handle %d setted...\n", con_handle);
    }
    
    NutThreadExit();
    
    while (1) { }
}

/**
 * \brief Calls the connection table callback on upper layer if required 
 */
void _cm_local_con_table_cb_extern_call(u_char type, u_char detail, 
                                        bt_hci_con_handle_t con_handle)
{
    if (con_mgr_stack.con_table_cb)
    {
        DEBUG("call external callback\n");
        
        con_mgr_stack.con_table_cb(type, detail, con_handle,
                                   con_mgr_stack.con_table_cb_arg);
    }
}

/**
 * \brief Forked short-time living thread to set the scan mode (incl. timeout)  
 */
THREAD(CM_NEXT_SCAN_MODE, arg)
{
    switch (cm_stack->next_scan_mode)
    {
        case CM_SCAN_MODE_INQUIRY_PAGE:
        {
            _cm_local_mutex_lock();
            _cm_local_write_scan_mode(BT_HCI_SCAN_MODE_INQUIRY_PAGE);
            _cm_local_mutex_unlock();
            break;   
        }
        case CM_SCAN_MODE_TIMEOUT_THEN_PAGE:
        case CM_SCAN_MODE_TIMEOUT_THEN_INQUIRY_PAGE:
        {
            // wait until timeout expired
            if (cm_stack->scan_mode_timeout != 0)
            {
                DEBUG("CM_NEXT_SCAN_MODE thread: sleeping...\n");
                NutSleep(cm_stack->scan_mode_timeout);
                DEBUG("CM_NEXT_SCAN_MODE thread: wakeup...\n");
            }
            
            _cm_local_mutex_lock();
            _cm_local_write_scan_mode(cm_stack->next_scan_mode);
            _cm_local_mutex_unlock();
            break;
        }
    }
    
    NutMutexUnlock(&cm_stack->change_scan_mode_mutex);
    
    NutThreadExit();
    
    while (1) { }
}

/**
 * \brief Policy for next scan mode
 * 
 * Reliant on the number of master/slave connections  
 */
inline void _cm_local_update_next_scan_mode(void)
{
    NutMutexLock(&cm_stack->change_scan_mode_mutex);

    if (cm_stack->my_role_slave_own_devices >=
            cm_stack->my_role_master_max_own_devices)
    {
        DEBUG("next_scan_mode: TIMEOUT_THEN_PAGE\n");
        cm_stack->next_scan_mode = CM_SCAN_MODE_TIMEOUT_THEN_PAGE;
    }
    else if (cm_stack->my_role_slave_own_devices > 0)
    {
        DEBUG("next_scan_mode: TIMEOUT_THEN_INQUIRY_PAGE\n");
        cm_stack->next_scan_mode = CM_SCAN_MODE_TIMEOUT_THEN_INQUIRY_PAGE;
    }
    else
    {
        DEBUG("next_scan_mode: INQUIRY_PAGE\n");
        cm_stack->next_scan_mode = CM_SCAN_MODE_INQUIRY_PAGE;
    }
    
    if (!NutThreadCreate("CM_NEXT", CM_NEXT_SCAN_MODE, 0, 256))
    {
        // should never happen
        ERROR("no ressources available for thread allocation...\n");
        ERROR("\tcannot set next scan mode!\n");
        CM_LED_SET(RED);
        NutMutexUnlock(&cm_stack->change_scan_mode_mutex);
    }
}

/**
 * \brief Connection table change callback
 * 
 * - Updates the slave/master connections and own/foreign devices counter
 * - Adapts the scan mode according the policy
 * - Calls the callback from upper layer
 */
void _cm_local_con_table_change_cb(u_char type, u_char detail, 
                                   bt_hci_con_handle_t con_handle,
                                   void * cb_arg)
{
    // only call extern callback if necessary (dis-/connection of own devices)
    
    bt_addr_t addr;
    u_long cod;
    u_char role;

    if (_cm_local_get_con_handle_info(con_handle, addr, &cod, &role) < 0)
    {
        // should never ever happen!!!
        ERROR("_cm_get_con_handle_info returns error!\n");
        NutMutexUnlock(&cm_stack->accept_con_cb_mutex);
        return;
    }
    
    DEBUG("_con_table_change_cb: %d, %d\n", type, detail);

    DEBUG("OM: %d, FM: %d, OS: %d, FS: %d\n",
          cm_stack->my_role_master_own_devices,
          cm_stack->my_role_master_foreign_devices,
          cm_stack->my_role_slave_own_devices,
          cm_stack->my_role_slave_foreign_devices);

    DEBUG("\tcon_handle %d details: 0x%.8lx, %d\n", con_handle, cod, role);
    if (role != BT_HCI_MY_ROLE_MASTER && role != BT_HCI_MY_ROLE_SLAVE)
    {
        // should never ever happen!!!
        ERROR("role is not determinated in connection callback\n");   
        NutMutexUnlock(&cm_stack->accept_con_cb_mutex);
        return;
    }

    if (type == BT_HCI_DISCONNECTION)
    {
        INFO("Disconnect con_handle %d (%d)!\n", con_handle, detail);
        
        if (cod == cm_stack->cod)
        {
            // own device
            
            if (role == BT_HCI_MY_ROLE_MASTER)
            {
                cm_stack->my_role_master_own_devices--;
                _cm_local_con_table_cb_extern_call(type, detail, con_handle);
            }
            else  // role == BT_HCI_MY_ROLE_SLAVE
            {
                cm_stack->my_role_slave_own_devices--;
                _cm_local_con_table_cb_extern_call(type, detail, con_handle);
            }
        }
        else
        {
            // foreign device
            
            if (role == BT_HCI_MY_ROLE_MASTER)
            {
                cm_stack->my_role_master_foreign_devices--;
            }
            else  // role == BT_HCI_MY_ROLE_SLAVE
            {
                cm_stack->my_role_slave_foreign_devices--;                
            }
        }    
    }
    else if (type == BT_HCI_CONNECTION)
    {        
        if (detail == BT_HCI_CONNECTION_ACTIVE)
        {
            // attention: cod is not correct (resp. always 0)
            // so workaround with inquiry results
            //   if found and cod compared true -> own cod

            u_char i;

            for (i=0; i<cm_stack->inq_counts; i++)
            {
                if (BD_ADDR_CMP(cm_stack->inq_results[i].bdaddr, addr))
                {
                    cod = cm_stack->inq_results[i].cod;
                    for (i=0; i<BT_HCI_MAX_NUM_CON; i++)
                    {
                        if (BD_ADDR_CMP(cm_stack->bt_stack->connection[i].bdaddr,
                                        addr))
                        {
                            cm_stack->bt_stack->connection[i].cod = cod;
                            break;
                        }
                    }                    
                    DEBUG("\tcod corrected to 0x%.8lx\n", cod);
                    break;
                }
            }
        }           
        
        INFO("Connect "ADDR_FMT" (con_handle %d)!\n", ADDR(addr), con_handle);
        
        if (cod == cm_stack->cod)
        {
            // own device
            
            if (role == BT_HCI_MY_ROLE_MASTER)
            {
                cm_stack->my_role_master_own_devices++;
                _cm_local_con_table_cb_extern_call(type, detail, con_handle);                
            }
            else  // role == BT_HCI_MY_ROLE_SLAVE
            {
                cm_stack->my_role_slave_own_devices++;
                _cm_local_con_table_cb_extern_call(type, detail, con_handle);                
            }
        }
        else
        {
            // foreign device
            
            // be sure that hold mode is disabled!
            // async call, else deadlock
            bt_hci_con_handle_t * temp_con_handle;
            temp_con_handle = NutHeapAlloc(sizeof(bt_hci_con_handle_t));
            
            if (temp_con_handle != NULL)
            {
                *temp_con_handle = con_handle; 

                if (!NutThreadCreate("CM_WRITE_LP", CM_WRITE_LP,
                                     temp_con_handle, 128))
                {
                    NutHeapFree(temp_con_handle);   
                }
            }
            
            if (role == BT_HCI_MY_ROLE_MASTER)
            {
                cm_stack->my_role_master_foreign_devices++;
            }
            else  // role == BT_HCI_MY_ROLE_SLAVE
            {
                cm_stack->my_role_slave_foreign_devices++;
            }
        }
    }
    else  // role change
    {
        role = type;
        
        INFO("Role change (%d) on con_handle %d!\n", role, con_handle);
        
        if (cod == cm_stack->cod)
        {
            if (role == BT_HCI_MY_ROLE_MASTER)
            {
                cm_stack->my_role_master_own_devices++;
                cm_stack->my_role_slave_own_devices--;
            }
            else  // role == BT_HCI_MY_ROLE_SLAVE
            {
                cm_stack->my_role_slave_own_devices++;
                cm_stack->my_role_master_own_devices--;
            }
        }
        else
        {
            if (role == BT_HCI_MY_ROLE_MASTER)
            {
                cm_stack->my_role_master_foreign_devices++;
                cm_stack->my_role_slave_foreign_devices--;
            }
            else  // role == BT_HCI_MY_ROLE_SLAVE
            {
                cm_stack->my_role_slave_foreign_devices++;
                cm_stack->my_role_master_foreign_devices--;
            }
        }
    }

    if (cod == cm_stack->cod)
    {
        if (cm_stack->my_role_master_own_devices > 0 ||
            cm_stack->my_role_slave_own_devices > 0)
        {
            CM_LED_SET(GREEN);
        }
        else
        {
            CM_LED_CLEAR(GREEN);        
        }

        if (role == BT_HCI_MY_ROLE_SLAVE)
        {
            _cm_local_update_next_scan_mode();
        }
    }

    NutMutexUnlock(&cm_stack->accept_con_cb_mutex);
    
    DEBUG("OM: %d, FM: %d, OS: %d, FS: %d\n",
          cm_stack->my_role_master_own_devices, 
          cm_stack->my_role_master_foreign_devices,
          cm_stack->my_role_slave_own_devices,
          cm_stack->my_role_slave_foreign_devices);
}

/**
 * \brief Accept connection callback
 * 
 * - Rejects undesired devices:
 *     - not ACL
 *     - pending connection table change callback
 *     - pending scan mode change
 *     - reach limitation of slave/master connection and own/foreign devices
 * 
 * - Role change of foreign master devices to slave (lower current consumption)
 */
u_char _cm_local_accept_con_cb(bt_addr_t addr, u_long cod, u_char type,
                               u_char * myrole, void * arg)
{
    DEBUG("_accept_con_cb: "ADDR_FMT", 0x%.8lx, %d\n", ADDR(addr), cod, type);

    // if not ACL, reject connection
    if (type != 0x01)
    {
        return 0;
    }

    // if con cb is pending, reject connection 
    if (NutMutexTrylock(&cm_stack->accept_con_cb_mutex))
    {
        DEBUG("rejected because a connection callback is pending!\n");
        return 0;
    }

    // if new scan mode not setted, reject connection 
    if (NutMutexTrylock(&cm_stack->change_scan_mode_mutex))
    {
        DEBUG("rejected because new scan mode is not setted!\n");
        goto reject;
    }

    if (cod == cm_stack->cod)
    {
        // own device

        if (cm_stack->my_role_slave_own_devices <
                cm_stack->my_role_slave_max_own_devices)
        {
            INFO("connection "ADDR_FMT" accepted!\n", ADDR(addr));
            return 1;
        }
        else
        {
            goto reject;
        }
    }
    else
    {
        // foreign device

        // first try a role switch
        if (cm_stack->my_role_master_foreign_devices <
                cm_stack->my_role_master_max_foreign_devices)
        {
            *myrole = BT_HCI_MY_ROLE_MASTER;
            INFO("connection "ADDR_FMT" accepted and role switched!\n",
                 ADDR(addr));
            return 1;
        }
        else
        {
            if (cm_stack->my_role_slave_foreign_devices <
                    cm_stack->my_role_slave_max_foreign_devices)
            {
                INFO("connection "ADDR_FMT" accepted!\n",
                     ADDR(addr));
                return 1;
            }
            else
            {
                goto reject;
            }
        }
    }
    
reject:
    INFO("connection "ADDR_FMT" rejected!\n", ADDR(addr));
    NutMutexUnlock(&cm_stack->accept_con_cb_mutex);
    return 0;        
}

void cm_local_init(struct btstack * bt_stack, bt_psm_t * psmux, u_short cm_psm,
                   HCI_CON_TABLE_CB_REGISTRATION, u_long cod)
{
    long res;
    
    // set CoD
    res = bt_hci_write_local_cod(bt_stack, BT_HCI_SYNC, cod);
    if (res < 0)
    {
        ERROR("cannot set local CoD (%d)\n", res);
        CM_LED_SET(RED);
        return;   
    }
    
    res = bt_hci_write_default_link_policy_settings(bt_stack, BT_HCI_SYNC,
                                                    CM_DEFAULT_LINK_POLICY); 
    if (res == 0)
    {
        DEBUG("set default link policy (role switch, sniff mode)\n");
    }
    else
    {
        ERROR("cannot set default link policy (%d)\n", res);
        CM_LED_SET(RED);
        return;   
    }

    // only return inquiry results with specified cod
    res = bt_hci_set_event_filter(bt_stack, BT_HCI_SYNC, 0x01, 0x01,
                                  cod, CM_COD_MASK);
    if (res == 0)
    {
        DEBUG("set event filter (CoD filtered inquiry results)\n");
    }
    else
    {
        ERROR("cannot set event filter for inquiry results (%d)\n", res);
        CM_LED_SET(RED);
        return;   
    }

    // build up stack    
    cm_stack = NutHeapAlloc(sizeof(cm_local_stack_t));
    if (!cm_stack)
    {
        ERROR("no ressources available for stack allocation...\n");        
        CM_LED_SET(RED);
        return;        
    }

    PARAMS_INIT();

    // write page resp. connect timeout 
    res = bt_hci_write_page_timeout(bt_stack, BT_HCI_SYNC,
                                    cm_stack->page_timeout);
    if (res == 0)
    {
        DEBUG("set page/connect timeout\n");
    }
    else
    {
        NutHeapFree(cm_stack);
        ERROR("cannot set page/connect timeout (%d)\n", res);
        CM_LED_SET(RED);
        return;   
    }        
    
    cm_stack->bt_stack = bt_stack;
    cm_stack->cod = cod;
    cm_stack->sleep_time = cm_stack->min_sleep_time;
    cm_stack->scan_mode = BT_HCI_SCAN_MODE_INQUIRY_PAGE;
    cm_stack->cur_scan_mode = BT_HCI_SCAN_MODE_INQUIRY_PAGE;
    cm_stack->inq_disabled = 0;
    cm_stack->page_list_head = NULL;
    cm_stack->page_list_tail = NULL;
    cm_stack->page_blacklist_head = NULL;
    cm_stack->page_blacklist_tail = NULL;
    cm_stack->my_role_master_own_devices = 0;
    cm_stack->my_role_master_foreign_devices = 0;
    cm_stack->my_role_slave_own_devices = 0;
    cm_stack->my_role_slave_foreign_devices = 0;

    NutMutexInit(&cm_stack->hci_mutex);
    NutMutexInit(&cm_stack->accept_con_cb_mutex);
    NutMutexInit(&cm_stack->change_scan_mode_mutex);

    // initialize con mgr interface
    con_mgr_stack.cm_fill_con_info = cm_local_fill_con_info;
    con_mgr_stack.cm_inq_disable = cm_local_inq_disable;
    con_mgr_stack.cm_inq_enable = cm_local_inq_enable;
    con_mgr_stack.cm_reg_cmds = cm_local_register_cmds;
    con_mgr_stack.cm_get_rel_cons = cm_local_get_rel_cons;
    con_mgr_stack.cm_get_info = cm_local_get_info;

    // register connection callback
    con_table_cb_reg(bt_stack, _cm_local_con_table_change_cb, NULL);

#if USE_CPM > 0
    cpm_init(bt_stack, cod);
#endif

    // start thread
    if (!NutThreadCreate("CM_LOCAL", CM_LOCAL, 0, 512))
    {
        ERROR("no ressources available for thread allocation...\n");
        CM_LED_SET(RED);
    }
}
