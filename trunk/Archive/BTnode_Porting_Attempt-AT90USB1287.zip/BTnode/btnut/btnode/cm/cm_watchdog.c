#include <sys/timer.h>
#ifdef __AVR__
#include <avr/wdt.h>
#endif

HANDLE _cm_watchdog_timer;

void _cm_watchdog_cb(HANDLE timer, void *arg)
{
#ifdef __AVR__
    wdt_enable(WDTO_60MS);
#endif
}

void _cm_watchdog_start(u_long timer_ms){
    _cm_watchdog_timer = NutTimerStart(timer_ms, _cm_watchdog_cb, NULL, TM_ONESHOT);
}

void _cm_watchdog_stop(void){
    NutTimerStop(_cm_watchdog_timer);
}
