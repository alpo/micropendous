/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * @file con_power_mgr.c
 *
 * @brief Implementation of a simple power manager
 *        for already established bluetooth connections
 *  
 * \author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 * 
 * \date 2006/03/29
 *
 * $Log: con_power_mgr.c,v $
 * Revision 1.11  2006/11/06 11:32:51  yuecelm
 * move my email address to a permanent one
 *
 * Revision 1.10  2006/10/26 13:27:32  kevmarti
 * - Adaption to obsolete typedef 'bt_msg'
 * - Included syslog debug definitions
 *
 * Revision 1.9  2006/06/18 19:35:34  yuecelm
 * add cpm_pause and cpm_resume
 *
 * Revision 1.8  2006/05/15 12:29:35  yuecelm
 * comment out LOG_LEVEL macro
 *
 * Revision 1.7  2006/05/15 12:20:16  yuecelm
 * set log level to 0
 *
 * Revision 1.6  2006/05/13 01:10:58  yuecelm
 * improved cpm
 *
 * Revision 1.5  2006/04/26 23:54:02  yuecelm
 * *** empty log message ***
 *
 * Revision 1.4  2006/04/26 23:50:35  yuecelm
 * add CoD filter, add doxygen comments
 *
 * Revision 1.3  2006/04/21 12:50:35  yuecelm
 * add first version of my connection manager,
 * corrections in connection power manager
 *
 * Revision 1.2  2006/04/06 17:04:46  yuecelm
 * some refactoring, reduced code size
 *
 * Revision 1.1  2006/04/06 13:55:53  yuecelm
 * add the connection power manager
 *
 */

#include <cm/con_power_mgr.h>

#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_defs.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/thread.h>

// set default debug level
#include <debug/logging.h>
#include <debug/syslog.h>
//#define LOG_LEVEL LOG_INFO
#define LOG_CLASS 10 // LOG_SYS_CLASS_CPM
#include <debug/log_set.h>

// EEPROM parameters
#define READ_EEPROM 0

#if READ_EEPROM > 0
#include <terminal/eeprom_cmds.h>
#endif

#define PARAMS(y) void _cpm_eeprom_params_init(void) {y}
#define PARAMS_INIT() _cpm_eeprom_params_init()

#if READ_EEPROM > 0
#define EEPROM_PARAM(param_name, param_id, param_val, param_default_val) \
    eeprom_cmds_param_ext_read(param_id, &param_val, param_default_val); \
    eeprom_cmds_add_param(param_name, param_id, &param_val, param_default_val);
#else  // READ_EEPROM <= 0
#define EEPROM_PARAM(param_name, param_id, param_val, param_default_val) \
    param_val = param_default_val;
#endif // READ_EEPROM

// Connection Power Manager CPM stack
typedef struct _cpm_stack {
    struct btstack * bt_stack;  // pointer to the bluetooth stack
    u_long cod;  // filter this CoD (0 to disable)
    HANDLE start;  // start event
    HANDLE pause;  // pause event
    HANDLE resume;  // resume event
    u_char running;
    u_char paused;
    u_char stop;
    u_long max_sniff_links;  // (u_char)
    u_long master_or_slave;  // (u_char)
    u_long thread_priority;  // (u_char)
    u_long wait_time;
    u_long sleep_time;
    u_long sniff_interval;  // (u_short)
    u_long sniff_attempt;  // (u_short)
    u_long sniff_timeout;  // (u_short)
} cpm_stack_t;

// Pointer to the CPM Stack
static cpm_stack_t * cpm_stack = NULL;

PARAMS(
    EEPROM_PARAM("cpm_msl", "pmsl", cpm_stack->max_sniff_links, CPM_DEFAULT_MAX_SNIFF_LINKS)
    EEPROM_PARAM("cpm_msl", "pmsl", cpm_stack->master_or_slave, CPM_DEFAULT_MASTER_OR_SLAVE)
    EEPROM_PARAM("cpm_tst", "pmts", cpm_stack->sleep_time, CPM_DEFAULT_SLEEP_TIME)
    EEPROM_PARAM("cpm_twt", "pmtw", cpm_stack->wait_time, CPM_DEFAULT_WAIT_TIME)
    EEPROM_PARAM("cpm_tp", "pmtp", cpm_stack->thread_priority, CPM_DEFAULT_THREAD_PRIORITY)
    EEPROM_PARAM("cpm_si", "pmsi", cpm_stack->sniff_interval, CPM_DEFAULT_SNIFF_INTERVAL)
    EEPROM_PARAM("cpm_sa", "pmsa", cpm_stack->sniff_attempt, CPM_DEFAULT_SNIFF_ATTEMPT)
    EEPROM_PARAM("cpm_st", "pmst", cpm_stack->sniff_timeout, CPM_DEFAULT_SNIFF_TIMEOUT)
)

void cpm_start(void)
{
    INFO("start cpm\n");
    NutEventPost(&cpm_stack->start);
}

void cpm_pause(void)
{
    if (cpm_stack->running)
    {
        INFO("pause cpm\n");
        NutEventPost(&cpm_stack->pause);
    }
}

void cpm_resume(void)
{
    if (cpm_stack->running)
    {
        INFO("resume cpm\n");
        NutEventPost(&cpm_stack->resume);
    }
}

void cpm_stop(void)
{
    if (cpm_stack->running)
    {
        INFO("stop cpm\n");
        cpm_stack->stop = 1;
        NutEventPost(&cpm_stack->pause);
    }
}

u_char _check_con_handle(bt_hci_con_handle_t con_handle, char mode, char role)
{
    long res;
    
    // check mode
    res = bt_hci_local_mode_discovery(cpm_stack->bt_stack, con_handle);
    if ( res == BT_ERR_NO_CON || (res & 0xff) != mode )
    {
        return -1;
    }
    
    if (role == -1)
    {
        return 0;  
    }
    
    // check role
    res = bt_hci_local_role_discovery(cpm_stack->bt_stack, con_handle);
    if ( res == BT_ERR_NO_CON || (res & 0xff) != role )
    {
        return -2;
    }
    
    if (cpm_stack->cod == 0)
    {
        return 0;
    }
    
    // check CoD
    res = bt_hci_get_remote_cod(cpm_stack->bt_stack, con_handle);
    if ( res == BT_ERR_NO_CON || res != cpm_stack->cod)
    {
        return -3;
    }
    
    return 0;
}

void _cpm_exit_sniff_mode(void)
{
    bt_hci_con_handle_array con_handles;
    u_char nr_open_con, i;
    long res;
    
    INFO("stop putting connections to sniff,"
         " now put all connections to active\n");
    
    nr_open_con = (u_char) bt_hci_get_con_handles(cpm_stack->bt_stack,
                                                  con_handles);
    DEBUG("open connections: %d\n", nr_open_con);
    
    for (i=0; i<nr_open_con; i++)
    {
        // only proceed connections in sniff mode
        if (_check_con_handle(con_handles[i], BT_HCI_CONN_MODE_SNIFF, -1) != 0)
        {
            continue;
        }

        res = bt_hci_exit_sniff_mode(cpm_stack->bt_stack, BT_HCI_SYNC, 
                                     con_handles[i]);

        if (res < 0)
        {
            WARNING("not possible to put handle %d to active (error %d)\n",
                    con_handles[i], res);
        }
        else
        {
            INFO("handle %d is in active mode\n", con_handles[i]);
        }
    }
}

THREAD(CPM, arg)
{
    bt_hci_con_handle_array con_handles;
    u_char nr_open_con, i, sniff_links;
    long res;
    
    NutThreadSetPriority(cpm_stack->thread_priority);
    
    while (1) // thread-loop
    {
        cpm_stack->stop = 0;
        
        // wait until event CPM_START released
        NutEventWait(&cpm_stack->start, NUT_WAIT_INFINITE);
        DEBUG("cpm started...\n");

        cpm_stack->running = 1;
        
        while (1) // sniff-loop
        {
            // try to put all connections in active mode to sniff mode

            sniff_links = 0;

            nr_open_con = (u_char) bt_hci_get_con_handles(cpm_stack->bt_stack,
                                                          con_handles);
            for (i=0; i<nr_open_con; i++)
            {
                res = bt_hci_local_mode_discovery(cpm_stack->bt_stack,
                                                  con_handles[i]);
                if ( res != BT_ERR_NO_CON &&
                     (res & 0xff) == BT_HCI_CONN_MODE_SNIFF )
                {
                    if (bt_hci_local_role_discovery(cpm_stack->bt_stack,
                                                    con_handles[i])
                            == cpm_stack->master_or_slave)
                    {
                        sniff_links++;
                    }
                }
            }
            
            for (i=0; i<nr_open_con; i++)
            {
                if (sniff_links >= cpm_stack->max_sniff_links)
                {
                    DEBUG("Maximum of sniff links reached\n");
                    break;
                }
                
                // only proceed connections in active mode and in right role
                if (_check_con_handle(con_handles[i], BT_HCI_CONN_MODE_ACTIVE,
                                      cpm_stack->master_or_slave) != 0)
                {
                    DEBUG("reject con_handle %d\n", con_handles[i]);
                    continue;
                }

                DEBUG("wait %u ms, watch out pause or stop event\n",
                      cpm_stack->wait_time);
                if (NutEventWait(&cpm_stack->pause, cpm_stack->wait_time)
                        == 0)  // if event released
                {
                    if (!cpm_stack->stop)
                    {
                        DEBUG("cpm paused...\n");
                        NutEventWait(&cpm_stack->resume, NUT_WAIT_INFINITE);
                        DEBUG("cpm resumed...\n");
                    }
                    break;
                }

                res = bt_hci_sniff_mode(cpm_stack->bt_stack, BT_HCI_SYNC,
                                        con_handles[i],
                                        (u_short) (cpm_stack->sniff_interval & 0xffff),
                                        (u_short) (cpm_stack->sniff_interval & 0xffff),
                                        (u_short) (cpm_stack->sniff_attempt  & 0xffff),
                                        (u_short) (cpm_stack->sniff_timeout  & 0xffff));
                
                if (res < 0)
                {
                    DEBUG("not possible to put con_handle %d to sniff (error %d)\n",
                          con_handles[i], res);
                }
                else
                {
                    if ((res & 0xff) == BT_HCI_CONN_MODE_SNIFF)
                    {
                        INFO("handle %d is in sniff mode (%d, %d, %d)\n",
                             con_handles[i], (u_short) (res >> 8) & 0xffff,
                             (u_short) (cpm_stack->sniff_attempt & 0xffff),
                             (u_short) (cpm_stack->sniff_timeout & 0xffff));
                        break;
                    }
                    else
                    {
                        // should never happen
                        WARNING("strange mode change\n");
                    }
                }
            }
            
            DEBUG("sleep %u ms, watch out pause or stop event\n", 
                  cpm_stack->sleep_time);
            
            if (cpm_stack->stop || (NutEventWait(&cpm_stack->pause,
                                                 cpm_stack->sleep_time)
                                        == 0)) // if event released
            {
                if (cpm_stack->stop)
                {
                    DEBUG("cpm stopped...\n");
                    _cpm_exit_sniff_mode();
                    cpm_stack->running = 0;
                    break; // sniff-loop
                }
                else
                {
                    DEBUG("cpm paused...\n");
                    NutEventWait(&cpm_stack->resume, NUT_WAIT_INFINITE);
                    DEBUG("cpm resumed...\n");                    
                }
            }
        } // sniff-loop
    } // thread-loop
}

char cpm_init(struct btstack * bt_stack, u_long cod)
{
    if (cpm_stack != NULL)
        return 1;
    
    long res;
       
    // check default link policy
    // its really not my task to set the right default link policies, 
    // but check and print out message is ok
    res = bt_hci_read_default_link_policy_settings(bt_stack, BT_HCI_SYNC);
    if (res < 0)
    {
        ERROR("cannot read default link policy (%d)\n", res);
        return -1;
    }
    else if (!(res & BT_HCI_LINK_POLICY_SNIFF_MODE))
    {
        ERROR("sniff mode not in default link policy\n");
        return -2;
    }
    
    cpm_stack = NutHeapAlloc(sizeof(cpm_stack_t));
    if (!cpm_stack)
    {
        ERROR("no ressources available for stack allocation...\n");        
        return -3;        
    }
    
    cpm_stack->bt_stack = bt_stack;
    cpm_stack->cod = cod;
    
    cpm_stack->start = 0;
    cpm_stack->running = 0;
    cpm_stack->pause = 0;
    cpm_stack->paused = 0;
    cpm_stack->resume = 0;
    cpm_stack->stop = 0;
    
    PARAMS_INIT();
    
    if (!NutThreadCreate("CPM", CPM, 0, 256))
    {
        ERROR("no ressources available for thread allocation...\n");
        NutHeapFree(cpm_stack);
        return -4;
    }
    
    return 0;
}
