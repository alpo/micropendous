#include <bt/bt_hci_api.h>
#include <bt/bt_acl_defs.h>
#include <sys/event.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <bt/bt_hci_cmds.h>
#include <sys/heap.h>
#include <led/btn-led.h>
#include <bt/l2cap_cl.h>
#include <bt/bt_psm.h>
#include <cm/con_event_buffer.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CM
#define LOG_LEVEL SYSLOG_LEVEL_CM
#include <debug/log_set.h>

#define BT_MAX_NR_MASTERS 3

#define BTNET_ROLE_SWITCH_RQST 1

#define BTNET_PSM 0x1001

// delay before broadcasting role switch request
#define ROLE_SWITCH_RQST_START_DELAY 1000
// timeout before disconnecting if role switch rqst does not succeed
#define ROLE_SWITCH_RQST_TIMEOUT 2000


typedef struct _btnet_stack {
	bt_hci_con_handle_t masters[BT_MAX_NR_MASTERS];
	u_char nr_masters;
	bt_hci_con_handle_t* current_con;
	HANDLE resources_exhausted;
	HANDLE resource_freed;
    struct btstack* bt_stack;       ///< Pointer to lower level hci stack
    bt_psm_t* psmux;
    HCI_CON_TABLE_CB;				///< Pointer to the rel con change cb
	void* cb_arg;
} btnet_stack_t;

btnet_stack_t* btnet_stack;

void btnet_register_con_table_cb(struct btstack* bt_stack, HCI_CON_TABLE_CB, void* cb_arg)
{
    btnet_stack->con_table_cb = con_table_cb;
    btnet_stack->cb_arg = cb_arg;
}

void _btnet_con_table_change_cb(u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg)
{
	u_char i;
	switch (type) {
    case BT_HCI_CONNECTION:
        if (detail == BT_HCI_CONNECTION_ACTIVE) break;
    case BT_HCI_MY_ROLE_SLAVE:
		// increment nr masters
		btnet_stack->nr_masters++;
		// store con handle
	    for (i=0; i<BT_MAX_NR_MASTERS; i++) {
	        if (btnet_stack->masters[i] == BT_HCI_HANDLE_INVALID) {
	            btnet_stack->masters[i] = con_handle;
	            btnet_stack->current_con = &btnet_stack->masters[i];
	            break;
	        }
	    }
    	// if we've reached max nr of masters
    	if (btnet_stack->nr_masters >= BT_MAX_NR_MASTERS) {
    		// Wake up btnet thread
    		NutEventPostAsync(&btnet_stack->resources_exhausted);
    	}
        break;
    case BT_HCI_DISCONNECTION:
    case BT_HCI_MY_ROLE_MASTER:
	    // if remote dev was a master dev, remove handle from list
	    for (i=0; i<BT_MAX_NR_MASTERS; i++) {
	        if (btnet_stack->masters[i] == con_handle) {
	            btnet_stack->masters[i] = BT_HCI_HANDLE_INVALID;
			    // decrement nr of masters
			    btnet_stack->nr_masters--;
			    // if nr masters < BT_MAX_NR_MASTERS, wake up btnet thread
			    if (btnet_stack->nr_masters < (BT_MAX_NR_MASTERS))
			    	NutEventPostAsync(&btnet_stack->resource_freed);
	            break;
	        }
	    }
        break;
    default:;
    }
    // signal higher layer
    btnet_stack->con_table_cb(type, detail, con_handle, btnet_stack->cb_arg);
}

THREAD(BTNET, arg)
{
	u_char i;
	long result;
	u_char pkt_type = BTNET_ROLE_SWITCH_RQST;
	
	while(1) {
		NutEventWait(&btnet_stack->resources_exhausted, NUT_WAIT_INFINITE);
		DEBUG("resources exhausted! nr masters: %d\n",
			btnet_stack->nr_masters);
		// if timeout
		if (NutEventWaitNext(&btnet_stack->resource_freed,
				ROLE_SWITCH_RQST_START_DELAY)) {
			// broadcast role switch rqst
			for (i=0; i<BT_MAX_NR_MASTERS; i++) {
				result = l2cap_cl_send(&pkt_type,
										1,
										btnet_stack->masters[i],
										BTNET_PSM);
				if (result)
					DEBUG("error: sending role switch rqst, handle %d (0x%.2x)\n",
						btnet_stack->masters[i], (-result));
			}
			// wait for available resources
			if (NutEventWaitNext(&btnet_stack->resource_freed,
					ROLE_SWITCH_RQST_TIMEOUT)) {
				DEBUG("role switch rqst not successfull. Closing con...\n");
				// disconnect
				bt_hci_disconnect(btnet_stack->bt_stack,
					BT_HCI_SYNC,
					*(btnet_stack->current_con),
					BT_HCI_DISCONNECT_LOW_RESOURCES);
			}
			else DEBUG("resource sharing successfull! nr masters: %d\n",
				btnet_stack->nr_masters);
		}
		else DEBUG("resource freed! nr masters: %d\n", btnet_stack->nr_masters);
	}
}

bt_acl_pkt_buf* _btnet_data_cb(bt_acl_pkt_buf* pkt_buf,
							   u_char* data,
							   u_short data_len,
							   u_short service_nr,
							   void* cb_arg)
{
	bt_hci_con_handle_t con_handle;
    long result;
    struct bt_hci_pkt_acl* pkt;
    
    // get con handle the packet was received on
    pkt = pkt_buf->pkt;
    con_handle = bt_acl_get_con_handle(pkt);
    
   	switch (data[0]) {
   	case BTNET_ROLE_SWITCH_RQST:
   		DEBUG("role switch rqst received! nr masters: %d\n",
   			btnet_stack->nr_masters);
   		// check if we have enough resources
   		if (btnet_stack->nr_masters < (BT_MAX_NR_MASTERS-1)) {
   			btn_led_set(1);
            // role switch only possible in active mode
            result = bt_hci_local_mode_discovery(btnet_stack->bt_stack, con_handle);
            if (result != BT_ERR_NO_CON && (result & 0xff) == BT_HCI_CONN_MODE_SNIFF) {
                result = bt_hci_exit_sniff_mode(btnet_stack->bt_stack, BT_HCI_SYNC, con_handle);
                if (result < 0) {
                    DEBUG("error role switching: cannot reach active mode (0x%.2x)\n", (-result));
                } else {
                    DEBUG("role switching: back to active mode\n", con_handle);
                }
            }
	    	// do role switch
	    	result = bt_hci_role_set(btnet_stack->bt_stack,
	    		BT_HCI_SYNC,
	    		con_handle,
	    		BT_HCI_MY_ROLE_SLAVE);
	    	btn_led_clear(1);
	    	if (result < 0) DEBUG("error role switching: (0x%.2x)\n", (-result));
   		}
   		break;
   	default:
   		DEBUG("bt net error: unknown pkt type (%d)!\n", data[0]);
   	}
   	return pkt_buf;
}
        	
		
void btnet_adapter_init(struct btstack *bt_stack,
						bt_psm_t* psmux,
    					HCI_CON_TABLE_CB_REGISTRATION)
{
    u_char i;
    long retval;
    
    // dyn. alloc btnet stack
    btnet_stack = NutHeapAllocClear(sizeof(btnet_stack_t));
    btnet_stack->bt_stack = bt_stack;
    btnet_stack->psmux = psmux;
    for (i=0; i<BT_MAX_NR_MASTERS; i++) {
    	btnet_stack->masters[i] = BT_HCI_HANDLE_INVALID;
    }
    
    // register con table change cb
    con_table_cb_reg(bt_stack, _btnet_con_table_change_cb, NULL);
	
    // register btnet adapter
    retval = bt_psm_service_register(psmux, BTNET_PSM, _btnet_data_cb, NULL);
    if (retval < 0) {
    	DEBUG("registering at psmux (%li)! psm: %d\n", retval, BTNET_PSM);
    	return;
    }
    
    // init btnet thread
    NutThreadCreate("BTNET", BTNET, 0, NUT_DEFAULT_STACKSIZE);
}
    	
