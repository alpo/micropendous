/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

 /*
  * btn-eepromdb.c
  *
  * 02.07.2004 Martin Hinz <btnode@hinz.ch>
  * 05.08.2004 Matthias Ringwald <matthias.ringwald@inf.ethz.ch>
  */

#include <eepromdb/btn-eepromdb.h>
#include <string.h>
#include <sys/confos.h>

/**
 * \file btn-eepromdb.c
 *
 * \brief Provides support for storing and retrieving values of
 * the particular BTnode the software is running. This can be used to
 * store, how much memory is availabe, or what the user readable name
 * of this device is. Or what sensors are connected to it.
 *
 * Values are addressed using a four byte identifier 'xxxx'. For
 * string values, the last byte has to be '=', so all string values
 * id look like 'xxx=' followed by the string in the eeprom.
 *
 * The value data is stored in the EEPROM of the device. The first
 * implementation supports Int32 and char[16] feature data.
 *
 * To create such a value ID, you can use the macro FOURCC(a,b,c,d)
 * that takes four characters and creates a 4 char constant. The simple
 * use of 'abcd' is deprecated.
 */

/* Prototypes */
short _btn_eepromdb_find_id(u_long id);
inline u_short _btn_eepromdb_valid_id_size(u_long id, u_char size);
u_long _btn_eepromdb_get_32bit_from_eeprom(u_short pos);
void _btn_eepromdb_store_32bit_to_eeprom(u_short pos, u_long data);

/* -------------------------------------------------------------------------
 * 
 * -------------------------------------------------------------------------
\brief Tests if a given eepromdb id is a string eepromdb

\param id VALUE ID
\return TRUE for string eepromdb
*/
#define BTN_EEPROMDB_ID_IS_STRING_ID(id) ((id & 255) == '=')

/* EEPROMDB storage starts after nut/os configuration 8-byte aligned */
#define EEPROM_START (((sizeof(CONFOS))+7) & 0xFFF8)

/* -------------------------------------------------------------------------
 * 
 * -------------------------------------------------------------------------

\brief Valide value data size against supported types

\param id 32 bit value id. String values have to be 'xxx='"
\param size Size of the value to store. 
\return Size Validates size
*/
inline u_short _btn_eepromdb_valid_id_size(u_long id, u_char size)
{
    // check data size. don't thow interrupts
    if (BTN_EEPROMDB_ID_IS_STRING_ID(id)) {
        if (size > BTN_EEPROMDB_STRING_SIZE)
            size = BTN_EEPROMDB_STRING_SIZE;
    } else {
        if (size > BTN_EEPROMDB_INT_SIZE)
            size = BTN_EEPROMDB_INT_SIZE;
    }
    return size;
}

/* -------------------------------------------------------------------------
 * 
 * -------------------------------------------------------------------------
  
\brief Get 32 bit value from eeprom. Avoid endianess problems

\param pos addr in eeprom
\return 32 bit value
*/
u_long _btn_eepromdb_get_32bit_from_eeprom(u_short pos)
{
    u_long res;
    res = eeprom_read_byte((unsigned char *) (uptr_t) pos + 3);
    res <<= 8;
    res |= eeprom_read_byte((unsigned char *) (uptr_t) pos + 2);
    res <<= 8;
    res |= eeprom_read_byte((unsigned char *) (uptr_t) pos + 1);
    res <<= 8;
    res |= eeprom_read_byte((unsigned char *) (uptr_t) pos);
    return res;
}

/* -------------------------------------------------------------------------
 * 
 * -------------------------------------------------------------------------
  
\brief Get 32 bit value from eeprom. Avoid endianess problems

\param pos addr in eeprom
\return 32 bit value
*/
void _btn_eepromdb_store_32bit_to_eeprom(u_short pos, u_long data)
{
    eeprom_write_byte((unsigned char *) (uptr_t) pos++, (data & 0x000000ff));
    eeprom_write_byte((unsigned char *) (uptr_t) pos++, (data & 0x0000ff00) >> 8);
    eeprom_write_byte((unsigned char *) (uptr_t) pos++, (data & 0x00ff0000) >> 16);
    eeprom_write_byte((unsigned char *) (uptr_t) pos++, (data & 0xff000000) >> 24);
}

u_long btn_eepromdb_get_by_index(u_short index)
{
    u_short pos;
    u_long current_id;

    // from the beginning
    pos = EEPROM_START;

    // look
    while (1) {
        // get value
        current_id = _btn_eepromdb_get_32bit_from_eeprom(pos);
        // eof
        if (current_id == 0xFFFFFFFF) {
            return 0;
        }
        // count if real id
        if ((current_id != 0) && (current_id != '=')) {
            if (index == 0)
                return current_id;
            else
                index--;
        }
        // next 
        pos += BTN_EEPROMDB_ID_SIZE;

        if (BTN_EEPROMDB_ID_IS_STRING_ID(current_id)) {
            // string
            pos += BTN_EEPROMDB_STRING_SIZE;
        } else {
            // int
            pos += BTN_EEPROMDB_INT_SIZE;
        }

        // check for max size of eeprom. defined in avr/io.h
        if (pos > E2END)
            break;
    };
    return 0;
}

/* -------------------------------------------------------------------------
 * 
 * -------------------------------------------------------------------------
  
\brief Scans for a value in the eeprom.

\param id 32 bit value id. String values have to be 'xxx='"
\return Position of the requested feature, or -1 to indicate an error
*/
short _btn_eepromdb_find_id(u_long id)
{
    short pos;
    u_long current_id;

    // from the beginning
    pos = EEPROM_START;

    // look
    while (1) {
        // get feature
        current_id = _btn_eepromdb_get_32bit_from_eeprom(pos);

        // found id (0xFFFFFFFF is also possible) ?
        if (current_id == id) {
            // found
            return pos;
        }
        // eof
        if (current_id == 0xFFFFFFFF) {
            return -1;
        }
        // next 
        pos += BTN_EEPROMDB_ID_SIZE;

        if (BTN_EEPROMDB_ID_IS_STRING_ID(current_id)) {
            // string
            pos += BTN_EEPROMDB_STRING_SIZE;
        } else {
            // int
            pos += BTN_EEPROMDB_INT_SIZE;
        }

        // check for max size of eeprom. defined in avr/io.h
        if (pos > E2END)
            break;
    }
    return -1;
}


u_short btn_eepromdb_store(u_long id, u_short size, void *data)
{
    short pos;
    u_char count;

    // check size
    size = _btn_eepromdb_valid_id_size(id, size);

    // find id
    pos = _btn_eepromdb_find_id(id);

    // not found
    if (pos < 0) {
        // check for deleted entry
        if (BTN_EEPROMDB_ID_IS_STRING_ID(id))
            pos = _btn_eepromdb_find_id((u_long) '=');
        else
            pos = _btn_eepromdb_find_id((u_long) 0);
    }
    // not found and no deleted entries
    if (pos < 0) {
        pos = _btn_eepromdb_find_id(0xFFFFFFFF);
    }
    // not even space avail
    if (pos < 0)
        return 0;

    // write id
    _btn_eepromdb_store_32bit_to_eeprom(pos, id);

    pos += BTN_EEPROMDB_ID_SIZE;

    // write data
    if (BTN_EEPROMDB_ID_IS_STRING_ID(id)) {
        for (count = 0; count < size; count++) {
            eeprom_write_byte((unsigned char *) (uptr_t) pos++, *((unsigned char *) data++));
        }
    } else {
        _btn_eepromdb_store_32bit_to_eeprom(pos, *((u_long *) data));
    }

    return size;
}


u_short btn_eepromdb_get(u_long id, u_short size, void *data)
{
    short pos;
    u_char len;
    char string_buffer[BTN_EEPROMDB_STRING_SIZE+1];
    
    // assert size > 0
    if (size == 0) return 0;
    
    // find eepromdb entry
    pos = _btn_eepromdb_find_id(id);

    // not found
    if (pos < 0)
        return 0;

    pos += BTN_EEPROMDB_ID_SIZE;

    // read feature
    if (BTN_EEPROMDB_ID_IS_STRING_ID(id)) {
        // get BTN_EEPROMDB_STRING_SIZE bytes
        eeprom_read_block(string_buffer, (uptr_t *) (uptr_t) pos, size);
        // append null termination
        string_buffer[BTN_EEPROMDB_STRING_SIZE] = '\0';    
        // get len    
        len = strlen(string_buffer);
        // copy string including null termination
        memcpy((char*) data, string_buffer, len + 1);
    } else {
        *((u_long *) data) = _btn_eepromdb_get_32bit_from_eeprom(pos);
        len = 1;
    }

    return len;
}

u_char btn_eepromdb_delete(u_long id)
{
    short pos;
    u_short size;
    u_char count;

    // find eepromdb entry
    pos = _btn_eepromdb_find_id(id);

    // not found
    if (pos < 0)
        return 0;

    // check size
//    size = _btn_eepromdb_valid_id_size(id, size);

    // erase it
    if (BTN_EEPROMDB_ID_IS_STRING_ID(id)) {
        id = (u_long) '=';
        size = BTN_EEPROMDB_STRING_SIZE;
    } else {
        id = (u_long) 0;
        size = BTN_EEPROMDB_INT_SIZE;
    }

    // write eepromdb id
    _btn_eepromdb_store_32bit_to_eeprom(pos, id);

    pos += BTN_EEPROMDB_ID_SIZE;

    // clear data
    for (count = 0; count < size; count++) {
        eeprom_write_byte((unsigned char *) (uptr_t) pos++, 0);
    }

    return 1;
}
