/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/*
 * btn_led.c - device drivers for LEDs
 *
 * 2001.01.03 Lukas Karrer <lkarrer@trash.net>
 * 2002.05.23 Oliver Kasten <oliver.kasten@inf.ethz.ch>
 * 19.05.2004 Martin Hinz <btnode@hinz.ch>
 */

/* -------------------------------------------------------------------------
 * includes
 * ------------------------------------------------------------------------- */
#include <led/btn-led.h>
#include <hardware/btn-hardware.h>
#include <hardware/btn-ledhw.h>

#include <time/btn-time.h>

//nut os h files
#include <sys/thread.h>
#include <sys/timer.h>

u_char _btn_led_heartbeat;
u_char _btn_led_settings;       //to store the setting and restore after pattern
u_char _btn_led_pattern_showing;
u_char _btn_led_heatbeat_bit_pattern = 0;       //stores the 4-bit heartbeat pattern
u_char _btn_led_heatbeat_pause = 15;
u_char _btn_led_heatbeat_bit_pattern_duration = 1;

typedef struct _btn_led_pattern {
    u_char pattern;
    u_char arg;
    u_char duration;
    u_char nr;
} _btn_led_pattern_t;


#define LEDSLEEPSTEP 63 // ms 

//ringbuffer
_btn_led_pattern_t _btn_led_pattern_queue[BTN_LED_MAX_PATTERN_QUEUE];
u_char _btn_led_pattern_queue_head;
u_char _btn_led_pattern_queue_end;

void _btn_led_restore_led_settings(void)
{
    u_char i;
    for (i = 0; i < 4; i++) {
        if (_btn_led_settings & (1 << i))
            _btn_led_set(i);
        else
            _btn_led_clear(i);
    }
}

void _btn_led_set_leds_by_nr(u_char code)
{
    if (code & 1)
        _btn_led_set(0);
    else
        _btn_led_clear(0);
    if (code & 2)
        _btn_led_set(1);
    else
        _btn_led_clear(1);
    if (code & 4)
        _btn_led_set(2);
    else
        _btn_led_clear(2);
    if (code & 8)
        _btn_led_set(3);
    else
        _btn_led_clear(3);
}

//Led
THREAD(Led, arg)
{
    u_char i, duration = 0;
    // set low priority
    NutThreadSetPriority(150);
    // Endless blinking LED
    for (;;) {
        if (_btn_led_pattern_queue_end == _btn_led_pattern_queue_head)
            _btn_led_pattern_showing = BTN_LED_PATTERN_NON;
        else {
            _btn_led_pattern_showing = _btn_led_pattern_queue[_btn_led_pattern_queue_end].pattern;
            //if pattern set, clear all leds and dec nr by 1
            for (i = 0; i < 4; i++) {
                _btn_led_clear(i);
            }
            if (_btn_led_pattern_queue[_btn_led_pattern_queue_end].nr != BTN_LED_INFINITE)
                _btn_led_pattern_queue[_btn_led_pattern_queue_end].nr--;
            duration = _btn_led_pattern_queue[_btn_led_pattern_queue_end].duration;
        }

        switch (_btn_led_pattern_showing) {
            case BTN_LED_PATTERN_NON:      //maybe heartbeat! 
				if (_btn_led_heatbeat_bit_pattern_duration)
				{
					if ((btn_time_global() % (LEDSLEEPSTEP * (u_short)_btn_led_heatbeat_pause)) < LEDSLEEPSTEP)
//					if ((_btn_led_heartbeat >= _btn_led_heatbeat_pause && SYNC_CURRENT_BOUNDS.validity == 0) || (SYNC_CURRENT_BOUNDS.validity == 1 && (btn_time_global()) % 2000 < 63 ))
					{
	                    //if heartbeat pattern set, show it
	                    //if no led set led 0
	                    if (_btn_led_heatbeat_bit_pattern)
	                        btn_led_add_pattern(BTN_LED_PATTERN_OFF_ON_OFF, _btn_led_heatbeat_bit_pattern,
	                                            _btn_led_heatbeat_bit_pattern_duration, 1);
	                    else if (_btn_led_settings == 0)
	                        btn_led_add_pattern(BTN_LED_PATTERN_OFF_ON_OFF, 1, 1, 1);
	                    _btn_led_heartbeat = 0;
					}
                }
                _btn_led_heartbeat++;

                NutSleep(LEDSLEEPSTEP);
                break;
            case BTN_LED_PATTERN_ON:
                _btn_led_set_leds_by_nr(_btn_led_pattern_queue[_btn_led_pattern_queue_end].arg);
                NutSleep(LEDSLEEPSTEP * duration);
                break;
            case BTN_LED_PATTERN_ON_OFF:
                _btn_led_set_leds_by_nr(_btn_led_pattern_queue[_btn_led_pattern_queue_end].arg);
                NutSleep(LEDSLEEPSTEP * duration);
                if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                    break;
                _btn_led_set_leds_by_nr(0);
                NutSleep(LEDSLEEPSTEP * duration);
                break;
            case BTN_LED_PATTERN_OFF_ON_OFF:
                _btn_led_set_leds_by_nr(0);
                NutSleep(LEDSLEEPSTEP * duration);
                if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                    break;
                _btn_led_set_leds_by_nr(_btn_led_pattern_queue[_btn_led_pattern_queue_end].arg);
                NutSleep(LEDSLEEPSTEP * duration);
                if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                    break;
                _btn_led_set_leds_by_nr(0);
                NutSleep(LEDSLEEPSTEP * duration);
                break;
            case BTN_LED_PATTERN_OFF_ON:
                _btn_led_set_leds_by_nr(0);
                NutSleep(LEDSLEEPSTEP * duration);
                if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                    break;
                _btn_led_set_leds_by_nr(_btn_led_pattern_queue[_btn_led_pattern_queue_end].arg);
                NutSleep(LEDSLEEPSTEP * duration);
                break;
            case BTN_LED_PATTERN_UP:
                _btn_led_set(0);
                for (i = 0; i < 3; i++) {
                    NutSleep(LEDSLEEPSTEP * duration);
                    if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                        break;
                    _btn_led_clear(i);
                    _btn_led_set(i + 1);
                }
                NutSleep(LEDSLEEPSTEP * duration);
                break;
            case BTN_LED_PATTERN_DOWN:
                _btn_led_set(3);
                for (i = 3; i > 0; i--) {
                    NutSleep(LEDSLEEPSTEP * duration);
                    if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                        break;
                    _btn_led_clear(i);
                    _btn_led_set(i - 1);
                }
                NutSleep(LEDSLEEPSTEP * duration);
                break;
            case BTN_LED_PATTERN_KNIGHT:
                _btn_led_set(0);
                for (i = 0; i < 3; i++) {
                    NutSleep(LEDSLEEPSTEP * duration);
                    if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                        break;
                    _btn_led_clear(i);
                    _btn_led_set(i + 1);
                }
                for (i = 3; i > 0; i--) {
                    NutSleep(LEDSLEEPSTEP * duration);
                    if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                        break;
                    _btn_led_clear(i);
                    _btn_led_set(i - 1);
                }
                break;
            case BTN_LED_PATTERN_HALF:
                _btn_led_set(0);
                _btn_led_set(1);
                _btn_led_clear(2);
                _btn_led_clear(3);
                NutSleep(LEDSLEEPSTEP * duration);
                if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
                    break;
                _btn_led_clear(0);
                _btn_led_clear(1);
                _btn_led_set(2);
                _btn_led_set(3);
                NutSleep(LEDSLEEPSTEP * duration);
                break;
            default:
                _btn_led_pattern_queue[_btn_led_pattern_queue_end].nr = 0;
        }
        if ((_btn_led_pattern_showing != BTN_LED_PATTERN_NON) && (_btn_led_pattern_queue[_btn_led_pattern_queue_end].nr == 0)) {
            if ((_btn_led_pattern_queue_end + 1) % BTN_LED_MAX_PATTERN_QUEUE == _btn_led_pattern_queue_head) {
                //was last pattern, restore led settings
                _btn_led_restore_led_settings();
            }
            _btn_led_pattern_queue_end = (_btn_led_pattern_queue_end + 1) % BTN_LED_MAX_PATTERN_QUEUE;
        }

    }
}

void btn_led_clear_pattern_queue(void)
{
    _btn_led_pattern_queue_end = _btn_led_pattern_queue_head;
    _btn_led_restore_led_settings();
    _btn_led_pattern_showing = BTN_LED_PATTERN_NON;
}

void btn_led_add_pattern(u_char pattern, u_char arg, u_char duration, u_char nr)
{
    _btn_led_pattern_queue[_btn_led_pattern_queue_head].pattern = pattern;
    _btn_led_pattern_queue[_btn_led_pattern_queue_head].arg = arg;
    _btn_led_pattern_queue[_btn_led_pattern_queue_head].duration = duration;
    _btn_led_pattern_queue[_btn_led_pattern_queue_head].nr = nr;
    _btn_led_pattern_queue_head = (_btn_led_pattern_queue_head + 1) % BTN_LED_MAX_PATTERN_QUEUE;
    //now if buffer full, move end once up
    if (_btn_led_pattern_queue_head == _btn_led_pattern_queue_end)
        _btn_led_pattern_queue_end = (_btn_led_pattern_queue_end + 1) % BTN_LED_MAX_PATTERN_QUEUE;
}


void btn_led_heartbeat(u_char pause, u_char bit_pattern, u_char duration)
{
    // start heartbeat thread
    _btn_led_heatbeat_pause = pause;
    _btn_led_heatbeat_bit_pattern = bit_pattern;
    _btn_led_heatbeat_bit_pattern_duration = duration;
}

/* -------------------------------------------------------------------------
 * 
 * ------------------------------------------------------------------------- */

// set up hardware (port directions, registers etc.)
void btn_led_init(u_char thread_on)
{
#if defined(__AVR_ATmega128__)

    _btn_led_init();

    _btn_led_pattern_queue_head = 0;
    _btn_led_pattern_queue_end = 0;
    if (thread_on != 0) {
      NutThreadCreate("LED", Led, 0, 1024);

    }
#endif
}

void btn_led_set(u_char no)
{
    //if no pattern showing, call normal led set
    if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
        _btn_led_set(no);
    //save into led settings
    _btn_led_settings |= (1 << no);
}

void btn_led_clear(u_char no)
{
    //if no pattern showing, call normal led set
    if (_btn_led_pattern_showing == BTN_LED_PATTERN_NON)
        _btn_led_clear(no);
    //save into led settings
    _btn_led_settings &= ~(1 << no);
}
