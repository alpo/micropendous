#include <time/btn-time.h>
#include <sys/timer.h>

long sync_offset = 0;
u_char sync_state;

inline u_long btn_time_local(void)
{
	return NutGetMillis();
}

inline u_long btn_time_global(void)
{
	if (sync_state == BTN_TIME_SYNC_LAG)
	{
		return NutGetMillis() + sync_offset;
	}
	else
	{
		return NutGetMillis() - sync_offset;
	}
}

inline void btn_time_global_set_offset(u_long offset, u_char sign)
{
	sync_offset = offset;
	sync_state = sign;
}
