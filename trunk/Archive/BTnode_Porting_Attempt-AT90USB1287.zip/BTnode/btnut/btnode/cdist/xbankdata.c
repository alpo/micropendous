/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: xbankdata.c,v 1.6 2006/11/10 15:20:34 yuecelm Exp $
 * 
 */

/*!
 * $Log: xbankdata.c,v $
 * Revision 1.6  2006/11/10 15:20:34  yuecelm
 * the flash flag will be only enabled if the whole image is stored on xbank),
 * add function xbank_register_enable_flash_callback(XBANK_ENABLE_FLASH_CB)
 * (to control the enabling of the flash flag)
 *
 * Revision 1.5  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * 
 */ 

/*
 * @file xbankdata.c
 *
 * \date 2006/03/29 
 *
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch.ch>
 * 
 * management of code images on a node
 */

#include <sys/heap.h>
#include <bt/bt_defs.h>
#include <string.h>
#include <terminal/btn-terminal.h>
#include <debug/logging.h>
#include <mhop/rpc.h>
#include <cdist/xbankdata.h>
#include <cdist/cdist-debug.h>
#include <debug/toolbox.h>
#include <sys/timer.h>

void _xbank_write_proginfo(void){
    u_char buffer[XBANK_PROG_HEADER_LEN];
    buffer[MEM_OFFSET_PROG_TYPE] = _xbank->program_info.type;
    TO_ARRAY32(buffer, MEM_OFFSET_PROG_VER, _xbank->program_info.version);
    buffer[MEM_OFFSET_AKTIV_FLAG] = 0;
    TO_ARRAY32(buffer, MEM_OFFSET_PROG_LEN, _xbank->program_info.size);
    cpy_to_xbank(buffer, XBANK_PROG_HEADER_START, XBANK_PROG_HEADER_LEN);
    update_xbank_crc(XBANK_PROG_HEADER_START, 
                     XBANK_PROG_HEADER_START + XBANK_PROG_HEADER_LEN);    
}

inline void xbank_get_prog_info(xbank_prog_info_t *prog_info){
    memcpy(prog_info, &_xbank->program_info, sizeof(xbank_prog_info_t));
}

void xbank_set_prog_info(xbank_prog_info_t *prog_info){
	memcpy(&_xbank->program_info, prog_info, sizeof(xbank_prog_info_t));
	_xbank_write_proginfo();
}

inline void xbank_set_prog_boot_addr(u_long boot_addr){
	_xbank->program_info.boot_addr = boot_addr;
}

inline void xbank_set_prog_name(char *name){
#ifndef __BTN_UNIX__
	strlcpy(_xbank->program_info.name, name, sizeof(_xbank->program_info.name));
#else
	strncpy(_xbank->program_info.name, name, sizeof(_xbank->program_info.name) - 1);
    _xbank->program_info.name[sizeof(_xbank->program_info.name) - 1] = (u_char) 0;
#endif
}

inline void xbank_update_prog_header(void)
{
	_xbank_write_proginfo();
}

void xbank_init_prog_read(void){
	_xbank->program_pos = XBANK_PROG_DATA_START;
	_xbank->program_recpos = XBANK_PROG_DATA_START;
}

void xbank_init_prog_write(void){
	_xbank->program_info.size = 0;
	_xbank->program_pos = XBANK_PROG_DATA_START;
	_xbank->program_recpos = XBANK_PROG_DATA_START;
	_xbank_write_proginfo(); // size changed
}

void _xbank_save_current_record_header(void){
	if(_xbank->program_pos > XBANK_PROG_DATA_START){
		// there is a record to store
		u_char rec[XBANK_RECORD_HEADER_LEN];
		u_long recaddr = _xbank->program_recaddr;
		u_long reclen = _xbank->program_reclen;
		
		// fill addr and len of current record
		rec[0] = (reclen >> 16) & 0xFF;
		rec[1] = (reclen >> 8) & 0xFF;
		rec[2] = reclen & 0xFF;
		rec[3] = (recaddr >> 16) & 0xFF;
		rec[4] = (recaddr >> 8) & 0xFF;
		rec[5] = recaddr & 0xFF;
		cpy_to_xbank(rec, _xbank->program_recpos, XBANK_RECORD_HEADER_LEN);
	}
}

u_char xbank_write_prog_record(u_long addr){	
	// store previous record
	_xbank_save_current_record_header();
	
	// init next record values
	_xbank->program_recaddr = addr;
	_xbank->program_reclen = 0;
	_xbank->program_recpos = _xbank->program_pos;
	
	_xbank->program_pos += XBANK_RECORD_HEADER_LEN;
    if(_xbank->program_pos > XBANK_PROG_END)
        return 1;
    return 0;
}

u_char xbank_read_prog_record(u_long *addr, u_long *len){	
	u_char rec[XBANK_RECORD_HEADER_LEN];
	
	// check end of program
	if(_xbank->program_recpos > _xbank->program_info.size)
		return 1;
	
	// read current record
	cpy_from_xbank(rec, _xbank->program_recpos, XBANK_RECORD_HEADER_LEN);
	
	// extract values
	*len = ((u_long) rec[0] << 16) | ((u_long) rec[1] << 8) | ((u_long) rec[2]);
	*addr = ((u_long) rec[3] << 16) | ((u_long) rec[4] << 8) | ((u_long) rec[5]);
	
	_xbank->program_pos = _xbank->program_recpos+XBANK_RECORD_HEADER_LEN;
	
	// get next record position
	_xbank->program_recpos += *len + XBANK_RECORD_HEADER_LEN;
	
	return 0;
}

u_char xbank_write_prog_data(u_char *buffer, u_short len){
    if(_xbank->program_pos+len > XBANK_PROG_END)
        return 1;
	// store data
	cpy_to_xbank(buffer, _xbank->program_pos, len);
	_xbank->program_pos += len;
	// update len of current record
	_xbank->program_reclen += len;
    return 0;
}

void xbank_read_prog_data(u_char *buffer, u_short len){
	cpy_from_xbank(buffer, _xbank->program_pos, len);
	_xbank->program_pos += len;
}

u_char xbank_write_prog_crc(u_char *buffer){
	// save last record
	_xbank_save_current_record_header();
    
    if(_xbank->program_pos+2 > XBANK_PROG_END)
        return 1;
	
	// remember program size
	_xbank->program_info.size = _xbank->program_pos - XBANK_PROG_DATA_START;
	xbank_update_prog_header();
	
	// crc
	if(buffer == NULL){
		update_xbank_crc(XBANK_PROG_DATA_START, _xbank->program_pos);
	}else{
		cpy_to_xbank(buffer, _xbank->program_pos, 2);
	}
    return 0;	
}

u_char xbank_get_program_lock(void){
	if(_xbank->program_lock == 0){
		_xbank->program_lock = 1;
		return 0;
	}
	return 1;
}

void xbank_free_program_lock(void){
	_xbank->program_lock = 0;
}

u_char xbank_check_program(void){
	return !_xbank->program_valid;
}

void _xbank_enable_flash(u_char enable)
{
    if (enable)
    {
        enable = REPROG_BOOT_ACTIVE;
    }
    
    // write active flag
    cpy_to_xbank(&enable, XBANK_PROG_HEADER_START + MEM_OFFSET_AKTIV_FLAG, 1);

    // update CRC of bootloader header
    update_xbank_crc(XBANK_PROG_HEADER_START, 
                     XBANK_PROG_HEADER_START + XBANK_PROG_HEADER_LEN);
}

u_char xbank_validate_program(void){
    _xbank->program_valid = 0;
    
    // sync proginfo to xbank
    _xbank_write_proginfo();
    
    // now check what we've got...
    u_char buffer[XBANK_PROG_HEADER_LEN];
    u_long progsize;

    // check prog header crc
    if (check_xbank_crc(XBANK_PROG_HEADER_START, XBANK_PROG_HEADER_START + XBANK_PROG_HEADER_LEN))
        return 1;  //header crc wrong

    cpy_from_xbank(buffer, XBANK_PROG_HEADER_START, XBANK_PROG_HEADER_LEN);
    progsize = FROM_ARRAY32(buffer, MEM_OFFSET_PROG_LEN);
    
    // check program length
    if (progsize == 0)
        return 2; // program length is zero
    
    // check prog data crc
    if (check_xbank_crc(XBANK_PROG_DATA_START, 
                        XBANK_PROG_DATA_START + progsize))
        return 3;    //data crc or prog_len wrong
    
    // no errors found, mark this valid
    _xbank->program_valid = 1;
    
    if (_xbank->program_info.type == XBANK_PROG_TYPE_DSN)
    {
        if (_xbank->enable_flash_cb != NULL)
        {
            _xbank_enable_flash(_xbank->enable_flash_cb(&_xbank->program_info));
        }
        else
        {
            _xbank_enable_flash(1);
        }
    }
    
    return 0;
}

void xbank_invalidate_program(void)
{
    _xbank->program_valid = 0;
    memset(&_xbank->program_info, 0, sizeof(_xbank->program_info));
    _xbank_enable_flash(0);  // disable active flag
}

void xbank_init(void)
{
    _xbank = NutHeapAllocClear(sizeof(xbank_stack_t));
}

void xbank_register_enable_flash_callback(XBANK_ENABLE_FLASH_CB)
{
    _xbank->enable_flash_cb = enable_flash_cb;
}
