/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: cdist.c,v 1.13 2006/11/10 15:20:34 yuecelm Exp $
 * 
 */

/*!
 * $Log: cdist.c,v $
 * Revision 1.13  2006/11/10 15:20:34  yuecelm
 * the flash flag will be only enabled if the whole image is stored on xbank),
 * add function xbank_register_enable_flash_callback(XBANK_ENABLE_FLASH_CB)
 * (to control the enabling of the flash flag)
 *
 * Revision 1.12  2006/10/26 13:26:51  kevmarti
 * - Adaption to obsolete typedef 'bt_msg'
 * - Included syslog debug definitions
 *
 * Revision 1.11  2006/10/23 10:45:04  kevmarti
 * Adapted to new interface of function 'bt_psm_service_set_buffers()' provided by 'bt/bt_psm.h'
 *
 * Revision 1.10  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * 
 */ 

/*
 * cdist.c
 *
 * \date 2004/09/08 
 *
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch.ch>
 * 
 * distribute data/code/files to nodes in a network
 */

#include <sys/thread.h>
#include <sys/types.h>
#include <sys/event.h>
#include <sys/timer.h>
#include <sys/heap.h>
#include <led/btn-led.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_acl_defs.h>
#include <debug/logging.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <mhop/mhop_cl.h>
#include <cm/con_mgr.h>
#include <hardware/ram_banks.h>
#include <cdist/xbankdata.h>
#include <cdist/cdist-debug.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CDIST
#define LOG_LEVEL SYSLOG_LEVEL_CDIST
#include <debug/log_set.h>

#define CDIST_ACK 11
#define CDIST_NACK 12
#define CDIST_INFO 13
#define CDIST_DATA 14

#define CDIST_WAIT_TIMEOUT (60*1000L)
#define CDIST_REPLY_TIMEOUT (5*1000L)
#define CDIST_DATA_TIMEOUT (5*1000L)
#define CDIST_PKT_SLEEP 0

// code distribution states
#define CDIST_READY     1
#define CDIST_ADVERTISE 2
#define CDIST_DOWNLOAD  3
#define CDIST_STOPPED   4

/* NOTE: Uncomment this to use the safe version of cdist 
 *       where every packet is acked. -> flow control
 *       Data rate will be reduced to ~1.5KB/s when enabled.
 *       
 */
//#define CDIST_USE_ACK

typedef struct _cdist_pkt_info_s {
    u_char ptype;
    xbank_prog_info_t prog_info;
} _cdist_pkt_info_t;

typedef struct _cdist_pkt_reply_s {
    u_char ptype;
    u_short seq_nr;
} _cdist_pkt_reply_t;

#define CDIST_DATA_HEADER_LEN 3
//#define CDIST_MAX_DATA_LEN            (L2CAP_CL_PKT_MAX_PAYLOAD-CDIST_DATA_HEADER_LEN)
#define CDIST_MAX_DATA_LEN 100    // TODO fix this
typedef struct _cdist_pkt_data_s {
    u_char ptype;
    u_short seq_nr;
    u_char data[CDIST_MAX_DATA_LEN];
} _cdist_pkt_data_t;

typedef struct _cdist_stack_s {
  // code distribution
  u_long progpos;               // byte position in program data
  u_long proglen;               // length of program data
  u_short seq_nr;               // expected seq_nr of next program data pkt
  u_char state;
  bt_hci_con_handle_t neighbour;    // current neighbour the cdist thread talks to
  _cdist_pkt_reply_t reply; // ACK or NACK pkt from cdist_neighbour
  HANDLE timer_data;            // timer for timeout when downloading
  HANDLE event_reply;           // reply pkt arrived
  HANDLE event_start;           // start code distribution
  struct btstack* bt_stack;
  u_char* data_pkt;
  bt_psm_t* psmux;
  u_short psm;
  u_char proc_nr;
} _cdist_stack_t;

static _cdist_stack_t* _cdist_stack;

void _cdist_cleanup_download(u_char success)
{
    _cdist_stack->state = CDIST_READY;
    xbank_free_program_lock();
    btn_led_clear_pattern_queue();
    if(success){
        btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 8, 2, 16);
    }else{
        btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 2, 2, 16);
    }
}

void _cdist_timer_cb(HANDLE handle, void *arg)
{
    ERROR("cdist download failed: timeout\n");
    _cdist_cleanup_download(0);
}

void _cdist_send_nack(bt_hci_con_handle_t con_handle)
{
    // alloc pkt
    u_char data[sizeof(_cdist_pkt_reply_t)];
    _cdist_pkt_reply_t* reply = (_cdist_pkt_reply_t*)data;
    
    reply->ptype = CDIST_NACK;
    l2cap_cl_send(data,
    				sizeof(_cdist_pkt_reply_t),
    				con_handle,
    				_cdist_stack->psm);
    
    DEBUG("cdist nack sent to %u\n", con_handle);
}

void _cdist_send_ack(bt_hci_con_handle_t con_handle, u_short seq_nr)
{
    // alloc pkt
    u_char data[sizeof(_cdist_pkt_reply_t)];
    _cdist_pkt_reply_t* reply = (_cdist_pkt_reply_t*)data;
    
    reply->ptype = CDIST_ACK;
    reply->seq_nr = seq_nr;
    l2cap_cl_send(data,
    				sizeof(_cdist_pkt_reply_t),
    				con_handle,
					_cdist_stack->psm);
    
    DEBUG("cdist ack sent to %u\n", con_handle);
}

void _cdist_send_program(bt_hci_con_handle_t con_handle)
{
    long res;
    u_short cpy_len;
    u_long prog_end, prog_addr;
    xbank_prog_info_t prog_info;
    
    // alloc pkt
    _cdist_pkt_data_t* data = (_cdist_pkt_data_t*) _cdist_stack->data_pkt;
    
    
    // TODO: check program code here?

    xbank_get_prog_info(&prog_info);
    // send CDIST_DATA
    prog_end = XBANK_PROG_HEADER_LEN+MEM_CRC+prog_info.size+MEM_CRC;
    prog_addr = XBANK_PROG_HEADER_START;
    data->ptype = CDIST_DATA;
    data->seq_nr = 0;
    
    while(prog_addr < prog_end){
        cpy_len = MIN(CDIST_MAX_DATA_LEN, prog_end-prog_addr);
        cpy_from_xbank(data->data, prog_addr, cpy_len);
        res = l2cap_cl_send(_cdist_stack->data_pkt, 
                             (u_short)(cpy_len+CDIST_DATA_HEADER_LEN),
                             con_handle,
                             _cdist_stack->psm);
        if(res != 0){                             
            ERROR("send prog: nb %u, res %ld, cpylen %u\n", _cdist_stack->neighbour, res, cpy_len);
            break;    
        }
        //DEBUG("send prog: addr=%lu seq=%u len=%u\n", prog_addr, data->seq_nr, cpy_len);
 #ifdef CDIST_USE_ACK
        // wait for ack
        _cdist_stack->reply.ptype = 0;
        NutEventWait(&_cdist_stack->event_reply, CDIST_REPLY_TIMEOUT);
        if(_cdist_stack->reply.ptype != CDIST_ACK){
            ERROR("send prog: ack timeout from nb %u\n", con_handle);
            break;
        }
 #else
        // wait some time, give other threads a chance
        if(CDIST_PKT_SLEEP > 100){
            NutSleep(CDIST_PKT_SLEEP);
        }
        else{
            NutThreadYield();
        }
 #endif
        data->seq_nr++;
        prog_addr += cpy_len;
    }
}


void _cdist_handle_data(bt_hci_con_handle_t con_handle, 
                        u_char* data,
                        u_short len)
{                        
    _cdist_pkt_data_t* cdist_data = (_cdist_pkt_data_t*) data;
    u_short data_len = len - CDIST_DATA_HEADER_LEN;
                                 
    if(_cdist_stack->state != CDIST_DOWNLOAD &&
       con_handle != _cdist_stack->neighbour){
        // ignore packet
        WARNING("cdist data: pkt ignored\n");
        return;
    }
       
       
    NutTimerStop(_cdist_stack->timer_data);
    // check program length
    if(_cdist_stack->progpos+data_len > _cdist_stack->proglen){
        // something went wrong here
        // anyway, ready for new programs
        ERROR("cdist download failed: program size\n");
        _cdist_cleanup_download(0);
        return;
    }
    
    // check seq nr
    if(_cdist_stack->seq_nr != cdist_data->seq_nr){
        // uh oh, unexpected seq nr
        ERROR("cdist download failed: seq nr (wanted=%u, got=%u)\n", _cdist_stack->seq_nr, cdist_data->seq_nr);
        _cdist_cleanup_download(0);
        return;
    }       
    
    // next seq nr
    _cdist_stack->seq_nr++;
    
    // store prog data
    u_long xaddr = XBANK_PROG_HEADER_START + _cdist_stack->progpos;
    cpy_to_xbank(cdist_data->data, xaddr, data_len);
    _cdist_stack->progpos += data_len;
    //tprintf("CDIST: data pkt seq=%u len=%u, pos=%lu\n", cdist_data->seq_nr, datalen, _cdist_stack->remprog_pos);
        
 #ifdef CDIST_USE_ACK           
        // send ack for this pkt (seq_nr+1)
        _cdist_send_ack(con_handle, _cdist_stack->seq_nr);
 #endif
        // is program complete?
    if(_cdist_stack->progpos == _cdist_stack->proglen){
        // program data should be complete
        // check program consistency
        u_char failed = xbank_validate_program();
        if (failed) {
            // error
            ERROR("cdist download failed: checksum error (%d)\n", failed);
            _cdist_cleanup_download(0);
        } else {
            // program crc ok
            INFO("cdist download complete :)\n");
            _cdist_cleanup_download(1);
            // got new program -> wake cdist thread
            NutEventPostAsync(&_cdist_stack->event_start);
        }
        return;
    }
         
    // set timeout
    _cdist_stack->timer_data = NutTimerStart(CDIST_DATA_TIMEOUT, _cdist_timer_cb, NULL, TM_ONESHOT);

    // free packet buffer
    return;
}

void _cdist_handle_info(bt_hci_con_handle_t con_handle, u_char* data, u_short len)
{   
    if(_cdist_stack->state != CDIST_READY){
        _cdist_send_nack(con_handle);
        return; 
    }
    
    _cdist_pkt_info_t* info = (_cdist_pkt_info_t*) data;
    
    if(xbank_check_program() == 0){
        // there is already a program here
        //  -> compare proginfos
        xbank_prog_info_t my_proginfo;
        xbank_get_prog_info(&my_proginfo);
        // version check
        if(my_proginfo.version >= info->prog_info.version) {
            INFO("cdist init: mine is better\n");
            _cdist_send_nack(con_handle);
            return; 
        }
    }
    
    if(xbank_get_program_lock()){
        INFO("cdist init: program locked\n");
        _cdist_send_nack(con_handle);
        return;
    }
    
    // 'delete' any previous program
    xbank_invalidate_program();  
    // switch to download mode
    _cdist_stack->state = CDIST_DOWNLOAD;
    // remember host
    _cdist_stack->neighbour = con_handle;
    // total length of program data to receive
    _cdist_stack->proglen = XBANK_PROG_HEADER_LEN+MEM_CRC+info->prog_info.size+MEM_CRC;
    // store program properties
    xbank_set_prog_info(&info->prog_info);
    // reset pkt status
    _cdist_stack->seq_nr = 0;
    _cdist_stack->progpos = 0;
    
    INFO("cdist download start: %lu bytes from nb %u\n", _cdist_stack->proglen, con_handle);
    
    // send ack
    _cdist_send_ack(con_handle, 0);
    
    // waiting for data pkt, setup timeout
    _cdist_stack->timer_data = NutTimerStart(CDIST_DATA_TIMEOUT, _cdist_timer_cb, NULL, TM_ONESHOT);
    btn_led_clear_pattern_queue();
    btn_led_add_pattern(BTN_LED_PATTERN_HALF, 0, 3, BTN_LED_INFINITE);
}

void _cdist_handle_reply(bt_hci_con_handle_t con_handle, u_char* data, u_short len){

    _cdist_pkt_reply_t* reply = (_cdist_pkt_reply_t*) data;
    
    if(_cdist_stack->state != CDIST_ADVERTISE){
        // ignore packet
        WARNING("cdist ack failed: not advertising\n");
        return; 
    }
    
    if(con_handle != _cdist_stack->neighbour){
        WARNING("cdist ack failed: wrong nb\n");
        return; 
    }
    
    _cdist_stack->reply.ptype = reply->ptype;
    if(reply->ptype == CDIST_ACK){
        _cdist_stack->reply.seq_nr = reply->seq_nr;
    }
    NutEventPostAsync(&_cdist_stack->event_reply);
    DEBUG("cdist ack %u posted from %u\n", _cdist_stack->reply.seq_nr, con_handle );
}


bt_acl_pkt_buf* _cdist_data_cb(bt_acl_pkt_buf* pkt_buf, u_char* data,
                        u_short data_len, u_short service_nr, void* cb_arg)
{
    bt_hci_con_handle_t con_handle = bt_acl_get_con_handle(pkt_buf->pkt);

    switch(data[0]){
        case CDIST_DATA:
            _cdist_handle_data(con_handle, data, data_len);
            break;
        case CDIST_INFO:
            _cdist_handle_info(con_handle, data, data_len);
            break;
        case CDIST_ACK:
        case CDIST_NACK:
            _cdist_handle_reply(con_handle, data, data_len);
            break;
    }

    return pkt_buf;
}




//========================================================================================
THREAD(CDIST, arg)
{
    u_char n,i;

    // alloc pkt
    
    u_char data[sizeof(_cdist_pkt_info_t)];
    _cdist_pkt_info_t* info = (_cdist_pkt_info_t*)data;
        
    // set priority
    NutThreadSetPriority(210); //low priority
    
    bt_hci_con_handle_t neighbours[BT_HCI_MAX_NUM_CON];
    
    DEBUG("dsn code distribution thread on\n");
    
    for(;;) {
        // wait for event/timer
        NutEventWait(&_cdist_stack->event_start, CDIST_WAIT_TIMEOUT);
        
        //INFO("cdist ad run started...\n");        
        if(_cdist_stack->state != CDIST_READY){
            INFO("cdist ad failed: not ready\n");
            continue;   
        }
        
        if(xbank_check_program()){
            WARNING("cdist ad failed: program invalid\n");
            continue;
        }
        
        // get lock
        if(xbank_get_program_lock()){
            INFO("cdist ad failed: lock\n");
            continue;
        }
        
       
        // switch to advertise mode
        _cdist_stack->state = CDIST_ADVERTISE;  
        
        // collect program information to advertise
        info->ptype = CDIST_INFO;
        xbank_get_prog_info(&info->prog_info);
        // get list of my neighbours
        n = con_mgr_get_rel_cons(neighbours);
        DEBUG("cdist ad: #neighbours = %u\n", n);
        
        // for all neighbours
        for(i = 0; i < n; i++){
            _cdist_stack->neighbour = neighbours[i];
            DEBUG("cdist ad: neighbour = %u\n", neighbours[i]);
            // advertise own fw version
            l2cap_cl_send(data,
            				sizeof(_cdist_pkt_info_t),
            				neighbours[i],
            				_cdist_stack->psm);
            // await reply from this neighbour
            _cdist_stack->reply.ptype = 0;
            NutEventWaitNext(&_cdist_stack->event_reply, CDIST_REPLY_TIMEOUT);
            // if ack send program
            if(_cdist_stack->reply.ptype == CDIST_ACK) {
                DEBUG("cdist ad: nb %u sent ack, sending program...\n", neighbours[i]);
                // temporary disable all cm inquiries
                _cdist_send_program(neighbours[i]);
            } else if(_cdist_stack->reply.ptype == CDIST_NACK){
                DEBUG("cdist ad: nb %u sent nack\n", neighbours[i]);
            }else{
                WARNING("cdist ad: nb %u timed out\n", neighbours[i]);
            }
        }
        
        // free lock
        xbank_free_program_lock();
        _cdist_stack->state = CDIST_READY;
        INFO("cdist ad run finished...\n");
    }
}


void cdist_init(struct btstack* bt_stack,
                    bt_psm_t* psmux,
                    u_short cdist_psm)
{    
    xbank_init();
    // init cdist stack
    _cdist_stack = NutHeapAllocClear(sizeof(_cdist_stack_t));
    _cdist_stack->bt_stack = bt_stack;
    _cdist_stack->psmux = psmux;
    _cdist_stack->psm = cdist_psm;
    _cdist_stack->state = CDIST_READY;
    _cdist_stack->data_pkt = NutHeapAllocClear(l2cap_cl_max_payload());

    //register service
    long retval = bt_psm_service_register(psmux, cdist_psm, _cdist_data_cb, NULL);
    if(retval < 0){ 
        ERROR("register psm %d: %d\n", cdist_psm, retval);
    }
    
    // init code distribution thread
    NutThreadCreate("cdist", CDIST, 0, 2048);
}

u_char cdist_on(void){
    if(_cdist_stack->state == CDIST_STOPPED){
        _cdist_stack->state = CDIST_READY;
        return 0;
    }
    else return 1;
}

u_char cdist_off(void){
    if(_cdist_stack->state == CDIST_READY){
        _cdist_stack->state = CDIST_STOPPED;
        return 0;
    }
    else return 1;
}

u_char cdist_run(void){
    if(_cdist_stack->state == CDIST_READY){
        NutEventPostAsync(&_cdist_stack->event_start);    
        return 0;
    }
    else return 1;
}
