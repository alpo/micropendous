/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: hexfile.c,v 1.14 2006/10/26 13:27:04 kevmarti Exp $
 * 
 */

/*!
 * $Log: hexfile.c,v $
 * Revision 1.14  2006/10/26 13:27:04  kevmarti
 * - Included syslog debug definitions
 *
 * Revision 1.13  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * 
 */ 

/*
 * hexfile.c
 *
 * \date 2006/08/09 
 *
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch.ch>
 * 
 * read in a .hex file via serial port
 */


#include <io.h>
#include <stdlib.h>
#include <string.h>
#include <dev/uart.h>
#include <dev/usartavr.h>
#include <sys/timer.h>
#include <terminal/btn-terminal.h>
#include <hardware/ram_banks.h>
#include <cdist/xbankdata.h>
#include <debug/logging.h>
#include <debug/toolbox.h>
#include <cm/con_mgr.h>
#include <cdist/hexfile.h>
#include <cdist/cdist-debug.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CDIST
#define LOG_LEVEL SYSLOG_LEVEL_CDIST
#include <debug/log_set.h>

#define MIN_HEX_LINE_LEN (1+2+4+2+2 +1)    // incl. newline
#define MAX_HEX_LINE_LEN (1+2+4+2+32+2 +1) // incl. newline
#define HEX2BYTE(c) (u_char)(((c)<='9') ? (c)-'0' : (c) - 'A' + 10)

// errors
#define HEX_ERR_READ     1
#define HEX_ERR_FORMAT   2

#define MAX_DATA_LEN 16
typedef struct hex_record_s {
    u_char datalen;
    u_short addr;
    u_char type;
    u_char data[MAX_DATA_LEN];
    u_char cc;
} hex_record_t;

typedef struct hexfile_stack_s {
    FILE* stream;
    hex_record_t record;
    u_char uart_errors;
} hexfile_stack_t;

static hexfile_stack_t _hexfile_stack;

u_char _hex2byte(u_char *hex)
{
	u_char b = HEX2BYTE(hex[0]) << 4 | HEX2BYTE(hex[1]);
	return b;
}

u_char _read_fully(u_char *buffer, u_char count){
    short read;
    while(count > 0){
        read = _read(_fileno(stdout), buffer, count);
        if(read == -1)
            return 1;
        count -= (u_char) read;
        buffer += (u_char) read;
    }
    // check driver status
    _hexfile_stack.uart_errors = get_uart_errors(_fileno(_hexfile_stack.stream));
    if(_hexfile_stack.uart_errors)
        return 1;
    return 0;
}

u_char _hex_record_read(void)
{
	u_char b, cc;
	u_char i;
	u_char linebuf[MAX_HEX_LINE_LEN];
	u_char *line = linebuf;

	// read static part
    if(_read_fully(linebuf, 9)){
        return HEX_ERR_READ;
    }

	if(*line != ':' )
		return HEX_ERR_FORMAT;
	line++;
		
	// checksum init
	cc = 0;
	
	// data length
	b = _hex2byte(line);
	if(b > MAX_DATA_LEN)
		return HEX_ERR_FORMAT;
	_hexfile_stack.record.datalen = b;
	cc += b;
	line+=2;
		
	// addr
	// high byte
	b = _hex2byte(line);
	_hexfile_stack.record.addr = b << 8;
	cc += b;
	line+=2;
	// low byte
	b = _hex2byte(line);
	_hexfile_stack.record.addr |= b;
	cc += b;
	line+=2;
	
	// record type
	b = _hex2byte(line);
	_hexfile_stack.record.type = b;
	cc += b;
	line+=2;

    // read variable part
    if(_read_fully(line, _hexfile_stack.record.datalen*2+2+1)){
        return HEX_ERR_READ;
    }
	
	// read data
	for(i = 0; i < _hexfile_stack.record.datalen; i++){
		b = _hex2byte(line);
		_hexfile_stack.record.data[i] = b;
		cc += b;
		line+=2;
	}
	
	// read cc field
	b = _hex2byte(line);
	_hexfile_stack.record.cc = b;
	
	// check cc
	cc = (u_char) ~cc + 1; // two's complement
	if(_hexfile_stack.record.cc != cc)
		return HEX_ERR_FORMAT;

	return 0;
}

void _loadhex_cmd_usage(void)
{
    tprintf("loadhex: usage: loadhex <ver> <type: 0=dsn, 1=tg> [<name>]\n");
}

void _loadhex_cmd(char * arg)
{
	unsigned int type;
	u_char terminate;
	u_long base_addr, seg_start_addr;
	u_short lines;
	// address the next data block would be written to if we would write the
	// program data contiguously
	u_long cont_addr;
	u_long addr;
	u_char first_record;
    
    // parse cmd line and set program properties
    xbank_prog_info_t prog_info;
    
    
    char* carg = arg;
    prog_info.version = strtoul(carg, &carg, 10);
    if(arg == (char*) carg){
        _loadhex_cmd_usage();
        return;
    }
    arg = carg;
    tprintf("first invalid: %c\n", *arg);
    carg++;
    sscanf(carg, "%u", &type);
    prog_info.type = type;
    tprintf("type: %u\n", prog_info.type);
    carg++;
    
//    prog_info.type = strtoul(carg, &carg, 10);
//    if(arg == (char*) carg){
//        _loadhex_cmd_usage();
//        return;
//    }
    if(*carg != '\0')
        carg++; // omit space
#ifndef __BTN_UNIX__
    strlcpy(prog_info.name, carg, sizeof(prog_info.name));
#else
    strncpy(prog_info.name, carg, sizeof(prog_info.name) -1);
    prog_info.name[sizeof(prog_info.name) -1] = (u_char) 0;
#endif
	
    tprintf("version: %lu\n", prog_info.version);
    tprintf("type: %u\n", prog_info.type);
    tprintf("name: %s\n", prog_info.name);
    
    // get program lock
    if(xbank_get_program_lock()){
        tprintf(":LH failed: program locked\n");
        return; 
    }
	
	xbank_invalidate_program();
    xbank_set_prog_info(&prog_info);
	xbank_init_prog_write();
    
	// init 
	first_record = 1;
	base_addr = 0;
	seg_start_addr = 0;
	cont_addr = 0;
	terminate = 0;
	lines = 0;
	
//    NutSleep(1000);
	
	tprintf("ready to receive hexfile, press enter to quit.\n");
	while(!terminate){
		u_char retval;
        
		if((retval = _hex_record_read())){
            if(retval == HEX_ERR_READ)
			    tprintf(":LH failed: read error: %u\n", _hexfile_stack.uart_errors);
            else
                tprintf(":LH failed: hex format\n");
			xbank_free_program_lock();
			return;
		}
		lines++;
		
		switch(_hexfile_stack.record.type){
			case HEX_RECORD_DATA:
				addr = base_addr + _hexfile_stack.record.addr;
				// we only create a new record in xmem if the data cannot be written
				// contiguously
				if (first_record || (addr != cont_addr))
				{
					DEBUG("new record: addr=%lx\n", addr);
					retval = xbank_write_prog_record(addr);
					cont_addr = addr;
					first_record = 0;
				}
				
				// write data
				retval = xbank_write_prog_data(_hexfile_stack.record.data, _hexfile_stack.record.datalen);
				
				// increase continued address
				cont_addr += _hexfile_stack.record.datalen;
				break;
			case HEX_RECORD_EOR:
				DEBUG("eor\n");
				// generate data crc
				retval = xbank_write_prog_crc(NULL);
				terminate = 1;
				break;
			case HEX_RECORD_ESA:
				base_addr = ((u_long)_hexfile_stack.record.data[0] << 12) | ((u_long)_hexfile_stack.record.data[1] << 4);
				DEBUG("esa=%lx\n", base_addr);
				break;
			case HEX_RECORD_ELA:
				base_addr = ((u_long)_hexfile_stack.record.data[0] << 24) | ((u_long)_hexfile_stack.record.data[1] << 16);
				DEBUG("ela=%lx\n", base_addr);
				break;
			case HEX_RECORD_SSA:
				seg_start_addr = (((u_long)_hexfile_stack.record.data[0] << 12) | 
				                 ((u_long)_hexfile_stack.record.data[1] << 4)) + // ext. seg. addr part
				                 (((u_long)_hexfile_stack.record.data[2] << 8) |
				                 ((u_long)_hexfile_stack.record.data[3]));       // offset addr part
				DEBUG("ssa=%lx\n", seg_start_addr);
				break;
			default:
				tprintf(":LH failed: record type\n");
				xbank_free_program_lock();
				return;
		}
        
        if(retval){
            tprintf(":LH failed: program size\n");
            xbank_free_program_lock();
            return;
        }		
	}                	
	
    // set start addr
    xbank_set_prog_boot_addr(seg_start_addr);
	
	// check program
    if(xbank_validate_program()){
    	tprintf(":LH failed: program check\n");
    }else{
    	tprintf(":LH completed: %u lines read\n", lines);
    }
    
    xbank_free_program_lock();
}

void hexfile_init(FILE* stream){
    _hexfile_stack.stream = stream;
}

void hexfile_register_cmds(void)
{
    btn_terminal_register_cmd("loadhex", _loadhex_cmd);		
}
