#include <sync/sync_rtt.h>
#include <time/btn-time.h>
#include <string.h>
#include <debug/syslog.h>

#define LOG_CLASS SYSLOG_CLASS_SYNC
#define LOG_LEVEL 0
#include <debug/log_set.h>

void _sync_push_rtt(u_char* stamp, u_long n){
	u_char * ptr = (u_char*) &n;
	stamp[SYNC_TSTAMP_OFFSET_RTT] = *(ptr + 0);
	stamp[SYNC_TSTAMP_OFFSET_RTT + 1] = *(ptr + 1);
	stamp[SYNC_TSTAMP_OFFSET_RTT + 2] = *(ptr + 2);
	stamp[SYNC_TSTAMP_OFFSET_RTT + 3] = *(ptr + 3);
}

void _sync_pop_rtt(u_long* n, u_char* stamp){
	u_char * ptr = (u_char*) n;

	*(ptr + 0) = stamp[SYNC_TSTAMP_OFFSET_RTT];
	*(ptr + 1) = stamp[SYNC_TSTAMP_OFFSET_RTT + 1];
	*(ptr + 2) = stamp[SYNC_TSTAMP_OFFSET_RTT + 2];
	*(ptr + 3) = stamp[SYNC_TSTAMP_OFFSET_RTT + 3];
}

//integer division by right-shift, preceded by adding 2^20 (this would have been
//	 the msb of the discarded fractional part)
u_long _sync_calculate_drift(u_long delta_h, u_long bound, long int drift_fac)
{
	return ((bound) + (u_long)((((long long)delta_h * drift_fac) + 1048576) >> 20));
}


/*****************************************
 * list functions                        *
 *****************************************/
sync_neigh* _sync_neigh_get(bt_hci_con_handle_t hdl)
{
	u_char i;
	
	for (i=0; i<BT_HCI_MAX_NUM_CON; i++)
	{
		if (sync_globals.neighs[i].hdl == hdl) return &sync_globals.neighs[i];
	}
	return NULL;
}

sync_neigh* _sync_neigh_add(bt_hci_con_handle_t hdl)
{
	u_char i;
	
	for (i=0; i<BT_HCI_MAX_NUM_CON; i++)
	{
		if (sync_globals.neighs[i].hdl == BT_HCI_HANDLE_INVALID)
		{
			sync_globals.neighs[i].hdl = hdl;
			sync_globals.neighs[i].last_rcvd = 0;
			sync_globals.neighs[i].last_send = 0;
			return &sync_globals.neighs[i];
		}
	}
	return NULL;
}

sync_neigh* _sync_neigh_remove(bt_hci_con_handle_t hdl)
{
	u_char i;
	
	for (i=0; i<BT_HCI_MAX_NUM_CON; i++)
	{
		if (sync_globals.neighs[i].hdl == hdl)
		{
			sync_globals.neighs[i].hdl = BT_HCI_HANDLE_INVALID;
			return &sync_globals.neighs[i];
		}
	}
	return NULL;
}

 /*******************************************************************************
 * sync_assemble_timestamp
 ******************************************************************************/
/**
 * @brief Converts two bounds into a timestamp stored in sync_timestamp_to_send
 */
void _sync_assemble_timestamp(u_char* stamp, syncbounds * bounds)
{
	u_char* cp = stamp;
	
	memcpy(cp, &(bounds->lower), SYNC_BOUND_LEN);
	cp += SYNC_BOUND_LEN;
	memcpy(cp, &(bounds->upper), SYNC_BOUND_LEN);
	cp += SYNC_BOUND_LEN;
	*cp = bounds->validity;
//	stamp[SYNC_TSTAMP_OFFSET_1 - 1] |= (u_char) (bounds->validity << 4);
}

 /*******************************************************************************
 * sync_dissassemble_timestamp
 ******************************************************************************/
/**
 * @brief Extracts the two bounds from the sync_timestamp_rcvd timestamp
 */
void _sync_dissassemble_timestamp(syncbounds* bounds, u_char* stamp)
{
	u_char* cp = stamp;
	
	bounds->validity = stamp[SYNC_BOUND_LEN + SYNC_BOUND_LEN];
	
	if(bounds->validity)
	{
		memcpy(&(bounds->lower), cp, SYNC_BOUND_LEN);
		cp += SYNC_BOUND_LEN;
		memcpy(&(bounds->upper), cp, SYNC_BOUND_LEN);
	}
}


void _sync_set_clock_offset(syncbounds* bnds, u_long t_local)
{
	u_long offset;
	u_char sync_state;
	u_long gt;		// global time
	
	if (!sync_globals.is_anchor)
	{
		// get global time at t_arrive
		gt = RT_COARSE_AVERAGE(bnds->lower, bnds->upper);
		// determine if local time lags/leads global time
		if (gt >= t_local)
		{
			offset = gt - t_local;
			sync_state = BTN_TIME_SYNC_LAG;
		}
		else
		{
			offset = t_local - gt;
			sync_state = BTN_TIME_SYNC_LEAD;
		}
		// set offset of local clock to global clock
		btn_time_global_set_offset(offset, sync_state);
		//change heartbeat after setting clock offset
		sync_globals.bitpattern = 0x5;
		btn_led_heartbeat(31, (char) sync_globals.bitpattern, 1);
		DEBUG("snyc offset set! %u, state: %d\n", offset, sync_state);
	}
}


//end bp_isa list funcs

/*****************************************
 * rt_init, rt_set_clock                 *
 *****************************************/

//should be done at startup
//	(especially sync_globals.bounds.validity has to be zero in order to
//	avoid unnecessary (and false) computations. furthermore, we want...
void rt_init(void)
{
	if (sync_globals.is_anchor) {
		sync_globals.bounds.validity = 1;		//the anchor node's bounds are always valid
		sync_globals.bitpattern = 0xA;
		btn_led_heartbeat(31, (char) sync_globals.bitpattern, 1);
	}
	// not anchor node
	else {
		sync_globals.bitpattern = 0x5;
		btn_led_heartbeat(10, (char) 0x1, 1);
	}
}


/*****************************************
 * sync_update_bounds                      *
 *****************************************/
void _sync_update_bounds(syncbounds* bnds, u_long t_ref)
{
	u_long delta_h;

	if (!sync_globals.is_anchor)
	{
		//time elapsed since the last update of the bounds
		delta_h = t_ref - bnds->last_update;
	
		//calculate new bounds
		if(delta_h < 0)
		{
			bnds->lower = _sync_calculate_drift(delta_h, bnds->lower, MAX_DRIFT_FAC_BW);
			bnds->upper = _sync_calculate_drift(delta_h, bnds->upper, MIN_DRIFT_FAC_BW);
		}
		else
		{
			bnds->lower = _sync_calculate_drift(delta_h, bnds->lower, MIN_DRIFT_FAC);
			bnds->upper = _sync_calculate_drift(delta_h, bnds->upper, MAX_DRIFT_FAC);
		}
	}
}


void sync_sync_bounds(syncbounds * rbnds, u_long t_arrive, u_short rtt)
{
	syncbounds* gbnds = &sync_globals.bounds;
	
	//disjoint intervals: received bounds lay beneath our bounds
	//	=> discard bounds
	if(gbnds->lower >= rbnds->upper)
	{
		return;
	}
	// get bounds we had at t_arrive & adjust time of last update
	_sync_update_bounds(gbnds, t_arrive);
	gbnds->last_update = t_arrive;
	
	DEBUG("updated bounds. valid: %d, lo: %li, up: %li\n",
		  gbnds->validity, gbnds->lower, gbnds->upper);
		
	//disjoint intervals: received bounds lay above our bounds
	//	=> make our interval the union of the two intervals
	if(gbnds->upper <= rbnds->lower)
	{
		gbnds->upper = rbnds->upper;
	}
	else
	{
		//lower_bound = max(lower_bound, lower_bound_received)
		if(gbnds->lower < rbnds->lower)
		{
			gbnds->lower = rbnds->lower;
		}
		//upper_bound = min(upper_bound, lupper_bound_received)
		if(gbnds->upper > rbnds->upper)
		{
			gbnds->upper = rbnds->upper;
		}
	}
}


/*****************************************
 * sync_generate_timestamp                 *
 *****************************************/
void sync_generate_timestamp(bt_hci_con_handle_t hdl, u_char* stamp)
{
	sync_neigh* nb;
	syncbounds bnds;
	u_long t_curr;
	
	// find neighbor in the neighbor list
	nb = _sync_neigh_get(hdl);
	
	// get local time
	t_curr = btn_time_local() + SYNC_COMPUTATIONAL_DELAY;
	DEBUG("----- gen t_stamp. hdl: %u, time: %li\n", hdl, t_curr);
	
	/* write rtt to the stamp */
	if (nb)		// only update if valid neighbor was found
	{
		// remember the sending time of this timestamp
		nb->last_send = t_curr;
		
		/** only write local delay to the packet if already measured **/
		if(nb->last_rcvd == 0)
		{
			_sync_push_rtt(stamp, 0);
			INFO("rtt not initialized -> set to 0!\n");
		}
		else
		{
			_sync_push_rtt(stamp, t_curr - nb->last_rcvd);
			DEBUG("local delay: %li\n", t_curr - nb->last_rcvd);
		}
	}
	else
	{
		_sync_push_rtt(stamp, 0);
		DEBUG("neigh not found -> set to 0\n");
	}
	
	/** write bounds to the packet **/
	// the anchor node sends its local time
	if (sync_globals.is_anchor)
	{
		bnds.lower = t_curr - 1;
		bnds.upper = t_curr + 1;
		bnds.last_update = t_curr;
		bnds.validity = 1;
	}
	// sensor nodes have to write their updated bounds to the packet
	else
	{
		// initialize bounds to send with global bounds
		memcpy(&bnds, &sync_globals.bounds, sizeof(syncbounds));
		// update bounds
		_sync_update_bounds(&bnds, t_curr);
	}
	_sync_assemble_timestamp(stamp, &bnds);
	DEBUG("generated.\t\t---\n");
}


void sync_process_timestamp(bt_hci_con_handle_t hdl, u_char* stamp, u_long t_arrive)
{
	sync_neigh * nb;
	long rtt;
	u_long diff;
	// received bounds
	syncbounds rbnds;
	// pointer to global bounds
	syncbounds* gbnds = &sync_globals.bounds;
	
	DEBUG("***** proc tstamp. hdl: %u, t_arrive: %li\n", hdl, t_arrive);
	
	// disassemble timestamp
	_sync_dissassemble_timestamp(&rbnds, stamp);
	DEBUG("bounds rcvd. valid: %d, lo: %li, up: %li\n", rbnds.validity, rbnds.lower, rbnds.upper);
	
	// find neighbor in list
	nb = _sync_neigh_get(hdl);
	
	// return if neighbor could not be found
	if (!nb)
	{
		INFO("neigh not found!\n");
		return;
	}
	
	// adjust arrival time
	nb->last_rcvd = t_arrive;
	
	if(nb->last_send == 0)
	{
		// if we can't determine the RTT, we do not try to synchronize (see below)
		DEBUG("RTT not initialized -> do not synchronize\n");
		rtt = 0;
	}
	else
	{
		_sync_pop_rtt(&diff, stamp);
		rtt = nb->last_rcvd - nb->last_send - diff;
		DEBUG("last rcvd: %li, last sent: %li, rtt: %li\n", nb->last_rcvd, nb->last_send, rtt);
	}

	/** update bounds if this is not the anchor node **/
	if (!sync_globals.is_anchor)
	{
		// only proceed if received bounds are valid
		if (rbnds.validity)
		{
			// check if round trip time is valid
			if ((rtt > (SYNC_MIN_DELAY << 2)) && (rtt < SYNC_MAX_RTT))
			{
				// adjust received bounds
				rbnds.lower += SYNC_MIN_DELAY;
				rbnds.upper += (rtt - SYNC_MIN_DELAY);
				DEBUG("adjusted bounds. lo: %li, up: %li\n", rbnds.lower, rbnds.upper);
				
				// if our bounds are invalid, initialize bounds, else synchronize				
				if(SYNC_CURRENT_BOUNDS.validity == 0)
				{
					// initialize bounds of this sensor node
					gbnds->validity = 1;
					gbnds->lower = rbnds.lower;
					gbnds->upper = rbnds.upper;
					gbnds->last_update = t_arrive;
				}
				else {
					// synchronize bounds with received bounds
					DEBUG("synchronizing...\n");
					sync_sync_bounds(&rbnds, t_arrive, (u_short)rtt);
				}
				
				// update offset of local clock
				_sync_set_clock_offset(gbnds, t_arrive);
			}
		}
	}
	
	DEBUG("bounds synced. valid: %d, lo: %li, up: %li *****\n",
		  gbnds->validity, gbnds->lower, gbnds->upper);
}

void _sync_con_table_change_cb(u_char type, u_char detail, bt_hci_con_handle_t hdl, void* cb_arg)
{
	// add neighbor to the list in case of a connection
	if (type == BT_HCI_CONNECTION)
	{
		if (_sync_neigh_add(hdl))
		{
			DEBUG("neigh added: %u\n", hdl);
		}
		else
		{
			WARNING("neigh list full!\n");
		}
	}
	// remove neighbor from the list in case of a disconnection
	else if (type == BT_HCI_DISCONNECTION)
	{
		if (_sync_neigh_remove(hdl))
		{
			DEBUG("neigh removed: %u\n", hdl);
		}
		else
		{
			WARNING("removing failed. could not found neigh: %u\n", hdl);
		}
	}
	
	// signal higher layer
	if (sync_globals.con_table_cb)
	{
		sync_globals.con_table_cb(type, detail, hdl, sync_globals.con_table_cb_arg);
	}
}

void sync_init(struct btstack* bt_stack, HCI_CON_TABLE_CB_REGISTRATION)
{
	u_char i;
	
	// store pointer to bt-stack to use
	sync_globals.bt_stack = bt_stack;
	
	// initialize neighbor list
	for (i=0; i<BT_HCI_MAX_NUM_CON; i++)
	{
		sync_globals.neighs[i].hdl = BT_HCI_HANDLE_INVALID;
	}
	
	// init mode (sensor node)
	sync_globals.is_anchor = 0;
	
	// invalidate bounds
	sync_globals.bounds.validity = 0;
	
	// invalidate con table change cb
	sync_globals.con_table_cb = 0;
	sync_globals.con_table_cb_arg = 0;
	
	// register own con table change cb
	con_table_cb_reg(bt_stack, _sync_con_table_change_cb, NULL);
}

void sync_register_con_table_cb(struct btstack* bt_stack, HCI_CON_TABLE_CB, void* cb_arg)
{
	sync_globals.con_table_cb = con_table_cb;
	sync_globals.con_table_cb_arg = cb_arg;
}
