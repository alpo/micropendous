#include <sys/thread.h>
#include <sys/event.h>
#include <sys/timer.h>
#include <sys/heap.h>
#include <bt/bt_defs.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_api.h>
#include <bt/l2cap_cl.h>
#include <sync/l2cap_cl_sync.h>
#include <sync/psync.h>

typedef struct _psync_stack_t {
	struct btstack* bt_stack;
	u_long min_period;
	u_long max_period;
	u_short psm;
} psync_stack_t;

psync_stack_t* psync_stack;

u_long _psync_get_rnd_sleep_time(u_long max_sleep) {
    return ((((max_sleep*rand())/RAND_MAX))/125)*125;
}

THREAD(PSYNC, arg) {
	u_char i;
	u_long period = psync_stack->min_period;
	u_char data = 0;
	bt_hci_con_handle_array handles;
	u_char nr_handles;
	u_long rnd_sleep;
	long result;
       
    while(1) {
		// send an empty packet for time synchronization to each connected device
		nr_handles = bt_hci_get_con_handles(psync_stack->bt_stack, handles);
		for (i=0; i<nr_handles; i++) {
			result = l2cap_cl_sync_send_pkt(&data, 1, handles[i], psync_stack->psm);
		}
		
        // sleep
        rnd_sleep = _psync_get_rnd_sleep_time(period);
        NutSleep(period);
        
        // increase period
        period += period;
        if (period >= psync_stack->max_period) period = psync_stack->max_period;
    }
}

void psync_init(struct btstack* bt_stack, u_short tsync_psm, u_long min_period, u_long max_period)
{
	// dyn. allocate & initialize psync stack
	psync_stack = NutHeapAllocClear(sizeof(psync_stack_t));
	psync_stack->bt_stack = bt_stack;
	psync_stack->min_period = min_period;
	psync_stack->max_period = max_period;
	psync_stack->psm = tsync_psm;
	
	NutThreadCreate("PSYNC", PSYNC, 0, 512);
}
