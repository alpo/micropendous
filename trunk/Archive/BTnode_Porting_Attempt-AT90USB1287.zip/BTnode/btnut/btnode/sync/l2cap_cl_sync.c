/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

 /**
 * @file l2cap_cl.c
 *
 *\author Kevin Martin <kevmarti@tik.ee.ethz.ch>
 * 
 *\date 10-14-05
 * 
 *\brief Implementation of the connection-less l2cap layer
 *
 */
#include <bt/bt_hci_api.h>
#include <bt/bt_acl_defs.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <sync/sync_rtt.h>
#include <sync/l2cap_cl_sync.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_SYNC
#define LOG_LEVEL SYSLOG_LEVEL_SYNC
#include <debug/log_set.h>

typedef struct _l2cap_cl_sync_trailer_s {
	u_char psm[L2CAP_CL_PSM_FIELD_SIZE];
	u_char tstamp[SYNC_TSTAMP_LEN];
} _l2cap_cl_sync_trailer;

struct _l2cap_cl_sync_stack_s {
	struct btstack* bt_stack;
	bt_psm_t* psmux;
	u_short sync_psm;
} _l2cap_cl_sync_stack;	

u_char l2cap_cl_sync_isinit = 0;

bt_acl_pkt_buf* _l2cap_cl_sync_cb(bt_acl_pkt_buf* pkt_buf,
								  u_char* data,
							 	  u_short len,
								  u_short service_nr,
								  void* cb_arg)
{
	long retval;
	u_short psm;
	bt_hci_con_handle_t hdl;
	bt_acl_pkt_buf* next_buf;

	// get con handle the packet was received on
	hdl = bt_acl_get_con_handle(pkt_buf->pkt);
	
	// do time synchronization
	sync_process_timestamp(hdl, data + len - SYNC_TSTAMP_LEN, l2cap_cl_get_arrival_time(pkt_buf));
	
	// get original payload size & adjust payload size
	len -= (SYNC_TSTAMP_LEN + L2CAP_CL_PSM_FIELD_SIZE);
	psm = data[len] | data[len + 1] << 8;
	
	DEBUG("tsync: len: %d, psm: %d\n", len, psm);
	
	// if psm equals time sync psm, do not deliver the packet
	if (psm == _l2cap_cl_sync_stack.sync_psm) {
		DEBUG("tsync: sync pkt w.o. data!\n");
		return pkt_buf;
	}
	
	// else, deliver the message
	retval = bt_psm_deliver_msg(_l2cap_cl_sync_stack.psmux, pkt_buf, data, len, psm, &next_buf);
	if (retval)
	{
		ERROR("tsync: delivering pkt to psm %d: %d!\n",
						psm, retval);
		return pkt_buf;
	}
	return next_buf;
}

/**
 * Sends a packet over the link corresponding to the handle passed. On the
 * receiving side, the incoming packet will be handled by the service that
 * is registered at the psm specified.
 */
long l2cap_cl_sync_send_pkt(u_char* data,
							u_short len,
							bt_hci_con_handle_t hdl,
							u_short psm)
{
	long result;
	u_char t_stamp[SYNC_TSTAMP_LEN];
	u_short send_len = len;
	u_short send_psm = psm;

	// add synchronization trailer if there is enough space
	if (len + SYNC_TSTAMP_LEN + L2CAP_CL_PSM_FIELD_SIZE <= l2cap_cl_max_payload())
	{
		send_len += SYNC_TSTAMP_LEN + L2CAP_CL_PSM_FIELD_SIZE;
		send_psm = _l2cap_cl_sync_stack.sync_psm;
	}
	
	// acquire l2cap cl channel
	result = l2cap_cl_acquire_write_lock(hdl, send_psm, send_len);    	
	if (result)
	{
		ERROR("sync: open l2cap cl chan (%d)!\n", result);
		return result;
	}
	
	// write data
	result = l2cap_cl_lowlevel_write(data, len);
	if (result)
	{
		ERROR("sync: send data (%d)!\n", result);
	}
	// if no error, generate timestamp and write it to channel
	else if (send_psm == _l2cap_cl_sync_stack.sync_psm)
	{
		// send original psm
		result = l2cap_cl_lowlevel_write((u_char*)&psm, 2);
		if (result)
		{
			ERROR("sending tstamp (%d)!\n", result);
		}
		else
		{
			// generate time stamp & send it
			sync_generate_timestamp(hdl, t_stamp);
			result += l2cap_cl_lowlevel_write(t_stamp, SYNC_TSTAMP_LEN);
			if (result)
			{
				ERROR("sending tstamp (%d)!\n", result);
			}
		}
	}
	// close channel
	l2cap_cl_release_write_lock();
	return result;
}

/**
 * Initializes the connection-less l2cap protocol stack
 */
void l2cap_cl_sync_init(struct btstack* bt_stack, bt_psm_t* mux, u_short psm)
{
	long tsync_service_nr;
	
	if (!l2cap_cl_sync_isinit)
	{
	    // store pointer to bt-stack
	    _l2cap_cl_sync_stack.bt_stack = bt_stack;
	    // store pointer to the protocol/service multiplexor
	    _l2cap_cl_sync_stack.psmux = mux;
	    _l2cap_cl_sync_stack.sync_psm = psm;
		
		// registe time synchronization callback
		tsync_service_nr =
			bt_psm_service_register(mux, psm, _l2cap_cl_sync_cb, NULL);
		bt_psm_service_set_buffers(mux, tsync_service_nr, NULL);
	}
}
