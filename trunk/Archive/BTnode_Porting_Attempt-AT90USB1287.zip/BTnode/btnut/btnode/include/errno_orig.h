
/**
 * \file errno_orig.h
 * 
 * \author matthias ringwald <mringwal@inf.ethz.ch>
 * 
 * \date 2004-06-08
 * 
 * this file is required for the unix emulation of nut/os
 * and includes the native system's errno.h
 *  
 * if you're system headers are somewhere else, you need to fix this  
 */   

#include "/usr/include/errno.h"

