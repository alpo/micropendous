
/**
 * \file unistd_orig.h
 * 
 * \author matthias ringwald <mringwal@inf.ethz.ch>
 * 
 * \date 2004-06-08
 * 
 * this file is required for the unix emulation of nut/os
 * and includes the native system's unistd.h
 *  
 * if you're system headers are somewhere else, you need to fix this  
 */   

#include "/usr/include/unistd.h"

