#include <sys/types.h>
#include <stdlib.h>
#include <sys/heap.h>
#include <utils/srtd_list.h>

/* Allocates the memory needed for the sorted list (given the parameters as
 * defined in "srtd_list.h"), and initializes it.
 */
srtd_list_t* srtd_list_init(u_char* nr_elems, u_char max_elems, u_long elem_size) {
    u_char i;
    srtd_list_t* list;
    // allocate memory
    list =
    	malloc((sizeof(void**) + elem_size)*max_elems + sizeof(srtd_list_t));
    // set nr of elements
    list->nr_elems = nr_elems;
    // set nr of elements to zero
    *nr_elems = 0;
    // set max nr of elements
    list->max_elems = max_elems;
    // set pointer to list elements
    list->elems = (void**)(((u_char*)list) + sizeof(srtd_list_t));
    // get pointer to first data block
    list->data = ((u_char*)list->elems) + max_elems*sizeof(void**);
    // initialize pointers to data blocks
    for (i=0; i<max_elems; i++) {
        list->elems[i] = (void**)(list->data + i*elem_size);
    }
    return list;
}

/* Registers the callbacks needed by the sorted list
 */
void srtd_list_register_cbs(srtd_list_t* list, \
			    signed char (*elem_cmp)(void*, void*), \
			    void (*elem_init)(void*, void*, u_char), \
			    void (*elem_set)(void*, void*, u_char), \
			    u_char (*is_elem) (void*, void*, u_char)) {
    list->elem_cmp = elem_cmp;
    list->elem_init = elem_init;
    list->elem_set = elem_set;
    list->is_elem = is_elem;
}

/* Adds the element passed to the sorted list at correct position. To get a
 * free data block, use #srtd_list_get_free_entry
 */
short srtd_list_add(srtd_list_t* list, void* args, u_char arg_len) {
    void* elem_data;
    u_char i;
    // if there is not enough space for a new element, return -1
    if (*(list->nr_elems) >= list->max_elems) return -1;
    // get pointer to the next free data block
    elem_data = list->elems[*(list->nr_elems)];

    // initialize element
    list->elem_init(elem_data, args, arg_len);
    // add element at correct position to the list (start from behind)
    for (i=*(list->nr_elems); i>0; i--) {
    	if (list->elem_cmp(elem_data, list->elems[i-1]) < 0) break;
    	list->elems[i] = list->elems[i-1];
    }
    // set pointer to data block
    list->elems[i] = elem_data;
    // increment list size
    (*(list->nr_elems))++;
    return i;
}

/* Returns the index of an elem in the list.
 */
short srtd_list_index_of(srtd_list_t* list, void* args, u_char arg_len) {
    u_char i;
    for (i=0; i < *list->nr_elems; i++) {
        if (list->is_elem(list->elems[i], args, arg_len)) return i;
    }
    return -1;
}


/* Removes the element at position 'index' from the sorted list passed
 */
u_char srtd_list_remove(srtd_list_t* list, u_char index) {
    u_char i;
    void* elem_data;
    // if index is out of bounds, return false
    if (index > list->max_elems) return 0;
    // get pointer to data block of the element that has to be removed
    elem_data = list->elems[index];
    // decrement size of list
    (*(list->nr_elems))--;
    // move remaining elements to the left
    for (i=index; i < *(list->nr_elems); i++) {
        list->elems[i] = list->elems[i+1];
    }
    // write pointer to data block of removed element at last position
    list->elems[*(list->nr_elems)] = elem_data;
    return 1;
}

/* Replaces the element at position 'i' with the element passed. Afterwards,
 * the element added will be moved to the correct place (according to its
 * value - correct place will be determined by using the 'compare' function)
 */
short srtd_list_set(srtd_list_t* list, u_char index, void* args, u_char args_len) {
    u_char i;
    // get pointer to data block of the element that has to be replaced
    void* elem_data = list->elems[index];
    // set new value
    list->elem_set(elem_data, args, args_len);
    // move element to the left, as long as elem > lhs
    for (i=index; i>0; i--) {
	if (list->elem_cmp(list->elems[i-1], elem_data) > 0) break;
	else list->elems[i] = list->elems[i-1];
    }
    // if position of element has changed, return
    if (i != index) {
	list->elems[i] = elem_data;
	return i;
    }
    // else, move element to the right, as long as elem < lhs
    for (i=index; i<*(list->nr_elems)-1; i++) {
	if (list->elem_cmp(list->elems[i+1], elem_data) < 0) break;
	else list->elems[i] = list->elems[i+1];
    }
    list->elems[i] = elem_data;
    return i;
}

/* Clears the sorted list
 */
void srtd_list_clear(srtd_list_t* list) {
    *(list->nr_elems) = 0;
}
