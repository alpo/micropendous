#include <sys/heap.h>
#include <utils/fifo_queue.h>

inline u_short fifo_queue_size(fifo_queue_t* que)
{
	return que->size;
}

inline u_short fifo_queue_max_size(fifo_queue_t* que)
{
	return que->max_size;
}

short fifo_queue_push(fifo_queue_t* que, void* elem)
{
	u_short size = que->size;
	u_short first = que->first;
	u_short max_size = que->max_size;
	// return error if the queue is full
	if (size == max_size) return -1;
	// store element
	que->que_start[(first + size) % max_size] = elem;
	// increment que size
	que->size++;
	return 0;
}

void* fifo_queue_pop(fifo_queue_t* que)
{
	u_short size = que->size;
	u_short first = que->first;
	void* elem;
	// return NULL if queue is empty
	if (!size) return NULL;
	// else, decrement size of queue
	que->size--;
	// get pointer to the element
	elem = que->que_start[first];
	// increment pointer to first element
	que->first = (first + 1) % (que->max_size);
	return elem;
}

inline void* fifo_queue_top(fifo_queue_t* que) {
	if (que->size == 0) return NULL;
	return que->que_start[que->first];
}

fifo_queue_t* fifo_queue_create(u_short max_size)
{
	fifo_queue_t* que;
	// dyn alloc memory for msg queue
	que = NutHeapAlloc(sizeof(fifo_queue_t) + max_size*sizeof(void*));
	que->first = 0;
	que->size = 0;
	que->max_size = max_size;
	que->que_start = ((void*)que) + sizeof(fifo_queue_t);
	return que;
}

void fifo_queue_destroy(fifo_queue_t* que)
{
	NutHeapFree(que);
}
