#include <utils/stack.h>
#include <sys/heap.h>

inline void stack_push(stack_t sp, u_char elem)
{
	*sp++ = elem;
}

inline u_char stack_pop(stack_t sp)
{
	return *(--sp);
}

inline u_char stack_top(stack_t sp)
{
	return *sp;
}

stack_t stack_init(u_short size)
{
	stack_t sp;
	sp = NutHeapAllocClear(size);
	return sp;
}
