
/// Sends a test data packet over a vc
void _vcp_cmds_send_vc_data(u_char handle, u_short len)
{
    // alloc pkt
    u_char pkt_mem[sizeof(PPP_PKT) - 1 + BT_MAX_PAYLOAD];
    PPP_PKT *pkt = (PPP_PKT*)pkt_mem;
    // create packet
    u_char *data = vcp_get_vc_data_pointer( pkt);
    u_char i;
    for (i = 0; i < len; i++) {
        data[i] = i;
    }
    INFO_VCP("Sending testdata:\n");
    //dump_data(data, len);
    vcp_send_vc_data( pkt, handle, len);

}


/// Prints VCP terminal command usage
void _vcp_cmds_print_usage(void)
{
    INFO( LOG_TERMINAL, "tp: error: usage:\n");
    INFO( LOG_TERMINAL, " tp openvc xx:xx:xx:xx:xx:xx\n");
    INFO( LOG_TERMINAL, " tp send <vc-handle> <len>\n");
    INFO( LOG_TERMINAL, " tp psend <vc-handle> <len> <#pkts> <pause 100ms>\n");
    INFO( LOG_TERMINAL, " tp clsnd xx:xx:xx:xx:xx:xx <len>\n");
    INFO( LOG_TERMINAL, " tp close <vc-handle>\n");
    INFO( LOG_TERMINAL, " tp vt (vc table)\n");
    INFO( LOG_TERMINAL, " tp ht (host table)\n");
    INFO( LOG_TERMINAL, " tp rc (reliable con)\n");
    INFO( LOG_TERMINAL, " tp bc\n");
    INFO( LOG_TERMINAL, " tp hd (host delete)\n");
    INFO( LOG_TERMINAL, " tp trace xx:xx:xx:xx:xx:xx\n");
    INFO( LOG_TERMINAL, " tp con xx:xx:xx:xx:xx:xx\n");
    INFO( LOG_TERMINAL, " tp rname xx:xx:xx:xx:xx:xx\n");
    INFO( LOG_TERMINAL, " tp cmd <ttl> xx:xx:xx:xx:xx:xx\n");
    INFO( LOG_TERMINAL, " tp debug [1|0]\n");
    INFO( LOG_TERMINAL, " tp verbose [1|0]\n");
}

/// VCP terminal command parser and dispatcher
void _vcp_cmds_vcp_cmd(u_char * arg)
{
    u_char i;
    unsigned int val = 0;
    unsigned int val2 = 0;
    unsigned int val3 = 0;
    unsigned int val4 = 0;
    unsigned int addr[BD_ADDR_LEN];
    bt_addr_t bt_addr;

    if (!strncmp(arg, "openvc", 4)) {
        if (sscanf(arg, "openvc%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
            for (i = 0; i < BD_ADDR_LEN; i++) {
                bt_addr[i] = (u_char) addr[i];
            }
            vcp_open_vc(bt_addr, 0);
        } else
            _vcp_cmds_print_usage();
    } else if (!strncmp(arg, "vt", 2)) {
        _vcp_print_vctable();
    } else if (!strncmp(arg, "ht", 2)) {
        _vcp_print_hosttable();
    } else if (!strncmp(arg, "rc", 2)) {
        _vcp_print_reliable_con();
    } else if (!strncmp(arg, "send", 4)) {
        if (sscanf(arg, "send%u%u", &val, &val2) == 2) {
            _vcp_cmds_send_vc_data((u_char) val, (u_short) val2);
        }
    } else if (!strncmp(arg, "psend", 4)) {
        if (sscanf(arg, "psend%u%u%u%u", &val, &val2, &val3, &val4) == 4) {
            _vcp_cmds_psend_vc_data((u_char) val, (u_short) val2, (u_char) val3, (u_char) val4);
        }
    } else if (!strncmp(arg, "close", 5)) {
        if (sscanf(arg, "close%u", &val) == 1) {
            vcp_close_vc((u_char) val);
        }
    } else if (!strncmp(arg, "verbose", 7)) {
        if (sscanf(arg, "verbose%u", &val) == 1) {
            _vcp_stack->verbose = (u_char) val;
        }
        else INFO( LOG_TERMINAL, "verbose = %d\n", _vcp_stack->verbose);
    } else if (!strncmp(arg, "clsnd", 5)) {
        if (sscanf(arg, "clsnd%2x:%2x:%2x:%2x:%2x:%2x%u%u", &addr[5], &addr[4], &addr[3], &addr[2], &addr[1], &addr[0], &val, &val2) == 8) {
            for (i = 0; i < BD_ADDR_LEN; i++) {
                bt_addr[i] = (u_char) addr[i];
            }
            _vcp_cmds_cl_send(bt_addr, (u_char)val, (u_char)val2);
        }
    } else if (!strncmp(arg, "trace", 5)) {
        if (sscanf(arg, "trace%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
            for (i = 0; i < BD_ADDR_LEN; i++) {
                bt_addr[i] = (u_char) addr[i];
            }
            _vcp_cmds_trace_request_send(bt_addr, 0);
        } else
            _vcp_cmds_trace_request_send(bt_addr_null, 0);
    } else if (!strncmp(arg, "cmd", 3)) {
        if (sscanf(arg, "cmd%u%2x:%2x:%2x:%2x:%2x:%2x", &val, &addr[5], &addr[4], &addr[3], &addr[2], &addr[1], &addr[0]) == 7) {
            for (i = 0; i < BD_ADDR_LEN; i++) {
                bt_addr[i] = (u_char) addr[i];
            }
            _vcp_cmds_send_cmdstring(bt_addr, (u_char)val);
        } else
            _vcp_cmds_send_cmdstring(bt_addr_null, (u_char)val);
    } else if (!strncmp(arg, "con", 3)) {
        _vcp_stack->verbose = 1;
        if (sscanf(arg, "con%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
            for (i = 0; i < BD_ADDR_LEN; i++) {
                bt_addr[i] = (u_char) addr[i];
            }
            _vcp_cmds_con_request_send(bt_addr, 0);
        } else
            _vcp_cmds_con_request_send(bt_addr_null, 0);
    } else if (!strncmp(arg, "rname", 5)) {
        if (sscanf(arg, "rname%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
            for (i = 0; i < BD_ADDR_LEN; i++) {
                bt_addr[i] = (u_char) addr[i];
            }
            _vcp_cmds_remote_name_send(bt_addr, 0);
        } else
            _vcp_cmds_remote_name_send(bt_addr_null, 0);
    } else if (!strncmp(arg, "bc", 2)) {
        _vcp_cmds_bc_request_send(0);
    } else if (!strncmp(arg, "hd", 2)) {
        _vcp_send_host_del();
#ifdef USE_VCP_WD
    } else if (!strncmp(arg, "wd", 2)) {
        if(!strncmp(arg+2, " reset", 6)){
            _vcp_stack->wd_count = 0;
            // (MY) I commented the next line out (unclean: use the string feature is deprecated, 
            //                                     value is stored in eeprom but never read)
            //btn_eepromdb_store(FOURCC('T', 'W', 'D', '='), sizeof(u_char), &_vcp_stack->wd_count);
        }
        INFO(LOG_TERMINAL, "tp resets: %u\n", _vcp_stack->wd_count);
#endif
    } else {
        _vcp_cmds_print_usage();
    }
}


////////////////////////////////////////////////////////////////////////////////
// Registers VCP terminal commands
////////////////////////////////////////////////////////////////////////////////
void vcp_register_cmds(void)
{
    btn_terminal_register_cmd("tp", _vcp_cmds_vcp_cmd);  
}
//@}
