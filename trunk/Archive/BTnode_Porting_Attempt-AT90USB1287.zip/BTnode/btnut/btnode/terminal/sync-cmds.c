/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file sync-cmds.c
 * 
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Terminal cmds for the time synchronization layer.
 * 
 */
#include <string.h>
#include <sync/sync_rtt.h>
#include <sync/l2cap_cl_sync.h>
#include <terminal/btn-terminal.h>
#include <terminal/sync-cmds.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_SYNC
#define LOG_LEVEL SYSLOG_LEVEL_SYNC
#include <debug/log_set.h>

u_short sync_cmds_psm;
struct btstack* sync_cmds_btstack;

void _sync_cmds_print_usage(void)
{
	tprintf("sync: error: usage: mode [get | set] <val>\n");
}

void _sync_cmd_print_mode(void)
{
	tprintf("mode is set to ");
	if (sync_globals.is_anchor)
		tprintf("anchor node.\n");
	else
		tprintf("sensor node.\n");
}

void _sync_cmd_mode(char* arg)
{
    int val;
    
    if (!strncmp(arg, "get", 3)) {
    	_sync_cmd_print_mode();
    }
    else if (!strncmp(arg, "set", 3)) {
    	arg += 3;
	    if (sscanf(arg, "%u", &val) == 1) {
	    	sync_globals.is_anchor = val;
	    	tprintf("anchor? %d\n", val);
	    	// (re-)initialize rt
	    	rt_init();
			// print current mode
			_sync_cmd_print_mode();
	    }
	    else
	    	_sync_cmds_print_usage();
    }
    else _sync_cmds_print_usage();
}

void _sync_cmd_start(void)
{
	u_char i;
	u_char data;
	bt_hci_con_handle_array handles;
	u_char nr_handles;
	long retval;
       
	// send an empty packet for time synchronization to each connected device
	nr_handles = bt_hci_get_con_handles(sync_cmds_btstack, handles);
	for (i=0; i<nr_handles; i++) {
		retval = l2cap_cl_sync_send_pkt(&data, 1, handles[i], sync_cmds_psm);
		DEBUG("sync pkt sent. res: %d\n", retval);
	}
}
    

void _sync_cmd_sync_cmds(char* arg) {
    if (!strncmp(arg, "mode", 4)) {
    	_sync_cmd_mode(arg+5);
    } else if (!strncmp(arg, "start", 5)) {
    	_sync_cmd_start();
    } else {
    	_sync_cmds_print_usage();
    }
}

void sync_cmds_init(struct btstack* bt_stack, u_short psm)
{
	sync_cmds_btstack = bt_stack;
	sync_cmds_psm = psm;
    btn_terminal_register_cmd("sync", _sync_cmd_sync_cmds);
}

