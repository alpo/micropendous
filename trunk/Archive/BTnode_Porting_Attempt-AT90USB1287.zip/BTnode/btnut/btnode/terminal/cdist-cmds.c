/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file cdist-cmds.c
 * 
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Terminal cmds for code distribution
 * 
 */
#include <string.h>
#include <terminal/btn-terminal.h>
#include <cdist/cdist.h>
#include <mhop/rpc.h>
#include <terminal/rpc-cmds.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CDIST
#define LOG_LEVEL SYSLOG_LEVEL_CDIST
#include <debug/log_set.h>

#define CDIST_CMD_NONE 0 
#define CDIST_CMD_ON   1
#define CDIST_CMD_OFF  2
#define CDIST_CMD_RUN  3

u_char _cdist_cmd_proc_nr;

u_char _cdist_proc(bt_acl_pkt_buf* pkt_buf, char* query, u_char query_len, void* arg, \
                        u_char* result, u_char* result_len)
{
    switch(query[0]){
        case CDIST_CMD_ON:
            cdist_on();
            break;
        case CDIST_CMD_OFF:
            cdist_off();
            break;
        case CDIST_CMD_RUN:
            cdist_run();
            break;
    }
    return 0;    
}
 
void _cdist_cmds(char * arg){
    u_char query = CDIST_CMD_NONE;
    if (!strncmp(arg, "on", 2)){
        query = CDIST_CMD_ON;
    } else if (!strncmp(arg, "off", 3)){
        query = CDIST_CMD_OFF;
    } else if (!strncmp(arg, "run", 3)){
        query = CDIST_CMD_RUN;
    }
    if(query == CDIST_CMD_NONE){
        tprintf("usage: cdist on|off|run\n");
    }
    else{
        rpc_handle_query(_cdist_cmd_proc_nr, &query, 1);
    }    
}

void cdist_cmds_register_cmds(void)
{
    rpc_register_proc(&_cdist_cmd_proc_nr,
                      _cdist_proc, NULL,
                      NULL , NULL);
                      
    DEBUG("cdist proc: %d\n", _cdist_cmd_proc_nr);
    
    btn_terminal_register_cmd("cdist", _cdist_cmds);
}
