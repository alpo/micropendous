/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

#include <string.h>
#include <dev/usartavr.h>
#include <sys/thread.h>
#include <sys/mutex.h>
#include <terminal/btn-terminal.h>
#include <led/btn-led.h>
#include <sys/heap.h>
#include <debug/toolbox.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_TERMINAL
#define LOG_LEVEL SYSLOG_LEVEL_TERMINAL
#include <debug/log_set.h>

FILE *debug_uart;

#define TERMINAL_ARROWCHAR_1 0x1b
#define TERMINAL_ARROWCHAR_2 0x5b
#define TERMINAL_ARROWCHAR_UP 0x41
#define TERMINAL_ARROWCHAR_DOWN 0x42

#define TERMINAL_BACK_SPACE_1 0x8
#define TERMINAL_BACK_SPACE_2 0x7f
#define TERMINAL_TAB 0x9

#define MIN(a,b) ((a) < (b) ? (a) : (b))

typedef struct _btn_terminal_cmd_s {
    char name[LEN_CMD_NAME+1];
    void (*fkt) (char * arg);
} _btn_terminal_cmd_t;

typedef struct _btn_terminal_thread_s {
    NUTTHREADINFO *info;
    u_char enable_capture;
    char buffer[TERMINAL_THREADBUFFER_SIZE+1];
    u_short buffer_pos;
} _btn_terminal_thread_t;

typedef struct _btn_terminal_stack_s {
    _btn_terminal_cmd_t cmds[MAX_CMDS];
    _btn_terminal_thread_t tds[TERMINAL_MAX_LOGGED_THREADS];
    char user_input[HISTORY_DEPTH][INPUT_LENGTH];     //buffer for command and history
    u_char current_pos;         //points to current user input line
    u_char user_input_pos;      //number of char in current user input
    char prompt[20];
    MUTEX _terminal_write_mutex;
    char lasterror[100];
    u_char lasterrorno;
} _btn_terminal_stack_t;

_btn_terminal_stack_t *_btn_terminal_stack;







extern int _putf(int _putb(int, CONST void *, size_t), int fd, CONST char *fmt, va_list ap);

/*
 * copies 'count' bytes from the buffer passed to the buffer associated
 * with the fd passed.
 */
static int _sputb(int fd, CONST void *buffer, size_t count)
{
	int copy_len;
	_btn_terminal_thread_t* thread = (_btn_terminal_thread_t*)fd;
    copy_len = MIN(count, TERMINAL_THREADBUFFER_SIZE - thread->buffer_pos - 1);
    memcpy(thread->buffer + thread->buffer_pos, buffer, copy_len);
    thread->buffer_pos += copy_len;
    return copy_len;
}

_btn_terminal_thread_t *get_thread( NUTTHREADINFO *t)
{
    u_short i;
    for( i = 0; i < TERMINAL_MAX_LOGGED_THREADS; i++) {
        if(_btn_terminal_stack->tds[i].info == t) {
            return &_btn_terminal_stack->tds[i];
        }
    }
    return NULL;
}


void _btn_terminal_display_prompt(void)
{
    DEBUGB(_btn_terminal_stack->prompt);
}

u_char _btn_terminal_display_cmds(char * name, u_char len, u_char show)
{
    u_char i, j, line = 0;
    u_char more_chars = 0xFF;
    u_char more_than_one = 0;
    for (i = 0; i < MAX_CMDS; i++) {    //go through array with valid entries
        if (_btn_terminal_stack->cmds[i].fkt != NULL) {
            if (strncmp(_btn_terminal_stack->cmds[i].name, name, len) == 0) {   //this cmd starts with name!
                //display it if show it set
                if (show) {
                    if (more_chars != 0xFF)
                        more_than_one = 1;
                    else
                        DEBUGT("\n");
                    DEBUGB(_btn_terminal_stack->cmds[i].name);
                    if (++line % 5 == 0)
                        DEBUGT("\n");
                    else
                        DEBUGT("\t");   //with tab  
                    more_chars = len;
                } else {
                    if (more_chars == 0xFF) {   //first hit
                        more_chars = strlen(_btn_terminal_stack->cmds[i].name);
                        strcpy(name, _btn_terminal_stack->cmds[i].name);        //copy text to name
                    } else {    //check untill where same chars
                        more_than_one = 1;
                        for (j = len; j < more_chars; j++) {
                            if (name[j] != _btn_terminal_stack->cmds[i].name[j]) {      //not same
                                more_chars = j;
                                break;
                            }
                        }       //end for
                    }
                }
            }
        }
    }                           //end while
    if (more_chars == 0xFF)
        return len;             //no cmd found
    if (!more_than_one) {       //the only cmd
        //add space and give back the index of this cmd!!
        name[more_chars++] = ' ';
    }
    if (show) {
        DEBUGT("\n");
        _btn_terminal_display_prompt();
        DEBUGL(name, more_chars);
    } else {
        DEBUGL(name + len, more_chars - len);
    }
    return more_chars;
}

void btn_terminal_refresh(void)
{
    //diplay prompt
    _btn_terminal_display_prompt();
    //write chars that typed in by user
    DEBUGL(_btn_terminal_stack->user_input[_btn_terminal_stack->current_pos], _btn_terminal_stack->user_input_pos);
}


void btn_terminal_register_cmd(char * name, void (*fkt) (char *))
{                               //name with \0 terminated
    u_char i = 0;
    if (strlen(name) > LEN_CMD_NAME) {
        DEBUGT("registering cmd:%s ", name);
        DEBUGT("failed! name too long!\n");
        return;
    }
    for (i = 0; i < MAX_CMDS; i++) {
        if (_btn_terminal_stack->cmds[i].fkt == NULL)
            break;
    }
    if (i == MAX_CMDS) {
        DEBUGT("registering cmd:%s ", name);
        DEBUGT("failed! cmds buffer full!\n");
        return;
    }
    _btn_terminal_stack->cmds[i].fkt = fkt;
    strcpy(_btn_terminal_stack->cmds[i].name, name);
}


u_char btn_terminal_process_cmd(char * cmd)
{
    u_char i;
    for (i = 0; i < MAX_CMDS; i++) {
        if (_btn_terminal_stack->cmds[i].fkt != NULL) {
            if ((strncmp(_btn_terminal_stack->cmds[i].name, cmd, strlen(_btn_terminal_stack->cmds[i].name)) == 0) && ((cmd[strlen(_btn_terminal_stack->cmds[i].name)] == ' ') || (strlen(_btn_terminal_stack->cmds[i].name) == strlen(cmd)))) { //this cmd starts with name!
                break;
            }
        }
    }
    if (i == MAX_CMDS)
        return 1; // command not found
    
    cmd += strlen(_btn_terminal_stack->cmds[i].name);
    /* skip the char after the command */
    if( *cmd != 0) {
        cmd++;
    }
    _btn_terminal_stack->cmds[i].fkt( cmd);
    return 0;
}


void _btn_terminal_main(void)
{
    u_char history_pos = 0;     //used to scroll through history
    char count = 0;
    u_char history_buf_full = 0;        //1 if we had more than HISTORY_DEPTH user inputs
    u_char tab_count = 0;       //counting the tabs  
    u_char input_buf[3];
    int i;
    u_char uart_errors;
    // set low priority
    NutThreadSetPriority(150);
    //loop
    btn_terminal_refresh();
    while (1) {
        do {
            count = _read(_fileno(debug_uart), input_buf, 1);
            if (count == -1)
                DEBUGT("BTN_TERMINAL: ERROR: while reading from uart\n");
        } while (count != 1);
        // check uart status
        uart_errors = get_uart_errors(_fileno(debug_uart));
        if (uart_errors)
        {
        	DEBUGT("\n uart read err: %d\n", uart_errors);
        }
        if (input_buf[0] == TERMINAL_ARROWCHAR_1) {     //might be arrow
            tab_count = 0;
            //read next two bytes!
            count = 0;
            while (count < 2) {
                count += _read(_fileno(debug_uart), input_buf + count, 2 - count);
            }
            if (input_buf[0] == TERMINAL_ARROWCHAR_2) { //check if up or down arrow
                if (input_buf[1] == TERMINAL_ARROWCHAR_UP) {    //arrow up
                    //show one older user input
                    if ((_btn_terminal_stack->current_pos + HISTORY_DEPTH - history_pos) % HISTORY_DEPTH != (HISTORY_DEPTH - 1)) {
                        //now at the beginning we don't have every entry full, only
                        //when current_pos once around we allow history_pos below "0"

                        if (history_buf_full || (history_pos != 0)) {
                            //go one back with history pos
                            history_pos = (history_pos + HISTORY_DEPTH - 1) % HISTORY_DEPTH;
                        }
                    }
                } else if (input_buf[1] == TERMINAL_ARROWCHAR_DOWN) {   //arrow down
                    //show newer user input, only if we are not back at pos
                    if (history_pos != _btn_terminal_stack->current_pos) {
                        history_pos = (history_pos + 1) % HISTORY_DEPTH;
                    }
                } else          //neither arrow up nor arrow down
                    history_pos = _btn_terminal_stack->current_pos;
            }
            //delete current cmd from terminal with char 8 (backspace)
            while (_btn_terminal_stack->user_input_pos != 0) {
                _btn_terminal_stack->user_input_pos--;
                DEBUGT("%c %c", 0x8, 0x8);
            }
            //if history_pos is current_pos dont copy 
            if (history_pos != _btn_terminal_stack->current_pos) {
                //copy cmd from history to current
                strncpy(_btn_terminal_stack->user_input[_btn_terminal_stack->current_pos],
                        _btn_terminal_stack->user_input[history_pos], INPUT_LENGTH);
                //print history
                DEBUGB(_btn_terminal_stack->user_input[history_pos]);
                //set position
                _btn_terminal_stack->user_input_pos = strlen(_btn_terminal_stack->user_input[_btn_terminal_stack->current_pos]);
            }

        } else if (input_buf[0] == '\n' || input_buf[0] == '\r') {
            tab_count = 0;
            // terminate with null
            _btn_terminal_stack->user_input[_btn_terminal_stack->current_pos][_btn_terminal_stack->user_input_pos] = '\0';
            DEBUGT("\n");
            //save cmd if there was input
            if (_btn_terminal_stack->user_input_pos > 0) {
                char *cmd = _btn_terminal_stack->user_input[_btn_terminal_stack->current_pos];
                if(btn_terminal_process_cmd(cmd)){
                    DEBUGT("%s: command not found\n", cmd);
                }
                
                _btn_terminal_stack->current_pos++;
                if (_btn_terminal_stack->current_pos == HISTORY_DEPTH) {
                    _btn_terminal_stack->current_pos = 0;
                    history_buf_full = 1;       //set flag that history buffer is full
                }
                history_pos = _btn_terminal_stack->current_pos;
                _btn_terminal_stack->user_input_pos = 0;
                //del this array
                for (i = 0; i < INPUT_LENGTH; i++)
                    _btn_terminal_stack->user_input[_btn_terminal_stack->current_pos][i] = 0;
            }

            _btn_terminal_display_prompt();
        } else if (input_buf[0] == TERMINAL_BACK_SPACE_1 || input_buf[0] == TERMINAL_BACK_SPACE_2) {
            // backspace
            tab_count = 0;
            if (_btn_terminal_stack->user_input_pos > 0) {
                DEBUGT("%c %c", 0x8, 0x8);
                _btn_terminal_stack->user_input_pos--;
                _btn_terminal_stack->user_input[_btn_terminal_stack->current_pos][_btn_terminal_stack->user_input_pos] = 0;
            }
        } else if (input_buf[0] == TERMINAL_TAB) {      //tab char
            _btn_terminal_stack->user_input_pos =
                _btn_terminal_display_cmds(_btn_terminal_stack->user_input[_btn_terminal_stack->current_pos],
                                           _btn_terminal_stack->user_input_pos, tab_count);
            tab_count++;
        } else if (_btn_terminal_stack->user_input_pos + 1 == INPUT_LENGTH - 2) {
            DEBUGT("!!LINE TOO LONG!!\n");
            btn_terminal_refresh();
        } else {
            tab_count = 0;
            DEBUGT("%c", input_buf[0]);
            _btn_terminal_stack->user_input[_btn_terminal_stack->current_pos][_btn_terminal_stack->user_input_pos] = input_buf[0];
            _btn_terminal_stack->user_input_pos++;
        }

    }

}


THREAD(TERMINAL, arg)
{
    _btn_terminal_main();
    while (1) {
    }
}

void btn_terminal_set_prompt(char * a_prompt)
{
    u_char len = strlen(a_prompt);
    if (len > 19)
        len = 19;
    strncpy(_btn_terminal_stack->prompt, a_prompt, len);
    _btn_terminal_stack->prompt[len] = '\0';
}

void btn_terminal_init(FILE * uart, char * a_prompt)
{
    u_char i, len;
    debug_uart = uart;
    //dyn alloc terminal stack
    _btn_terminal_stack = NutHeapAllocClear(sizeof(_btn_terminal_stack_t));
    if (_btn_terminal_stack == NULL) {
        DEBUGT("TERMINAL ERROR: cannot alloc memory\n");
        return;
    }

    len = strlen(a_prompt);
    if (len > 20)
        len = 20;
    strncpy(_btn_terminal_stack->prompt, a_prompt, len);

    for (i = 0; i < MAX_CMDS; i++) {
        _btn_terminal_stack->cmds[i].fkt = NULL;
    }
    NutMutexInit(&_btn_terminal_stack->_terminal_write_mutex);

    _btn_terminal_stack->lasterror[0] = '\0';
}

void btn_terminal_run(u_char type, u_short thread_size)
{
    if (type == BTN_TERMINAL_FORK) {
        // start ui thread
        NutThreadCreate("T_TERMINAL", TERMINAL, 0, thread_size + 1024);
    } else {
        _btn_terminal_main();
    }
}


void DEBUGB(char * text)
{
    NutMutexLock(&_btn_terminal_stack->_terminal_write_mutex);
    fputs(text, debug_uart);
    NutMutexUnlock(&_btn_terminal_stack->_terminal_write_mutex);
}

//debug print formated string with arguments or just text
int DEBUGT_I(PGM_P fmt, ...)
{
    int rc;
    va_list ap;
    NutMutexLock(&_btn_terminal_stack->_terminal_write_mutex);
    va_start(ap, fmt);
    rc = vfprintf_P(debug_uart, fmt, ap);
    va_end(ap);
    NutMutexUnlock(&_btn_terminal_stack->_terminal_write_mutex);
    return rc;
}

//debug print buffer with len
void DEBUGL(char * buf, u_char len)
{
    NutMutexLock(&_btn_terminal_stack->_terminal_write_mutex);
    _write(_fileno(debug_uart), buf, len);
    NutMutexUnlock(&_btn_terminal_stack->_terminal_write_mutex);
}

int tprintf(CONST char* fmt, ...)
{
	
	int rc;
	va_list ap;
	
    /* write to thread buffer */
    _btn_terminal_thread_t *thread;
    if( (thread = get_thread( runningThread)) != NULL) {
        if(thread->enable_capture) {
        	// generate output string & write it to the thread's buffer
		    va_start(ap, fmt);
		    _putf(_sputb, (int) ((uptr_t)thread), fmt, ap);
		    va_end(ap);
        }
    }
    
    /* log text if desired */
    va_start(ap, fmt);
    INFO_STR(fmt, ap);
    va_end(ap);
    
    /* write to terminal */
    btn_terminal_get_writing_lock();
    va_start(ap, fmt);
    rc = vfprintf(debug_uart, fmt, ap);
    va_end(ap);
    btn_terminal_free_writing_lock();
    return rc;
}

char term_register_thread(void)
{
    _btn_terminal_thread_t *thread;
    /* register thread */
    if( (thread = get_thread( NULL)) != NULL) {
        thread->info = runningThread;
        thread->buffer_pos = 0;
        return 0;
    }
    return 1;
}

char term_start_capture( void)
{
    _btn_terminal_thread_t *thread;
    /* check runningThread */
    if( (thread = get_thread( runningThread)) != NULL) {
        thread->enable_capture = 1;
        thread->buffer_pos = 0;
        return 0;
    }
    return 1;
}

char *term_stop_capture( void)
{
    _btn_terminal_thread_t *thread;
    /* check runningThread */
    if( (thread = get_thread( runningThread)) != NULL) {
        thread->buffer[thread->buffer_pos] = 0;
        thread->enable_capture = 0;
        return thread->buffer;
    }
    return 0;
}

void btn_terminal_get_writing_lock(void)
{
    NutMutexLock(&_btn_terminal_stack->_terminal_write_mutex);
}

void btn_terminal_free_writing_lock(void)
{
    NutMutexUnlock(&_btn_terminal_stack->_terminal_write_mutex);
}

void btn_set_error(u_char errorno, char * lasterror)
{
    u_char len;
    if (_btn_terminal_stack->lasterror[0] == '\0') {
        _btn_terminal_stack->lasterrorno = errorno;
        len = strlen(lasterror);
        if (len > 99)
            len = 99;
        strncpy(_btn_terminal_stack->lasterror, lasterror, len);
        _btn_terminal_stack->lasterror[len] = '\0';
        btn_show_error();
    }
}

void btn_show_error()
{
    btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, _btn_terminal_stack->lasterrorno, 1, 100);
    DEBUGB(_btn_terminal_stack->lasterror);
}
