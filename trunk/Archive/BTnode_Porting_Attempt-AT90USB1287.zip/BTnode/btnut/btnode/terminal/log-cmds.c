/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file log-cmds.c
 * 
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Terminal priniting logged data.
 * 
 */
#include <terminal/btn-terminal.h>
#include <eepromdb/btn-eepromdb.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/timer.h>
#include <sys/mutex.h>
#include <string.h>
#include <fcntl.h>
#include <bt/bt_hci_defs.h>
#include <hardware/btn-hardware.h>
#include <hardware/ram_banks.h>
#include <dev/usart.h>
#include <dev/usartavr.h>
#include <stdio.h>
#include <io.h>
#include <sys/tracer.h>
#include <debug/logging.h>

struct _log_cmds_stack_s {
	FILE *terminal_uart;
	log_filter_t verbosity;
};

struct _log_cmds_stack_s log_cmds_stack;

extern struct _log_stack log_stack;

// log level Names
static char logNameERROR[] =	"ERR: ";
static char logNameWARNING[] =	"WRN: ";
static char logNameINFO[] =		"INF: ";
static char logNameDEBUG[] =	"DBG: ";

static char* logLevelNames[LOG_LEVELS + 1] = {0,
										  logNameERROR,
                                          logNameWARNING,
                                          logNameINFO,
                                          logNameDEBUG};
                                          

void _log_cmds_print_msg(u_char* msg, log_msg_tail* msgtail, void* cb_arg)
{
	// get lock on terminal
    btn_terminal_get_writing_lock();
    fprintf( log_cmds_stack.terminal_uart,
    			"%5u %10lu C%.2d, %s",
                msgtail->id,
                msgtail->t_stamp,               // timestamp
                msgtail->class,                 // class
                logLevelNames[msgtail->level]); // level

	// print logged data
	fputs((char*) msg, log_cmds_stack.terminal_uart);
	
    // release lock on terminal
    btn_terminal_free_writing_lock();
}


void _log_cmds_print_usage(void)
{
    tprintf("log usage:\n");
    tprintf("show [<nr_msgs> [<class> [<mask]]]\n");
    tprintf("get [<id_newer> [<nr_msgs> [<class> [<mask>]]]]\n");
    tprintf("clear\n");
    tprintf("logmask <class> [<mask>]\n");
    tprintf("verbosity on\n");
    tprintf("verbosity <class> [<mask>]\n");
    tprintf("verbosity pause\n");
    tprintf("verbosity resume\n");
    tprintf("verbosity off\n");
}


void _log_cmds_verbosity_cmd(char* arg)
{
	int num;
	int retval;
	u_int class = LOG_ALL_CLASSES, mask = LOG_MASK_ALL;
	
	if (!strncmp(arg, "on", 2))
	{
		// register _log_cmds_print_msg() for verbosity
		retval = log_evt_listener_register(_log_cmds_print_msg,
												NULL,
												log_cmds_stack.verbosity);
		if (!retval)
		{
			tprintf("verbosity on!\n");
		}
		else
		{
			tprintf("failed: other log listener registered!\n");
		}
		return;
	}
    if (!strncmp(arg, "off", 4)) {
    	log_evt_listener_clear();
    	tprintf("verbosity off!\n");
    	return;
    } else if (!strncmp(arg, "pause", 3)) {
    	log_evt_listener_pause();
    	tprintf("verbosity paused.\n");
    	return;
    } else if (!strncmp(arg, "resume", 5)) {
        log_evt_listener_resume();
        tprintf("verbosity resumed.\n");
        return;
    } else {
    	num = sscanf(arg, "%d%x", &class, &mask);
    	if( num == 2)
    	{
        	if( class > 0 && class < LOG_MAX_CLASSES)
        	{
        		log_cmds_stack.verbosity[class] = mask;
    		}
    		else
    		{
    			tprintf("err: invalid log class!\n");
    		}
    	}
    	if( num >= 1)
    	{
        	if( class > 0 && class < LOG_MAX_CLASSES)
        	{
            	tprintf("log class %i, verbosity mask set to: %.2X\n",
                        class, log_cmds_stack.verbosity[class]);
            	return;
        	}
    	}	
	}
	_log_cmds_print_usage();
}

void _log_cmds_log_cmd(char * arg)
{
    u_int class = LOG_ALL_CLASSES, mask = LOG_MASK_ALL, nr_msgs = 0;
    u_int id_newer = 0;
    int num;
    if (!strncmp(arg, "show", 4)) {
        sscanf(arg+4, "%u%u%x", &nr_msgs, &class, &mask);
        log_get(nr_msgs, class, mask, _log_cmds_print_msg, NULL);
        return;
    } else if (!strncmp(arg, "get", 3)) {
        sscanf(arg+3, "%u%u%u%x", &id_newer, &nr_msgs, &class, &mask);
        log_get_messages(id_newer, nr_msgs, _log_cmds_print_msg, NULL);
        return;
    } else if (!strncmp(arg, "clear", 5)) {
		log_empty();
        return;
    } else if (!strncmp(arg, "logmask", 7)) {
        num = sscanf(arg+7, "%d%x", &class, &mask);
        if( num == 2) {
            log_set_logmask( class, mask);
        }
        if( num >= 1) {
        	mask = log_get_logmask(class);
        	tprintf("log class %i, ", class);
        	if (mask < 0) {
        		tprintf("invalid!\n");
        		return;
        	}
        	else {
        		tprintf(" logmask set to: %.2X\n", mask);
        		return;
        	}
        }
    } else if (!strncmp(arg, "verbosity", 9)) {
    	_log_cmds_verbosity_cmd(arg + 10);
    	return;
    }
    _log_cmds_print_usage();
}


int log_cmds_verbosity_on(void)
{
	return log_evt_listener_register(_log_cmds_print_msg, NULL, log_cmds_stack.verbosity);
}


char log_cmds_set_verbosity(u_char class, u_char mask)   
{   
    if( class > 0 && class < LOG_MAX_CLASSES)
    {     
        log_cmds_stack.verbosity[class] = mask;
        return 0;     
    }
    
    return -1;
}


void log_cmds_init( FILE *uart)
{
	u_short i;
	
	// store pointer to the terminal uart
    log_cmds_stack.terminal_uart = uart;
	
	// init verbosity
	for (i=0; i<LOG_MAX_CLASSES; i++) {
		log_cmds_stack.verbosity[i] = LOG_VERBOSITY_OFF;
	}
											
	// register cmds at terminal
	btn_terminal_register_cmd("log", _log_cmds_log_cmd);
}
