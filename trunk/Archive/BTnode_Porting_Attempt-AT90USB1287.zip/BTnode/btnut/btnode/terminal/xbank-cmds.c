/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: xbank-cmds.c,v 1.10 2006/10/26 13:31:10 kevmarti Exp $
 * 
 */

/*!
 * $Log: xbank-cmds.c,v $
 * Revision 1.10  2006/10/26 13:31:10  kevmarti
 * - Adaption to obsolete typedef 'bt_msg'
 * - Included syslog debug definitions
 *
 * Revision 1.9  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * 
 */ 

/*
 * @file xbank-cmds.c
 *
 * \date 2006/10/03 
 *
 * \author Jan Beutel <j.beutel@ieee.org>
 * 
 * basic xbank memory management commands
 */

#include <string.h>
#include <terminal/btn-terminal.h>
#include <cdist/xbankdata.h>
#include <mhop/rpc.h>
#include <terminal/rpc-cmds.h>
#include <debug/toolbox.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_CDIST
#define LOG_LEVEL SYSLOG_LEVEL_CDIST
#include <debug/log_set.h>

u_char _xbank_cmd_proc(bt_acl_pkt_buf* pkt_buf, char* query, u_char query_len, void* arg,
                        u_char* result, u_char* result_len)
{
    *result_len = 0;
    result[0] = query[0];
    switch(query[0]){
        case XBANK_CMD_GET_PROGINFO:
            if(xbank_check_program()){
                *result_len = 1;
            }
            else{
                result[1] = _xbank->program_info.type;
                memcpy(result+2, &_xbank->program_info.version, 4);
                memcpy(result+6, &_xbank->program_info.size, 4);
#ifndef __BTN_UNIX__
                strlcpy((char*)(result+10), _xbank->program_info.name, sizeof(_xbank->program_info.name));
#else
                strncpy((char*)(result+10), _xbank->program_info.name, sizeof(_xbank->program_info.name) -1);
                result[10+sizeof(_xbank->program_info.name) - 1] = (u_char) 0;
#endif
                *result_len = sizeof(xbank_prog_info_t) + 1;
            }
            break;
        case XBANK_CMD_GET_STATUS:
            result[1] = _xbank->program_valid;
            result[2] = _xbank->program_lock;
            *result_len = 3;
            break;
        case XBANK_CMD_SET_PROGTYPE:
            if(query[1] == XBANK_PROG_TYPE_DSN ||
                query[1] == XBANK_PROG_TYPE_TARGET){
                if(xbank_get_program_lock() == 0){
                    _xbank->program_info.type = query[1];
                    xbank_update_prog_header();
                    xbank_free_program_lock();
                }
            }
            break;
        case XBANK_CMD_SET_PROGNAME:
            xbank_set_prog_name(query+1);  
            break;
        case XBANK_CMD_SET_PROGVER:
            if(xbank_get_program_lock() == 0){ 
                memcpy(&(_xbank->program_info.version), query+1, sizeof(u_long));
                xbank_update_prog_header();
                xbank_free_program_lock();
            }
            break;
        case XBANK_INVALIDATE_PROG:
            xbank_invalidate_program();
            break;
        default:
            break;
    }
    return 0;
}                           

void _xbank_cmd_result(u_char* source_addr, u_char* result, u_char result_len, 
                       void* arg)
{
	// get lock on terminal
    btn_terminal_get_writing_lock();
    
    tprintf("\n:XP %s\n", dbg_bt_addr_to_str(source_addr));
    switch(result[0]){
        case XBANK_CMD_GET_PROGINFO:
            if(result_len == 1){
                tprintf("NP\n");
            }
            else{
                //prog_info = (xbank_prog_info_t*)result+1;
                tprintf("PI %u %010lu %lu %s\n", 
                     result[1],
                     *(u_long*)(result+2),
                     *(u_long*)(result+6),
                     result+10);
            }
            break;
        case XBANK_CMD_GET_STATUS:
                tprintf("PS %u %u\n", 
                     result[1],
                     result[2]);
            break;
        default:
            break;
    }
    
    // release lock on terminal
    btn_terminal_free_writing_lock();    
}

void _xbank_cmd_parser(char *arg){
    char query[XBANK_MAX_PROGNAME_LEN+2];
    u_char query_len = 0;
    u_long ver;
    if (!strncmp(arg, "get ", 4)) {
        if(!strncmp(arg+4, "proginfo", 8)){
            query[0] = XBANK_CMD_GET_PROGINFO;
            query_len = 1;
        }
        else if(!strncmp(arg+4, "status", 6)){
            query[0] = XBANK_CMD_GET_STATUS;
            query_len = 1;
        }
    } else if (!strncmp(arg, "set ", 4)) {
        if(!strncmp(arg+4, "progtype ", 9)){
            if(!strncmp(arg+13, "dsn", 3)){
                query[0] = XBANK_CMD_SET_PROGTYPE;
                query[1] = XBANK_PROG_TYPE_DSN;
                query_len = 2;
            }
            else if(!strncmp(arg+13, "tg", 2)){
                query[0] = XBANK_CMD_SET_PROGTYPE;
                query[1] = XBANK_PROG_TYPE_TARGET;
                query_len = 2;
            }
        }
        else if(!strncmp(arg+4, "progname ", 9)){
            query[0] = XBANK_CMD_SET_PROGNAME;
#ifndef __BTN_UNIX__
            strlcpy(query+1, arg+13, XBANK_MAX_PROGNAME_LEN+1);
#else
            strncpy(query+1, arg+13, XBANK_MAX_PROGNAME_LEN);
            query[1 /* see above ! */ + XBANK_MAX_PROGNAME_LEN] = (u_char) 0;
#endif
            query_len = XBANK_MAX_PROGNAME_LEN + 2;
        }
        else if(sscanf(arg+4, "progver%lu", &ver) == 1){
            query[0] = XBANK_CMD_SET_PROGVER;
            memcpy(query+1, &ver, sizeof(u_long));
            query_len = 1 + sizeof(u_long);
        }
    } else if (!strncmp(arg, "del", 3)){
        query[0] = XBANK_INVALIDATE_PROG;
        query_len = 1;
    }
    if(query_len == 0){
       tprintf("usage: xbank\n"
                " get proginfo\n"
                " get status\n"
                " set protype [dsn|tg] \n"
                " set progname <name>\n" 
                " set progver <version>\n"
                " del\n");    }
    else{
        rpc_handle_query(_xbank->proc_nr, (u_char*)query, query_len);
    }
}


void xbank_cmds_init(void){
    rpc_register_proc(&_xbank->proc_nr,
                      _xbank_cmd_proc, NULL,
                      _xbank_cmd_result, NULL);   
    btn_terminal_register_cmd("xbank", _xbank_cmd_parser);                                                 
}
