/*
 * Copyright (C) 2000-2004 by ETH Zurich
 * Copyright (C) 2004 by Ole Reinhardt <ole.reinhardt@embedded-it.de>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * @file rfcomm-cmds.c
 *
 * @brief Commands for demonstrating an rfcomm connection.
 * 
 * \author Ole Reinhardt <ole.reinhardt@embedded-it.de>
 * \date
 * 
 * $Log: rfcomm-cmds.c,v $
 * Revision 1.7  2006/03/29 01:15:01  olereinhardt
 *
 * Changed signedness of strings in order to compile with avr-gcc 4.0.2
 *
 * Revision 1.6  2005/06/06 09:50:13  olereinhardt
 * Connection message (in connection callback) shows dlci of the affected channel
 *
 * Revision 1.5  2005/06/03 14:03:44  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.4  2005/05/27 13:21:24  olereinhardt
 *
 * Changed receive callback length parameter to u_short
 *
 * Revision 1.3  2005/04/15 12:31:00  beutel
 * added link key requests and more pin code stuff
 *
 */

#include <string.h>
#include <sys/heap.h>
#include <sys/thread.h>
#include <sys/event.h>
#include <sys/atom.h>
#include <terminal/btn-terminal.h>
#include <terminal/bt-cmds.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>
#include <bt/bt_rfcomm.h>

#ifndef RFCOMM_CMD_DEBUG
#define RFCOMM_CMD_DEBUG 1
#endif

#if     RFCOMM_DEBUG >= 1
#define INFO(text, ...) DEBUGT("rfcomm-cmds: " text,## __VA_ARGS__)
#else
#define INFO(text, ...)
#endif

#define MIN_CREDITS 10
#define MAX_CREDITS 40

static u_char connected = 0;
HANDLE sig_disconnect;

static void _print_bt_addr(bt_addr_t addr)
{
    DEBUGT("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x", addr[5], addr[4], addr[3], addr[2], addr[1], addr[0]);
}

static void _print_inq_result(void)
{
    int i;
    DEBUGT("Devices: %d\n", _terminal_bt_cmds->nr_inq_dev);
    if (_terminal_bt_cmds->nr_inq_dev < 0) {
        _terminal_bt_cmds->nr_inq_dev = 0;
    } else {
        DEBUGT("Device         bt_addr cod        clock_offs  page_scan_rep\n");
    }
    for (i = 0; i < _terminal_bt_cmds->nr_inq_dev; i++) {
        DEBUGT("[%d]: ", i);
        _print_bt_addr(_terminal_bt_cmds->inqres[i].bdaddr);
        DEBUGT(" 0x%.8lx 0x%.4x      0x%x\n", _terminal_bt_cmds->inqres[i].cod, _terminal_bt_cmds->inqres[i].clock_offset,
               _terminal_bt_cmds->inqres[i].page_scan_rep_mode);
    }
}

static void rcv_cb(u_char dlci, u_char * payload, u_short len, void *arg)
{
#if RFCOMM_CMD_DEBUG >=1
    u_short idx;
    if (len > 0) {
        printf_P(PSTR("\n----------------\n"));
        for (idx = 0; idx < len; idx++)
            printf_P(PSTR("%c "), payload[idx]);
        printf_P(PSTR("\n----------------\n"));
    }
#endif
}

static void con_cb(u_char dlci, u_char type, void *arg)
{
    if (type == BT_RFCOMM_CONNECT) {
        DEBUGT("RFCOMM Connect on dlci %d...\n", dlci);
        bt_rfcomm_send_credits(dlci, MAX_CREDITS - BT_RFCOMM_DEF_CREDITS);
        connected = 1;
    } else {
        DEBUGT("RFCOMM Disconnect on dlci %d...\n", dlci);
        NutEventPostAsync(&sig_disconnect);
        connected = 0;
    }
}

static void line_cb(u_char dlci, u_char flags, void *arg)
{
    DEBUGT("rfcomm Line status has changed: dlci: %d, flags: %02x\n", dlci, flags);
}

static void credit_cb(u_char dlci, u_char credits, void *arg)
{
    DEBUGT("rfcomm Credits running low on dlci %d. Credits remaining: %d\n", dlci, credits);
    DEBUGT("rfcomm Send new credits: %d\n", MAX_CREDITS - credits);
    bt_rfcomm_send_credits(dlci, MAX_CREDITS - credits);
}

static void rcv_cb_active(u_char dlci, u_char * payload, u_short len, void *arg)
{
#if RFCOMM_CMD_DEBUG >=1
    u_short idx;
    if (len > 0) {
        printf_P(PSTR("\n----------------\n"));
        for (idx = 0; idx < len; idx++)
            printf_P(PSTR("%c "), payload[idx]);
        printf_P(PSTR("\n----------------\n"));
    }
#endif
}

static void con_cb_active(u_char dlci, u_char type, void *arg)
{
    if (type == BT_RFCOMM_CONNECT) {
        DEBUGT("RFCOMM Connect on dlci %d...\n", dlci);
        connected = 1;
        bt_rfcomm_send_credits(dlci, MAX_CREDITS - BT_RFCOMM_DEF_CREDITS);
    } else {
        DEBUGT("RFCOMM Disconnect on dlci %d...\n", dlci);
        connected = 0;
    }
}

static void line_cb_active(u_char dlci, u_char flags, void *arg)
{
    DEBUGT("rfcomm Line status has changed: dlci: %d, flags: %02x\n", dlci, flags);
}

static void credit_cb_active(u_char dlci, u_char credits, void *arg)
{
    DEBUGT("rfcomm Credits running low for dlci %d. Credits remaining: %d\n", dlci, credits);
    DEBUGT("rfcomm Send new credits: %d\n", MAX_CREDITS - credits);
    bt_rfcomm_send_credits(dlci, MAX_CREDITS - credits);
}



THREAD(CH1_LISTEN, arg)
{
    for (;;) {
        DEBUGT("rfcomm listening on channel 1\n");
        if (bt_rfcomm_listen(1, con_cb, rcv_cb, line_cb, credit_cb, MIN_CREDITS, NULL, NUT_WAIT_INFINITE) == BT_RFCOMM_ERR_SUCCESS) {
            DEBUGT("rfcomm channel 1 connected...\n");
            NutEventWait(&sig_disconnect, NUT_WAIT_INFINITE);
            // NutSleep(100);                              // give a short time to clean up the stack. 
        }
        DEBUGT("rfcomm channel 1 disconnected...\n");
    }
}

static void _bt_rfcomm_cmd_test(char * arg)
{
    u_char res;

    res = bt_rfcomm_test(10000);

    if (res == BT_RFCOMM_ERR_SUCCESS) {
        DEBUGT("rftest: succeded\n");
    } else {
        DEBUGT("rftest: timeout...\n");
    }
}

static void _bt_rfcomm_cmd_credit(char * arg)
{
    u_char res;
    u_int credits;
    u_int dlci;

    if (sscanf(arg, "%u%u", &dlci, &credits) == 2) {
        if (credits > 0xFF) {
            DEBUGT("rfcredit: error: credits out of range\n");
            return;
        } else if (dlci > (BT_RFCOMM_MAX_CHANNELS << 2)) {
            DEBUGT("rfcredit: error: dlci out of range\n");
            return;
        }
        res = bt_rfcomm_send_credits(dlci, credits);

        if (res != BT_RFCOMM_ERR_SUCCESS) {
            DEBUGT("rfcredit: error %d\n", res);
            return;
        }
    } else {
        DEBUGT("rfcredit: error: usage: rfcredit <dlci> <credits>\n");
    }

}

static void _bt_rfcomm_cmd_session(char * arg)
{
    bt_addr_t addr;
    int index = -1;
    int i;
    u_char res;
    u_int channel_nr;

    if (connected) {
        DEBUGT("rfsession: error: allready connected!\n");
        return;
    }
    if ((sscanf
         (arg, "%2x:%2x:%2x:%2x:%2x:%2x%u", &_terminal_bt_cmds->bt_addr_buffer[5], &_terminal_bt_cmds->bt_addr_buffer[4],
          &_terminal_bt_cmds->bt_addr_buffer[3], &_terminal_bt_cmds->bt_addr_buffer[2], &_terminal_bt_cmds->bt_addr_buffer[1],
          &_terminal_bt_cmds->bt_addr_buffer[0], &channel_nr) == 7) || (sscanf(arg, "%u%u", &index, &channel_nr) == 2)) {
        //sync con call

        if (index >= _terminal_bt_cmds->nr_inq_dev) {
            DEBUGT("rfsession: error: dev index out of range\n");
            _print_inq_result();
            return;
        } else if (index == -1) {
            for (i = 0; i < BD_ADDR_LEN; i++)
                addr[i] = (u_char) _terminal_bt_cmds->bt_addr_buffer[i];
        }
        if ((channel_nr < 1) || (channel_nr > 30)) {
            DEBUGT("rfsession: error: channel nr out of range [1..30]\n");
            return;
        }
        DEBUGT("RFCOMM connect to ");
        if (index > -1) {       //call with addr in inq_result _terminal_bt_cmds->inqres[index].bdaddr
            _print_bt_addr(_terminal_bt_cmds->inqres[index].bdaddr);
            DEBUGT(" Channel %d\n", channel_nr);
            res = bt_rfcomm_start_session(_terminal_bt_cmds->inqres[index].bdaddr,
                                          _terminal_bt_cmds->inqres[index].page_scan_rep_mode,
                                          _terminal_bt_cmds->inqres[index].clock_offset);

            if ((res == BT_RFCOMM_ERR_SUCCESS) || (res == BT_RFCOMM_ERR_SESSION_EXISTS))
                res =
                    bt_rfcomm_connect(channel_nr, con_cb_active, rcv_cb_active, line_cb_active, credit_cb_active, MIN_CREDITS,
                                      NULL);
        } else {                //call with addr
            _print_bt_addr(addr);
            DEBUGT(" Channel %d\n", channel_nr);
            res = bt_rfcomm_start_session(addr, 0, 0);
            if ((res == BT_RFCOMM_ERR_SUCCESS) || (res == BT_RFCOMM_ERR_SESSION_EXISTS))
                res =
                    bt_rfcomm_connect(channel_nr, con_cb_active, rcv_cb_active, line_cb_active, credit_cb_active, MIN_CREDITS,
                                      NULL);
        }
        if (res != BT_L2CAP_ERR_SUCCESS) {      //error
            if (res == BT_L2CAP_ERR_TIMEOUT) {
                bt_rfcomm_disconnect(BT_RFCOMM_DLCI_MUX);
                DEBUGT("rfsession: error: timeout...\n");
            } else {
                bt_rfcomm_disconnect(BT_RFCOMM_DLCI_MUX);
                DEBUGT("rfsession: error: %d\n", res);
            }
        } else {
            DEBUGT("rfsession: success\n");
        }
    } else {
        DEBUGT("rfsession: error: usage: rfsession xx:xx:xx:xx:xx:xx <channel>\n"
               "                         rfsession <inq-index> <channel>\n");
    }
}

static void _bt_rfcomm_cmd_send(char * arg)
{
    u_char res;
    u_short dlci;
    char *text;

    if (!connected) {
        DEBUGT("rfsend: error: not connected!\n");
        return;
    }

    dlci = atol(arg);

    if (dlci != 0) {
        text = arg;
        while (*text != 0) {
            if (*text == ' ') {
                text++;
                break;
            } else {
                text++;
            }
        }
        if (*text == 0) {
            DEBUGT("rfsend: error: usage: rfsend <dlci> <text>\n");
            return;
        }
        res = bt_rfcomm_send(dlci, (u_char*)text, strlen(text));
        if (res != BT_RFCOMM_ERR_SUCCESS) {
            DEBUGT("rfsend: error %d\n", res);
        }
    } else {
        DEBUGT("rfsend: error: usage: rfsend <dlci> <text>\n");
    }
}

static void _bt_rfcomm_cmd_connect(char * arg)
{
    u_char res;
    u_int channel_nr;

    if (sscanf(arg, "%u", &channel_nr) == 1) {
        if ((channel_nr < 1) || (channel_nr > BT_RFCOMM_MAX_CHANNELS)) {
            DEBUGT("rfcon: error: channel out of range [1..30]\n");
            return;
        }
        res = bt_rfcomm_connect(channel_nr, con_cb_active, rcv_cb_active, line_cb_active, credit_cb_active, MIN_CREDITS, NULL);

        if (res != BT_RFCOMM_ERR_SUCCESS) {
            DEBUGT("rfcon: error %d\n", res);
            return;
        }
    } else {
        DEBUGT("rfcon: error: usage: rfcon <channel>\n");
    }

}

static void _bt_rfcomm_cmd_disconnect(char * arg)
{
    u_char res;
    u_int dlci;

    if (sscanf(arg, "%u", &dlci) == 1) {
        if (dlci > (BT_RFCOMM_MAX_CHANNELS << 2)) {
            DEBUGT("rfdiscon: error: dlci out of range\n");
            return;
        }
        res = bt_rfcomm_disconnect(dlci);

        if (res != BT_RFCOMM_ERR_SUCCESS) {
            DEBUGT("rfdiscon: error %d\n", res);
            return;
        }
    } else {
        DEBUGT("rfdiscon: error: usage: rfdiscon <dlci>\n");
    }

}

void rfcomm_cmds_init(void)
{
    NutThreadCreate("ch1_listen", CH1_LISTEN, NULL, 256);
}


void rfcomm_cmds_register_cmds(void)
{
    btn_terminal_register_cmd("rftest", _bt_rfcomm_cmd_test);
    btn_terminal_register_cmd("rfcredit", _bt_rfcomm_cmd_credit);
    btn_terminal_register_cmd("rfsend", _bt_rfcomm_cmd_send);
    btn_terminal_register_cmd("rfsession", _bt_rfcomm_cmd_session);
    btn_terminal_register_cmd("rfcon", _bt_rfcomm_cmd_connect);
    btn_terminal_register_cmd("rfdiscon", _bt_rfcomm_cmd_disconnect);
}
