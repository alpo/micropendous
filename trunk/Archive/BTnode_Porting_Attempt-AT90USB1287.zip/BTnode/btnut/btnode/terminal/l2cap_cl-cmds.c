/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file l2cap_cl-cmds.c
 * 
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Terminal cmds for the l2cap connection-less layer.
 * 
 */
#include <string.h>
#include <terminal/btn-terminal.h>
#include <sys/thread.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <utils/fifo_queue.h>
#include <debug/toolbox.h>

/**
 * Use this packet type to send pkts with a payload up to #BT_MAX_ACL_COM_PAYLOAD.\n
 * DM3 means three slots are used for one pkt. Smaller amount of slots can lead
 * to fragmented pkts
 */
#define HCI_PACKET_TYPE BT_HCI_PACKET_TYPE_DM3

typedef struct _l2cap_cl_cmds_stack_t {
	struct btstack* bt_stack;
	char l2cap_cl_cmds_str_buf[100];
} l2cap_cl_cmds_stack_t;

l2cap_cl_cmds_stack_t* l2cap_cl_cmds_stack;

void _l2cap_cl_cmds_print_usage(void)
{
	tprintf("l2capc: error: usage: send <handle> <psm> <nr_data>\n"
            "                      chpkttype\n");
}

// send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void _l2cap_cl_cmd_send(char * arg)
{
    long res;
    int handle, psm;
    unsigned int nrdata, i;
    u_char data[150];
    
    // parse user input
    if (sscanf(arg, "%u%u%u", &handle, &psm, &nrdata) == 3) {
    	if (nrdata > l2cap_cl_max_payload()) {
    		tprintf("send: error: data too large!\n");
    		return;
    	}
        //copy rest of arg string into pkt
        for (i = 0; i < nrdata; i++) {
            data[i] = i;
        }
        // send the packet
        tprintf("sending %d bytes over con %d. psm %d\n", nrdata, handle, psm);
        res = l2cap_cl_send(data, (u_short)nrdata, handle, psm);
        // error handling
        if (res == L2CAP_CL_ERR_PAYLOAD_OVERFLOW)
        	tprintf("send: error: payload ovflw! limited to %d bytes\n",
        		l2cap_cl_max_payload());
        else if (res == BT_ERR_NO_CON)
            tprintf("send: error: no con with hdl %d\n", handle);
        else if (res == BT_ERR_BT_MODULE)
            tprintf("send: error: module error!\n");
        else if (res == 0)
            tprintf("data sent.\n");
        else 
        	tprintf("send: error: 0x%.2x\n", -res);
    } else _l2cap_cl_cmds_print_usage();
}

// change pkt type!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void _l2cap_cl_cmd_change_pkt_type(char * arg)
{
    int handle;
    long res;
    if (sscanf(arg, "%u", &handle) == 1) {
        res = bt_hci_change_con_pkt_type(l2cap_cl_cmds_stack->bt_stack,
        							BT_HCI_SYNC, handle, HCI_PACKET_TYPE);
        if (res < 0)
            tprintf("pkt change: error\n");
        else {
            tprintf("pkt changed to 0x%.4x\n", res);
        }
    } else _l2cap_cl_cmds_print_usage();
}

void _l2cap_cl_cmd_l2cap_cl_cmds(char* arg) {
    if (!strncmp(arg, "send", 4)) {
    	_l2cap_cl_cmd_send(arg+4);
    } else if (!strncmp(arg, "chpkttype", 9)) {
    	_l2cap_cl_cmd_change_pkt_type(arg+9);
    } else {
    	_l2cap_cl_cmds_print_usage();
    }
}

void l2cap_cl_cmds_register_cmds(void)
{
    btn_terminal_register_cmd("l2capc", _l2cap_cl_cmd_l2cap_cl_cmds);
}

void l2cap_cl_cmds_init(struct btstack* bt_stack) {
	l2cap_cl_cmds_stack = NutHeapAllocClear(sizeof(l2cap_cl_cmds_stack_t));
	l2cap_cl_cmds_stack->bt_stack = bt_stack;
}
