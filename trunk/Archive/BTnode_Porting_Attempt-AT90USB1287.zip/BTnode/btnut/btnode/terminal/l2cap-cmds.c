/*
 * Copyright (C) 2000-2004 by ETH Zurich
 * Copyright (C) 2004 by Ole Reinhardt <ole.reinhardt@embedded-it.de>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/*
 * cmds for sending text to other connection, ping a device etc...
 */
#include <string.h>
#include <sys/heap.h>
#include <terminal/btn-terminal.h>
#include <terminal/bt-cmds.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>

#ifndef L2CAP_CMD_DEBUG
#define L2CAP_CMD_DEBUG 1
#endif

#if     L2CAP_DEBUG >= 1
#define INFO(text, ...) DEBUGT("l2cap-cmds: " text,## __VA_ARGS__)
#else
#define INFO(text, ...)
#endif

struct bt_l2cap_stack *_l2cap_stack;
u_char l2cap_service;
struct bt_l2cap_acl_pkt *pkt;
static u_char connected = 0;
u_short l2cap_channel_id;

#define PSM_TEST 0x09

static void _bt_l2cap_rcv_cb(struct bt_l2cap_acl_pkt *pkt, u_char service_nr, u_short channel_id, void *arg)
{
    DEBUGT("Received \"%s\"\n", pkt->payload);
    bt_l2cap_complete_pkt(pkt);
}

static void _bt_l2cap_con_cb(u_char type, u_char detail, u_char service_nr, u_short channel_id, void *arg)
{
    if (type == BT_L2CAP_CONNECT) {
        connected = 1;
        l2cap_channel_id = channel_id;
        DEBUGT("L2CAP connect. Unique handle: %04x\n", channel_id);
        INFO("\t--- PSM:  %04x\n\t--- lcid: %04x\n\t--- rcid: %04x\n\t--- omtu: %d\n",
             ((struct bt_l2cap_service *) arg)->psm, ((struct bt_l2cap_service *) arg)->local_cid,
             ((struct bt_l2cap_service *) arg)->remote_cid, ((struct bt_l2cap_service *) arg)->omtu);
    } else {
        connected = 0;
        DEBUGT("L2CAP disconnect. Unique handle: %04x\n", channel_id);
    }
}

static void _print_bt_addr(bt_addr_t addr)
{
    DEBUGT("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x", addr[5], addr[4], addr[3], addr[2], addr[1], addr[0]);
}

static void _print_inq_result(void)
{
    int i;
    DEBUGT("Devices: %d\n", _terminal_bt_cmds->nr_inq_dev);
    if (_terminal_bt_cmds->nr_inq_dev < 0) {
        _terminal_bt_cmds->nr_inq_dev = 0;
    } else {
        DEBUGT("Device         bt_addr cod        clock_offs  page_scan_rep\n");
    }
    for (i = 0; i < _terminal_bt_cmds->nr_inq_dev; i++) {
        DEBUGT("[%d]: ", i);
        _print_bt_addr(_terminal_bt_cmds->inqres[i].bdaddr);
        DEBUGT(" 0x%.8lx 0x%.4x      0x%x\n", _terminal_bt_cmds->inqres[i].cod, _terminal_bt_cmds->inqres[i].clock_offset,
               _terminal_bt_cmds->inqres[i].page_scan_rep_mode);
    }
}

static void _bt_l2cap_cmd_l2ping(char * arg)
{
    bt_addr_t addr;
    int index = -1;
    int count = 1, i;
    u_char res;
    u_long time;

    if ((sscanf
         (arg, "%2x:%2x:%2x:%2x:%2x:%2x%u", &_terminal_bt_cmds->bt_addr_buffer[5], &_terminal_bt_cmds->bt_addr_buffer[4],
          &_terminal_bt_cmds->bt_addr_buffer[3], &_terminal_bt_cmds->bt_addr_buffer[2], &_terminal_bt_cmds->bt_addr_buffer[1],
          &_terminal_bt_cmds->bt_addr_buffer[0], &count) == 7)
        ||
        (sscanf
         (arg, "%2x:%2x:%2x:%2x:%2x:%2x", &_terminal_bt_cmds->bt_addr_buffer[5], &_terminal_bt_cmds->bt_addr_buffer[4],
          &_terminal_bt_cmds->bt_addr_buffer[3], &_terminal_bt_cmds->bt_addr_buffer[2], &_terminal_bt_cmds->bt_addr_buffer[1],
          &_terminal_bt_cmds->bt_addr_buffer[0]) == 6) || (sscanf(arg, "%u%u", &index, &count) == 2)
        || (sscanf(arg, "%u", &index) == 1)) {
        //sync con call

        if (index >= _terminal_bt_cmds->nr_inq_dev) {
            DEBUGT("l2ping: error: dev index out of range\n");
            _print_inq_result();
            return;
        } else if (index == -1) {
            for (i = 0; i < BD_ADDR_LEN; i++)
                addr[i] = (u_char) _terminal_bt_cmds->bt_addr_buffer[i];
        }
        for (i = 0; i < count; i++) {
            DEBUGT("l2ping to ");
            if (index > -1) {   //call with addr in inq_result _terminal_bt_cmds->inqres[index].bdaddr
                _print_bt_addr(_terminal_bt_cmds->inqres[index].bdaddr);
                DEBUGT("\n");
                res = bt_l2cap_l2ping(_terminal_bt_cmds->inqres[index].bdaddr, (u_char*)"BTNut", strlen("BTNut") + 1, &time);
            } else {            //call with addr
                _print_bt_addr(addr);
                DEBUGT("\n");
                res = bt_l2cap_l2ping(addr, (u_char*)"BTNut", strlen("BTNut") + 1, &time);
            }
            if (res != BT_L2CAP_ERR_SUCCESS) {  //error
                if (res == BT_L2CAP_ERR_TIMEOUT) {
                    DEBUGT("l2ping: error: timeout...\n");
                } else {
                    DEBUGT("l2ping: error: %d\n", res);
                }
            } else {
                DEBUGT("l2ping: success, time = %ldms\n", time);
            }
        }
    } else {
        DEBUGT("l2ping: error: usage: l2ping xx:xx:xx:xx:xx:xx [count]" "                      l2ping <inq-index> [count]\n");
    }
}

static void _bt_l2cap_cmd_connect(char * arg)
{
    bt_addr_t addr;
    int index = -1;
    int i;
    u_char res;
    u_int psm;
    u_short channel_id = 0x0000;

    if (connected) {
        DEBUGT("l2con: error: allready connected!\n");
        return;
    }
    if ((sscanf
         (arg, "%2x:%2x:%2x:%2x:%2x:%2x%u", &_terminal_bt_cmds->bt_addr_buffer[5], &_terminal_bt_cmds->bt_addr_buffer[4],
          &_terminal_bt_cmds->bt_addr_buffer[3], &_terminal_bt_cmds->bt_addr_buffer[2], &_terminal_bt_cmds->bt_addr_buffer[1],
          &_terminal_bt_cmds->bt_addr_buffer[0], &psm) == 7) || (sscanf(arg, "%u%u", &index, &psm) == 2)) {
        //sync con call

        if (index >= _terminal_bt_cmds->nr_inq_dev) {
            DEBUGT("l2con: error: dev index out of range\n");
            _print_inq_result();
            return;
        } else if (index == -1) {
            for (i = 0; i < BD_ADDR_LEN; i++)
                addr[i] = (u_char) _terminal_bt_cmds->bt_addr_buffer[i];
        }
        if ((psm & 0x01) == 0) {
            DEBUGT("l2con: error: psm needs to be odd\n");
            return;
        }
        DEBUGT("L2CAP connect to ");
        if (index > -1) {       //call with addr in inq_result _terminal_bt_cmds->inqres[index].bdaddr
            _print_bt_addr(_terminal_bt_cmds->inqres[index].bdaddr);
            DEBUGT(" PSM %d\n", psm);
            res = bt_l2cap_connect(l2cap_service, _terminal_bt_cmds->inqres[index].bdaddr,
                                   _terminal_bt_cmds->inqres[index].page_scan_rep_mode,
                                   _terminal_bt_cmds->inqres[index].clock_offset, psm, &channel_id);
        } else {                //call with addr
            _print_bt_addr(addr);
            DEBUGT(" PSM %d\n", psm);
            res = bt_l2cap_connect(l2cap_service, addr, 0, 0, psm, &channel_id);
        }
        if (res != BT_L2CAP_ERR_SUCCESS) {      //error
            if (res == BT_L2CAP_ERR_TIMEOUT) {
                DEBUGT("l2con: error: timeout...\n");
            } else {
                DEBUGT("l2con: error: %d\n", res);
            }
        } else {
            DEBUGT("l2con: success\n");
        }
    } else {
        DEBUGT("l2con: error: usage: l2con xx:xx:xx:xx:xx:xx <psm>\n" "                     l2con <inq-index> <psm>\n");
    }
}

static void _bt_l2cap_cmd_disconnect(char * arg)
{
    u_long res;

    if (!connected) {
        DEBUGT("l2discon: error: not connected!\n");
        return;
    }

    res = bt_l2cap_disconnect(l2cap_channel_id);

    if (res != BT_L2CAP_ERR_SUCCESS) {  //error
        if (res == BT_L2CAP_ERR_TIMEOUT) {
            DEBUGT("l2discon: error: timeout...\n");
        } else {
            DEBUGT("l2discon: error: %d\n", res);
        }
    } else {
        DEBUGT("l2discon: success\n");
    }
}

static void _bt_l2cap_cmd_contable(char * arg)
{
    u_char idx;

    DEBUGT("bb conhandle:   rcid:   lcid:   state:\n");
    for (idx = 0; idx < _l2cap_stack->max_channel; idx++) {
        if (_l2cap_stack->channels[idx].service_nr != BT_L2CAP_SERVICENR_INVALID)
            DEBUGT("%08x        %04x    %04x    %02x\n",
                   _l2cap_stack->services[_l2cap_stack->channels[idx].service_nr].con_handle,
                   _l2cap_stack->channels[idx].remote_cid, _l2cap_stack->channels[idx].local_cid,
                   _l2cap_stack->channels[idx].state);
    }
}

static void _bt_l2cap_cmd_send(char * arg)
{
    struct bt_l2cap_acl_pkt *pkt;

    if (!connected) {
        DEBUGT("l2send: error: not connected!\n");
        return;
    }
    if ((arg != NULL) && (strlen(arg) > 0)) {
        pkt = NutHeapAlloc(sizeof(struct bt_l2cap_acl_pkt) - 1 + 255);
        strncpy((char*)pkt->payload, arg, 255);
        bt_l2cap_send(l2cap_channel_id, pkt, strlen((char*)pkt->payload) + 1);
        NutHeapFree(pkt);
    } else {
        DEBUGT("l2send: error: usage: l2send <text>\n");
    }
}

void l2cap_cmds_init(struct bt_l2cap_stack *stack, u_char nr_buffer, u_short min_mtu, u_short max_mtu)
{
    pkt = NutHeapAlloc(max_mtu);
    _l2cap_stack = stack;
    l2cap_service = bt_l2cap_register_service(PSM_TEST, nr_buffer, min_mtu, max_mtu, _bt_l2cap_con_cb, _bt_l2cap_rcv_cb, NULL);
}


void l2cap_cmds_register_cmds(void)
{
    btn_terminal_register_cmd("l2ping", _bt_l2cap_cmd_l2ping);
    btn_terminal_register_cmd("l2con", _bt_l2cap_cmd_connect);
    btn_terminal_register_cmd("l2discon", _bt_l2cap_cmd_disconnect);
    btn_terminal_register_cmd("l2contable", _bt_l2cap_cmd_contable);
    btn_terminal_register_cmd("l2send", _bt_l2cap_cmd_send);
}
