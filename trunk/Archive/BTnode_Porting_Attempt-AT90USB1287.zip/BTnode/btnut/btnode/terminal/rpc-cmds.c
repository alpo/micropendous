/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file rpc-cmds.c
 * 
 * \author Matthias Dyer <dyer@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Terminal cmds for the RPC layer.
 * 
 */
#include <string.h>
#include <sys/heap.h>
#include <mhop/rpc.h>
#include <terminal/btn-terminal.h>
#include <debug/logging.h>
#include <debug/toolbox.h>
#include <terminal/rpc-cmds.h>
#include <sys/timer.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_RPC
#define LOG_LEVEL SYSLOG_LEVEL_RPC
#include <debug/log_set.h>

#define RPC_CMD_TYPE_LOCAL     0
#define RPC_CMD_TYPE_DEST      1
#define RPC_CMD_TYPE_BROADCAST 2

typedef struct _rpc_cmd_s{
    u_char cmd_type;
    bt_addr_t destination;
    u_char ttl;
    u_char str_proc_nr;
    u_char more_pkts;
    char* data;
    u_short to_send;    
    u_short rpc_psm;
} _rpc_cmd_t;

_rpc_cmd_t* _rpc_cmd;

inline u_short rpcs_max_result_size(void){
    return rpc_max_result_size() - 3;
}

void _rpc_handle_str_cmd(char* cmd){
    u_char data_len = strlen(cmd);
    u_char pkt[data_len + 1];
    pkt[0] = _rpc_cmd->str_proc_nr;
    memcpy(pkt+1, cmd, data_len);
    // send query
    if(_rpc_cmd->cmd_type == RPC_CMD_TYPE_BROADCAST){
        memcpy(_rpc_cmd->destination, bt_addr_null, BD_ADDR_LEN);
    }
    DEBUG("sending query to "ADDR_FMT" len=%d\n", 
       ADDR(_rpc_cmd->destination), data_len);
    mhop_cl_send_pkt(pkt, 
                     data_len + 1, 
                     _rpc_cmd->destination,
                     _rpc_cmd->rpc_psm,
                     MHOP_CL_BROADCAST,
                     _rpc_cmd->ttl);   
}

void _rpc_cmd_parser(char* arg){
    u_char i;
    u_char offset = 0;
    unsigned int val = 0;
    unsigned int addr[BD_ADDR_LEN];
    if(sscanf(arg, "%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], 
       &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
        for (i = 0; i < BD_ADDR_LEN; i++) {
            _rpc_cmd->destination[i] = (u_char) addr[i];
        }
        offset = 18;
        _rpc_cmd->ttl = 0;
        _rpc_cmd->cmd_type = RPC_CMD_TYPE_DEST;
    } 
    else if((sscanf(arg, "%u", &val) == 1) && val == 0){ 
        offset = 2;
        _rpc_cmd->ttl = 0;
        _rpc_cmd->cmd_type = RPC_CMD_TYPE_BROADCAST;        
    }
    else{
        tprintf("rpc: error: usage:\n rpc {<addr>|0} <command>\n");
    }
    if(offset!=0){
        btn_terminal_process_cmd(arg+offset);
    }
    _rpc_cmd->cmd_type = RPC_CMD_TYPE_LOCAL;                
}

void _rpc_scmd_parser(char* arg){
    u_char i;
    u_char offset = 0;
    unsigned int val = 0;
    unsigned int addr[BD_ADDR_LEN];
    if(sscanf(arg, "%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], 
       &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
        for (i = 0; i < BD_ADDR_LEN; i++) {
            _rpc_cmd->destination[i] = (u_char) addr[i];
        }
        offset = 18;
        _rpc_cmd->ttl = 0;
        _rpc_cmd->cmd_type = RPC_CMD_TYPE_DEST;
    } 
    else if((sscanf(arg, "%u", &val) == 1) && val == 0){ 
        offset = 2;
        _rpc_cmd->ttl = 0;
        _rpc_cmd->cmd_type = RPC_CMD_TYPE_BROADCAST;        
    }
    else{
        tprintf("rpcs: error: usage:\n rpcs {<addr>|0} <command>\n");
    }
    if(offset!=0){
        DEBUG_STR("sending rpcs cmd: [%s]\n",arg+offset);
        _rpc_handle_str_cmd(arg+offset);
    }
    _rpc_cmd->cmd_type = RPC_CMD_TYPE_LOCAL;                
}

u_char _rpc_scmd_proc(bt_acl_pkt_buf* pkt_buf, char* query, u_char query_len, void* arg,
                      u_char* result, u_char* result_len)
{
    u_char error;
    if(!_rpc_cmd->more_pkts){
        // exec cmd and capture result
        if(term_register_thread() != 0) {
            ERROR("log_register_thread failed\n");
        }
        if(term_start_capture() != 0){        
            ERROR("start capture failed\n");
        }
        query[query_len] = '\0';
        DEBUG_STR("rpcs: [%s]\n", query);
        error = btn_terminal_process_cmd(query);
        _rpc_cmd->data = term_stop_capture();
        _rpc_cmd->to_send = strlen(_rpc_cmd->data);
        DEBUG("captured length %d\n", _rpc_cmd->to_send);
    }
    
    if(_rpc_cmd->to_send == 0){
        return 0;
    }
    
    result[0] = _rpc_cmd->to_send >> 8;
    result[1] = _rpc_cmd->to_send & 0xff;

    u_short maxlen = rpcs_max_result_size();
       
    if(_rpc_cmd->to_send > maxlen){
        _rpc_cmd->more_pkts = 1;
        memcpy(result+2, _rpc_cmd->data, maxlen);
        result[2+maxlen]  = '\0'; // null terminate string part
        *result_len = maxlen + 3;
        _rpc_cmd->data += maxlen;
        _rpc_cmd->to_send -= maxlen;
        return 1;
    }
    else{
        _rpc_cmd->more_pkts = 0;
        memcpy(result+2, _rpc_cmd->data, _rpc_cmd->to_send);
        result[2+_rpc_cmd->to_send]  = '\0'; // null terminate string part
        *result_len = _rpc_cmd->to_send + 3;
        return 0;
    }    
}

void _rpc_scmd_result(u_char* source_addr, u_char* result, u_char result_len, 
                      void* arg)
{
    u_short length = (u_short) result[0] << 8 | result[1]; 
    btn_terminal_get_writing_lock();
    //print header
    tprintf("\n:RP %s\n", 
         dbg_bt_addr_to_str(source_addr)); 
    //print message
    tprintf("%s", result+2);
    
    if ((result_len - 3) != length){
        // if log message is not complete, print breaktag
        printf("\x03\n");
    }
    else{
        // else print endtag
        printf("\x04\n");
    }
    btn_terminal_free_writing_lock();         
}

void rpc_handle_query(u_char proc_nr, u_char* data, u_char data_len)
{
    switch(_rpc_cmd->cmd_type){
        case RPC_CMD_TYPE_LOCAL:
            rpc_local_query(proc_nr, data, data_len);
            break;
        case RPC_CMD_TYPE_DEST:            
            rpc_send_query(proc_nr, data, data_len, _rpc_cmd->destination, _rpc_cmd->ttl);
            break;
        case RPC_CMD_TYPE_BROADCAST:
            rpc_send_query(proc_nr, data, data_len, bt_addr_null, _rpc_cmd->ttl); 
            break;     
    }
}


void rpc_cmds_init(u_short rpc_psm)
{
    _rpc_cmd = NutHeapAllocClear(sizeof(_rpc_cmd_t));
    _rpc_cmd->cmd_type = RPC_CMD_TYPE_LOCAL;
    _rpc_cmd->rpc_psm = rpc_psm;
    
    rpc_register_proc(&_rpc_cmd->str_proc_nr,
                      _rpc_scmd_proc, NULL,
                      _rpc_scmd_result, NULL);
                      
    DEBUG("rpcs prog: %d\n", _rpc_cmd->str_proc_nr);
    
    btn_terminal_register_cmd("rpc", _rpc_cmd_parser);                          
    btn_terminal_register_cmd("rpcs", _rpc_scmd_parser);                          
}
