#include <eepromdb/btn-eepromdb.h>
#include <terminal/btn-terminal.h>
#include <string.h>
#include <sys/heap.h>

#define EEPROM_CMDS_MAX_CMD_LEN 8
#define EEPROM_CMDS_MAX_NR_PARAMS 20

// prints the values of the paramter passed to the terminal
#define EEPROM_CMDS_PRINT_PARAM(param_ptr, eepr_val) \
	        DEBUGT("%-9s: %4.lu EEPROM: %4lu\n", \
        	param_ptr->cmd_name, *(param_ptr->val), eepr_val)

typedef struct _eeprom_cmds_param {
	char cmd_name[EEPROM_CMDS_MAX_CMD_LEN+1];
	u_long eeprom_id;
	u_long* val;
	u_long default_val;
} eeprom_cmds_param_t;

typedef struct _eeprom_cmds_stack {
	eeprom_cmds_param_t params[EEPROM_CMDS_MAX_NR_PARAMS];
	u_char nr_params;
} eeprom_cmds_stack_t;

// pointer to the eeprom cmds stack
eeprom_cmds_stack_t* eeprom_cmds_stack;

// initializes the EEPROM cmds stack
void eeprom_cmds_init(void) {
	eeprom_cmds_stack = NutHeapAllocClear(sizeof(eeprom_cmds_stack_t));
	// initialize nr of parameters to zero
	eeprom_cmds_stack->nr_params = 0;
}

// creates a terminal cmd for managing the EEPROM parameter passed
void eeprom_cmds_add_param(char* cmd_name, u_char* eeprom_id, u_long* val_ptr, u_long default_val) {
	if (eeprom_cmds_stack->nr_params == EEPROM_CMDS_MAX_NR_PARAMS) {
		DEBUGT("adding parameter \"%s\" failed: cmd buffer is full!\n");
		return;
	}
    // set cmd name
    strncpy(eeprom_cmds_stack->params[eeprom_cmds_stack->nr_params].cmd_name, cmd_name, EEPROM_CMDS_MAX_CMD_LEN);
    // set pointer to the parameter
    eeprom_cmds_stack->params[eeprom_cmds_stack->nr_params].val = val_ptr;
    // store default value
    eeprom_cmds_stack->params[eeprom_cmds_stack->nr_params].default_val = default_val;
    // store eeprom id
    eeprom_cmds_stack->params[eeprom_cmds_stack->nr_params].eeprom_id = *((u_long*) eeprom_id);
    // increment nr of params
    eeprom_cmds_stack->nr_params++;
}

// returns the pointer to an EEPROM parameter, given its cmd name
eeprom_cmds_param_t* _eeprom_cmds_get_param(char* cmd_name) {
	u_short i;
	for (i=0; i<EEPROM_CMDS_MAX_NR_PARAMS; i++) {
		if (!strcmp(eeprom_cmds_stack->params[i].cmd_name, cmd_name)) break;
	}
	if (i<EEPROM_CMDS_MAX_NR_PARAMS)
		return &eeprom_cmds_stack->params[i];
	else return NULL;
}

// resets all currently defined EEPROM parameters
void eeprom_cmds_reset(char* arg) {
	u_short i = 0;
	if ((*arg) & 1) {
		DEBUGT("resetting EEPROM...");
		for (i=0; i<eeprom_cmds_stack->nr_params; i++) {
	    	// write default value to eeprom
			if (btn_eepromdb_store(eeprom_cmds_stack->params[i].eeprom_id,
				sizeof(u_long), &eeprom_cmds_stack->params[i].default_val) == 0) {
		   		DEBUGT("\nERROR: writing parameter \"%s\": %lu to EEPROM!",
		   			eeprom_cmds_stack->params[i].cmd_name, \
		   			eeprom_cmds_stack->params[i].default_val);
		   	}
		}
		DEBUGT(" done.\n");
	}
	if ((*arg) & 2) {
		DEBUGT("resetting parameter values... ");
		for (i=0; i<eeprom_cmds_stack->nr_params; i++) {
			*eeprom_cmds_stack->params[i].val = 
				eeprom_cmds_stack->params[i].default_val;
		}
		DEBUGT(" done.\n");
	}
}

// terminal cmd for reading a parameter from the EEPROM
void eeprom_cmds_param_read(char* arg) {
	long val;
	eeprom_cmds_param_t* param;
	param = _eeprom_cmds_get_param(arg);
	if (param != NULL) {
		// read param from EEPROM
		btn_eepromdb_get(param->eeprom_id, sizeof(u_long), &val);
		// print parameter
		EEPROM_CMDS_PRINT_PARAM(param, val);
	}
	else DEBUGT("can't find eeprom parameter: %s!\n", arg);
}

// try to read param from eeprom, if not found, current value will be stored to eeprom
u_char eeprom_cmds_param_ext_read(u_char* name, u_long* data_ptr, u_long default_val) {
    u_short len = 0;
    u_long id;
    // create EEPROM id
    id = *((u_long*) name);
    // read param value from EEPROM if defined
    len = btn_eepromdb_get(id, sizeof(u_long), data_ptr);
    // if not set, set default value
    if (len == 0) {
        *data_ptr = default_val;
        DEBUGT("Identifier: \"%s\" unknown!\nInitialising Parameter... ", name);
        // write parameter value to EEPROM
        len = btn_eepromdb_store(id, sizeof(u_long), data_ptr);
        if (len==0) {
            DEBUGT("ERROR writing to EEPROM!\n");
            return 0;
        }
        else {
            DEBUGT("done. Wrote %d bytes\n", len);
        }
    }
    DEBUGT("parameter \"%s\" is set to %lu\n", name, *data_ptr);
    return 1;
}

// terminal cmd for setting the value of an EEPROM paramter
void eeprom_cmds_param_set(char* arg) {
	eeprom_cmds_param_t* param;
	char param_name[EEPROM_CMDS_MAX_CMD_LEN];
	u_long val;
	u_int eeprom_write;
    if (sscanf(arg, "%s%lu%d", param_name, &val, &eeprom_write) >= 2) {
    	// get parameter by its name
    	param = _eeprom_cmds_get_param(param_name);
    	if (param == NULL) {
    		DEBUGT("can't find eeprom parameter: %s!\n", param->cmd_name);
    		return;
    	}
    	// set value of parameter
		*(param->val) = val;
		// write value to EEPROM
        if (eeprom_write) {
			if (!btn_eepromdb_store(param->eeprom_id, sizeof(u_long), &param->val)) {
				DEBUGT("error writing to eeprom!\n");
			}
        }
		// read param value from EEPROM
		btn_eepromdb_get(param->eeprom_id, sizeof(u_long), &val);
        EEPROM_CMDS_PRINT_PARAM(param, val);
    }
}

void _eeprom_cmds_params_show(void) {
	u_short i;
	u_long val;
	eeprom_cmds_param_t* param;
	for (i=0; i<eeprom_cmds_stack->nr_params; i++) {
		param = &eeprom_cmds_stack->params[i];
		// read param from EEPROM
		btn_eepromdb_get(eeprom_cmds_stack->params[i].eeprom_id, sizeof(u_long), &val); 
		EEPROM_CMDS_PRINT_PARAM(param, val);
	}
}


void _eeprom_cmds_print_usage(void)
{
    DEBUGT("eeprom: error: usage:\n"
           "reset\n"
           "show\n"
           "set <param> <value> [<eeprom_write>]\n"
           "read <param>\n");
}

void _eeprom_cmds_cmd(char * arg)
{
    if (!strncmp(arg, "reset", 5)) {
        eeprom_cmds_reset(arg+6);
    } else if (!strncmp(arg, "show", 4)) {
        _eeprom_cmds_params_show();
    } else if (!strncmp(arg, "set", 3)) {
        eeprom_cmds_param_set(arg+4);
    } else if (!strncmp(arg, "read", 4)) {
        eeprom_cmds_param_read(arg+5);
    } else {
        _eeprom_cmds_print_usage();
    }
}

void eeprom_cmds_register_cmds(void)
{
    btn_terminal_register_cmd("eeprom", _eeprom_cmds_cmd);
}

