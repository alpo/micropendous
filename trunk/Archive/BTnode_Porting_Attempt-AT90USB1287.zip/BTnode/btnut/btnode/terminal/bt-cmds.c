/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 * $Id: bt-cmds.c,v 1.30 2006/10/23 11:18:26 kevmarti Exp $
 * 
 */

/*
 * $Log: bt-cmds.c,v $
 * Revision 1.30  2006/10/23 11:18:26  kevmarti
 * The command "bt contable" prints out the whole con table now, including some additional information about con state, etc.
 *
 * Revision 1.29  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * Revision 1.28  2006/08/07 11:52:31  yuecelm
 * replace bt_hci_read_bt_addr with bt_hci_get_local_bt_addr
 *
 * Revision 1.27  2006/06/18 19:01:20  yuecelm
 * fixed parsing of "bt inquiry async" without time parameter.
 *
 * Revision 1.26  2006/06/16 13:15:42  dyerm
 * fixed parsinc of "bt inquiry sync" without time parameter.
 * This should fix bug #1497710
 *
 * Revision 1.25  2006/04/10 15:33:25  yuecelm
 * move low power mode commands to bt-extra-cmds,
 * async. inquiry works again ('inquiry wait' is no more necessary,
 * 'inquiry result' includes waiting),
 * some cosmetic changes
 *
 * Revision 1.24  2006/04/06 10:54:54  kevmarti
 * removed inclusion of obsolete 'terminal/tprintf.h'
 *
 * Revision 1.23  2006/03/29 01:15:01  olereinhardt
 *
 * Changed signedness of strings in order to compile with avr-gcc 4.0.2
 *
 * Revision 1.22  2006/03/23 07:22:22  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.18.2.9  2006/03/22 17:01:05  dyerm
 * fixed bt_addr_cmd
 *
 * Revision 1.18.2.8  2006/03/22 14:07:39  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.18.2.7  2006/03/20 13:41:26  kevmarti
 * replaced TPRINTF() macro by direct call to tprintf()
 *
 * Revision 1.21  2006/03/17 18:04:58  beutel
 * added make version for applications
 * added new header and prompt for bt-cmd
 *
 * Revision 1.18.2.6  2006/03/20 10:15:29  kevmarti
 * Adapted to new logging / terminal printing macros
 *
 * Revision 1.18.2.5  2006/02/14 07:30:03  dyerm
 * Converted some DEBUGT to INFO(LOG_TERMINAL,...
 * shortened some usage printers
 *
 * Revision 1.18.2.4  2006/02/02 09:01:19  dyerm
 * fixed cmd parsing
 *
 * Revision 1.18.2.3  2006/02/02 08:21:36  kevmarti
 * cod cmd fixed
 *
 * Revision 1.18.2.2  2006/01/30 14:05:26  dyerm
 * fixed parsing of command strings
 *
 * Revision 1.18.2.1  2005/11/03 14:05:11  kevmarti
 * added tp-cmds, vcp-cmds & eeprom-cmds. Created subgroup for bt cmds
 *
 * Revision 1.18  2005/09/27 08:29:48  kevmarti
 * added "cod" command to set and get local class of device
 *
 * Revision 1.17  2005/06/14 09:01:23  hobid
 * Fix - "rname btaddr" working now.
 *
 * Revision 1.16  2005/06/03 14:03:44  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.15  2005/04/15 12:31:00  beutel
 * added link key requests and more pin code stuff
 *
 */

/*
 * @file bt-cmds.c
 *
 * \date 2006/10/03 
 *
 * \author Jan Beutel <j.beutel@ieee.org>
 * 
 * bluetooth terminal commands
 */

#include <terminal/btn-terminal.h>
#include <terminal/bt-cmds.h>
#include <sys/heap.h>
#include <sys/event.h>
#include <string.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_cmds.h>
#include <sys/timer.h>

_terminal_bt_cmds_t *_terminal_bt_cmds;


void _bt_cmds_print_bt_addr(bt_addr_t addr)
{
    tprintf("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x", addr[5], addr[4], addr[3], addr[2], addr[1], addr[0]);
}

void _bt_cmds_print_inq_result(void)
{
    int i;
    tprintf("Devices: %d\n", _terminal_bt_cmds->nr_inq_dev);
    if (_terminal_bt_cmds->nr_inq_dev < 0) {
        _terminal_bt_cmds->nr_inq_dev = 0;
    } else {
        tprintf("Device         bt_addr cod        RSSI\n");
    }
    for (i = 0; i < _terminal_bt_cmds->nr_inq_dev; i++) {
        tprintf("[%d]: ", i);
        _bt_cmds_print_bt_addr(_terminal_bt_cmds->inqres[i].bdaddr);
        tprintf(" 0x%.8lx %d\n", _terminal_bt_cmds->inqres[i].cod, _terminal_bt_cmds->inqres[i].rssi);
    }
}

void _bt_cmds_print_usage(void)
{
	tprintf("bt: error usage:\n"
            " bt addr\n"
            " bt contable\n"
            " bt uartdebug <0=off, 1=on>\n"
            " bt chtimeout <handle> <time>\n"
            " bt con <inq-index> | xx:xx:xx:xx:xx:xx\n"
            " bt discon <handle>\n"
            " bt inquiry\n");
    tprintf(" bt name\n"
            " bt cod\n"
            " bt rname\n"
            " bt role <handle>\n"
            " bt roleset <handle> <my_role:M=0 S=1>\n"
            " bt features\n"
            " bt version\n");
}

void _bt_cmds_change_disc_timeout(char * arg)
{
    long res;
    int handle, time;
    if (sscanf(arg, "%u%u", &handle, &time) == 2) {
        tprintf("change disc timeout for handle %d\n", handle);
        res = bt_hci_write_link_supervision_timeout(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, handle, 0x0640 * time);   //set to 1sec
        if (res < 0)
            tprintf("chtimeout: error=%ld\n", -res);
        else
            tprintf("chtimeout changed!\n");
    } else
        _bt_cmds_print_usage();
}

void _bt_cmds_inquiry_cmd(char * arg)
{
    int time = 5;
    
    if (!strncmp(arg, "sync", 4)) {
        sscanf(arg+4, "%u", &time);
        _terminal_bt_cmds->inq_time = time;
        tprintf("Starting sync inquiry for %d sec:\n", _terminal_bt_cmds->inq_time);
        _terminal_bt_cmds->nr_inq_dev =
            bt_hci_inquiry(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, _terminal_bt_cmds->inq_time, MAX_INQ_DEV,
                           _terminal_bt_cmds->inqres);
        _bt_cmds_print_inq_result();
    } else if (!strncmp(arg, "async", 5)) {
        if (_terminal_bt_cmds->inq_active == 1)
            tprintf("Please call first 'bt inquiry result'!\n");        
        else
        {
            sscanf(arg+5, "%u", &time);
            _terminal_bt_cmds->inq_time = time;
            tprintf("Starting async inquiry!\n Use next 'bt inquiry check' and/or 'bt inquiry result'.\n");
            bt_hci_inquiry(_terminal_bt_cmds->bt_stack, &_terminal_bt_cmds->inq_respond,
                           _terminal_bt_cmds->inq_time, MAX_INQ_DEV, _terminal_bt_cmds->inqres);
            _terminal_bt_cmds->inq_active = 1;
        }
    } else if (!strncmp(arg, "check", 4)) {
        if (_terminal_bt_cmds->inq_active == 0)
            tprintf("Please call first 'bt inquiry async'!\n");
        else {
            if (_terminal_bt_cmds->inq_respond.block == SIGNALED)
                tprintf("Inquiry done!\n");
            else
                tprintf("Inquiry still running!\n");
        }
    } else if (!strncmp(arg, "result", 4)) {
        if (_terminal_bt_cmds->inq_active == 0)
            tprintf("Please call first 'bt inquiry async'!\n");
        else {
            NutEventWait(&_terminal_bt_cmds->inq_respond.block, _terminal_bt_cmds->inq_time * 1000L);
            _terminal_bt_cmds->nr_inq_dev = (char) _terminal_bt_cmds->inq_respond.response;
            tprintf("Inquiry done!\n");
            _bt_cmds_print_inq_result();
            _terminal_bt_cmds->inq_active = 0;
        }
    } else {
        tprintf("inquiry: error: usage:\n"
                " inquiry sync [time in sec]\n"
                " inquiry async [time in sec]\n"
                " inquiry result\n"
                " inquiry check\n");
    }
}

void _bt_cmds_rname_cmd(char * arg)
{
    bt_addr_t addr;
    int index = -1;
    int handle = -1;
    long res;
    char _bt_cmds_name[30];
    if ((sscanf
         (arg, "%2x:%2x:%2x:%2x:%2x:%2x", &_terminal_bt_cmds->bt_addr_buffer[5], &_terminal_bt_cmds->bt_addr_buffer[4],
          &_terminal_bt_cmds->bt_addr_buffer[3], &_terminal_bt_cmds->bt_addr_buffer[2], &_terminal_bt_cmds->bt_addr_buffer[1],
          &_terminal_bt_cmds->bt_addr_buffer[0]) == 6) || (sscanf(arg, "h%u", &handle) == 1) || (sscanf(arg, "%u", &index) == 1)) {
        //sync con call
        if (index >= _terminal_bt_cmds->nr_inq_dev) {
            tprintf("rname: error: dev index out of bounds\n");
            _bt_cmds_print_inq_result();
            return;
        }
        if (index > -1) {       //call with addr in inq_result _terminal_bt_cmds->inqres[index].bdaddr
            tprintf("getting rname of ");
            _bt_cmds_print_bt_addr(_terminal_bt_cmds->inqres[index].bdaddr);
            tprintf("\n");
            res =
                bt_hci_remote_name_request(_terminal_bt_cmds->bt_stack, _terminal_bt_cmds->inqres[index].bdaddr,
                                           _terminal_bt_cmds->inqres[index].clock_offset,
                                           _terminal_bt_cmds->inqres[index].page_scan_rep_mode, _bt_cmds_name,
                                           sizeof(_bt_cmds_name));
        } else {                //call with addr or handle
            if (handle > -1) {  //with handle
                //get addr of this connection
                if (bt_hci_get_remote_bt_addr(_terminal_bt_cmds->bt_stack, (bt_hci_con_handle_t) handle, addr) == BT_ERR_NO_CON) {
                    tprintf("rname: error: no con with handle %d\n", handle);
                    return;
                }
            } else {            //call with addr
                for (index = 0; index < BD_ADDR_LEN; index++)
                    addr[index] = (u_char) _terminal_bt_cmds->bt_addr_buffer[index];
            }
            tprintf("getting rname of ");
            _bt_cmds_print_bt_addr(addr);
            tprintf("\n");
            res =
                bt_hci_remote_name_request(_terminal_bt_cmds->bt_stack, addr, 0, 0,
                                           _bt_cmds_name, sizeof(_bt_cmds_name));
        }
        if (res < 0) {          //error
            tprintf("rname: error: %.2x!\n", -res);
        } else {
            tprintf("remote name:'");
            DEBUGL(_bt_cmds_name, res);
            tprintf("'\n");
        }
    } else {
        tprintf("rname: error: usage:\n"
                " rname xx:xx:xx:xx:xx:xx\n"
                " rname <inq-index>\n"
                " rname h<handle>\n");
    }
}

void _bt_cmds_con_cmd(char * arg)
{
    bt_addr_t addr;
    int index = -1;
    long res;
    if ((sscanf
         (arg, "%2x:%2x:%2x:%2x:%2x:%2x", &_terminal_bt_cmds->bt_addr_buffer[5], &_terminal_bt_cmds->bt_addr_buffer[4],
          &_terminal_bt_cmds->bt_addr_buffer[3], &_terminal_bt_cmds->bt_addr_buffer[2], &_terminal_bt_cmds->bt_addr_buffer[1],
          &_terminal_bt_cmds->bt_addr_buffer[0]) == 6) || (sscanf(arg, "%u", &index) == 1)) {
        //sync con call

        if (index >= _terminal_bt_cmds->nr_inq_dev) {
            tprintf("con: error: dev index out of bounds\n");
            _bt_cmds_print_inq_result();
            return;
        }
        tprintf("open con to ");
        if (index > -1) {       //call with addr in inq_result _terminal_bt_cmds->inqres[index].bdaddr
            _bt_cmds_print_bt_addr(_terminal_bt_cmds->inqres[index].bdaddr);
            tprintf("\n");
            res =
                bt_hci_create_connection(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, _terminal_bt_cmds->inqres[index].bdaddr,
                                         BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DH1 | BT_HCI_PACKET_TYPE_DM3,
                                         _terminal_bt_cmds->inqres[index].page_scan_rep_mode,
                                         _terminal_bt_cmds->inqres[index].clock_offset, BT_HCI_ROLE_SWITCH_CHANGE);
        } else {                //call with addr
            for (index = 0; index < BD_ADDR_LEN; index++)
                addr[index] = (u_char) _terminal_bt_cmds->bt_addr_buffer[index];
            _bt_cmds_print_bt_addr(addr);
            tprintf("\n");
            res =
                bt_hci_create_connection(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, addr,
                                         BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DH1 | BT_HCI_PACKET_TYPE_DM3, 0, 0,
                                         BT_HCI_ROLE_SWITCH_CHANGE);
        }
        if (res < 0) {          //error
            tprintf("con: error: (%lx)\n", -res);
        } else {
            tprintf("new con! handle %ld\n", res);
        }
    } else _bt_cmds_print_usage();
}

void _bt_cmds_discon_cmd(char * arg)
{
    int handle;
    bt_addr_t addr;
    if (sscanf(arg, "%u", &handle) == 1) {
        //disconnect handle
        //check if connection is open
        if (bt_hci_is_con_open(_terminal_bt_cmds->bt_stack, handle)) {
            tprintf("discon: error: no con with handle %d\n", handle);
        } else {
            if (bt_hci_get_remote_bt_addr(_terminal_bt_cmds->bt_stack, handle, addr)) {
                tprintf("discon: error: cannot get bt_addr of handle %d\n", handle);
            } else {            //disconnect
                tprintf("discon connection to ");
                _bt_cmds_print_bt_addr(addr);
                tprintf("\n");
                if (bt_hci_disconnect(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, handle, BT_HCI_DISCONNECT_USER_ENDED))
                    tprintf("discon: error: cannot disconnect connection with handle %d\n", handle);
                else
                    tprintf("disconnected!\n");
            }
        }
    } else _bt_cmds_print_usage();
}

void _bt_cmds_roleset_cmd(char * arg)
{
    int handle, role;
    long res;
    if (sscanf(arg, "%u%u", &handle, &role) == 2) {
        res = bt_hci_role_set(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, handle, role);
        if (res < 0)
            tprintf("ERROR role change: error code=%ld\n", -res);
        else
        {
            tprintf("roleset handle %d: my role is ", handle);
            res = bt_hci_local_role_discovery(_terminal_bt_cmds->bt_stack, handle);
            if (res == BT_HCI_MY_ROLE_MASTER)
                tprintf("MASTER\n");
            else
                tprintf("SLAVE\n");            
        }
    } else {
        tprintf("roleset: error: usage:\n"
                " roleset <handle> <my_role:M=0 S=1>\n");
    }
}

void _bt_cmds_get_role_cmd(char * arg)
{
    int handle;
    long res;
    if (sscanf(arg, "%u", &handle) == 1) {
        tprintf("my role to con with handle %d is ", handle);
        res = bt_hci_local_role_discovery(_terminal_bt_cmds->bt_stack, handle);
        if (res == BT_HCI_MY_ROLE_MASTER)
            tprintf("MASTER\n");
        else
            tprintf("SLAVE\n");
    } else _bt_cmds_print_usage();
}

void _bt_cmds_debug_uart(char * arg)
{
    int state;
    if (sscanf(arg, "%u", &state) == 1) {
        _bt_hci_debug_uart = state;
    } else _bt_cmds_print_usage();
}

void _bt_cmds_con_cmdtable(void)
{
	struct btstack* stack = _terminal_bt_cmds->bt_stack;
    u_char i;
    
    tprintf("\nHdl Mhdl Addr              State Role Mode\n");
    
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        tprintf("%3d", stack->connection[i].app_con_handle);
        tprintf("% 4d ", stack->connection[i].module_con_handle);
        _bt_cmds_print_bt_addr(stack->connection[i].bdaddr);
        tprintf(" %5d ", stack->connection[i].state);
        printf("%4d", stack->connection[i].role);
        switch (stack->connection[i].mode) {
            case BT_HCI_CONN_MODE_ACTIVE:
                tprintf(" active");
                break;
            case BT_HCI_CONN_MODE_HOLD:
                tprintf(" hold");
                break;
            case BT_HCI_CONN_MODE_SNIFF:
                tprintf(" sniff");
                break;
            case BT_HCI_CONN_MODE_PARK:
                tprintf(" park");
                break;
            default:
                tprintf(" invalid");
        }
        tprintf("\n");
    }
}

// Read or write local name of device
void _bt_cmds_name_cmd(char * arg)
{
    u_char _bt_cmds_name[30];
    if (!strncmp(arg, "set", 3)) {
        //name starts at arg+4 till \0 ending
        if (bt_hci_write_local_name(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, (u_char*)(arg + 4)))
            tprintf("ERROR writing local name!\n");
        else
            tprintf("Local name set!\n");
    } else if (!strncmp(arg, "get", 3)) {
        //get name
        if (bt_hci_read_local_name(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, _bt_cmds_name, sizeof(_bt_cmds_name)))
            tprintf("ERROR asking local name!\n");
        else
            tprintf("Local name: '%s'\n", _bt_cmds_name);
    } else {
        tprintf("name: error: usage:\n"
                " name set <name>\n"
                " name get\n");
    }
}

// Read or write local class of device
void _bt_cmds_cod_cmd(char* arg)
{
	u_long cod;
	if (!strncmp(arg, "set", 3)) {
		// read new cod value
		if (sscanf(arg+4, "%lu", &cod) == 1) {
			if (bt_hci_write_local_cod(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, cod))
				tprintf("ERROR writing local COD!\n");
			else
				tprintf("Local COD set!\n");
		}
		else tprintf("ERROR writing local COD: Illegal value (%lu).\n");
	}
	else if (!strncmp(arg, "get", 3)) {
		// read cod
		cod = bt_hci_read_local_cod(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC);
		if (cod < 0)
			tprintf("ERROR reading local COD!\n");
		else
			tprintf("Local COD: 0x%.8lx\n", cod);
	}
	else
		tprintf("cod: error: usage:\n"
                " cod set <value>\n"
				" cod get\n");
}

// Read local address of device
void _bt_cmds_addr_cmd(void)
{
    tprintf("Local bt_addr: ");
    _bt_cmds_print_bt_addr(_terminal_bt_cmds->bt_stack->bt_addr);
    tprintf("\n");
}

// Read local version
void _bt_cmds_version_cmd(void)
{
    u_long retval;
    struct bt_hci_local_version_result version;

    retval = bt_hci_read_local_version_information(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, &version);
    tprintf("Local HCI version info: %X %.4X %X %.4X %.4X\n", version.hciversion,
           version.hcirevision, version.lmpversion, version.manufacturername, version.lmpsubversion);
}

// Read local LMP supported features
void _bt_cmds_features_cmd(void)
{
    u_long retval;
    u_char features[8];

    retval = bt_hci_read_local_supported_features(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC, features);
    tprintf("Local LMP supported features: %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X\n",
           features[0], features[1], features[2], features[3], features[4], features[5], features[6], features[7]);
}

void bt_cmds_init(struct btstack *bt_stack)
{
    //dyn alloc terminal stack
    _terminal_bt_cmds = NutHeapAllocClear(sizeof(_terminal_bt_cmds_t));
    _terminal_bt_cmds->inq_time = 5;
    _terminal_bt_cmds->bt_stack = bt_stack;
}

void _bt_cmds_bt_cmd(char* arg) {
    if (!strncmp(arg, "addr", 4)) {
        _bt_cmds_addr_cmd();
    } else if (!strncmp(arg, "contable", 8)) {
    	_bt_cmds_con_cmdtable();
    } else if (!strncmp(arg, "uartdebug", 9)) {
    	_bt_cmds_debug_uart(arg+10);
    } else if (!strncmp(arg, "chtimeout", 9)) {
        _bt_cmds_change_disc_timeout(arg+10);
    } else if (!strncmp(arg, "con", 3)) {
		_bt_cmds_con_cmd(arg+4);
    } else if (!strncmp(arg, "discon", 6)) {
    	_bt_cmds_discon_cmd(arg+7);
    } else if (!strncmp(arg, "inquiry", 7)) {
    	_bt_cmds_inquiry_cmd(arg+8);
    } else if (!strncmp(arg, "name", 4)) {
    	_bt_cmds_name_cmd(arg+5);
    } else if (!strncmp(arg, "cod", 3)) {
    	_bt_cmds_cod_cmd(arg+4);
    } else if (!strncmp(arg, "rname", 5)) {
    	_bt_cmds_rname_cmd(arg+6);
    } else if (!strncmp(arg, "roleset", 7)) {
        _bt_cmds_roleset_cmd(arg+8);
    } else if (!strncmp(arg, "role", 4)) {
    	_bt_cmds_get_role_cmd(arg+5);
    } else if (!strncmp(arg, "features", 8)) {
    	_bt_cmds_features_cmd();
    } else if (!strncmp(arg, "version", 7)) {
    	_bt_cmds_version_cmd();
    } else {
        _bt_cmds_print_usage();
    }
}

void bt_cmds_register_cmds(void)
{
    btn_terminal_register_cmd("bt", _bt_cmds_bt_cmd);
}
