/*
 * Copyright (C) 2005 Mario Strasser <mast@gmx.net>,
 *                    Swiss Federal Institute of Technology (ETH) Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id: bmac-cmds.c,v 1.2 2006/03/29 01:15:01 olereinhardt Exp $
 */

#include <string.h>
#include <terminal/btn-terminal.h>
#include <sys/heap.h>
#include <sys/timer.h>
#include <cc/bmac.h>

void bmac_cmd_send(char *arg)
{
    unsigned int i, num, addr, msg_len;
    char msg[16];
    if (sscanf(arg, "%u%x%15s", &num, &addr, msg) != 3) {
        printf("usage: bmac-snd <#packets> <dst> <message>\n");
        return;
    }
    msg_len = strlen(msg) + 1;
    for (i = 0; i < num || !num; i++) {
        printf("bmac_send(%04x, %s) = ", addr, msg);
        int res = bmac_send(addr, (u_char*)msg, msg_len);
        printf("%d\n", res);
        NutSleep(2000);
    }
}

void bmac_cmd_receive(char *arg)
{
    unsigned int i, num, timeout;
    u_short src, dst, data_len;
    u_char *data = NutHeapAlloc(bmac_get_mtu());
    if (data == NULL || sscanf(arg, "%u%u", &num, &timeout) != 2) {
        printf("usage: bmac-rcv <#packets> <timeout>\n");
        return;
    }
    for (i = 0; i < num || !num; i++) {
        data_len = bmac_get_mtu();
        if (bmac_receive(&src, &dst, data, &data_len, timeout) == 0) {
            printf("\033[32mPacket received from %04x to %04x "
                   "(%d bytes):\033[39m %.80s\n", src, dst, data_len, data);
        } else {
            printf("No packet received.\n");
        }
    }
    NutHeapFree(data);
}

void bmac_cmds_register_cmds()
{
    btn_terminal_register_cmd("bmac-snd", bmac_cmd_send);
    btn_terminal_register_cmd("bmac-rcv", bmac_cmd_receive);
}

