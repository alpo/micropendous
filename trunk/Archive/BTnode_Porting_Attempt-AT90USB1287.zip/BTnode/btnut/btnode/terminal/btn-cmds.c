/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 * $Id: btn-cmds.c,v 1.13 2006/10/03 17:05:16 beutel Exp $
 * 
 */

/*
 * $Log: btn-cmds.c,v $
 * Revision 1.13  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 */

/*
 * @file btn-cmds.c
 *
 * \date 2006/10/03 
 *
 * \author Jan Beutel <j.beutel@ieee.org>
 * 
 * btnode specific terminal commands
 */


#include <string.h>
#include <terminal/btn-terminal.h>
#include <led/btn-led.h>
#include <hardware/btn-bat.h>



//battery cmds
void _btn_cmds_bat(char * arg)
{
    int voltage = btn_bat_measure(10);
    tprintf("Battery Voltage: %d.%02d V\n\r", voltage / 1000, (voltage % 1000) / 10);
}

//led cmd
void _btn_cmds_led_cmd(char * arg)
{
    int pattern, speed, duration, led, argument = 0;
    if (sscanf(arg, "pattern%u%u%u%u", &speed, &duration, &pattern, &argument) >= 3) {
        btn_led_add_pattern(pattern, argument, speed, duration);
    } else if (!strncmp(arg, "patternclr", 10)) {
        btn_led_clear_pattern_queue();
    } else if (sscanf(arg, "on%u", &led) == 1) {
        btn_led_set(led);
    } else if (sscanf(arg, "off%u", &led) == 1) {
        btn_led_clear(led);
    } else if (sscanf(arg, "hb%u%u%u", &argument, &led, &duration) == 3) {
        btn_led_heartbeat(argument, led, duration);
    } else {
        tprintf("usage:\n"
                " led pattern <speed:1-10> <duration> <nr:1-8> [arg]\n"
                " led patternclr\n"
                " led on <nr:0-3>\n"
                " led off <nr:0-3>\n" 
                " led hb <pause> <4-bit pattern> <duration>\n");
    }
}


void btn_cmds_register_cmds(void)
{
    btn_terminal_register_cmd("led", _btn_cmds_led_cmd);
    btn_terminal_register_cmd("bat", _btn_cmds_bat);
}
