/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file mhop_cl-cmds.c
 * 
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Terminal cmds for the multi-hop connection-less layer.
 * 
 */
#include <string.h>
#include <sys/types.h>
#include <mhop/mhop_cl_defs.h>
#include <terminal/btn-terminal.h>
#include <debug/toolbox.h>

extern _mhop_cl_stack_t _mhop_cl_stack;

void _mhop_cl_cmds_print_usage(void)
{
    tprintf("mhop usage:\n");
    tprintf("fwt\n");
}

void _mhop_cl_cmds_print_fwt(void)
{
	u_char i;
	mhop_cl_fwt_entry* fwte = _mhop_cl_stack.fwt;
	
	for (i=0; i<MHOP_CL_MAX_FWD_TABLE_SIZE; i++)
	{
		tprintf("hdl: %d, " SADDR_FMT ", seq: %d, dist: %d\n",
				fwte->handle, SADDR(fwte->src_addr), fwte->seq, fwte->distance);
		fwte++;
	}
}


void _mhop_cl_cmds_mhop_cmd(char* arg)
{
    if (!strncmp(arg, "fwt", 3)) {
    	_mhop_cl_cmds_print_fwt();
    }
    else {
    	_mhop_cl_cmds_print_usage();
    }
}


void mhop_cl_cmds_init(void)
{
	btn_terminal_register_cmd("mhop", _mhop_cl_cmds_mhop_cmd);
}
