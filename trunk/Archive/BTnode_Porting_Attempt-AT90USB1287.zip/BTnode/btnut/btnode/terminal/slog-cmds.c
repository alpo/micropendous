/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file slog-cmds.c
 * 
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Terminal cmds for sending log data.
 * 
 */
#include <terminal/slog-cmds.h>
#include <terminal/btn-terminal.h>
#include <eepromdb/btn-eepromdb.h>
#include <string.h>
#include <stdio.h>
#include <debug/logging.h>
#include <debug/toolbox.h>
#include <debug/slog.h>
#include <bt/bt_psm.h>
#include <mhop/mhop_cl.h>
#include <sys/timer.h>


struct slog_cmds_stack_s {
	FILE* terminal_uart;
	u_short reply_psm;
};

struct slog_cmds_stack_s slog_cmds_stack;

bt_acl_pkt_buf* _slog_cmds_log_reply_cb(bt_acl_pkt_buf* pkt_buf, 
                                        u_char* data, u_short data_len,
                                        u_short service_nr, void* cb_arg)
{
    log_msg_tail* log_msg = (log_msg_tail*)data;
	
    // get lock on terminal
    btn_terminal_get_writing_lock();
    // print header
    fprintf(slog_cmds_stack.terminal_uart, ":SL "SADDR_FMT" %u %u %lu %d %d\n",
               SADDR(mhop_cl_get_source_addr(pkt_buf->pkt)),
               log_msg->id,
               log_msg->len & 0xff,  // low byte: frag. nr., high byte used to indicate last message
               log_msg->t_stamp,
               log_msg->class,
               log_msg->level);
                 
    // print message data
    fputs((char *) (data + sizeof(log_msg_tail)), slog_cmds_stack.terminal_uart);
   
    if (log_msg->len < 256) {
        // if log message is not complete, print breaktag
        fputs("\x03\n", slog_cmds_stack.terminal_uart);
    } else {
        // else print endtag
        fputs("\x04\n", slog_cmds_stack.terminal_uart);
    }

    // release lock on terminal
    btn_terminal_free_writing_lock();
    return pkt_buf;
}
	
void _slog_cmds_print_usage(void)
{
    tprintf("slog: usage:\n");
    tprintf("send <addr> [<nr_msgs> [<class> [<mask]]]\n");
    tprintf("get <addr> [<id_newer> [<nr_msgs> [<class> [<mask>]]]]\n");
    tprintf("verbosity on\n");
    tprintf("verbosity <class> [<mask>]\n");
    tprintf("vtarget [<addr>]\n");
}

void _slog_cmds_verbosity_cmds(char* arg)
{
	int num;
	int retval;
	u_int class, mask;
	
	if (!strncmp(arg, "on", 2))
	{
		// register _log_cmds_print_msg() for verbosity
		retval = slog_verbosity_on();
		if (!retval)
		{
			tprintf("slog verbosity on!\n");
		}
		else
		{
			tprintf("failed: other log listener registered!\n");
		}
		return;
	}
	else
	{
    	num = sscanf(arg, "%d%x", &class, &mask);
    	if( num == 2)
    	{
        	if( class > 0 && class < LOG_MAX_CLASSES)
        	{
        		slog_verbosity_set(class, mask);
    		}
    		else
    		{
    			tprintf("err: invalid log class!\n");
    		}
    	}
    	if( num >= 1)
    	{
        	if( class > 0 && class < LOG_MAX_CLASSES)
        	{
            	tprintf("log class %i, verbosity mask set to: %.2X\n",
                        class, slog_verbosity_get(class));
            	return;
        	}
    	}
	}
	_slog_cmds_print_usage();
}

void _slog_cmds_cmd(char * arg)
{
	u_short i;
    u_int class = LOG_ALL_CLASSES, mask = LOG_MASK_ALL, nr_msgs = 0;
    bt_addr_t target;
    u_int id_newer = 0;
    int addr_buf[BD_ADDR_LEN];

    if (!strncmp(arg, "send", 4)){
    	// read target addr
    	if (sscanf(arg+5, "%2x:%2x:%2x:%2x:%2x:%2x", &addr_buf[5], &addr_buf[4], &addr_buf[3], &addr_buf[2], &addr_buf[1], &addr_buf[0]) == 6) {
    		// copy target addr
    		for (i=0; i<BD_ADDR_LEN; i++)
    			target[i] = (u_char)addr_buf[i];
    		// read filter options
        	sscanf(arg+23, "%u%u%x", &nr_msgs, &class, &mask);
        	slog_send(target, slog_cmds_stack.reply_psm, nr_msgs, class, mask);
    	}
    } else if (!strncmp(arg, "get", 3)) {
        if (sscanf(arg+4, "%2x:%2x:%2x:%2x:%2x:%2x", &addr_buf[5], &addr_buf[4], &addr_buf[3], &addr_buf[2], &addr_buf[1], &addr_buf[0]) == 6) {
            for (i=0; i<BD_ADDR_LEN; i++)
                target[i] = (u_char)addr_buf[i];
            // read filter options
            sscanf(arg+22, "%u%u%u%x", &id_newer, &nr_msgs, &class, &mask);
            slog_send_messages(target, slog_cmds_stack.reply_psm, id_newer, nr_msgs);
        }
    } else if (!strncmp(arg, "vtarget", 7)) {
    	// read target addr & filter options
    	if (sscanf(arg+8, "%2x:%2x:%2x:%2x:%2x:%2x", &addr_buf[5], &addr_buf[4], &addr_buf[3], &addr_buf[2], &addr_buf[1], &addr_buf[0]) == 6) {
    		// copy target addr
    		for (i=0; i<BD_ADDR_LEN; i++)
    			target[i] = (u_char)addr_buf[i];
    		// set verbose target
        	slog_verbose_target_set(target, slog_cmds_stack.reply_psm);
    	}
    	// print out target
    	tprintf("slog target set to: " ADDR_FMT "\n", ADDR(slog_verbose_target_get()));
    } else if (!strncmp(arg, "verbosity", 9)) {
    	_slog_cmds_verbosity_cmds(arg + 10);
    } else {
    	_slog_cmds_print_usage();
    }
}

void slog_cmds_init(FILE* terminal_uart, bt_psm_t* psmux, u_short log_reply_psm)
{
	long retval;
	
	// store pointer to terminal uart & rcv psm
	slog_cmds_stack.reply_psm = log_reply_psm;
	slog_cmds_stack.terminal_uart = terminal_uart;
	
	// register reply callback at psmux
	retval = bt_psm_service_register(psmux, log_reply_psm, _slog_cmds_log_reply_cb, NULL);
	//printf("done. retval: %li\n", retval);
	btn_terminal_register_cmd("slog", _slog_cmds_cmd);
}
