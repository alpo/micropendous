/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/*
 * cmds for checking the state of the point-to-point protocol layer.
 */
#include <string.h>
#include <terminal/btn-terminal.h>
#include <sys/thread.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <utils/fifo_queue.h>
#include <debug/toolbox.h>


typedef struct _bt_psm_service_s {
	u_short psm;					///< Protocol/Service Multiplexor value
	u_short service_nr;				///< Service number uniquely defining a registered service
	BT_PSM_DATA_CB;					///< Data Reception Callback
	void* cb_arg;					///< Data Reception Callback Argument
	bt_acl_pkt_buf** free_bufs;		///< Available free buffers (opt.)
} _bt_psm_service_t;


struct bt_psm_s {
	struct btstack* bt_stack;		///< Pointer to the bt-stack to use
	_bt_psm_service_t* services;	///< Pointer to the registered services
	u_short nr_services;			///< Maximal nr of services
	bt_acl_pkt_buf* free_bufs;		///< Pointer to the default message buffers
	u_short nr_free_bufs;			///< Number of default message buffers
	bt_acl_pkt_fifo* msg_que;			///< Message delivery fifo queue
	HANDLE msg_avail;
};

bt_psm_t* bt_psm_cmds_psmux;
char _bt_psm_cmds_str_buf[100];

void _bt_psm_cmds_print_usage(void)
{
	tprintf("psm: error: usage: services\n"
	        "                   chctxt <service_nr> <td_size>\n"
	        "                   clear <service_nr>\n");
}

void _bt_psm_cmds_show_services_cmd(void)
{
	int i;
	u_short count;
	_bt_psm_service_t* service;
	bt_acl_pkt_buf* buf_p = NULL;
	
	// first, print delivery queue
	tprintf("msg que: ");
	buf_p = bt_acl_pkt_fifo_top(bt_psm_cmds_psmux->msg_que);
	while (buf_p)
	{
		tprintf("%p, ", buf_p);
		buf_p = buf_p->next;
	}
	
	// next, print registered services & their buffers
	tprintf("\nServices:\n");
    for (i=0; i<bt_psm_cmds_psmux->nr_services; i++) {
    	// get pointer to service
    	service = &bt_psm_cmds_psmux->services[i];
        if (service->psm) {
        	tprintf("service [%d]: psm: 0x%.4x, cb: %p bufs:", i, service->psm, service->data_cb);
	        // print out buffers
			if (service->free_bufs)
			{
				tprintf("\n\t");
				buf_p = *(service->free_bufs);
				count = 0;
				while (buf_p) {
					tprintf("%p, ", buf_p);
					buf_p = buf_p->next;
					count++;
				}
				tprintf("\n\tfree: %d\n", count);
			}
			else
			{
				tprintf(" NULL\n");
			}
        }
    }
}

void _bt_psm_cmds_clear_service_cmd(char* arg) {
	short res;
	int service_nr;
	// parse user input
	if (sscanf(arg, "%u", &service_nr) == 1) {
		// close port
		res = bt_psm_service_clear(bt_psm_cmds_psmux, service_nr);
		if (res == BT_PSM_ERR_INVALID_SERVICE_NR)
			tprintf("error: invalid service nr (%d)!\n", service_nr);
		else
			tprintf("service with nr %d cleared.\n", service_nr);
	}
	else _bt_psm_cmds_print_usage();
}

void _bt_psm_cmds_add_buffers_cmd(char* arg)
{
	unsigned int service_nr;
	unsigned int nr_bufs;
	bt_acl_pkt_buf** bufs;
	short res;
	
	// parse input
	if (sscanf(arg, "%u%u", &service_nr, &nr_bufs) == 2)
	{
		if (nr_bufs)
		{
			// alloc pointer on heap!
			bufs = NutHeapAllocClear(sizeof(void*));
			// create buffers
			*bufs = bt_acl_pkt_queue_create(bt_psm_cmds_psmux->bt_stack, nr_bufs);
			res = bt_psm_service_set_buffers(bt_psm_cmds_psmux, service_nr, bufs);
		}
		else
		{
			res = bt_psm_service_set_buffers(bt_psm_cmds_psmux, service_nr, NULL);
			tprintf(" set buffers done: %d\n");
		}
	}
	else
	{
		_bt_psm_cmds_print_usage();
	}
}

void _bt_psm_cmds_psm_cmd(char* arg)
{
    if (!strncmp(arg, "services", 8)) {
    	_bt_psm_cmds_show_services_cmd();
    } else if (!strncmp(arg, "clear", 5)) {
    	_bt_psm_cmds_clear_service_cmd(arg + 5);
    } else if (!strncmp(arg, "addbufs", 7)) {
    	_bt_psm_cmds_add_buffers_cmd(arg + 7);
    } else {
    	_bt_psm_cmds_print_usage();
    }
}

void bt_psm_cmds_register_cmds(void)
{
    btn_terminal_register_cmd("psm", _bt_psm_cmds_psm_cmd);
}

void bt_psm_cmds_init(bt_psm_t* psmux) {
	bt_psm_cmds_psmux = psmux;
}
