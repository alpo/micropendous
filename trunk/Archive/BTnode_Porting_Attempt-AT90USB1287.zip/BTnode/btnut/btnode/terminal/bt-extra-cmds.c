/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * @file bt-extra-cmds.c
 *
 * $Log: bt-extra-cmds.c,v $
 * Revision 1.10  2007/01/16 10:28:43  yuecelm
 * add missing new line in help
 *
 * Revision 1.9  2007/01/05 16:30:54  yuecelm
 * add command "ebt power [0|1]", rename command "ebt hw_reset" to "ebt reset",
 * remove command "ebt cpm" (connection power manager)
 *
 * Revision 1.8  2006/11/08 15:09:32  yuecelm
 * cosmetic change
 *
 * Revision 1.7  2006/10/27 15:02:16  yuecelm
 * Changed signedness of strings in order to compile with avr-gcc >4.0
 *
 * Revision 1.6  2006/08/30 13:04:13  yuecelm
 * terminal use now the bt_hw_reset function
 *
 * Revision 1.5  2006/08/07 11:45:55  yuecelm
 * remove unblocked reset command, useless with event watchdog
 *
 * Revision 1.4  2006/07/07 12:53:47  yuecelm
 * add commands 'ebt ub_reset' (unblocked sending of HCI_RESET)
 * and 'ebt hw_reset' (includes hardware reset of Bluetooth module)
 *
 * Revision 1.3  2006/06/30 16:31:40  yuecelm
 * add 'ebt reset' and 'ebt console' commands
 *
 * Revision 1.2  2006/06/18 19:04:27  yuecelm
 * add command to set the inquiry/page scan, rename 'mode' to 'ebt'
 *
 * Revision 1.1  2006/04/10 15:33:25  yuecelm
 * move low power mode commands to bt-extra-cmds,
 * async. inquiry works again ('inquiry wait' is no more necessary,
 * 'inquiry result' includes waiting),
 * some cosmetic changes
 *
 *
 */

#include <string.h>
#include <bt/bt_hci_cmds.h>
#include <cm/con_power_mgr.h>
#include <terminal/btn-terminal.h>
#include <terminal/bt-cmds.h>
#include <sys/timer.h>

#include <dev/uart.h>
#include <bt/bt_hci_dispatch.h>

HCI_CON_RQST_CB = NULL;

void _bt_extra_mode_cmds_print_usage(void)
{
    tprintf("ebt error - usage:\n"
            " hold\n"
            " sniff\n"
            " park\n"
            " scan <inquiry_scan> <page_scan>\n"
//            " cpm <0=off, 1=on>\n"
            " power [0|1]\n"
            " reset\n"
#if (BT_RADIO_TYPE == ZEEVO)
            " console <string>\n"
#endif
            );
}

void _bt_extra_mode_cmds_hold_cmd(char * arg)
{
    int handle, interval;
    long res;
    
    if (sscanf(arg, "%u%u", &handle, &interval) == 2) {
        // min = max: particular interval is accepted or not        
        res = bt_hci_hold_mode(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC,
                               handle, interval, interval);
        if (res > -1)
            tprintf("hold: mode change: %d (interval %d)\n",
                    (u_short) (res & 0xff), (u_short) ((res >> 8) & 0xffff));
        else
            tprintf("ERROR mode change: error code=%ld\n", -res);
    } else
        tprintf("hold error - usage: hold <handle> <time>\n");            
}

void _bt_extra_mode_cmds_sniff_cmd(char * arg)
{
    int handle, interval, attempt, timeout;
    long res;
    int args = sscanf(arg, "%u%u%u%u", &handle, &interval, &attempt, &timeout);

    if (args == 1 || args == 4)
    {
        if (args == 1)
            res = bt_hci_exit_sniff_mode(_terminal_bt_cmds->bt_stack,
                                         BT_HCI_SYNC, handle);
        else
            // min = max: particular interval is accepted or not
            res = bt_hci_sniff_mode(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC,
                                    handle, interval, interval, attempt,
                                    timeout);
    } else {
        tprintf("sniff error - usage:\n"
                " <handle> <interval> <attempt> <timeout>\n"
                " <handle>\n");
        return;
    }

    if (res > -1)
        tprintf("sniff: mode change: %d (interval %d)\n",
                (u_short) (res & 0xff), (u_short) ((res >> 8) & 0xffff));
    else
        tprintf("ERROR mode change: error code=%ld\n", -res);
}

void _bt_extra_mode_cmds_park_cmd(char * arg)
{
    int handle, interval;
    long res;
    int args = sscanf(arg, "%u%u", &handle, &interval); 
    
    if (args == 1 || args == 2)
    {
        if (args == 1)
            res = bt_hci_exit_park_state(_terminal_bt_cmds->bt_stack,
                                         BT_HCI_SYNC, handle);
        else
            // min = max: particular interval is accepted or not
            res = bt_hci_park_state(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC,
                                    handle, interval, interval);
    } else {
        tprintf("park error - usage:\n"
                " <handle> <interval-slots>\n"
                " <handle>\n");
        return;
    }
         
    if (res > -1)
        tprintf("park: mode change: %d (interval %d)\n",
                (u_short) (res & 0xff), (u_short) ((res >> 8) & 0xffff));        
    else
        tprintf("ERROR mode change (error code=%ld).\n", -res);
}

//void _bt_extra_mode_cmds_pm_cmd(char * arg)
//{
//    int pm;
//    int args = sscanf(arg, "%u", &pm); 
//    
//    if (args == 1 && (pm == 0 || pm == 1))
//    {
//        switch (pm)
//        {
//            case (0):
//            {
//                cpm_stop();
//                break;
//            }
//            case (1):
//            {
//                cpm_start();
//                break;
//            }   
//        }
//    }
//    else
//    {
//        tprintf("cpm: error: usage:\n"
//                " cpm <0=off, 1=on>\n");
//    }
//}

void _bt_extra_mode_cmds_scan_cmd(char * arg)
{
    int inquiry_scan, page_scan;
    int args = sscanf(arg, "%u%u", &inquiry_scan, &page_scan); 
 
    
    if (args == 2 && (inquiry_scan == 0 || inquiry_scan == 1)
                  && (page_scan == 0 || page_scan == 1))
    {
        bt_hci_write_scan_enable(_terminal_bt_cmds->bt_stack, BT_HCI_SYNC,
                                 ((u_char) inquiry_scan) + 
                                     (((u_char) page_scan) << 1));
    }
    else
    {
        tprintf("scan error - usage: scan <inquiry scan: 0=off, 1=on> <page scan: 0=off, 1=on>\n");
    }
}

void _bt_extra_mode_cmds_hw_power_cmd(char * arg)
{
    if (*arg == '0') {
        con_rqst_cb = bt_hw_shutdown(_terminal_bt_cmds->bt_stack);
    } else if (*arg == '1') {
        bt_hw_startup(_terminal_bt_cmds->bt_stack, con_rqst_cb);
    } else {
        _bt_extra_mode_cmds_print_usage();
    }
}

void _bt_extra_mode_cmds_hw_reset_cmd(void)
{
    bt_hw_reset(_terminal_bt_cmds->bt_stack);
}

#if (BT_RADIO_TYPE == ZEEVO)
void _bt_extra_mode_cmds_console_cmd(char * arg)
{
    if (strlen(arg) > 0)
    {
        printf("\n");
        
        _terminal_bt_cmds->bt_stack->cmd.type = HCI_COMMAND_DATA_PACKET;

        _terminal_bt_cmds->bt_stack->cmd.payload[1] = HCI_OGF_VENDOR_COMMANDS << 2; // OGF
        _terminal_bt_cmds->bt_stack->cmd.payload[0] = 0x06; // OCF

        _terminal_bt_cmds->bt_stack->cmd.payload[2] = strlen(arg) + 1; // cmd-length
        strncpy((char*) &(_terminal_bt_cmds->bt_stack->cmd.payload[3]), arg, _terminal_bt_cmds->bt_stack->cmd.payload[2]);

        _bt_hci_send_pkt(_terminal_bt_cmds->bt_stack, (u_char *) & _terminal_bt_cmds->bt_stack->cmd);
        
        NutSleep(5000);
        printf("\n");
    }
    else
    {
       tprintf("console error - usage: ebt console <string>\n");   
    }
}
#endif

void _bt_extra_mode_cmds_bt_cmd(char* arg) {
    if (!strncmp(arg, "hold", 4)) {
        _bt_extra_mode_cmds_hold_cmd(arg+5);
    } else if (!strncmp(arg, "sniff", 5)) {
        _bt_extra_mode_cmds_sniff_cmd(arg+6);
    } else if (!strncmp(arg, "park", 4)) {
        _bt_extra_mode_cmds_park_cmd(arg+5);
//    } else if (!strncmp(arg, "cpm", 2)) {
//        _bt_extra_mode_cmds_pm_cmd(arg+3);
    } else if (!strncmp(arg, "scan", 4)) {
        _bt_extra_mode_cmds_scan_cmd(arg+5);
    } else if (!strncmp(arg, "power ", 6)) {
        _bt_extra_mode_cmds_hw_power_cmd(arg+6);
    } else if (!strncmp(arg, "reset", 5)) {
        _bt_extra_mode_cmds_hw_reset_cmd();
#if (BT_RADIO_TYPE == ZEEVO)
    } else if (!strncmp(arg, "console", 7)) {
        _bt_extra_mode_cmds_console_cmd(arg+8);
#endif
    } else {
        _bt_extra_mode_cmds_print_usage();
    }
}

void bt_extra_cmds_register_cmds(void)
{
    if (_terminal_bt_cmds->bt_stack)
    {
//        cpm_init(_terminal_bt_cmds->bt_stack, 0);
        btn_terminal_register_cmd("ebt", _bt_extra_mode_cmds_bt_cmd);
    }
}
