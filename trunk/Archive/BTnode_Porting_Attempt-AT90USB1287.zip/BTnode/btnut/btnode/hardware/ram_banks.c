
/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 * $Log: ram_banks.c,v $
 * Revision 1.8  2006/03/24 15:13:16  freckle
 * added avr-libc version test to choose correct include paths
 *
 * Revision 1.7  2006/03/23 07:22:22  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.5.2.1  2006/03/22 14:07:32  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.6  2006/03/21 15:40:23  beutel
 * changed includes for avr-libc 1.4.* compatibility
 *
 * Revision 1.5  2005/08/22 13:04:09  lwinterhalter
 * Last revision broke bootloader. Reverted changes.
 * *
 * Revision 1.3  2005/06/03 14:03:43  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.2  2004/10/08 15:13:12  freckle
 * removed .init1 section
 * added crc16 xbank functions
 *
 * Revision 1.1  2004/10/08 14:37:34  freckle
 * Added ram banks functions
 *
 * 2003. 1.10 Urs Frey <ufrey@ee.ethz.ch>
 *
 *
 * functions to write and read from additional RAM banks (addr>64kB)
 *
 */


// -------------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------------

#include <hardware/ram_banks.h>
#include <hardware/btn-hardware.h>
#include <sys/thread.h>
#include <string.h>

#include <util/crc16.h>


// -------------------------------------------------------------------------
// mem copy routines
//
// address range: 0-183551
// -------------------------------------------------------------------------


// TODO - these need to be used
void bank_cpy_01(void *to, const void *from, size_t len)
{
    //
}
void bank_cpy_02(void *to, const void *from, size_t len)
{
    //
}
void bank_cpy_03(void *to, const void *from, size_t len)
{
    //
}
void bank_cpy_10(void *to, const void *from, size_t len)
{
    //
}
void bank_cpy_20(void *to, const void *from, size_t len)
{
    //
}
void bank_cpy_30(void *to, const void *from, size_t len)
{
    //
}




u_char bankcpy_check_address(u_long address, u_short len)
{
    if (address + len > 0x2CCFFUL) {
        //printf("ERROR: address range from 0x0 to 0x2CCFF"NL);
        return 1;
    }
    return 0;
}

u_char bankcpy_get_bank(u_long address)
{
    return (u_char) (address / 0xEF00UL) + 1;
}

u_short bankcpy_get_offset(u_long address)
{
    return (u_short) (address % 0xEF00UL + 0x1100UL);
}

u_short bankcpy_get_len_remain(u_long address)
{
    return (u_short) (0xEF00UL - address % 0xEF00UL);
}

u_char cpy_to_xbank(void *buffer, u_long address, u_short len)
{

    u_char start_bank, end_bank;
#if defined(__linux__) || defined (__APPLE__)
    u_long start_offset;
#else
    u_short start_offset;
#endif
    u_short banklen;

    if (bankcpy_check_address(address, len)) {
        return 1;
    }

    start_bank = bankcpy_get_bank(address);
    end_bank = bankcpy_get_bank(address + len);

    start_offset = bankcpy_get_offset(address);

    if (start_bank == end_bank) {
        banklen = len;
    } else if (start_bank == end_bank - 1) {
        banklen = bankcpy_get_len_remain(address);
    } else {
        //printf("ERROR: cpy failed...");
        return 1;
    }

    //printf("cpy to bank %u, offset %u, len %u"NL, start_bank, start_offset, banklen);
    switch (start_bank) {
    case 1:
        bank_cpy_01((u_char *) start_offset, buffer, banklen);
        break;
    case 2:
        bank_cpy_02((u_char *) start_offset, buffer, banklen);
        break;
    case 3:
        bank_cpy_03((u_char *) start_offset, buffer, banklen);
        break;
    default:
        //printf("ERROR: invalid bank in cpy routine"NL);
        return 1;
        break;
    }

    if (start_bank == end_bank - 1) {
        //printf("cpy to bank %u, offset %u, len %u"NL, end_bank, 0x1100, len-banklen);
        switch (end_bank) {
        case 1:
            bank_cpy_01((u_char *) 0x1100, buffer + banklen, len - banklen);
            break;
        case 2:
            bank_cpy_02((u_char *) 0x1100, buffer + banklen, len - banklen);
            break;
        case 3:
            bank_cpy_03((u_char *) 0x1100, buffer + banklen, len - banklen);
            break;
        default:
            //printf("ERROR: invalid bank in cpy routine"NL);
            return 1;
            break;
        }
    }

    return 0;
}

u_char cpy_from_xbank(void *buffer, u_long address, u_short len)
{


    u_char start_bank, end_bank;
#if defined(__linux__) || defined (__APPLE__)
    u_long start_offset;
#else
    u_short start_offset;
#endif
    u_short banklen;

    if (bankcpy_check_address(address, len)) {
        return 1;
    }

    start_bank = bankcpy_get_bank(address);
    end_bank = bankcpy_get_bank(address + len);

    start_offset = bankcpy_get_offset(address);

    if (start_bank == end_bank) {
        banklen = len;
    } else if (start_bank == end_bank - 1) {
        banklen = bankcpy_get_len_remain(address);
    } else {
        //printf("ERROR: cpy failed..."NL);
        return 1;
    }

    //printf("cpy from bank %u, offset %u, len %u"NL, start_bank, start_offset, banklen);
    switch (start_bank) {
    case 1:
        bank_cpy_10(buffer, (u_char *) start_offset, banklen);
        break;
    case 2:
        bank_cpy_20(buffer, (u_char *) start_offset, banklen);
        break;
    case 3:
        bank_cpy_30(buffer, (u_char *) start_offset, banklen);
        break;
    default:
        //printf("ERROR: invalid bank in cpy routine"NL);
        return 1;
        break;
    }

    if (start_bank == end_bank - 1) {
        //printf("cpy from bank %u, offset %u, len %u"NL, end_bank, 0x1100, len-banklen);
        switch (end_bank) {
        case 1:
            bank_cpy_10(buffer + banklen, (u_char *) 0x1100, len - banklen);
            break;
        case 2:
            bank_cpy_20(buffer + banklen, (u_char *) 0x1100, len - banklen);
            break;
        case 3:
            bank_cpy_30(buffer + banklen, (u_char *) 0x1100, len - banklen);
            break;
        default:
            //printf("ERROR: invalid bank in cpy routine"NL);
            return 1;
            break;
        }
    }

    return 0;
}

/* -------------------------------------------------------------------------
*  update crc reverse, needed for unix
* ------------------------------------------------------------------------- */
#ifdef __BTN_UNIX__

#define		M16	0xA001

u_short _crc16_update(u_short crc, u_short c)
{
    u_char i;
    for (i = 0; i < 8; i++) {
        if ((crc ^ c) & 1)
            crc = (crc >> 1) ^ M16;
        else
            crc >>= 1;
        c >>= 1;
    }
    return crc;
}
#endif

/* -------------------------------------------------------------------------
* calculate xbank crc
* ------------------------------------------------------------------------- */
u_short get_xbank_crc(u_long start, u_long end)
{

#define CHECK_BUFFER_LEN 50
    u_char check_buffer[CHECK_BUFFER_LEN];
    u_long j;
    u_short i;
    u_long len;
    u_short crc16 = 0;

    //calculate crc
    for (j = start; j < end; j += CHECK_BUFFER_LEN) {
        len = MIN(end, j + CHECK_BUFFER_LEN) - j;
        cpy_from_xbank(check_buffer, j, len);
        for (i = 0; i < len; i++) {
            crc16 = _crc16_update(crc16, check_buffer[i]);
        }
    }

    return crc16;
}

u_char check_xbank_crc(u_long start, u_long end)
{
    return (get_xbank_crc(start, end + CRC_LENGTH) != 0);
}

void update_xbank_crc(u_long start, u_long end)
{

    u_char buffer[2];
    u_short crc = get_xbank_crc(start, end);

    buffer[0] = (u_char) (crc & 0xFF);
    buffer[1] = (u_char) (crc >> 8);

    cpy_to_xbank(buffer, end, 2);

}
