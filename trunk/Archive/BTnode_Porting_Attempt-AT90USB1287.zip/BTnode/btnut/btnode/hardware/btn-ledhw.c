/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/** 
 * $Log: btn-ledhw.c,v $
 * Revision 1.3  2005/06/03 14:03:43  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.2  2004/10/06 14:00:50  freckle
 * added _btn prefix to _led_set and _led_clear
 *
 * Revision 1.1  2004/10/06 13:50:49  freckle
 * moved hardware depenedant LED functions from led/btn-led.c into
 * hardware/btn-ledhw.c to access them from bootloader
 *
 * Revision 1.5  2004/09/27 13:14:03  beutel
 * added sys/atom for compiling
 *
 * Revision 1.4  2004/09/23 16:36:12  freckle
 * fixed correct latch pin for bt power
 *
 * Revision 1.3  2004/07/27 10:10:16  martinhinz
 * shorter bootup time for rev2
 *
 * Revision 1.2  2004/07/26 12:34:06  martinhinz
 * bugfix || to | and && to &
 *
 * Revision 1.1  2004/07/26 09:33:02  martinhinz
 * handling power, latch and init section
 *
 * Revision 1.8  2004/07/12 12:33:49  freckle
 * Added BTnode3 Config Latch accessor functions
 * Changed btn-led.c and btn-power.c to use the new latch accessor funcs
 *
 */

/*
 * btn_ledhw.c - low-level led functions
 *
 * 19.05.2004 Martin Hinz <btnode@hinz.ch>
 * 06.10.2004 Matthias Ringwald <mringwal@inf.ethz.ch>
 */

#include <hardware/btn-hardware.h>
#include <hardware/btn-ledhw.h>

#include <io.h>

/* -------------------------------------------------------------------------
 *
 * ------------------------------------------------------------------------- */
void _btn_led_init(void)
{
#if defined(__AVR_ATmega128__)

#if defined(HAVE_CONFIG_LATCH)
    btn_hardware_config_latch_init();
#else
    // set ddr to output
    sbi(LED_PORT_DDR, LED0);
    sbi(LED_PORT_DDR, LED1);
    sbi(LED_PORT_DDR, LED2);
    sbi(LED_PORT_DDR, LED3);
#endif

    _btn_led_clear(LED0);
    _btn_led_clear(LED1);
    _btn_led_clear(LED2);
    _btn_led_clear(LED3);

#endif
}

/* -------------------------------------------------------------------------
 *
 * ------------------------------------------------------------------------- */
void _btn_led_set(u_char no)
{

#if defined(__AVR_ATmega128__)

#if defined(HAVE_CONFIG_LATCH)
    if (no == 0)
        btn_hardware_config_latch_set(LED0);
    else if (no == 1)
        btn_hardware_config_latch_set(LED1);
    else if (no == 2)
        btn_hardware_config_latch_set(LED2);
    else if (no == 3)
        btn_hardware_config_latch_set(LED3);
#else
    if (no == 0)
        sbi(LED_PORT, LED0);
    else if (no == 1)
        sbi(LED_PORT, LED1);
    else if (no == 2)
        sbi(LED_PORT, LED2);
    else if (no == 3)
        sbi(LED_PORT, LED3);
#endif

#endif
}

/* -------------------------------------------------------------------------
*
* ------------------------------------------------------------------------- */

void _btn_led_clear(u_char no)
{
#if defined(__AVR_ATmega128__)

#if defined(HAVE_CONFIG_LATCH)
    if (no == 0)
        btn_hardware_config_latch_clear(LED0);
    else if (no == 1)
        btn_hardware_config_latch_clear(LED1);
    else if (no == 2)
        btn_hardware_config_latch_clear(LED2);
    else if (no == 3)
        btn_hardware_config_latch_clear(LED3);
#else
    if (no == 0)
        cbi(LED_PORT, LED0);
    else if (no == 1)
        cbi(LED_PORT, LED1);
    else if (no == 2)
        cbi(LED_PORT, LED2);
    else if (no == 3)
        cbi(LED_PORT, LED3);
#endif

#endif
}
