/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/** 
 * $Log: btn-hardware.c,v $
 * Revision 1.21  2007/01/05 16:18:37  yuecelm
 * add btn_hardware_bt_power_[on|off] to power down temporary BT module
 *
 * Revision 1.20  2006/04/05 05:51:03  dyerm
 * set IDLE as default sleep mode (when nut runs idle thread)
 *
 * Revision 1.19  2006/03/28 23:26:10  olereinhardt
 * Changed some string variables in signedness in order to make it compiling with avr-gcc 4.0.2
 *
 * Revision 1.18  2006/03/23 07:22:22  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.16.4.1  2006/02/02 08:10:27  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.17  2006/01/12 14:21:44  beutel
 * added cc1000 power on/off to btnut
 * added lpm command to bttest (unfinished)
 *
 * Revision 1.16  2004/11/09 15:19:48  freckle
 * added btn_hardware_io_power to switch VCC_IO
 *
 * Revision 1.15  2004/11/08 11:15:03  freckle
 * in btn_hardware_bt_on: enable tristated lines again
 * cleaned up #ifdefs
 *
 * Revision 1.14  2004/11/08 11:09:16  freckle
 * _tristate_bt functions are only for btnode3
 * in tristate_off_bt set TX as output and as '1'
 *
 * Revision 1.13  2004/11/02 13:42:07  dyerm
 * tuned delays
 *
 * Revision 1.12  2004/11/02 09:28:47  dyerm
 * Faster bootup, EEPROM storage fixed.
 *
 * Revision 1.11  2004/10/20 16:48:46  olereinhardt
 * fixed compile bug in btn_hardware_init (no sbi in unix emulation)
 *
 * Revision 1.10  2004/10/20 13:27:40  freckle
 * Enabled RX Pull-Up of APP_UART in btn_hardware_init()
 *
 * Revision 1.9  2004/10/05 17:18:59  beutel
 * first try bt-cmd working on btnode3
 *
 * Revision 1.8  2004/10/05 16:21:04  freckle
 * moved config_latch functions to seperate files (for bootloader linking)
 *
 * Revision 1.7  2004/10/05 15:56:03  olereinhardt
 * Fixed compile bug for unix emulation
 *
 * Revision 1.6  2004/10/05 12:41:16  beutel
 * first try at correct btnode rev3 init routines
 *
 * Revision 1.5  2004/09/27 13:14:03  beutel
 * added sys/atom for compiling
 *
 * Revision 1.4  2004/09/23 16:36:12  freckle
 * fixed correct latch pin for bt power
 *
 * Revision 1.3  2004/07/27 10:10:16  martinhinz
 * shorter bootup time for rev2
 *
 * Revision 1.2  2004/07/26 12:34:06  martinhinz
 * bugfix || to | and && to &
 *
 * Revision 1.1  2004/07/26 09:33:02  martinhinz
 * handling power, latch and init section
 *
 * Revision 1.8  2004/07/12 12:33:49  freckle
 * Added BTnode3 Config Latch accessor functions
 * Changed btn-led.c and btn-power.c to use the new latch accessor funcs
 *
 */
 
/*
 * btn_hardware.c - device drivers for hardware management, SRAM and Config_Latch
 *
 * 2001.01.03 Lukas Karrer <lkarrer@trash.net>
 * 2002.05.23 Oliver Kasten <oliver.kasten@inf.ethz.ch>
 * 19.05.2004 Martin Hinz <btnode@hinz.ch>
 * 10.07.2004 Matthias Ringwald <mringwal@inf.ethz.ch>
 */
 
#include <hardware/btn-hardware.h>

// nut/os h files
#include <sys/timer.h>
#include <sys/atom.h>
#ifdef __AVR__
#include <avr/sleep.h>
#endif
#include <sys/thread.h>

#if defined(__AVR_ATmega128__)

void my_init(void) __attribute__ ((naked))
    __attribute__ ((section(".init0")));

void my_init(void)
{

    // enable xsram at the very beginning to be able to place .bss and
    // .data there
    sbi(MCUCR, SRE);
    // bus-keeper
    sbi(XMCRB, XMBK);

    // set address lines for external memory
    // => address lines are output, select bank 0
#if defined(RAM_CTR_A_DDR) || defined (RAM_CTR_B_PIN)
    sbi(RAM_CTR_A_DDR, RAM_CTR_A_PIN);
    sbi(RAM_CTR_B_DDR, RAM_CTR_B_PIN);
    cbi(RAM_CTR_A_PORT, RAM_CTR_A_PIN);
    cbi(RAM_CTR_B_PORT, RAM_CTR_B_PIN);
#endif
}

#endif

/*
 * this init has to be called for the my_init section being initialized
 */
void btn_hardware_init(void) {

#if !defined(__BTN_UNIX__)

    // enable rx pull-up for APP_UART
    // => do not receive random noise, if not connected

#if (APP_UART_NR == 0)
    sbi( PORTE, 0);
#else
    sbi( PORTD, 2);
#endif

    // set BT_UART's tx default to 1
    // => do not confuse BT module when doing baud rate change
    // TODO: this is a temporary fix to circumvent problematic behavior of nut/os
    //       ater nut/os is fixed, this can be removed. MR 2004-11-08
    
#if (BT_UART_NR == 0)
    sbi ( PORTE, 1);
    sbi ( DDRE, 1);
#else
    sbi ( PORTD, 3);
    sbi ( DDRD, 3);
#endif
    
#ifdef __AVR__
    NutThreadSetSleepMode(SLEEP_MODE_IDLE);    
#endif

#endif     
}
// -------------------------------------------------------------------------
// 
// -------------------------------------------------------------------------
void btn_hardware_bt_radio_power(u_char on)
{
#if defined(__BTNODE2__)
    sbi(BT_RADIO_ON_DDR, BT_RADIO_ON_PIN);     // bluetooth-ON

    // switch ON the bluetooth module: pull ON pin on the bluetooth
    // module to high. the pin is connected to PIN 0 of port F of the
    // avr128
    if (on) {
        sbi(BT_RADIO_ON_PORT, BT_RADIO_ON_PIN);
    } else {
        cbi(BT_RADIO_ON_PORT, BT_RADIO_ON_PIN);
    }
#endif

#if defined(__BTNODE3__)
    // not available on BTNODE3/zv4002
#endif
}

// -------------------------------------------------------------------------
// 
// -------------------------------------------------------------------------
void btn_hardware_bt_reset(u_char reset)
{
#if defined(__BTNODE2__)
    sbi(BT_RESET_DDR, BT_RESET_PIN);

    if (reset) {
        cbi(BT_RESET_PORT, BT_RESET_PIN);
    } else {
        sbi(BT_RESET_PORT, BT_RESET_PIN);
    }
#endif

#if defined(__BTNODE3__)
    if (reset)
        btn_hardware_config_latch_clear( BT_RESET_PIN );
    else
        btn_hardware_config_latch_set( BT_RESET_PIN );
#endif

}

// jtag enable/disable--------------------------------------------

void _jtag_off(char *arg){
#if defined(__BTNODE2__) || defined(__BTNODE3__) 
	u_char value = MCUCSR | BV(7);	// JTD - JTAG Disable Bit
	// ... the application software must write the desired value 
	// two times within four cycles
	MCUCSR = value;
	MCUCSR = value;
#endif
}

void _jtag_on(char *arg){
#if defined(__BTNODE2__) || defined(__BTNODE3__)
        u_char value = MCUCSR & ~BV(7);	// JTD - JTAG Disable Bit
	// ... the application software must write the desired value 
	// two times within four cycles
	MCUCSR = value;
	MCUCSR = value;
#endif
}

//bluetooth functions--------------------------------------------

/** 
 * set all bt module lines to tri-state on btnode3
 */
void _tristate_bt(char *arg){
#if defined(__BTNODE3__)
    // disabling TXEN for BT uart nr 1 in UCSR1B
	cbi ( UCSR1B, TXEN);
	// set TX  as input
	cbi ( DDRD, 3);
	cbi ( PORTD, 3);
	// set RX  as input
	cbi ( DDRD, 2);
	cbi ( PORTD, 2);
	// set RTS as input
	cbi ( DDRD, 4);	//
	cbi ( PORTD, 4);
	// set CTS as input
	cbi ( DDRE, 5);	//
	cbi ( PORTE, 5);
	// set AVR_TDO as input
	cbi ( DDRF, 6);
	cbi ( PORTF, 6);
	// set TMS as input
	cbi ( DDRF, 5);
	cbi ( PORTF, 5);
	// set TCK as input
	cbi ( DDRF, 4);
	cbi ( PORTF, 4);
#endif
}

/** 
 * re-activate tri-stated bt module lines on btnode3
 */
void _tristate_off_bt(char *arg){
#if defined(__BTNODE3__)
    // enabling TXEN for BT uart nr 1 in UCSR1B
    sbi ( UCSR1B, TXEN);
    // set TX  as output
    sbi ( DDRD, 3);
    // set TX as '1'
    sbi ( PORTD, 3);
    // set RX  as input. 
    cbi ( DDRD, 2);
    // set RX up pull ups
    sbi ( PORTD, 2);
    // set RTS as output
    sbi ( DDRD, 4);	//
    // set CTS as input. set up pull ups/downs?
    cbi ( DDRE, 5);	//
#endif
}

// -------------------------------------------------------------------------
// 
// -------------------------------------------------------------------------
void btn_hardware_bt_power(u_char on)
{
#if defined(__BTNODE2__)
    sbi(BT_POWER_ON_DDR, BT_POWER_ON_PIN);                 // bluetooth-switchable power supply

    // switch on the switchable power supply
    if (on) {
        sbi(BT_POWER_ON_PORT, BT_POWER_ON_PIN);
    } else {
        cbi(BT_POWER_ON_PORT, BT_POWER_ON_PIN);
    }
#endif

#if defined(__BTNODE3__)
    if (on)
        btn_hardware_config_latch_set  ( BT_POWER_ON_PIN );
    else
        btn_hardware_config_latch_clear( BT_POWER_ON_PIN );
        _tristate_bt("");
        _jtag_off("");
#endif
}

void btn_hardware_bt_power_off(void)
{
#if defined(__BTNODE3__)
    // tri-state
    _tristate_bt("");
    _jtag_off("");
    // vcc and reset to GND
    btn_hardware_bt_power(0);
    btn_hardware_bt_reset(1);
#endif
}

void btn_hardware_bt_power_on(void)
{
#if defined(__BTNODE3__)
    btn_hardware_bt_power(1);
    NutSleep(500);
    btn_hardware_bt_reset(0);
    _jtag_on("");
    _tristate_off_bt("");
    NutSleep(2000);
#endif
}

void btn_hardware_bt_on(void)
{
#if defined(__BTNODE2__)
    // switch on bt module
    btn_hardware_bt_power(1);
    btn_hardware_bt_radio_power(1);
    // hard-reset the module
    btn_hardware_bt_reset(1);
    NutDelay(10);
    btn_hardware_bt_reset(0);
    NutSleep(1500L);
#endif

#if defined(__BTNODE3__)
    btn_hardware_bt_power_off();
    NutSleep(1000);
    btn_hardware_bt_power_on();
#endif
}

// -------------------------------------------------------------------------
// 
// -------------------------------------------------------------------------
void btn_hardware_cc1000_power(u_char on)
{
#if defined(__BTNODE3__)
    if (on)
        btn_hardware_config_latch_set  ( CC1000_POWER_ON_PIN );
    else
        btn_hardware_config_latch_clear( CC1000_POWER_ON_PIN );
#endif
}

// -------------------------------------------------------------------------
// 
// -------------------------------------------------------------------------
void btn_hardware_io_power(u_char on)
{
#if defined(__BTNODE3__)
    if (on)
        btn_hardware_config_latch_set  ( IO_POWER_ON_PIN );
    else
        btn_hardware_config_latch_clear( IO_POWER_ON_PIN );
#endif
}


