/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/** 
 * $Log: btn-latch.c,v $
 * Revision 1.5  2006/03/28 09:58:34  freckle
 * removed code for dead patched rev 3.10 devices
 * allowed btn_hardware_config_init to be called multiple times
 *
 * Revision 1.4  2005/06/03 14:03:43  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.3  2004/10/08 14:31:25  freckle
 * latch prototypes not necessary, if no config_latch
 *
 * Revision 1.2  2004/10/06 13:14:13  freckle
 * split config latch code into seperate sram and patched versions
 *
 * Revision 1.1  2004/10/05 16:13:54  freckle
 * moved config_latch functions to seperate files (for bootloader linking)
 *
 *
 */

/*
 * btn-latch.c - device drivers for Config_Latch
 *
 * 2004/10/05 Matthias Ringwald <mringwal@inf.ethz.ch>
 */

#include <hardware/btn-hardware.h>
#include <sys/atom.h>

#ifdef HAVE_CONFIG_LATCH

// prototypes
void _btn_latch_write_sram(u_char);
void _btn_hardware_config_latch_write(u_char);

// -------------------------------------------------------------------------
// initial value for config latch set on start-up
// -------------------------------------------------------------------------

u_char _btn_hardware_config_latch_value = CONFIG_LATCH_INIT_VALUE;

// -------------------------------------------------------------------------
// init latch
// -------------------------------------------------------------------------
void btn_hardware_config_latch_init()
{
    // config latch_select as output pin
    sbi(CONFIG_LATCH_SELECT_DDR, CONFIG_LATCH_SELECT_PIN);
    
    // write initial value
    _btn_hardware_config_latch_write(_btn_hardware_config_latch_value);
}

// -------------------------------------------------------------------------
// write latch
// -------------------------------------------------------------------------
void _btn_hardware_config_latch_write(u_char value)
{
    volatile u_char *test_byte_pointer;
    u_char dummy;
    
    // no interrupts allowed here
    NutEnterCritical();
    
    // put value on address bus
    // read address
    test_byte_pointer = (u_char *) (((u_short) value) << 8);
    dummy = *test_byte_pointer;
    // play with the compiler, let it think, we really use that value
    dummy++;
    dummy--;
    // write, too
    *test_byte_pointer = dummy;
    
    // set bit 
    sbi(CONFIG_LATCH_SELECT_PORT, CONFIG_LATCH_SELECT_PIN);
    // wait a bit
    asm volatile ("nop"::);
    // clear bit
    cbi(CONFIG_LATCH_SELECT_PORT, CONFIG_LATCH_SELECT_PIN);
    
    NutExitCritical();
    
    // store new value
    _btn_hardware_config_latch_value = value;
}

// -------------------------------------------------------------------------
// set latch bit
// -------------------------------------------------------------------------
void btn_hardware_config_latch_set(u_char bit)
{
    u_char value = _btn_hardware_config_latch_value | (1 << bit);
    _btn_hardware_config_latch_write(value);
}

// -------------------------------------------------------------------------
// clear latch bit
// -------------------------------------------------------------------------
void btn_hardware_config_latch_clear(u_char bit)
{
    u_char value = _btn_hardware_config_latch_value & ~(1 << bit);
    _btn_hardware_config_latch_write(value);
}

#endif
