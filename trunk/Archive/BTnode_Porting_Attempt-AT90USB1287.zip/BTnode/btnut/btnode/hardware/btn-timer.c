/*
 * Copyright (C) 2005 Mario Strasser <mast@gmx.net>,
 *                    Swiss Federal Institute of Technology (ETH) Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * $Id: btn-timer.c,v 1.1 2005/08/15 10:01:44 mast2 Exp $
 */

#include <dev/irqreg.h>
#include <hardware/btn-timer.h>

#if !defined(__BTN_UNIX__)

static u_short interval;
static u_short duration;
static u_short remaining;

static void (*timer_callback)(void *);
static void *callback_arg;

static void timer_handler(void *arg)
{
    if (remaining <= interval) {
        timer_callback(callback_arg);
        remaining = duration - (interval - remaining);
    } else {
        remaining -= interval;
    }    
}

void btn_timer_start(u_long ms, void(*callback)(void *), void *arg)
{
    timer_callback = callback;
    duration = remaining = (u_short)(ms & 0xffff);
    callback_arg = arg;
    /* the timer interval is 10 ms */
    interval = 10;   
    /* disable timer interrupts. */
    cbi(TIMSK, OCIE1A);
    /* reset counter register. */
    TCNT1 = 0;
    /* set output compare register. */
    OCR1A = 36863;        
    /* set CTC mode and prescaler. */
    TCCR1A = 0;
    TCCR1B = _BV(WGM12) | _BV(CS10);
    TCCR1C = 0;
    /* clear interrupt flags. */
    cbi(TIFR, OCF1A);    
    /* enable timer compare interrupts. */
    NutRegisterIrqHandler(&sig_OUTPUT_COMPARE1A, timer_handler, 0);
    sbi(TIMSK, OCIE1A); 
}                             
                     
void btn_timer_stop(void)
{
    /* stop timer 1 */
    cbi(TIMSK, OCIE1A);        
    outb(TCCR1A, 0);
    outb(TCCR1B, 0);
    outb(TCCR1C, 0);
}

int btn_timer_is_running(void)
{
    return bit_is_set(TIMSK, OCIE1A);
}

#endif
