/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * $Log: btn-bat.c,v $
 * Revision 1.11  2006/09/23 07:22:06  freckle
 * fixed unix emulation here
 *
 * Revision 1.10  2006/09/22 15:14:50  freckle
 * use new adc2
 *
 * Revision 1.9.2.3  2006/09/22 10:20:36  freckle
 * adapted code to use new adc2
 *
 * Revision 1.9.2.2  2006/09/22 09:35:13  freckle
 * extracted adc init function
 *
 * Revision 1.9.2.1  2006/05/19 09:48:07  bosterm
 * switched to adc2 functions
 *
 * Revision 1.9  2006/03/23 07:22:22  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.7.2.1  2006/02/02 08:10:27  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.8  2006/01/12 08:14:53  ewolfey
 *       as the nut source to ADCInit() has been changed to allow for
 *       multiple executions.
 *
 * Revision 1.7  2005/08/11 07:50:18  lwinterhalter
 * Removed ADCInit()  because it must not be called multiple times. Call it once in your app instead.
 *
 * Revision 1.6  2005/07/04 11:19:30  lwinterhalter
 * Changed ADC mode to SINGLE_CONVERSION in order to mimimize ADC interrupt load.
 *
 * Revision 1.5  2005/06/27 15:03:31  hobid
 * Call ADCStopConversion() to stop getting ADC interrupts.
 *
 * Revision 1.4  2005/06/07 12:07:52  yuecelm
 * improved btn_external_power()
 *
 * Revision 1.3  2005/06/03 14:03:43  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.2  2005/01/24 10:39:37  yuecelm
 * added btn_external_power funktion
 *
 *
 */

// default number of measures
#define DEFNUMOFMEAS 10

// threshold
// this is adapted to a RMS of 6.44 mV
//#define THRESHOLDVAR 1
#define THRESHOLDTOT 50

// # of buffer for rms
#define BUFSIZEVAR 50

#include <sys/thread.h>
#include <hardware/btn-hardware.h>
#include <dev/adc2.h>

#if !defined(__BTN_UNIX__)
static u_char initialized = 0;
static u_int adc_handle;

static void initialize(void)
{
    adc_handle = adc2_init( ADC2_MODE_SINGLE_CONVERSION,
                            ADC2_INTERRUPT_DISABLE,
                            ADC2_PRESCALE_DIV64, // (!)
                            BAT_SENSE_ADC,
                            ADC2_REF_AREF );
    initialized = 1;
}
#endif
    
int btn_bat_measure(int n)
{

#if !defined(__BTN_UNIX__)

    int i;
    long average = 0;

    //if ( initialized == 0 ) 
    {
        initialize();
    }
        
    // test if n between 10 and 100
    // if not take a default value
    if (n < 10 || n > 100)
        n = DEFNUMOFMEAS;

    // read values from ADC n times
    for (i = 0; i < n; i++)
    {
        average += adc2_read( adc_handle );
        NutThreadYield();        
    }

    // calculate average in (mV)
    average = ((average * VCC_mV * BAT_DIVIDER / n) >> 10);

    return (int) average;

#else

    return 3300;                // 3.3 Volts on Unix.. :)

#endif
}

u_char btn_external_power(void)
{

#if !defined(__BTN_UNIX__)

    short i;
    u_short buffer[BUFSIZEVAR];
    long average = 0;
    long variance = 0;
    
    if ( initialized == 0 ) 
    {
        initialize();
    }

    // read values from ADC n times
    for (i = 0; i < BUFSIZEVAR; i++)
    {
        buffer[i] = adc2_read( adc_handle );
        NutThreadYield();
    }

    // calculate average
    for (i = 0; i < BUFSIZEVAR; i++)
        average += buffer[i];
    average /= BUFSIZEVAR;

    if (((average * VCC_mV * BAT_DIVIDER) >> 10) < 500)
        return 1;
    
    // calulate variance
    for (i = 0; i < BUFSIZEVAR; i++)
        variance += (average - buffer[i]) * (average - buffer[i]);
    //leave next step away to have a better quantization of threshold :)
    //variance /= BUFSIZEVAR;

    //if (variance<THRESHOLDVAR)
    if (variance < THRESHOLDTOT)
        return 1;
    else
        return 0;

#else

    return 1;                   // Enough power on Unix.. :)

#endif
}
