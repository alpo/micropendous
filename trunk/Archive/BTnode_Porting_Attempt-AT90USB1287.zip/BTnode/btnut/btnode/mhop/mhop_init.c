#include <mhop/mhop_init.h>
#include <bt/bt_defs.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_acl_defs.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <cm/con_mgr.h>
#include <mhop/mhop_cl.h>

#define CM_PSM 				0x1003

#define MHOP_PSM 			0x1005

bt_psm_t* mhop_init(struct btstack* bt_stack,
					u_short nr_services,
					u_short pkt_types,
					u_short rcv_bufs,
					u_short fwd_bufs,
					CON_MGR_INIT_FUNC,
					u_long cm_cod)
{
	bt_psm_t* psmux;
	
    // Set ACL packet types
    printf("setting acl pkt types... ");
    bt_acl_init(bt_stack, pkt_types);
    printf("done.\n");
    
    // Init protocol/service multiplexor
    printf("init protcol/service mux... ");
    psmux = bt_psm_init(bt_stack, nr_services, rcv_bufs);
    printf("done.\n");
    
    // Init connectionless l2cap stack
    printf("init connectionless l2cap... ");
    l2cap_cl_init(bt_stack, psmux);
    printf("done.\n");
    
    // Init connection manager
    printf("init connection manager... ");
    cm_init(bt_stack, psmux, CM_PSM, bt_hci_register_con_table_cb, cm_cod);
    printf("done.\n");
    
    // Init connectionless multihop protocol
    printf("init connectionless multi-hop protocol... ");
    mhop_cl_init(bt_stack,
    				psmux,
    				MHOP_PSM,
    				fwd_bufs,
    				con_mgr_register_con_table_cb);
    printf("done.\n");
    
    return psmux;
}
