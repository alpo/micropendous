#include <bt/bt_psm.h>
#include <mhop/mhop_cl.h>
#include <cm/con_mgr.h>
#include <terminal/btn-terminal.h>
#include <debug/toolbox.h>
#include <mhop/rpc.h>

u_char _mhop_con_info_proc_nr;

u_char _mhop_con_info_proc(bt_acl_pkt_buf* pkt_buf, char* query, u_char query_len, void* arg,
                              u_char* result, u_char* result_len)
{
	// get con info from connection manager
	*result_len = con_mgr_fill_con_info(result, (u_char*)query);
	return 0;
}

// to send a connection info reply using the terminal
void _mhop_con_info_parser(char* arg){
    u_char i;
    u_char query = 0;
    unsigned int addr[BD_ADDR_LEN];
    bt_addr_t destination = { 0, 0, 0, 0, 0, 0 };
    if(sscanf(arg, "%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], 
       &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
        for (i = 0; i < BD_ADDR_LEN; i++) {
            destination[i] = (u_char) addr[i];
        }
        query = 1;
    }
    rpc_send_query(_mhop_con_info_proc_nr, &query, 1, destination, 0);    
}

// processes connection info reply packets
void _mhop_con_info_reply(u_char* source_addr, u_char* result, u_char result_len, 
                            void* arg)
{
    u_char i;
    u_char* pos = result+1;
    
    // print info to the debug uart
    tprintf("\n:T %s %d\n", 
         dbg_bt_addr_to_str(source_addr), result[0]);
    for (i = 0; i < result[0]; i++) {
        tprintf(":TE %02x:%02x %d %d\n",
             pos[1], pos[0],               // neighbor address
             pos[2],                   // conn state
             (signed char)pos[3]);     // rssi
        pos += 4;
    }
}


void mhop_con_info_init(void)
{
    rpc_register_proc(&_mhop_con_info_proc_nr,
                      _mhop_con_info_proc, NULL,
                      _mhop_con_info_reply, NULL);
                      
    btn_terminal_register_cmd("coninfo", _mhop_con_info_parser);                             
}

