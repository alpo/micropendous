#include <sys/heap.h>
#include <string.h>
#include <terminal/btn-terminal.h>
#include <debug/toolbox.h>
#include <bt/bt_hci_cmds.h>
#include <cm/con_mgr.h>
#include <debug/logging.h>
#include <mhop/mhop_con_info.h>
#include <debug/log_server.h>
#include <cdist/xbankdata.h>
#include <mhop/bt_gui.h>
#include <mhop/rpc.h>
#include <mhop/rpc.h>
#include <terminal/rpc-cmds.h>

typedef struct bt_gui_stack_s {
	bt_addr_t my_addr;
	struct btstack* bt_stack;
	bt_psm_t* psmux;
	MUTEX log_process;
    rpc_stack_t* rpc;
} bt_gui_stack_t;

bt_gui_stack_t* gui_stack;


// process log data
bt_acl_pkt_buf* _bt_gui_log_data_cb(bt_acl_pkt_buf* pkt_buf,
									u_char* data,
									u_short len,
									u_short service_nr,
									void* cb_arg)
{
	u_char* source_addr;
    static u_char data_buf[115];
    u_short l;
    	
	// get bt address of the source
	source_addr = mhop_cl_get_source_addr(pkt_buf->pkt);

//    data++;
//    len--;

	NutMutexLock(&gui_stack->log_process);
    while( len) {
        l = (((u_short)data[1]) << 8) | data[0];
        memcpy( data_buf, &data[8], l-8);
        data_buf[l-8] = 0;
		tprintf("\n:DL %s %u %u %u %lu\n%s\n",
                         dbg_bt_addr_to_str(source_addr),
                         data[2],
                         data[3],
                         l-8,
                         (u_long)data[7] << 24 | (u_long)data[6] << 16 |
                             (u_long)data[5] <<  8 | data[4],
                         data_buf);
        data += l;
        len -= l;
    }
    NutMutexUnlock(&gui_stack->log_process);
	return pkt_buf;
}


void _bt_gui_cmds_print_usage(void)
{
}



void _bt_gui_addr_cmd(char* arg){
    tprintf("Local bt_addr: %s (error code=0)\n",
    dbg_bt_addr_to_str(gui_stack->my_addr));
}


void bt_gui_init(struct btstack* bt_stack,
					bt_psm_t* psmux)
{
	// dyn. allocate the gui stack
	gui_stack = NutHeapAllocClear(sizeof(bt_gui_stack_t));
	gui_stack->bt_stack = bt_stack;
	gui_stack->psmux = psmux;
	

	// get bt addr of this device
	bt_hci_get_local_bt_addr(bt_stack, gui_stack->my_addr);
		
	NutMutexInit(&gui_stack->log_process);
}

void bt_gui_register_cmds(void)
{
    btn_terminal_register_cmd("addr", _bt_gui_addr_cmd); 
}
