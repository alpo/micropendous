#include <mhop/rpc.h>
#include <debug/logging.h>

typedef struct _log_send_stack_s{
    u_char buf[LOG_LINE_SIZE+8];
    u_char is_first;           ///< first pkt to send?
    u_short offset;            ///< current pos in log record
    u_short to_send;           ///< bytes still to be sent
} _log_send_stack_t;

_log_send_stack_t* log_send_stack;

u_char _log_send_proc(u_char* query, u_char query_len, void* arg,
                      u_char* result, u_char* result_len)
{
    // TODO rewrite this function such that a log class can be defined in the
    // query and only records with the given class are sent.
    
    if(log_send_stack->is_first){
        // current pos in log 
        log_send_stack->offset = log_stack.xbank_start;
        // calculate length (with/without wrap)
        log_send_stack->to_send = log_stack.xbank_end - log_stack.xbank_start;
        if(log_stack.xbank_end < log_stack.xbank_start){
            log_send_stack->to_send += LOG_BANK_SIZE;
        }
        log_send_stack->is_first = 0;
    }
    
    // wrapped buffer
    // |          | |     |<-  len1  ->|   
    // 0        end start |         tail
    //                 offset  
    u_short len1 = log_stack.xbank_tail - log_send_stack->offset;
    
    if(log_send_stack->to_send > RPC_MAX_RESULT_LENGTH){
        // not last pkt
        if(len1 <= RPC_MAX_RESULT_LENGTH){
            // no wrap
            cpy_from_xbank(result, 
                   LOG_BANK_START+log_send_stack->offset, 
                   RPC_MAX_RESULT_LENGTH);
            log_send_stack->offset += RPC_MAX_RESULT_LENGTH;
        }
        else{// wrap
            cpy_from_xbank(result, 
                   LOG_BANK_START+log_send_stack->offset,
                   len1);
            cpy_from_xbank(result+len1, 
                   LOG_BANK_START, 
                   RPC_MAX_RESULT_LENGTH - len1);
            log_send_stack->offset = RPC_MAX_RESULT_LENGTH - len1;                   
        }
        log_send_stack->to_send -= RPC_MAX_RESULT_LENGTH;
        *result_len = RPC_MAX_RESULT_LENGTH;
        return 1;
    }
    else{
        // last pkt
        if(len1 <= log_send_stack->to_send){
            // no wrap
            cpy_from_xbank(result, 
                   LOG_BANK_START+log_send_stack->offset, 
                   log_send_stack->to_send);
        }
        else{// wrap
            cpy_from_xbank(result, 
                   LOG_BANK_START+log_send_stack->offset,
                   len1);
            cpy_from_xbank(result+len1, 
                   LOG_BANK_START, 
                   log_send_stack->to_send - len1);
        }
        *result_len = log_send_stack->to_send;
        return 0;
    }    
}

void log_send_init(void){
    log_send_stack = NutHeapAllocClear(sizeof(_log_send_stack_t));
    log_send_stack->is_first = 1;
}