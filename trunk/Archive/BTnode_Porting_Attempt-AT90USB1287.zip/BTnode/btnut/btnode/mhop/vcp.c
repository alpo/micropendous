/**
 * \file vcp.c
 * \brief Implementation of the virtual connection protocol (VCP) layer
 */

#include <bt/bt_defs.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <terminal/btn-terminal.h>
#include <led/btn-led.h>
#include <stdio.h>
#include <string.h>
#include <sys/thread.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/timer.h>
#include <eepromdb/btn-eepromdb.h>
#ifdef __AVR__
#include <avr/wdt.h>
#endif
#include <mhop/tp.h>
#include <mhop/vcp.h>
#include <cm/con_mgr.h>
#include <log/logging.h>

#ifndef VCP_DEBUG
#define VCP_DEBUG 0
#endif

#if     VCP_DEBUG >= 4
#define DEBUG_VCP( text, ...)    (DEBUG( LOG_VCP, text, ## __VA_ARGS__))
#else
#define DEBUG_VCP( text, ...)
#endif

#if     VCP_DEBUG >= 3
#define INFO_VCP( text, ...)     (INFO( LOG_VCP, text, ## __VA_ARGS__))
#else
#define INFO_VCP( text, ...)
#endif

#if     VCP_DEBUG >= 2
#define WARNING_VCP( text, ...)  (WARNING( LOG_VCP, text, ## __VA_ARGS__))
#else
#define WARNING_VCP( text, ...)
#endif

#if     VCP_DEBUG >= 1
#define ERROR_VCP( text, ...)    (ERROR( LOG_VCP, text, ## __VA_ARGS__))
#else
#define ERROR_VCP( text, ...)
#endif


/// max number of virtual connections
#define VCP_MAX_VC 4

///type of virtual connection identifier
typedef u_short vcp_vci_t;       

///virtual connection identifier length
#define VCP_VCI_LEN 2

/** 
 * \name VCP Control Packet Types
 * payload of acl_com:
 \verbatim --------------------------------------------
 | ppp_port | type | packet               |
 --------------------------------------------
 .    1        1    BT_MAX_PAYLOAD-1\endverbatim
 * tp packet types (acl_com->payload[1])
 */
//@{ 
///send vc data over a vc
#define VCP_VC_RQST        1
#define VCP_VC_RQST_REPLY   2    
///delets a vc
#define VCP_TEARDOWN_PKT      3      
///send data to a neighbour host
#define VCP_VC_INFO_REPLY          4

/// VC teardown packet. A teardown message follows a virtual connection and removes it
typedef struct _vcp_teardown_pkt {
    vcp_vci_t vci;               ///< virtual circuit identifier
    u_char reason;              ///< teardown reason
} vcp_teardown_pkt_t;
//@}

/// VC data packet to send data over a virtual connection
typedef struct _vcp_data_pkt {
    vcp_vci_t vci;               ///< virtual circuit identifier
    u_char data[BT_MAX_PAYLOAD - VCP_VC_DATA_HEADER_LEN]; ///< data section
} vcp_vc_data_pkt_t;

/// VC teardown packet length
#define VCP_VC_TEARDOWN_LEN (1+VCI_LEN+2) //+1 service_nr, +1 type
//@}

/// VC routing table entry
typedef struct _vcp_table_entry {
    bt_con_handle_t handle;     ///< connection handle
    vcp_vci_t vci;               ///< virtual circuit identifier
    bt_addr_t to_addr;          ///< address of endpoint (not needed for routing)
} vcp_table_entry_t;

/// VCP stack
typedef struct _vcp_stack_s {
    /** \brief VC routing table
     * 
     * An entry in the routing table consists of two #vcp_vc_table_entry_t 
     * entries. The first entry (with even index) holds the connection handle to
     * a host and its VCI while the second entry (with odd index) holds the
     * conneciton handle to a target node and its VCI.
     * 
     * The VC handle of a virtual connection is the even index of the entry in 
     * the VC routing table
     */
    vcp_vc_table_entry_t vctable[2 * VCP_MAX_VC];
    struct btstack *bt_stack;   ///< pointer to the bt stack (needed to get connections for broadcast)
    vcp_vci_t next_vci;          ///< next vci to choose for a new entry
    mpp_mux* port_mux;
} _vcp_stack_t;

_vcp_stack_t* _vcp_stack;

/// Prints out the VC routing table
void _vcp_print_vctable(void)
{
    u_char i;
    char buf[18], buf2[18];
    vcp_vc_table_entry_t *vct = _vcp_stack->vctable;
    INFO( LOG_TERMINAL, ":VT Hdl|H-Con|H-VCI|T-Con|T-VCI|      host       |     target\n");
    INFO( LOG_TERMINAL, ":VT ---|-----|-----|-----|-----|-----------------|----------------\n");
    for (i = 0; i < 2 * VCP_MAX_VC; i += 2) {
        if (vct[i].handle == BT_HANDLE_INVALID)
            continue;
        if (vct[i].handle == BT_HANDLE_OWN) {       //this device is host
            INFO( LOG_TERMINAL, ":VT %2d |     |     |%4d |%4d |       me        |%s\n",
                  i, vct[i + 1].handle, vct[i + 1].vci,
                  bt_addr_to_string( buf, vct[i + 1].to_addr));
        } else if (vct[i + 1].handle == BT_HANDLE_OWN) {    //this device is target
            INFO( LOG_TERMINAL, ":VT %2d |%4d |%4d |     |     |%s|      me\n", 
                  i, vct[i].handle, vct[i].vci,
                  bt_addr_to_string( buf, vct[i].to_addr));
        } else {                //device in the middle
            INFO( LOG_TERMINAL, ":VT    |%4d |%4d |%4d |%4d |%s|%s\n",
                  vct[i].handle, vct[i].vci, vct[i + 1].handle, vct[i + 1].vci,
                  bt_addr_to_string( buf, vct[i].to_addr),
                  bt_addr_to_string( buf2, vct[i + 1].to_addr));
        }
    }
}

/// Adds an entry in #_vcp_stack_s.vctable
u_char _vcp_vctable_add( bt_con_handle_t host_handle,
                        vcp_vci_t host_vci,
                        bt_con_handle_t target_handle,
                        vcp_vci_t target_vci,
                        bt_addr_t host_addr,
                        bt_addr_t target_addr)
{
    u_char vc_handle;
    for (vc_handle = 0; vc_handle < 2 * VCP_MAX_VC; vc_handle += 2) {
        if (_vcp_stack->vctable[vc_handle].handle == BT_HANDLE_INVALID)
            break;
    }
    if (vc_handle == 2 * VCP_MAX_VC) {
        ERROR_VCP("too many vc's!\n");
    } else {
        _vcp_stack->vctable[vc_handle].handle = host_handle;
        _vcp_stack->vctable[vc_handle].vci = host_vci;
        memcpy(_vcp_stack->vctable[vc_handle].to_addr, host_addr, BD_ADDR_LEN);
        _vcp_stack->vctable[vc_handle + 1].handle = target_handle;
        _vcp_stack->vctable[vc_handle + 1].vci = target_vci;
        memcpy(_vcp_stack->vctable[vc_handle + 1].to_addr, target_addr, BD_ADDR_LEN);
    }
    return vc_handle;
}


/// Sends a reply pkt back to the host which sets up a VC.
void _vcp_send_vc_rqst_reply(bt_addr_t host)
{
    u_char vc_handle;
    bt_con_handle_t host_handle;
    // alloc pkt
    ppp_pkt_t pkt;
    u_char *args = _vcp_cmd_pkt_build( pkt, VCP_CMD_REPLY_PKT, VCP_OPEN_VC_COMMAND,
                                     _vcp_stack->my_addr, host, 0, 0, 0, 0);
    //fill in args
    args[0] = BTN_LO(_vcp_stack->next_vci);
    args[1] = BTN_HI(_vcp_stack->next_vci);
    //get handle
    host_handle = _vcp_get_handle_of_host(host);
    // send to host
    if (host_handle == BT_HANDLE_OWN) { //i am the host
        WARNING_VCP("can not set up a vc to it's own host!\n");
    } else {
        // send a setup tp ack packet back to host
        if( BT_SEND( _vcp_stack->l2cap_stack, pkt, host_handle, VCP_SERVICE_NR, VCP_CMD_PKT_HEADER_LEN + 2) != BT_ERR_SUCCESS) {
            ERROR_VCP("cannot send vc open reply over con = %d\n", host_handle);
        } else {
            // setup vc
            vc_handle = _vcp_vctable_add( host_handle, _vcp_stack->next_vci, BT_HANDLE_OWN, 0, host, _vcp_stack->my_addr);
            _vcp_stack->next_vci++;
            // callback
            _vcp_stack->vc_change_cb(VC_CON_OPEN, vc_handle, 0, host);
        }
    }
}


void _vcp_send_vc_info_reply(u_char type, u_char vc_handle)
{
    // alloc pkt
    u_char pkt_mem[sizeof(PPP_PKT) - 1 + BT_MAX_PAYLOAD];
    PPP_PKT *pkt = (PPP_PKT*)pkt_mem;

    // create packet
    u_char *data = _vcp_get_cmd_data_pointer( pkt);
    u_char i;
    vcp_host_table_entry_t hte;
    data[0] = type;
    memcpy(data+1, &_vcp_stack->vctable[vc_handle+1].to_addr , BD_ADDR_LEN);
    data[7] = vc_handle;
    for (i = 0; i < VCP_MAX_HOSTS; i++){
        hte = _vcp_stack->hosttable[i];
        if((hte.handle != BT_HANDLE_INVALID) && (hte.verbose)){
            _vcp_cmd_pkt_build( pkt, VCP_CMD_REPLY_PKT, VCP_VC_INFO_REPLY, _vcp_stack->my_addr, 
                               hte.host_addr, 0, 0, 0, 0);
            if(hte.handle == BT_HANDLE_OWN){
                _vcp_command_reply(_vcp_stack->my_addr, VCP_VC_INFO_REPLY, data, 8);
            }                                         
            else{
                // send to host
                if( BT_SEND( _vcp_stack->l2cap_stack, pkt, hte.handle, VCP_SERVICE_NR, VCP_CMD_PKT_HEADER_LEN + 8) != BT_ERR_SUCCESS) {
                    ERROR_VCP("can not send vc info reply over con = %d\n", hte.handle);
                }        
            }
        }
    }
}

/// Sends a #VCP_VC_TEARDOWN_PKT packet to clean up a VC
void _vcp_send_vc_teardown( bt_con_handle_t handle, vcp_vci_t vci, u_char reason)
{
    // alloc pkt
    u_char pkt_mem[sizeof(PPP_PKT) - 1 + BT_MAX_PAYLOAD];
    PPP_PKT *pkt = (PPP_PKT*)pkt_mem;

    // create packet
    u_char *payload = BT_GET_DATA_POINTER( pkt);
    vcp_vc_teardown_pkt_t *teardown_pkt = (vcp_vc_teardown_pkt_t *) (payload + 2);
    payload[0] = VCP_SERVICE_NR;
    payload[1] = VCP_VC_TEARDOWN_PKT;
    teardown_pkt->vci = vci;
    teardown_pkt->reason = reason;
    if( BT_SEND( _vcp_stack->l2cap_stack, pkt, handle, VCP_SERVICE_NR, VCP_VC_TEARDOWN_LEN) != BT_ERR_SUCCESS) {
        ERROR_VCP( "cannot send teardown over con = %d\n", handle);
    }
}

// tp data callback
void _vcp_control_cb(tp_pkt_t* ppp_pkt, u_char* data, u_short data_len,
		bt_addr_t source, u_char rcv_port)
{
    // packet and type cast pointers
    vcp_vc_data_pkt_t *vc_data_pkt;
    vcp_vc_teardown_pkt_t *vc_teardown_pkt;
    u_char i, vc_handle;
    bt_hci_con_handle_t out_handle;
    vcp_vci_t out_vci;
    u_char found;

    for( i = 0; i < BT_MAX_NUM_CON; i++) {
        if (_vcp_stack->reliable_con_handles[i] == con_handle)
            break;
    }
    if( i == BT_MAX_NUM_CON) {
        WARNING_VCP("no con handle to this pkt!!\n");
        // free packet
        BT_FREE_PACKET(_vcp_stack->l2cap_stack, pkt_buf);
        // disconnect?
        return;
        //btn_led_clear_pattern_queue();
        //btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 11, 1, BTN_LED_INFINITE);
    }
    //TODO: check if this con_handle is already in reliable con table, if not, wait for this
    //reliable connection. this problem occures at new connection. other deivce sends
    //the host entry pkt (if host entries are found) before the reliable con changed is called!!       
    //check packet
    switch (data[0]) {        // type
    case VCP_VC_RQST:
		_tp_send_vc_rqst_reply;
    	break;
    case VCP_VC_RQST_REPLY:
	    // am I the host of this command reply?
	    if (BD_ADDR_CMP(cmd_pkt->destination, _vcp_stack->my_addr)) {
	        DEBUG_VCP("I am the host\n");
	            // add new entry, return handle
	            out_vci = cmd_pkt->data[0] | (cmd_pkt->data[1]) << 8;
	            vc_handle = _vcp_vctable_add(BT_HANDLE_OWN, 0, host_handle, out_vci, _vcp_stack->my_addr, cmd_pkt->source);
	            _vcp_stack->vc_change_cb(VC_CON_OPEN, vc_handle, 0, cmd_pkt->source);
	            _vcp_send_vc_info_reply(VC_CON_OPEN, vc_handle);
	    }
	    else {            // for intermediate nodes
	        DEBUG_VCP("I am an intermediate node\n");
	        // find host handle in host table
	        out_handle = _vcp_get_handle_of_host(cmd_pkt->destination);
	        if (out_handle == BT_HANDLE_INVALID) {
	            ERROR_VCP("unknown host: %s\n",
	                     bt_addr_to_string( _vcp_stack->bt_addr_buf,
	                                        cmd_pkt->destination));
	            break;
	        }
	        // find empty vc entry
	        for (i = 0; i < 2 * VCP_MAX_VC; i += 2) {
	            if (_vcp_stack->vctable[i].handle == BT_HANDLE_INVALID)
	                break;
	        }
	        if (i == 2 * VCP_MAX_VC) {
	            ERROR_VCP("too many vc's!\n");
	            break;
	        }
	        // add new entry in vc table
	        out_vci = cmd_pkt->data[0] | (cmd_pkt->data[1]) << 8;
	        DEBUG_VCP("incomming vc_id: %d\n", out_vci);
	        _vcp_vctable_add(out_handle, _vcp_stack->next_vci, host_handle, out_vci, cmd_pkt->destination, cmd_pkt->source);
	        // patch
	        cmd_pkt->data[0] = BTN_LO(_vcp_stack->next_vci);
	        cmd_pkt->data[1] = BTN_HI(_vcp_stack->next_vci);
	        DEBUG_VCP("outgoing vc_id: %d\n", _vcp_stack->next_vci);
	        _vcp_stack->next_vci++;
	        // forward
	        if( BT_SEND( _vcp_stack->l2cap_stack, pkt, out_handle, VCP_SERVICE_NR, len) != BT_ERR_SUCCESS) {
	            ERROR_VCP("cannot send vc open over con = %d\n", out_handle);
	        }
	    }
        break;
    case VCP_VC_INFO_REPLY:
    	break;
        //------------------------------------------------------------------
    case VCP_TEARDOWN_PKT:
        DEBUG_VCP("received tp teardown packet.\n");
        vc_teardown_pkt = (vcp_vc_teardown_pkt_t *) (payload + 2);
        out_vci = 0;
        out_handle = BT_HANDLE_INVALID;
        // find and delete entry
        for (i = 0; i < 2 * VCP_MAX_VC; i += 2) {
            if ((_vcp_stack->vctable[i].handle == con_handle)
                 && (_vcp_stack->vctable[i].vci == vc_teardown_pkt->vci)) {
                out_handle = _vcp_stack->vctable[i + 1].handle;
                out_vci = _vcp_stack->vctable[i + 1].vci;
                _vcp_stack->vctable[i].handle = BT_HANDLE_INVALID;
                _vcp_stack->vctable[i].vci = 0;
                _vcp_stack->vctable[i + 1].handle = BT_HANDLE_INVALID;
                _vcp_stack->vctable[i + 1].vci = 0;
                break;
            }
            if ((_vcp_stack->vctable[i + 1].handle == con_handle)
                 && (_vcp_stack->vctable[i + 1].vci == vc_teardown_pkt->vci)) {
                out_handle = _vcp_stack->vctable[i].handle;
                out_vci = _vcp_stack->vctable[i].vci;
                _vcp_stack->vctable[i].handle = BT_HANDLE_INVALID;
                _vcp_stack->vctable[i].vci = 0;
                _vcp_stack->vctable[i + 1].handle = BT_HANDLE_INVALID;
                _vcp_stack->vctable[i + 1].vci = 0;
                break;
            }
        }
        if (out_handle == BT_HANDLE_OWN) {
            // I am the endpoint of this vc -> inform 
            _vcp_stack->vc_change_cb(VC_CON_CLOSE, i, vc_teardown_pkt->reason, bt_addr_null);
            if(_vcp_stack->vctable[i].handle == BT_HANDLE_OWN){
                _vcp_send_vc_info_reply(VC_CON_CLOSE, i);     
            }
            break;
        }
        // patch
        vc_teardown_pkt->vci = out_vci;
        // forward
        if( BT_SEND( _vcp_stack->l2cap_stack, pkt, out_handle, VCP_SERVICE_NR, len) != BT_ERR_SUCCESS) {
            ERROR_VCP("cannot send teardown over con = %d\n", out_handle);
        }
        break;
    default:
        ERROR_VCP("unknown VCP packet type %d!\n", data[0]);
        break;
        //------------------------------------------------------------------
    }                       // end switch
    // free packet
    BT_FREE_PACKET( _vcp_stack->l2cap_stack, pkt_buf);
}


////////////////////////////////////////////////////////////////////////////////
/// \brief VCP data callback
///
/// Waits for a packet with service ID #VCP_SERVICE_NR and dispatches it.
////////////////////////////////////////////////////////////////////////////////
void _vcp_data_cb(mhop_pkt_buf_t* pkt_buf, u_char* data, u_short data_len,
						bt_hci_con_handle_t con_handle, u_char rcv_port)
{
    DEBUG_VCP("received vc data\n");
    vc_data_pkt = (vcp_vc_data_pkt_t *) (payload + 2);
    out_vci = 0;
    out_handle = BT_HANDLE_INVALID;
    for (i = 0; i < 2 * VCP_MAX_VC; i += 2) {
        if ((_vcp_stack->vctable[i].handle == con_handle)
             && (_vcp_stack->vctable[i].vci == vc_data_pkt->vci)) {
            out_handle = _vcp_stack->vctable[i + 1].handle;
            out_vci = _vcp_stack->vctable[i + 1].vci;
            break;
        }
        if ((_vcp_stack->vctable[i + 1].handle == con_handle)
             && (_vcp_stack->vctable[i + 1].vci == vc_data_pkt->vci)) {
            out_handle = _vcp_stack->vctable[i].handle;
            out_vci = _vcp_stack->vctable[i].vci;
            break;
        }
    }
    if (out_handle == BT_HANDLE_INVALID) {
        ERROR_VCP("entry not found in VC table [handle = %d vci = %d]\n", con_handle, vc_data_pkt->vci);
        break;

    }
    if (out_handle == BT_HANDLE_OWN) {
        // I am the endpoint of this tp
        _vcp_stack->vc_data_cb(i, vc_data_pkt->data, len - VCP_VC_DATA_HEADER_LEN);
    } else {
        // patch
        vc_data_pkt->vci = out_vci;
        // forward
        if( BT_SEND(_vcp_stack->l2cap_stack, pkt, out_handle, VCP_SERVICE_NR, len) != BT_ERR_SUCCESS) {
            ERROR_VCP("cannot send vc data over con = %d\n", out_handle);
        }
    }
}


/// Callback function for changes in reliable connections
void _vcp_reliable_con_change_cb(u_char type, u_char detail, bt_con_handle_t con_handle)
{
    // alloc pkt
    u_char pkt_mem[sizeof(PPP_PKT) - 1 + BT_MAX_PAYLOAD];
    PPP_PKT *pkt = (PPP_PKT*)pkt_mem;
    
    vcp_vc_table_entry_t *vct = _vcp_stack->vctable;
    u_char *payload;
    u_char i;
    u_char open, active = 0;
    if (type == BT_CON_CONNECT) {
        open = 1;
        if (detail == BT_CON_ACTIVE) {
            active = 1;
        }
        btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 2, 3);
    } else {
        open = 0;
        btn_led_add_pattern(BTN_LED_PATTERN_HALF, 0, 2, 3);
    }
    INFO_VCP( "reliable con %s %s, handle %d, detail %d \n", open ? "open" : "close",
                           open ? active ? "active" : "passive" : "",
                           con_handle, detail);
    if (type == BT_CON_CONNECT) {
        //enter to reliable connections
        for (i = 0; i < BT_MAX_NUM_CON; i++) {
            if (_vcp_stack->reliable_con_handles[i] == con_handle) // add a con_handle only once!
                break;
            if (_vcp_stack->reliable_con_handles[i] == BT_HANDLE_INVALID) {
                _vcp_stack->reliable_con_handles[i] = con_handle;
                break;
            }
        }
    } else if (type == BT_CON_DISCONNECT) {
        //delete out of reliable connections
        for (i = 0; i < BT_MAX_NUM_CON; i++) {
            if (_vcp_stack->reliable_con_handles[i] == con_handle)
                _vcp_stack->reliable_con_handles[i] = BT_HANDLE_INVALID;
        }
        // check if connection to a host broke!
        for (i = 0; i < VCP_MAX_HOSTS; i++) {
            if (_vcp_stack->hosttable[i].handle == con_handle) {
                //connection to host lost!
                _vcp_stack->hosttable[i].handle = BT_HANDLE_INVALID;
                _vcp_stack->hosttable[i].seq = 0;
                //send out host del pkt!
                payload = BT_GET_DATA_POINTER( pkt);
                payload[0] = VCP_SERVICE_NR;
                payload[1] = VCP_HOST_DEL_PKT;
                memcpy( payload + 2, _vcp_stack->hosttable[i].host_addr, BD_ADDR_LEN);
                _vcp_broadcast( pkt, 0, 8);
            }
            
        }
        // find affected vc's, send teardown message to other side and delete entry
        for (i = 0; i < 2 * VCP_MAX_VC; i += 2) {
            if (vct[i].handle == con_handle) {
                if (vct[i + 1].handle != BT_HANDLE_OWN) {
                    _vcp_send_vc_teardown(vct[i + 1].handle, vct[i + 1].vci, VC_CLOSE_LINK);
                } else {
                    // I am the endpoint (target) of this vc -> inform 
                    _vcp_stack->vc_change_cb(VC_CON_CLOSE, i, VC_CLOSE_LINK, bt_addr_null);
                }
                vct[i].handle = BT_HANDLE_INVALID;
                vct[i].vci = 0;
                vct[i + 1].handle = BT_HANDLE_INVALID;
                vct[i + 1].vci = 0;
            }
            if (vct[i + 1].handle == con_handle) {
                if (vct[i].handle != BT_HANDLE_OWN) {
                    _vcp_send_vc_teardown(vct[i].handle, vct[i].vci, VC_CLOSE_LINK);
                } else {
                    // I am the endpoint (host) of this vc -> inform 
                    _vcp_stack->vc_change_cb(VC_CON_CLOSE, i, VC_CLOSE_LINK, bt_addr_null);
                    // inform verbose hosts
                    _vcp_send_vc_info_reply(VC_CON_CLOSE, i);                      
                }
                vct[i].handle = BT_HANDLE_INVALID;
                vct[i].vci = 0;
                vct[i + 1].handle = BT_HANDLE_INVALID;
                vct[i + 1].vci = 0;
            }

        }
    }
    DEBUG_VCP("rel-con change done: handle = %d, type = %d\n", con_handle, type);
}


////////////////////////////////////////////////////////////////////////////////
/// \name API functions
////////////////////////////////////////////////////////////////////////////////
//@{

////////////////////////////////////////////////////////////////////////////////
// init
////////////////////////////////////////////////////////////////////////////////
void vcp_init(
    struct btstack *bt_stack, 
    PPP_STACK* l2cap_stack,
    void (*rel_con_change_registration)(void (*cb)(u_char type, u_char detail, bt_con_handle_t con_handle)))       
{
    int i;
    //dyn alloc tp stack
    _vcp_stack = NutHeapAllocClear(sizeof(_vcp_stack_t));
    vcp_vc_table_entry_t *vcentry = _vcp_stack->vctable;
    // initialize tptable
    for (i = 0; i < 2 * VCP_MAX_VC; i++) {
        vcentry[i].handle = BT_HANDLE_INVALID;
        vcentry[i].vci = 0;

    }
    // initialize host table
    for (i = 0; i < VCP_MAX_HOSTS; i++) {
        _vcp_stack->hosttable[i].handle = BT_HANDLE_INVALID;
        _vcp_stack->hosttable[i].seq = 0;
    }
    for (i = 0; i < BT_MAX_NUM_CON; i++) {
        _vcp_stack->reliable_con_handles[i] = BT_HANDLE_INVALID;
    }
    _vcp_stack->next_vci = 1;
    _vcp_stack->bt_stack = bt_stack;
    _vcp_stack->l2cap_stack = l2cap_stack;
    _vcp_stack->mylastseq = 1;
    _vcp_stack->verbose = 0;    

    // Read own bt address
    bt_hci_get_local_bt_addr(_vcp_stack->bt_stack, _vcp_stack->my_addr);

	// init protocol muxes
	_vcp_stack->cl_data_mux =
		mpp_init_port_mux(VCP_NR_PORTS, NULL, NULL, NULL);
    // register null callbacks
    vcp_register_vc_data_cb(_vcp_vc_data_cb_null);
    //vcp_register_cl_data_cb(_vcp_cl_data_cb_null);
    vcp_register_vc_change_cb(_vcp_vc_change_cb_null);
    vcp_register_nb_data_cb(_vcp_nb_data_cb_null);
    // register con change callback
    rel_con_change_registration(_vcp_reliable_con_change_cb);
    // register data received callback
    BT_REGISTER_SERVICE(_vcp_stack->l2cap_stack, VCP_SERVICE_NR, _vcp_data_cb, 1);
}


////////////////////////////////////////////////////////////////////////////////
// VC change registration
////////////////////////////////////////////////////////////////////////////////
void vcp_register_vc_change_cb(void (*cb)
                              (u_char type, u_char vc_handle, u_char reason, bt_addr_t bt_addr))
{
    _vcp_stack->vc_change_cb = cb;
}

////////////////////////////////////////////////////////////////////////////////
// Opens a VC
////////////////////////////////////////////////////////////////////////////////
void vcp_open_vc(bt_addr_t target, u_char ttl)
{
    // alloc pkt
    u_char pkt_mem[sizeof(PPP_PKT) - 1 + BT_MAX_PAYLOAD];
    PPP_PKT *pkt = (PPP_PKT*)pkt_mem;
    // create packet
    _vcp_cmd_pkt_build( pkt, VCP_CMD_REQUEST_PKT, VCP_OPEN_VC_COMMAND, _vcp_stack->my_addr, target, _vcp_stack->mylastseq++, _vcp_stack->verbose, ttl, 0);
    // send to all open connections except to this device (host entry with handle 0)
    _vcp_broadcast( pkt, 0, VCP_CMD_PKT_HEADER_LEN);
}

////////////////////////////////////////////////////////////////////////////////
// Closes a VC
////////////////////////////////////////////////////////////////////////////////
void vcp_close_vc(u_char vc_handle)
{
    vcp_vc_table_entry_t *vct = _vcp_stack->vctable;
    //get right position
    u_char out_vc_handle = vc_handle +
        (_vcp_stack->vctable[vc_handle].handle == BT_HANDLE_OWN ? 1 : 0);
    _vcp_send_vc_teardown(vct[out_vc_handle].handle, vct[out_vc_handle].vci, VC_CLOSE_NORMAL);
    vct[vc_handle].handle = BT_HANDLE_INVALID;
    vct[vc_handle].vci = 0;
    vct[vc_handle + 1].handle = BT_HANDLE_INVALID;
    vct[vc_handle + 1].vci = 0;
    _vcp_stack->vc_change_cb(VC_CON_CLOSE, vc_handle, VC_CLOSE_NORMAL, bt_addr_null);
    _vcp_send_vc_info_reply(VC_CON_CLOSE, vc_handle);
}

////////////////////////////////////////////////////////////////////////////////
// Returns a pointer to the begin of payload data in a VC data packet
////////////////////////////////////////////////////////////////////////////////
u_char* vcp_get_data_pointer(vcp_pkt_t* pkt)
{
	return ppp_get_data_pointer((ppp_pkt_t*)pkt) + VCP_HEADER_LEN;
}


////////////////////////////////////////////////////////////////////////////////
// Sends a VC data packet
////////////////////////////////////////////////////////////////////////////////
u_char vcp_send_vc_data( PPP_PKT *pkt, u_char vc_handle, u_short len)
{
    // create packet
    u_char *payload = BT_GET_DATA_POINTER( pkt);
    vcp_vc_data_pkt_t *vc_pkt = (vcp_vc_data_pkt_t *) (payload + 2);

    if( (vc_handle >= 2 * VCP_MAX_VC)
        //check we are endpoint
        || ((_vcp_stack->vctable[vc_handle].handle != BT_HANDLE_OWN)
           && (_vcp_stack->vctable[vc_handle + 1].handle != BT_HANDLE_OWN))) {
        return VCP_ERR_DEST;
    } else if (len > (BT_MAX_PAYLOAD - VCP_VC_DATA_HEADER_LEN)) {
        return VCP_ERR_PKT_LEN;
    } else if (len > 0) {
        payload[0] = VCP_SERVICE_NR;
        payload[1] = VCP_VC_DATA_PKT;
        //get right position
        if (_vcp_stack->vctable[vc_handle].handle == BT_HANDLE_OWN)
            vc_handle++;        //means we are target
        vc_pkt->vci = _vcp_stack->vctable[vc_handle].vci;
        if( BT_SEND( _vcp_stack->l2cap_stack, pkt, _vcp_stack->vctable[vc_handle].handle, VCP_SERVICE_NR, VCP_VC_DATA_HEADER_LEN + len) != BT_ERR_SUCCESS) {
            return VCP_ERR_SEND;
        }
    }
    return 0; // success
}
