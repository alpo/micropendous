/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: mhop_blink.c,v 1.7 2006/10/26 13:28:28 kevmarti Exp $
 * 
 */

/*!
 * $Log: mhop_blink.c,v $
 * Revision 1.7  2006/10/26 13:28:28  kevmarti
 * - Adaption to obsolete typedef 'bt_msg'
 * - Included syslog debug definitions
 *
 * Revision 1.6  2006/10/23 11:10:22  kevmarti
 * code beautification
 *
 * Revision 1.5  2006/10/23 10:45:31  kevmarti
 * Adapted to new interface of function 'bt_psm_service_set_buffers()' provided by 'bt/bt_psm.h'
 *
 * Revision 1.4  2006/10/23 09:11:11  kevmarti
 * Adapted to simplified interface provided by connection-less mhop layer
 *
 * Revision 1.3  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * 
 */ 

/*
 * @file mhop_blink.c
 *
 * \date 2006/03/29 
 *
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch.ch>
 * 
 */

#include <bt/bt_psm.h>
#include <mhop/mhop_cl.h>
#include <terminal/btn-terminal.h>
#include <led/btn-led.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_MHOP_CL
#define LOG_LEVEL SYSLOG_LEVEL_MHOP_CL
#include <debug/log_set.h>

u_short _mhop_blink_psm;

bt_acl_pkt_buf* _mhop_blink_cb(bt_acl_pkt_buf* pkt_buf,
							   u_char* data,
							   u_short len,
							   u_short service_nr,
							   void* cb_arg)
{
	DEBUG("<blink, blink>");
	// blink
	btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 15, 2, 8);
	return pkt_buf;
}

short mhop_blink(bt_addr_t addr)
{
	long retval;
	retval = mhop_cl_send_pkt(NULL, 0, addr, _mhop_blink_psm, MHOP_CL_BROADCAST, MHOP_CL_TTL_INFINITE);
	return (short)retval;
}

void _mhop_blink_cmd(char* arg)
{
    u_char i;
    short retval;
    unsigned int iaddr[BD_ADDR_LEN];
    bt_addr_t addr;
    
    // parse user input
    if (sscanf(arg, "%2x:%2x:%2x:%2x:%2x:%2x", &iaddr[5], &iaddr[4], &iaddr[3], &iaddr[2], &iaddr[1], &iaddr[0]) == 6) {
    	// store bt addr
        for (i = 0; i < BD_ADDR_LEN; i++) {
            addr[i] = (u_char) iaddr[i];
        }
        // send the packet
        retval = mhop_blink(addr);
        if (!retval)
        {
        	tprintf("blink rqst sent.\n");
        }
        else
        {
        	tprintf("error: %d\n", retval);
        }
    }
    else tprintf("error usage: blink <addr>\n");
}

void mhop_blink_init(bt_psm_t* psmux, u_short psm)
{
	long retval;
	
	// store psm
	_mhop_blink_psm = psm;
	
	// register reset service at psmux
	retval =
		bt_psm_service_register(psmux, psm, _mhop_blink_cb, NULL);
	if (retval < 0) {
        ERROR("could not register mhop blink service\n");
        return;
    }
    // do not use any buffers for this service
	bt_psm_service_set_buffers(psmux, retval, NULL);
    
    // register terminal cmd
    btn_terminal_register_cmd("mblink", _mhop_blink_cmd);
}

