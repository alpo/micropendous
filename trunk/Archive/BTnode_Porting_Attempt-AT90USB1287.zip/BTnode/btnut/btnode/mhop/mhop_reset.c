#include <bt/bt_psm.h>
#include <mhop/mhop_cl.h>
#include <terminal/btn-terminal.h>
#ifdef __AVR__
#include <avr/wdt.h>
#endif
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_MHOP_CL
#define LOG_LEVEL SYSLOG_LEVEL_MHOP_CL
#include <debug/log_set.h>

u_short _mhop_reset_psm;

bt_acl_pkt_buf* _mhop_reset_cb(bt_acl_pkt_buf* pkt_buf,
							   u_char* data,
							   u_short len,
							   u_short service_nr,
							   void* cb_arg)
{
	// start watchdog-timer
#ifdef __AVR__
    wdt_enable(WDTO_2S);
#endif
	return pkt_buf;
}

short mhop_reset(bt_addr_t addr)
{
	long retval;
	
	// send packet with empty payload
	retval = mhop_cl_send_pkt(NULL,
							  0,
							  addr,
							  _mhop_reset_psm,
							  MHOP_CL_BROADCAST,
							  MHOP_CL_TTL_INFINITE);
	return (short)retval;
}

void _mhop_reset_cmd(char* arg)
{
    u_char i;
    short retval;
    unsigned int iaddr[BD_ADDR_LEN];
    bt_addr_t addr;
    
    // parse user input
    if (sscanf(arg, "%2x:%2x:%2x:%2x:%2x:%2x", &iaddr[5], &iaddr[4], &iaddr[3], &iaddr[2], &iaddr[1], &iaddr[0]) == 6) {
    	// store bt addr
        for (i = 0; i < BD_ADDR_LEN; i++) {
            addr[i] = (u_char) iaddr[i];
        }
        // send the packet
        retval = mhop_reset(addr);
        if (!retval)
        {
        	tprintf("reset rqst sent.\n");
        }
        else
        {
        	tprintf("error: %d\n", retval);
        }
    }
    else tprintf("error usage: reset <addr>\n");
}

void mhop_reset_init(bt_psm_t* psmux, u_short psm)
{
	long retval;
	
	// store psm
	_mhop_reset_psm = psm;
	
	// register reset service at psmux
	retval =
		bt_psm_service_register(psmux, psm, _mhop_reset_cb, NULL);
	if (retval < 0) {
        ERROR("could not register mhop reset service\n");
    }
    // do not use any buffers for this service
	bt_psm_service_set_buffers(psmux, retval, NULL);
    
    // register terminal cmd
    btn_terminal_register_cmd("mreset", _mhop_reset_cmd);
}
