/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

 /**
 * @file mhop_cl.c
 *
 *\author Kevin Martin <kevmarti@tik.ee.ethz.ch>
 * 
 *\date 10-14-05
 * 
 *\brief Implementation of the connection-less multi-hop layer
 *
 */
#include <string.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/thread.h>
#include <sys/mutex.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_acl_defs.h>
#include <bt/bt_hci_cmds.h>
#include <terminal/btn-terminal.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <mhop/mhop_cl.h>
#include <mhop/mhop_cl_defs.h>
#include <debug/toolbox.h>
#include <sys/timer.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_MHOP_CL
#define LOG_LEVEL SYSLOG_LEVEL_MHOP_CL
#include <debug/log_set.h>

#if LOG_LEVEL >= 4
u_char _mhop_cl_dbg_buf[3*121];
#endif

// declaration of the mhop cl stack
_mhop_cl_stack_t _mhop_cl_stack;


/**
 * Returns the forwarding table entry associated with the passed device address.
 * 
 * Scans the forwarding table for an entry containing the destination
 * address \p dest and returns it.
 * 
 * \param addr Address of the desired destination node
 * 
 * \return
 * - the corresponding forwarding table entry
 * - NULL else
 */
mhop_cl_fwt_entry* mhop_cl_fwt_get_entry(bt_addr_t addr)
{
	u_short i;
	
	for (i=0; i < MHOP_CL_MAX_FWD_TABLE_SIZE; i++)
	{
		// check if entry is valid
		if (_mhop_cl_stack.fwt[i].handle != BT_HCI_HANDLE_INVALID)
		{
			// check if address matches
			if (BD_ADDR_CMP(_mhop_cl_stack.fwt[i].src_addr, addr))
			{
				return &_mhop_cl_stack.fwt[i];
			}
		}
	}
	return NULL;
}

void mhop_cl_fwt_register_cb(MHOP_CL_FWTABLE_CB, void* cb_arg)
{
	_mhop_cl_stack.fwt_cb = fwt_cb;
	_mhop_cl_stack.fwt_cb_arg = cb_arg;
}
	
/**
 * \brief Updates the forwarding table.
 *
 * \param src_addr Address of the source
 * \param src_handle Handle pkt was received from
 * \param src_seq Sequence number of the source broadcast
 * \param ttl time to live of the source broadcast
 * \param distance Distance to the source
 */
int mhop_cl_fwt_update(bt_addr_t src_addr,
						bt_hci_con_handle_t src_handle,
						u_char src_seq,
						u_char distance)
{
	u_short i;
	mhop_cl_fwt_entry* fwte = NULL;
    
    // find source in table or an empty entry
    for (i=0; i<MHOP_CL_MAX_FWD_TABLE_SIZE; i++)
    {
    	// check if fwd table entry is valid
    	if (_mhop_cl_stack.fwt[i].handle != BT_HCI_HANDLE_INVALID)
    	{
    		// check if source addr matches
        	if (BD_ADDR_CMP(_mhop_cl_stack.fwt[i].src_addr, src_addr))
        	{
        		fwte = &_mhop_cl_stack.fwt[i];
        		break;
        	}
        }
        // if we have not found an empty entry yet, check if the entry is free
        else if (!fwte)
        {
        	// if the entry is free, remember it
        	if (_mhop_cl_stack.fwt[i].handle == BT_HCI_HANDLE_INVALID)
        	{
        		fwte = &_mhop_cl_stack.fwt[i];
        	}
        }
    }
    
    // if src is not in table & no free entry was found, return error
    if (!fwte) 
    {
    	ERROR("fwd table full!\n");
    	return -1;
    }
    
    // if this is a new source, store it & signal higher layer
    if (fwte->handle == BT_HCI_HANDLE_INVALID)
    {
        INFO("new src: " SADDR_FMT " stored.\n", SADDR(src_addr));
        memcpy(fwte->src_addr, src_addr, BD_ADDR_LEN);
        fwte->seq = src_seq;
        fwte->handle = src_handle;
        fwte->distance = distance;
        // notify higher layer that a new source has been recorded
        if (_mhop_cl_stack.fwt_cb)
        {
        	_mhop_cl_stack.fwt_cb(fwte, MHOP_CL_FWT_SOURCE_ADDED, _mhop_cl_stack.fwt_cb_arg);
        }
    }
    // else, update the entry only if we did not yet receive that broadcast
    else
    {
	        
	    INFO("src updt: " SADDR_FMT ", in hdl: %d, seq: %d, cseq: %d, hop cnt: %d\n",
	        	  SADDR(src_addr), src_handle, src_seq, fwte->seq, distance);
    	// if bc already received, return error
    	if (((fwte->seq - src_seq) % (sizeof(src_seq)*256)) <= MHOP_CL_BC_WINDOW)
    	{
    		INFO("src update FAILED: old bc!\n");
    		return -2;
    	}
    	// else, just update the entry
        fwte->handle = src_handle;
        fwte->seq = src_seq;
        fwte->distance = distance;
       	DEBUG("from host "ADDR_FMT" with seq nr %d over handle %d\n",
                ADDR(src_addr),
                src_seq, src_handle);
    }
    return 0;
}


int mhop_cl_fwt_remove(bt_addr_t src, bt_hci_con_handle_t src_hdl)
{
	u_char i;
	mhop_cl_fwt_entry* fwte;
	
    //find source and delete it
    for (i = 0; i < MHOP_CL_MAX_FWD_TABLE_SIZE; i++)
    {
    	fwte = &_mhop_cl_stack.fwt[i];
    	// only delete, if source direction was on this con
        if (fwte->handle == src_hdl)
        {
        	// check if address matches
            if (BD_ADDR_CMP(fwte->src_addr, src))
            {
            	// call fwd table callback
            	if (_mhop_cl_stack.fwt_cb)
            	{
            		_mhop_cl_stack.fwt_cb(fwte,
            							  MHOP_CL_FWT_SOURCE_DELETED,
            							  _mhop_cl_stack.fwt_cb_arg);
            	}
            	
                // delete source from fwd table & forward the packet
                fwte->handle = BT_HCI_HANDLE_INVALID;
                fwte->seq = 0;
                fwte->distance = 0;
                DEBUG("src deleted.\n");
                return 0;
            }
        }
    }
    return -1;
}


long _mhop_cl_send_pkt_to(mhop_cl_pkt_hdr* hdr,
							u_char* data,
							u_short len,
							bt_hci_con_handle_t con_hdl)
{
	long res;
	
	// get access to the l2cap cl channel
	res = l2cap_cl_acquire_write_lock(con_hdl,
								_mhop_cl_stack.mhop_psm,
								len + sizeof(mhop_cl_pkt_hdr));							
	if (res)
	{
		WARNING("err acquiring cl chan: %d\n", res);
		return res;
	}
	
	// write mhop header
	res = l2cap_cl_lowlevel_write((u_char*)hdr, sizeof(mhop_cl_pkt_hdr));
	if (res)
	{
		WARNING("err sending hdr: %d\n", res);
		l2cap_cl_release_write_lock();
		return res;
	}
	// write data
	if (len)
	{
		res = l2cap_cl_lowlevel_write(data, len);
	}
	if (res)
	{
		WARNING("err sending data: %d\n", res);
	}
					
	// close the channel
	l2cap_cl_release_write_lock();
	return 0;
}

/**
 * \brief Forwards a packet to the target device.
 * 
 * If an entry for the target device exists in the forwarding table (that is
 * we know how to reach the target device), the packet is forwarded to the
 * corresponding next hop.
 * 
 * If there is no entry in the forwarding table, the packet is broadcasted.
 * 
 * \param stack Pointer to the connectionless multi-hop stack
 * \param hdr Pointer to the mhop cl header
 * \param data Pointer to the data to be sent
 * \param len Length of the data to be sent (excluding mhop cl header)
 * \param in_handle Connection handle the packet was received on.
 */
long _mhop_cl_fwd_pkt(mhop_cl_pkt_hdr* hdr, u_char* data,
								u_short len, bt_hci_con_handle_t in_hdl)
{
	u_short i;
	long res;
	bt_hci_con_handle_t* rel_cons;
    bt_hci_con_handle_t out_handle;
    mhop_cl_fwt_entry* fwte;
    
	// increment hop count
	hdr->hop_cnt++;
	
	if (hdr->type == MHOP_CL_PKT_TYPE_UNICAST)
	{
		// Check if the desired destination can be found in the forwarding table
		fwte = mhop_cl_fwt_get_entry(hdr->destination);
		if (fwte)
		{
			out_handle = fwte->handle;
			DEBUG("forwarding pkt (hdl: %d)\n", out_handle);
			return _mhop_cl_send_pkt_to(hdr, data, len, out_handle);
		}
		else
		{
			INFO("no out hdl for dest: " SADDR_FMT " found!\n", SADDR(hdr->destination));
			return MHOP_CL_ERR_FORWARDING;
		}
	}
	
	// if the packet is a broadcast packet (or a source del packet)
	DEBUG("broadcasting pkt...\n");
	
	// send to all reliable connections excpet to incoming handle
	rel_cons = _mhop_cl_stack.reliable_con_handles;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++)
    {
    	// check if entry is valid
        if (rel_cons[i] != BT_HCI_HANDLE_INVALID)
        {
        	// do not forward to incoming con handle
        	if (rel_cons[i] != in_hdl)
        	{
            	// send packet
            	DEBUG("bc: sending to handle: %d...\n", rel_cons[i]);				
            	res = _mhop_cl_send_pkt_to(hdr, data, len, rel_cons[i]);
            	if (res)
            	{
                	DEBUG("bc: error! hdl %d (0x%.2x)\n", rel_cons[i], -res);
            	}
            	else
            	{
            		DEBUG("bc to hdl %d sent\n", rel_cons[i]);
            	}
        	}
        }
    }
	return 0;
}


/**
 * Is called each time a packet has to be forwarded.
 * 
 * Since forwarding may require some time (e.g. if we have to broadcast the
 * packet), received packets are forwarded within the context of a special
 * thread. The required context-switch is implemented by registering a
 * forwarding service at the protocol / service multiplexor which provides
 * the buffering / context-switch needed "for free".
 * 
 * This is the callback function registered at the protocol/service multiplexor
 * during initialization.
 * 
 * \see #bt_psm.h
 * \see #BT_PSM_DATA_CB
 * \see #mhop_cl_init
 */
bt_acl_pkt_buf* _mhop_cl_fwd_queue_data_cb(bt_acl_pkt_buf* pkt_buf,
									u_char* data,
									u_short len,
									u_short service_nr,
									void* cb_arg)
{
    bt_hci_con_handle_t in_handle;
    mhop_cl_pkt_hdr* hdr;
    bt_acl_pkt_buf* free_buf;
    u_short psm;
    long retval;
    
    // get pointer to the multi-hop header
    hdr = (mhop_cl_pkt_hdr*)data;
    // adjust payload pointer
    data += sizeof(mhop_cl_pkt_hdr);
    // adjust payload size
    len -= sizeof(mhop_cl_pkt_hdr);
	// get con handle the packet was received on
	in_handle = bt_acl_get_con_handle(pkt_buf->pkt);
	
	// forward the packet
	retval = _mhop_cl_fwd_pkt(hdr, data, len, in_handle);
	if (retval)
	{
		INFO("error fwd pkt: %d\n", retval);
	}
	
    // if destination addr is the broadcast addr, we additionally
    // have to deliver the packet
    if (BD_ADDR_CMP(hdr->destination, bt_addr_null))
    {
    	// do not deliver src del packets
    	if (hdr->type != MHOP_CL_PKT_TYPE_SRC_DEL)
    	{
    		// deliver message
    		psm = hdr->psm[0] | hdr->psm[1] << 8;
        	retval = bt_psm_deliver_msg(_mhop_cl_stack.psmux, pkt_buf, data, len, psm, &free_buf);
        	// if everything's ok, we return the free buffer obtained
			if (!retval)
			{
				return free_buf;
			}
			// else, we discard the message (i.e. return it immediately)
			WARNING("couldn't deliver pkt to psm %d! code: %d\n", psm, retval);
    	}
    }
	return pkt_buf;
}


/**
 * \brief l2cap cl data callback.
 * 
 * This callback is called each time an l2cap cl packet arrives on the
 * psm #mhop_cl_stack::mhop_psm. This callback is registered at the
 * protocol / service multiplexor during initalization of the
 * connection-less multi-hop layer.
 */
bt_acl_pkt_buf* _mhop_cl_data_cb(bt_acl_pkt_buf* pkt_buf,
							u_char* data,
							u_short len,
							u_short service_nr,
							void* cb_arg)
{
	u_short psm;
	mhop_cl_pkt_hdr* hdr;
	bt_hci_con_handle_t in_handle;
	long retval;
	bt_acl_pkt_buf* free_buf;
	
	// get pointer to multi-hop packet header
	hdr = (mhop_cl_pkt_hdr*)data;
    // get connection handle the packet was received on
    in_handle = bt_acl_get_con_handle(pkt_buf->pkt);
	// get psm the packet has to be delivered to
	psm = hdr->psm[0] | hdr->psm[1] << 8;
    
    INFO("rcvd: " SADDR_FMT " to: " SADDR_FMT ", @%p, len: %d, psm: 0x%04x, in_hdl: %d, seq: %d\n",
    	 SADDR(hdr->source), SADDR(hdr->destination), pkt_buf, len, psm, in_handle, hdr->seq);
    
    // packets that are from this device are not processed, they are only delivered
    // to the next higher layer (see below). Packets from own device are received
    // if a mhop packet is sent to the broadcast address
    // (bt_addr_null, see #mhop_cl_send_pkt).
    if (in_handle != BT_HCI_CON_HANDLE_OWN)
    {
		/*
		 * a source deletion packet arrived:
		 * if the packet arrived on the same handle as in the forwarding table,
		 * delete the source & fwd the packet
		 */
		if (hdr->type == MHOP_CL_PKT_TYPE_SRC_DEL)
		{
	        INFO("src del from: " SADDR_FMT "! handle: %d, src: "SADDR_FMT"\n", SADDR(hdr->source), in_handle, SADDR(data + sizeof(mhop_cl_pkt_hdr)));
	        
	        // remove source from fwd table - discard packet if no entry found
	        if (mhop_cl_fwt_remove(data + sizeof(mhop_cl_pkt_hdr), in_handle))
	        {
	        	return pkt_buf;
	        }
		}
		/*
		 * A broadcast packet arrived, thus we have to update the
		 * forwarding table: if the packet has already been received,
		 * we discard it.
		 */
	    else if (hdr->type == MHOP_CL_PKT_TYPE_BROADCAST)
	    {
    		DEBUG("src rec pkt rcvd!\n");
    		retval = mhop_cl_fwt_update(hdr->source, in_handle, hdr->seq, hdr->hop_cnt);
    		if (retval == -1)
    		{
        		ERROR("ft full! src: " SADDR_FMT ", in hdl: %d, seq: %d, hop cnt: %d\n",
        	  	  	  SADDR(hdr->source), in_handle, hdr->seq, hdr->hop_cnt);
        		return pkt_buf;
    		}
    		else if (retval == -2)
    		{
        		return pkt_buf;
    		}
	    }
		
		/*
		 * Forwarding: if this device is not the destination, we forward
		 * the packet by delivering it to the forwarding mux
		 */
		if (!BD_ADDR_CMP(hdr->destination, _mhop_cl_stack.my_addr))
		{
			// only forward the packet if the ttl is still valid
			if ((hdr->ttl == MHOP_CL_TTL_INFINITE) || (hdr->hop_cnt <= hdr->ttl))
			{
				INFO("deliver pkt\n");
				retval = bt_psm_deliver_msg(_mhop_cl_stack.fwd_mux,
											pkt_buf,
											data,
											len,
											_mhop_cl_stack.mhop_psm,
											&free_buf);
				if (!retval)
				{
					return free_buf;
				}
				INFO("err forwarding! retval: %d\n", retval);
			}
			// if ttl invalid, or packet could not be delivered to forwarding mux
			INFO("ttl invalid! ttl: %d, hop cnt: %d\n", hdr->ttl, hdr->hop_cnt);
			return pkt_buf;
		}
    }
	// deliver the packet
    INFO("deliver pkt\n");
	// adjust payload pointer
	data += sizeof(mhop_cl_pkt_hdr);
	// adjust payload size
	len -= sizeof(mhop_cl_pkt_hdr);
	// deliver packet
	retval = bt_psm_deliver_msg(_mhop_cl_stack.psmux,
								pkt_buf,
								data,
								len,
								psm,
								&free_buf);
	// if everything's ok, return free buffer obtained from higher layer
	if (!retval)
	{
		return free_buf;
	}
	// else, return next free pkt buffer
	ERROR("couldn't deliver pkt to psm %d! code: %d\n", psm, retval);
	return pkt_buf;
}

// Callback function for changes in reliable connections
void _mhop_cl_reliable_con_change_cb(u_char type, u_char detail, bt_hci_con_handle_t hdl, void* cb_arg)
{
    u_char i;
    bt_hci_con_handle_t* rel_cons;
    mhop_cl_fwt_entry* fwte;
    
    rel_cons = _mhop_cl_stack.reliable_con_handles;
    if (type == BT_HCI_CONNECTION) {
        DEBUG("new con! detail: %d, handle: %d\n",
                      type, detail, hdl);
        // add handle to reliable connections table
        for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
            if (rel_cons[i] == hdl) // add a con_handle only once!
                break;
            if (rel_cons[i] == BT_HCI_HANDLE_INVALID) {
                rel_cons[i] = hdl;
                break;
            }
        }
    } else if (type == BT_HCI_DISCONNECTION) {
        DEBUG("disconnect! detail: %d, handle: %d\n",
                      type, detail, hdl);
        // remove handle from reliable connections table
        for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
            if (rel_cons[i] == hdl)
                rel_cons[i] = BT_HCI_HANDLE_INVALID;
        }
        // check if connection to a known source broke!
        for (i = 0; i < MHOP_CL_MAX_FWD_TABLE_SIZE; i++)
        {
            fwte = &_mhop_cl_stack.fwt[i];
            if (fwte->handle == hdl)
            {
                INFO("was conn to known src ("ADDR_FMT")!\n", ADDR(fwte->src_addr));
                // signal higher layer
                if (_mhop_cl_stack.fwt_cb)
                {
                	_mhop_cl_stack.fwt_cb(fwte,
                						  MHOP_CL_FWT_SOURCE_DELETED,
                						  _mhop_cl_stack.fwt_cb_arg);
                }
                //connection to source lost!
                fwte->handle = BT_HCI_HANDLE_INVALID;
                fwte->seq = 0;
                fwte->distance = 0;
                //send out host del pkt!
                mhop_cl_send_src_del_pkt(fwte->src_addr, 0);
            }
        }
    }
    else
    {   
        DEBUG("rel-con change: handle = %d, type = %d\n", hdl, type);
    }
    // singal higher layer
    if (_mhop_cl_stack.con_table_cb)
    {
    	_mhop_cl_stack.con_table_cb(type, detail, hdl, _mhop_cl_stack.con_table_cb_arg);
    }
}

// send multi-hop packet
long mhop_cl_send_pkt(u_char* data,
						u_short len,
						bt_addr_t dest,
						u_short psm,
						u_char bc_flag,
						u_char ttl)
{
	long retval;
	mhop_cl_pkt_hdr hdr;

	// return error if payload size is too big
	if (len > (l2cap_cl_max_payload() - sizeof(mhop_cl_pkt_hdr)))
	{
		return MHOP_CL_ERR_PAYLOAD_OVERFLOW;
	}
	
	// build multi-hop header: add bc sequence number if packet shall
	// be broadcasted.
    if ((bc_flag == MHOP_CL_BROADCAST) || (BD_ADDR_CMP(dest, bt_addr_null)))
    {
    	hdr.type = MHOP_CL_PKT_TYPE_BROADCAST;
    	hdr.seq = _mhop_cl_stack.mylastseq++;
    	hdr.ttl = ttl;
    }
    else
    {
    	hdr.type = MHOP_CL_PKT_TYPE_UNICAST;
    	hdr.seq = 0;
    	hdr.ttl = MHOP_CL_TTL_INFINITE;
    }
    hdr.ttl = ttl;
    hdr.hop_cnt = 0;
    // set source and destination addresses
    memcpy(hdr.source, _mhop_cl_stack.my_addr, BD_ADDR_LEN);
    memcpy(hdr.destination, dest, BD_ADDR_LEN);
    // destination port
    hdr.psm[0] = BTN_LO(psm);
    hdr.psm[1] = BTN_HI(psm);
        
    // forward packet
    retval = _mhop_cl_fwd_pkt(&hdr, data, len, BT_HCI_CON_HANDLE_OWN);

    // if packet should be broadcasted or if target is this device,
    // we have to send the packet to this device
    if (BD_ADDR_CMP(dest, bt_addr_null) || BD_ADDR_CMP(dest, _mhop_cl_stack.my_addr))
    {
    	retval = _mhop_cl_send_pkt_to(&hdr, data, len, BT_HCI_CON_HANDLE_OWN);
    }
    return retval;
}

long mhop_cl_send_src_del_pkt(bt_addr_t addr, u_char  ttl)
{
	long retval;
	mhop_cl_pkt_hdr hdr;
	
	// build multi-hop header. src del packets are broadcast packets
	hdr.type = MHOP_CL_PKT_TYPE_SRC_DEL;
	hdr.seq = 0;
    hdr.ttl = ttl;
    hdr.hop_cnt = 0;
    // set source and destination addresses
    memcpy(hdr.source, _mhop_cl_stack.my_addr, BD_ADDR_LEN);
    memcpy(hdr.destination, bt_addr_null, BD_ADDR_LEN);
    // destination port
    hdr.psm[0] = BTN_LO(_mhop_cl_stack.mhop_psm);
    hdr.psm[1] = BTN_HI(_mhop_cl_stack.mhop_psm);
        
    // forward packet (i.e. send it to _all_ connected neighbors)
    retval = _mhop_cl_fwd_pkt(&hdr, addr, BD_ADDR_LEN, BT_HCI_CON_HANDLE_OWN);
			
    // send packet to all connected neighbors
    INFO("SRC DEL with seq %d. retval: %d\n", _mhop_cl_stack.mylastseq - 1, retval);
	return retval;
}


u_char* mhop_cl_get_target_addr(struct bt_hci_pkt_acl* pkt)
{
	return ((mhop_cl_pkt_hdr*)l2cap_cl_get_data_ptr(pkt))->destination;
}

u_char* mhop_cl_get_source_addr(struct bt_hci_pkt_acl* pkt)
{
	return ((mhop_cl_pkt_hdr*)l2cap_cl_get_data_ptr(pkt))->source;
}

u_short mhop_cl_max_payload_size(void)
{
	return l2cap_cl_max_payload() - sizeof(mhop_cl_pkt_hdr);
}

u_char* mhop_cl_get_my_addr(void)
{
	return _mhop_cl_stack.my_addr;
}

void mhop_cl_init(struct btstack* bt_stack,
					bt_psm_t* psmux,
					u_short psm,
					u_short buf_size,
					HCI_CON_TABLE_CB_REGISTRATION)
{
	u_short i;
	long service_nr;
	
	// init stack
	_mhop_cl_stack.bt_stack = bt_stack;
	_mhop_cl_stack.psmux = psmux;
	_mhop_cl_stack.mhop_psm = psm;
    bt_hci_get_local_bt_addr(_mhop_cl_stack.bt_stack, _mhop_cl_stack.my_addr);
    _mhop_cl_stack.mylastseq = 1;
    _mhop_cl_stack.con_table_cb = NULL;
    _mhop_cl_stack.con_table_cb_arg = NULL;
    _mhop_cl_stack.fwt_cb = NULL;
    _mhop_cl_stack.fwt_cb_arg = NULL;
    
    // initialize forwarding table
    for (i = 0; i < MHOP_CL_MAX_FWD_TABLE_SIZE; i++)
    {
        _mhop_cl_stack.fwt[i].handle = BT_HCI_HANDLE_INVALID;
        _mhop_cl_stack.fwt[i].seq = 0;
    }
    
    // initialize reliable connections
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++)
    {
        _mhop_cl_stack.reliable_con_handles[i] = BT_HCI_HANDLE_INVALID;
    }
    
	// register multi-hop service at protocol / service multiplexor
	service_nr =
		bt_psm_service_register(psmux, psm, _mhop_cl_data_cb, NULL);
	// we don't need any buffers for the mhop protocol
	bt_psm_service_set_buffers(psmux, service_nr, NULL);
	
	// init second psmux for packet forwarding
	_mhop_cl_stack.fwd_mux = bt_psm_init(bt_stack, MHOP_CL_MAX_NR_SERVICES, buf_size);
	// register fwd service at forwarding mux
	bt_psm_service_register(_mhop_cl_stack.fwd_mux, psm, _mhop_cl_fwd_queue_data_cb, NULL);

	// register con change callback
	con_table_cb_reg(bt_stack, _mhop_cl_reliable_con_change_cb, NULL);
}

void mhop_cl_register_con_table_cb(HCI_CON_TABLE_CB, void* cb_arg)
{
	_mhop_cl_stack.con_table_cb = con_table_cb;
	_mhop_cl_stack.con_table_cb_arg = cb_arg;
}

