/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: rpc.c,v 1.13 2006/10/26 13:28:28 kevmarti Exp $
 * 
 */

/*!
 * $Log: rpc.c,v $
 * Revision 1.13  2006/10/26 13:28:28  kevmarti
 * - Adaption to obsolete typedef 'bt_msg'
 * - Included syslog debug definitions
 *
 * Revision 1.12  2006/10/23 11:16:02  kevmarti
 * code beautification
 *
 * Revision 1.11  2006/10/23 10:45:31  kevmarti
 * Adapted to new interface of function 'bt_psm_service_set_buffers()' provided by 'bt/bt_psm.h'
 *
 * Revision 1.10  2006/10/23 09:11:11  kevmarti
 * Adapted to simplified interface provided by connection-less mhop layer
 *
 * Revision 1.9  2006/10/03 17:05:16  beutel
 * * added copyright headers
 * * added blue blink to rpc receptions
 * * minor xbank terminal cleanups
 *
 * 
 */ 

/*
 * @file rpc.c
 *
 * \date 2006/03/29 
 *
 * \author Matthias Dyer <dyer@tik.ee.ethz.ch.ch>
 * 
 * remote procedure calls for btnut mhop
 */

#include <sys/heap.h>
#include <mhop/rpc.h> 
#include <string.h>
#include <debug/logging.h>
#include <debug/toolbox.h>
#include <terminal/btn-terminal.h>
#include <sys/timer.h>
#include <bt/l2cap_cl.h>
#include <led/btn-led.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_RPC
#define LOG_LEVEL SYSLOG_LEVEL_RPC
#include <debug/log_set.h>

u_char _rpc_dbg_buf[3*121];

/**
 * \brief registered PSM callback for rpc data.
 * Finds the corresponding rpc procedure, calls it and sends results back to
 * source.
 */
bt_acl_pkt_buf* _rpc_proc_cb(bt_acl_pkt_buf* pkt_buf, 
                       u_char* data,
                       u_short data_len, 
                       u_short service_nr, 
                       void* cb_arg)
{
    // process pkt
    u_char* source_addr;
    u_char more_pkts;
    u_char result_len = 0;
    
    source_addr = mhop_cl_get_source_addr(pkt_buf->pkt);
    u_char proc_nr = data[0];
    if(proc_nr >= _rpc->max_procs)
    { 
        return pkt_buf;
    }
    _rpc_procs_t* proc = &_rpc->procs[proc_nr];
    // call rpc procedure
    do{
        DEBUG("call proc nr %d\n", proc_nr);
        more_pkts = proc->rpc_proc(pkt_buf, (char *)data+1, data_len-1, proc->proc_arg,
                                   _rpc->result_data+1, &result_len);
        btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF,1,2,5);
        // send result
        _rpc->result_data[0] = proc_nr;  
        if(result_len > 0){
            DEBUG("sending result to "ADDR_FMT" len= %d\n",
                      ADDR(source_addr), 
                      result_len+1);
//            DEBUG_STR("%s\n", 
//                      dbg_str_to_hex_str(_rpc_dbg_buf, _rpc->result_data, result_len+1));
            mhop_cl_send_pkt(_rpc->result_data,
            				 result_len + 1,
            				 source_addr,
            				 _rpc->result_psm,  
                             MHOP_CL_UNICAST, 
                             MHOP_CL_TTL_INFINITE);
            DEBUG("done.\n");
        }
    } while (more_pkts > 0);
    // free packet buffer
    return pkt_buf;
}

/**
 * \brief registered PSM callback for handling returned rpc results.
 */
bt_acl_pkt_buf* _rpc_result_cb(bt_acl_pkt_buf* pkt_buf, 
                       u_char* data,
                       u_short data_len, 
                       u_short service_nr, 
                       void* cb_arg)
{
    // process pkt
    DEBUG("result cb for proc %d\n", data[0]);
    u_char* source_addr = mhop_cl_get_source_addr(pkt_buf->pkt);
    u_char proc_nr = data[0];
    if(proc_nr >= _rpc->max_procs){
        return pkt_buf;
    }
    _rpc_procs_t* proc = &_rpc->procs[proc_nr];
    u_char* result = data+1; 
    // call result procedure
    
    DEBUG("call result\n");
    proc->rpc_result(source_addr, result, data_len-1, proc->result_arg);
    // free packet buffer
    return pkt_buf;
}


void rpc_send_query(u_char proc_nr,  
                    u_char* data, u_char data_len,
                    bt_addr_t dest_addr, u_char ttl)
{                    
    u_char pkt[data_len + 1];
    pkt[0] = proc_nr;
    memcpy(pkt+1, data, data_len);
    // send query
    DEBUG("sending query to "ADDR_FMT"\n", ADDR(dest_addr));
    mhop_cl_send_pkt(pkt, 
                     data_len + 1,
                     dest_addr,
                     _rpc->proc_psm, 
                     MHOP_CL_BROADCAST, 
                     MHOP_CL_TTL_INFINITE);
}

// TODO mutex protect _rpc->result_data
void rpc_local_query(u_char proc_nr, u_char* data, u_char data_len)
{
    u_char more_pkts;
    u_char result_len = 0;
    DEBUG("local query proc %d\n",proc_nr);
    _rpc_procs_t* proc = &_rpc->procs[proc_nr];
    
    // call rpc procedure
    do{
        more_pkts = proc->rpc_proc(NULL, (char*)data, data_len, proc->proc_arg,
                                          _rpc->result_data+1, &result_len);
        if(result_len > 0){
            proc->rpc_result(mhop_cl_get_my_addr(), _rpc->result_data+1, result_len, proc->result_arg);
        }
    } while(more_pkts > 0);
}                     


char rpc_register_proc(u_char* proc_nr, \
                       RPC_PROC, void* proc_arg, \
                       RPC_RESULT, void* result_arg)
{
    u_char i;
    _rpc_procs_t* proc = NULL;
    for( i=0; i < _rpc->max_procs; i++){
        proc = &_rpc->procs[i];
        if(proc->rpc_proc == NULL){
            // insert service
            proc->rpc_proc = rpc_proc;
            proc->proc_arg = proc_arg;
            proc->rpc_result = rpc_result;
            proc->result_arg = result_arg;
            *proc_nr = i;
            break;      
        }
    }
//    printf("proc registered: %d, @%p\n", i, proc);
    if(i == _rpc->max_procs){
        return RPC_ERR_TOO_MANY_PROCS;
    }
    return 0;    
}                     

inline u_short rpc_max_result_size(void){
    return mhop_cl_max_payload_size() - 1;
}


rpc_stack_t* rpc_init(bt_psm_t* psmux,
						u_char nr_procs,
						u_short proc_psm,
						u_short result_psm)
{
    _rpc = NutHeapAllocClear(sizeof(rpc_stack_t));
    _rpc->procs = NutHeapAllocClear(nr_procs * sizeof(_rpc_procs_t));
    _rpc->max_procs = nr_procs;
    _rpc->proc_psm = proc_psm;
    _rpc->result_psm = result_psm;
    _rpc->result_data = NutHeapAllocClear(mhop_cl_max_payload_size());
    
    // register rpc service
    bt_psm_service_register(psmux, proc_psm, _rpc_proc_cb, NULL);
    bt_psm_service_register(psmux, result_psm, _rpc_result_cb, NULL);
    return _rpc;
}


