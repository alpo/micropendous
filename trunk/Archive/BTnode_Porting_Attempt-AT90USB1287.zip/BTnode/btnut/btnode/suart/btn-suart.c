/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */
 /*
  * btn-suart.c
  *
  * 18.06.2004 Martin Hinz <btnode@hinz.ch>
  * 
  * \brief In this file SUART will be called sometimes USARTS equal to USART0 
  * and USART1.
  */

#include <string.h>

#include <sys/atom.h>
#include <sys/event.h>
#include <sys/timer.h>

#include <cfg/modem.h>
#include <dev/irqreg.h>
#include <dev/usartavr.h>
#include <suart/btn-suart.h>
#include <arch/btn-hardware.h>

#ifdef NUTTRACER
#include <sys/tracer.h>
#endif

#ifdef __AVR_ATmega128__

/*
 * Local function prototypes.
 */
static int AvrUsartInit(void);
static int AvrUsartDeinit(void);
static void AvrUsartSReceiveInterrupt(void *arg);
static void AvrUsartSTimer(void *arg);
static void AvrUsartTxStart(void);
static void AvrUsartRxStart(void);
static u_long AvrUsartGetStatus(void);
static int AvrUsartSetSpeed(u_long rate);
static u_char AvrUsartGetStopBits(void);
static int AvrUsartSetStopBits(u_char bits);
static u_char AvrUsartGetParity(void);
static int AvrUsartSetParity(u_char mode);
/*!
 * \addtogroup xgUsartAvr
 */
/*@{*/

/*!
 * \brief USARTS device control block structure.
 */
static USARTDCB dcb_usarts = {
    0,                          /* dcb_modeflags */
    0,                          /* dcb_statusflags */
    0,                          /* dcb_rtimeout */
    0,                          /* dcb_wtimeout */
    {0, 0, 0, 0, 0, 0, 0, 0},   /* dcb_tx_rbf */
    {0, 0, 0, 0, 0, 0, 0, 0},   /* dcb_rx_rbf */
    0,                          /* dbc_last_eol */
    AvrUsartInit,               /* dcb_init */
    AvrUsartDeinit,             /* dcb_deinit */
    AvrUsartTxStart,            /* dcb_tx_start */
    AvrUsartRxStart,            /* dcb_rx_start */
    0,                          //not supported AvrUsartSetFlowControl,     /* dcb_set_flow_control */
    0,                          //not supported AvrUsartGetFlowControl,     /* dcb_get_flow_control */
    AvrUsartSetSpeed,           /* dcb_set_speed */
    0,                          //not supported AvrUsartGetSpeed,           /* dcb_get_speed */
    0,                          //not supported AvrUsartSetDataBits,        /* dcb_set_data_bits */
    0,                          //not supported AvrUsartGetDataBits,        /* dcb_get_data_bits */
    AvrUsartSetParity,          /* dcb_set_parity */
    AvrUsartGetParity,          /* dcb_get_parity */
    AvrUsartSetStopBits,        /* dcb_set_stop_bits */
    AvrUsartGetStopBits,        /* dcb_get_stop_bits */
    0,                          //not supported AvrUsartSetStatus,          /* dcb_set_status */
    AvrUsartGetStatus,          /* dcb_get_status */
    0,                          //not supported AvrUsartSetClockMode,       /* dcb_set_clock_mode */
    0,                          //not supported AvrUsartGetClockMode,       /* dcb_get_clock_mode */
};

/*!
 * \name AVR USARTS Device
 */
/*@{*/
/*!
 * \brief USARTS device information structure.
 *
 * An application must pass a pointer to this structure to 
 * NutRegisterDevice() before using the software serial communication
 * driver. (for connection see btn-hardware.h file)
 *
 * The device is named \b uarts.
 *
 * \showinitializer
 */
NUTDEVICE devUsartAvrS = {
    0,                          /* Pointer to next device, dev_next. */
    {'u', 'a', 'r', 't', 's', 0, 0, 0, 0},      /* Unique device name, dev_name. */
    IFTYP_CHAR,                 /* Type of device, dev_type. */
    0,                          /* Base address, dev_base (not used). */
    0,                          /* First interrupt number, dev_irq (not used). */
    0,                          /* Interface control block, dev_icb (not used). */
    &dcb_usarts,                /* Driver control block, dev_dcb. */
    UsartInit,                  /* Driver initialization routine, dev_init. */
    UsartIOCtl,                 /* Driver specific control function, dev_ioctl. */
    UsartRead,                  /* Read from device, dev_read. */
    UsartWrite,                 /* Write to device, dev_write. */
    UsartWrite_P,               /* Write data from program space to device, dev_write_P. */
    UsartOpen,                  /* Open a device or file, dev_open. */
    UsartClose,                 /* Close a device or file, dev_close. */
    0                           /* Request file size, dev_size. */
};




/*!
 * \brief Receiver error flags.
 */
static ureg_t rx_errors;

u_short slow_start;
u_short stop_bits;
u_short stop_bits_counter;
#define dcb_usart   dcb_usarts


#define port_and(port, val) outp((inp(port)&val),port);

#define port_or(port, val)  outp((inp(port)|val),port);

/* software UART Speed
 *
 * We need to use Timer2 to generate interrupts after 1
 * bitlength of the Baudrate.
 *
 * ATTENTION: we need different timings for internal and external memory usage!!!!
 * 
 * SUART_BIT_TIME = ( Xtal / (Baudrate * Prescaling)) - 1
 * (see AVR Manual, page 152ff)
 * For a 7.3728 Mhz Xtal:
 *      38400 Baud: prescale by  8 => 0x02,  SUART_BIT_TIME = 0d23 => 0x17
 *      19200 Baud: prescale by  8 => 0x02,  SUART_BIT_TIME = 0d47 => 0x2F
 *       9600 Baud: prescale by  8 => 0x02,  SUART_BIT_TIME = 0d95 => 0x5F
 *       4800 Baud: prescale by 64 => 0x03,  SUART_BIT_TIME = 0d23 => 0x17
 *       2400 Baud: prescale by 64 => 0x03,  SUART_BIT_TIME = 0d47 => 0x2F
 * 
 * default set to 9600 Baud in btn_suart_init() and can be changed by function 
 * btn_suart_set_baud()
 */
u_char SUART_BIT_TIME;
u_char SUART_BIT_TIME_Prescaler;


// software UART state machine
u_char SUART_state;

// states
#define SUART_IDLE 0
#define SUART_SEND_STARTBIT 1
#define SUART_SEND_DATA 2
#define SUART_SEND_PARITY 3
#define SUART_SEND_STOPBIT 4
#define SUART_SAMPLE_DATA 5
#define SUART_SAMPLE_PARITY 6
#define SUART_SAMPLE_STOPBIT 7
#define SUART_SHIFT_HALFBIT 8

// parity
#define UART_PARITY_NONE 0
#define UART_PARITY_ODD 1
#define UART_PARITY_EVEN 2


// data byte which is sent out or received
u_char SUART_DataByte;

// number of bit sent or received in one transaction
u_char SUART_BitCount;
u_char SUART_ParityCount;

u_char SUART_Parity;


//end new defines and variables


/*
 * \brief Initialize the USART hardware driver.
 *
 * This function is called during device registration by the upper level 
 * USART driver through the USARTDCB jump table.
 * Default settings: 8N1 and 9600 Baud
 *
 * \return 0 on success, -1 otherwise.
 */
static int AvrUsartInit(void)
{
    /*
     * Register receive and transmit interrupts.
     * 
     */
    if (NutRegisterIrqHandler(&sig_SUART_RECV, AvrUsartSReceiveInterrupt, 0))
        return -1;
    if (NutRegisterIrqHandler(&sig_OUTPUT_COMPARE2, AvrUsartSTimer, &dcb_usart)) {
        NutRegisterIrqHandler(&sig_SUART_RECV, 0, 0);
        return -1;
    }
    //and init all register
    // set up TXD port as output
    sbi(SUART_TXD_PORT_DDR, SUART_TXD);
    sbi(SUART_TXD_PORT, SUART_TXD);     // set TXD to high (= idle)
    // enable rx pull-up
    //  -> don't receive rx interrupts if not connected!
    sbi(SUART_RXD_PORT, SUART_RXD);
    SUART_Parity = UART_PARITY_NONE;    //default!
    stop_bits = 1;
    sbi(EICRB, ISC61);          // enable interrupt on falling edge, i.e. startbit
    cbi(EICRB, ISC60);
    //this call maybe has to move to the function AvrUsartRxStart(void)!!!
    sbi(EIMSK, SUART_RXD_INTERRUPT);    // unmask  External interrupt
    //default
    SUART_BIT_TIME_Prescaler = 0x02;
    SUART_BIT_TIME = 0x2F;
    sbi(TCCR2, WGM1);           // Clear Timer on Compare Match
    sbi(TIMSK, OCIE2);          // unMask Timer2 Compare Interupt

    SUART_state = SUART_IDLE;
    SUART_BitCount = 0;
    SUART_DataByte = 0;
    return 0;
}

/*
 * \brief Deinitialize the USART hardware driver.
 *
 * This function is called during device deregistration by the upper 
 * level USART driver through the USARTDCB jump table.
 *
 * \return 0 on success, -1 otherwise.
 */
static int AvrUsartDeinit(void)
{
    /* Deregister receive and transmit interrupts. */
    NutRegisterIrqHandler(&sig_SUART_RECV, 0, 0);
    NutRegisterIrqHandler(&sig_OUTPUT_COMPARE2, 0, 0);
    //disable interrupt
    //this call maybe has to move to the function AvrUsartRxStart(void)!!!
    cbi(EIMSK, SUART_RXD_INTERRUPT);    // unmask  External interrupt on PORTE:4 (RXD);
    return 0;
}

/*
 * \brief Called after the Timer reached the compare value.
 *
 * If this interrupt is triggered we have to send another bit! This interrupt
 * is used for sending and receiving! Receiving not possible during sending.
 * Two timers would be needed to be able to send and receive at the same time
 * or at least flowcontrol for not loosing receive data!
 * 
 * \param arg Pointer to the transmitter ring buffer.
 */
static void AvrUsartSTimer(void *arg)
{

    //arg is the dcb to access the receive AND send ringbuffer
    USARTDCB *dcb = (USARTDCB *) arg;
    register RINGBUF *r_rbf = &(dcb->dcb_rx_rbf);       //receive ring buffer
    register RINGBUF *t_rbf = &(dcb->dcb_tx_rbf);       //transmit ring buffer
    register u_char *t_rbf_cp = t_rbf->rbf_tail;        //char transmit ring buffer
    register size_t cnt;

#ifdef NUTTRACER
    TRACE_ADD_ITEM(TRACE_TAG_INTERRUPT_ENTER, TRACE_INT_SUART_TIMER);
#endif
    switch (SUART_state) {
    case SUART_SEND_STARTBIT:
        if (t_rbf->rbf_cnt--) { //data left to transmit
            //get next DataByte out of trans-buffer
            SUART_DataByte = *t_rbf_cp;
            SUART_BitCount = 0;
            SUART_ParityCount = 0;
            stop_bits_counter = 0;
            SUART_state = SUART_SEND_DATA;
            if (slow_start) {   //if slow start, set timing to normal
                port_and(TCCR2, 0xF8);  //stop timer
                outp(0, TCNT2); //set Timer2 to 0
                outp(SUART_BIT_TIME, OCR2);     //set correct timing!
                port_or(TCCR2, SUART_BIT_TIME_Prescaler);       //start timer
                slow_start = 0; //slow start done
            }
            // set TXD to low => this is Start Bit
            cbi(SUART_TXD_PORT, SUART_TXD);
        } else {                //no more data
            t_rbf->rbf_cnt = 0;
            NutEventPostAsync(&t_rbf->rbf_que);
            SUART_state = SUART_IDLE;
            port_and(TCCR2, 0xF8);      //stop Timer2
            // Enable RX again (receive interrupt enable)
            sbi(EIMSK, SUART_RXD_INTERRUPT);
        }
        break;
    case SUART_SEND_DATA:
        if (SUART_DataByte & 0x01) {
            sbi(SUART_TXD_PORT, SUART_TXD);
            SUART_ParityCount++;
        } else {
            cbi(SUART_TXD_PORT, SUART_TXD);
        }
        SUART_BitCount++;
        if (SUART_BitCount == 8) {
            // all data has been sent
            if (SUART_Parity == UART_PARITY_NONE) {
                SUART_state = SUART_SEND_STOPBIT;
            } else {
                SUART_state = SUART_SEND_PARITY;
            }
        } else {
            SUART_DataByte = (SUART_DataByte >> 1);     // shift Data Byte
        }
        break;
    case SUART_SEND_PARITY:
        if (SUART_Parity == UART_PARITY_ODD) {
            if (SUART_ParityCount & 0x01) {
                cbi(SUART_TXD_PORT, SUART_TXD);
            } else {
                sbi(SUART_TXD_PORT, SUART_TXD);
            }
        } else {                // UART_PARITY_EVEN
            if (SUART_ParityCount & 0x01) {
                sbi(SUART_TXD_PORT, SUART_TXD);
            } else {
                cbi(SUART_TXD_PORT, SUART_TXD);
            }
        }
        SUART_state = SUART_SEND_STOPBIT;
        break;
    case SUART_SEND_STOPBIT:
        sbi(SUART_TXD_PORT, SUART_TXD);
        stop_bits_counter++;
        if (stop_bits_counter == stop_bits) {
            /*
             * Wrap around the buffer pointer if we reached its end.
             */
            if (++t_rbf_cp == t_rbf->rbf_last) {
                t_rbf_cp = t_rbf->rbf_start;
            }
            t_rbf->rbf_tail = t_rbf_cp;
            if (t_rbf->rbf_cnt == t_rbf->rbf_lwm) {     //what is that for????
                NutEventPostAsync(&t_rbf->rbf_que);
            }
            //check in the startbit, if more data to send!
            SUART_state = SUART_SEND_STARTBIT;
        }
        break;
    case SUART_IDLE:
        // all data send
        port_and(TCCR2, 0xF8);  //stop timer
        // Enable RX again (receive interrupt enable)
        sbi(EIMSK, SUART_RXD_INTERRUPT);
        break;
        //receiving part *******************************************************      
    case SUART_SHIFT_HALFBIT:
        outp(0x00, TCNT2);      // set Timer2 to zero
        outp(SUART_BIT_TIME, OCR2);     // setting CompareRegister to SUART_BIT_TIME
        SUART_state = SUART_SAMPLE_DATA;
        break;
    case SUART_SAMPLE_DATA:
        // sample databit
        if (bit_is_set(SUART_RXD_PIN, SUART_RXD)) {
            SUART_DataByte = SUART_DataByte | 0x80;
            SUART_ParityCount++;
        } else {
            SUART_DataByte = SUART_DataByte & 0x7f;
        }
        SUART_BitCount++;
        if (SUART_BitCount == 8) {
            if (SUART_Parity == UART_PARITY_NONE) {
                SUART_state = SUART_SAMPLE_STOPBIT;
            } else {
                SUART_state = SUART_SAMPLE_PARITY;
            }
        } else {
            SUART_DataByte = SUART_DataByte >> 1;
        }
        break;
    case SUART_SAMPLE_PARITY:
        if (SUART_Parity == UART_PARITY_ODD) {
            if (SUART_ParityCount & 0x01) {
                if (bit_is_set(SUART_RXD_PIN, SUART_RXD)) {
                    // parity error
                    rx_errors |= _BV(UPE);
                }
            } else {
                if (!bit_is_set(SUART_RXD_PIN, SUART_RXD)) {
                    // parity error
                    rx_errors |= _BV(UPE);
                }
            }
        } else {                // UART_PARITY_EVEN
            if (SUART_ParityCount & 0x01) {
                if (!bit_is_set(SUART_RXD_PIN, SUART_RXD)) {
                    // parity error
                    rx_errors |= _BV(UPE);
                }
            } else {
                if (bit_is_set(SUART_RXD_PIN, SUART_RXD)) {
                    // parity error
                    rx_errors |= _BV(UPE);
                }
            }
        }
        SUART_state = SUART_SAMPLE_STOPBIT;
        break;
    case SUART_SAMPLE_STOPBIT:
        stop_bits_counter++;
        if (bit_is_clear(SUART_RXD_PIN, SUART_RXD)) {  //check if stop bit
            //error of framing
            rx_errors |= _BV(FE);
        }
        if (stop_bits_counter == stop_bits) {
            // we have sampled a complete byte here..
            port_and(TCCR2, 0xF8);      //stop timer
            SUART_state = SUART_IDLE;
            sbi(EIFR, SUART_RXD_INTERRUPT);
            // clear interrupt flag here, since the transmission had 
            // several edges which set the flag.
            // If we omit this, we will jump directly into 
            // SUART_RXD_INTERRUPT after returning from SIG_OUTPUT_COMPARE2
            // Enable RX again (receive interrupt enable)
            sbi(EIMSK, SUART_RXD_INTERRUPT);

            /*
             * Check buffer overflow.
             */
            cnt = r_rbf->rbf_cnt;
            if (cnt >= r_rbf->rbf_siz) {
                rx_errors |= _BV(DOR);
                return;
            }

            /* Wake up waiting threads if this is the first byte in the buffer. */
            if (cnt++ == 0) {
                NutEventPostAsync(&r_rbf->rbf_que);
            }
            /* 
             * Store the character and increment and the ring buffer pointer. 
             */
            *r_rbf->rbf_head++ = SUART_DataByte;
            if (r_rbf->rbf_head == r_rbf->rbf_last) {
                r_rbf->rbf_head = r_rbf->rbf_start;
            }

            /* Update the ring buffer counter. */
            r_rbf->rbf_cnt = cnt;
        }
        break;
    default:
        // This should not happen and is an ERROR 
        port_and(TCCR2, 0xF8);  //stop timer
        SUART_state = SUART_IDLE;
        break;
    }
#ifdef NUTTRACER
    TRACE_ADD_ITEM(TRACE_TAG_INTERRUPT_EXIT, TRACE_INT_SUART_TIMER)
#endif
}

/*
 * \brief Interrupt on USARTS receive port.
 *
 *
 * \param arg Pointer to the receiver ring buffer.
 */
static void AvrUsartSReceiveInterrupt(void *arg)
{

#ifdef NUTTRACER
    TRACE_ADD_ITEM(TRACE_TAG_INTERRUPT_ENTER, TRACE_INT_SUART_RX)
#endif
        // if we are called when not idle sth. screwed up
        if (SUART_state == SUART_IDLE) {

        // we are in the middle of the incoming startbit. if we sample 0
        // here, we continue to sample data, otherwise we return to idle state
        if (bit_is_clear(SUART_RXD_PIN, SUART_RXD)) {
            // we seem to have a valid startbit
            // set Timer2 to zero -> timing is critical now
            //outp(0x00, TCNT2);        // set Timer2 half the bit-time
            outp(0x00, TCNT2);  // set Timer2 to zero
            outp(SUART_BIT_TIME >> 1, OCR2);    // setting CompareRegister to SUART_BIT_TIME/2
            // sampling is done in the middle of a bit (blum, 21.12.04)
            port_or(TCCR2, SUART_BIT_TIME_Prescaler);   // Start Timer2, Prescaling with factor

            // mask interrupt
            cbi(EIMSK, SUART_RXD_INTERRUPT);    // mask (=disable) receive interrupt

            // next state
            SUART_state = SUART_SHIFT_HALFBIT;
            SUART_ParityCount = 0;
            SUART_BitCount = 0;
            SUART_DataByte = 0;
            stop_bits_counter = 0;
        }
    } else {
        // do nothing..
        // NOTE: IF WE GET HERE.. WE SCREWED UP
        // NO ERRORHANDLING IS DONE IF OTHER PARTY SEND WHILE RTS IS LOW AND WE
        // ARE SENDING!!!!
        // debug_out_string("ERROR: RXD activity while sending data\n\r");
        // maybe implement flow control or suart with 2 timer for receive and send
        // at same time!?
    }
#ifdef NUTTRACER
    TRACE_ADD_ITEM(TRACE_TAG_INTERRUPT_EXIT, TRACE_INT_SUART_RX)
#endif
}


/*!
 * \brief Start the USART software counter (Timer 2) for sending data.
 *
 * The upper level USART driver will call this function through the 
 * USARTDCB jump table each time it added one or more bytes to the 
 * transmit buffer.
 */
static void AvrUsartTxStart(void)
{
    if (SUART_state != SUART_IDLE)      //if already sending, do nothing
        return;
    //data for sending

    // ATTENTION: THIS NEEDS TO BE ATOMIC => DISABLE INTERRUPTS
    // because arriving data can set the SUART_state to not idle

    NutEnterCritical();         // disable global interrupts

    if (SUART_state == SUART_IDLE) {    //check if uart is not running yet!!!
        // disable RX during TX (receive interrupt disable)
        cbi(EIMSK, SUART_RXD_INTERRUPT);
        //first byte needs a slow start, send start bit after about 1ms
        //without slow start the star bit is longer than one bit and messes up
        //the transmission (mhinz)
        slow_start = 1;
        outp(0x00, TCNT2);      //set timer to zero 
        //next state: send start bit
        SUART_state = SUART_SEND_STARTBIT;
        outp(0x5F, OCR2);       //slow start count up high ...
        port_or(TCCR2, 4);      //... and slowely

    }
    NutExitCritical();          // enable interrupts
}

/*!
 * \brief Start the USART receiver hardware.
 *
 * The upper level USART driver will call this function through the 
 * USARTDCB jump table each time it removed enough bytes from the 
 * receive buffer. Enough means, that the number of bytes left in
 * the buffer is below the low watermark.
 */
static void AvrUsartRxStart(void)
{
    //nothing to be done
}

/*!
 * \brief Set the USART software bit rate.
 *
 * This function is called by ioctl function of the upper level USART 
 * driver through the USARTDCB jump table.
 *
 * Only baud supported: 2400, 4800, 9600, 19200(38400 not working very reliable)
 * Transmission and reception problems occure if exact bit-timing is
 * interfered by hign CPU load (in particular high interrupt activities)
 * 
 * \param rate Number of bits per second.
 *
 * \return 0 on success, -1 otherwise.
 */
static int AvrUsartSetSpeed(u_long rate)
{
    switch (rate) {
    case 38400:
        SUART_BIT_TIME_Prescaler = 0x02;
        SUART_BIT_TIME = 0x17;
        break;
    case 19200:
        SUART_BIT_TIME_Prescaler = 0x02;
        SUART_BIT_TIME = 0x2F;
        break;
    case 9600:
        SUART_BIT_TIME_Prescaler = 0x02;
        SUART_BIT_TIME = 0x5F;
        break;
    case 4800:
        SUART_BIT_TIME_Prescaler = 0x03;
        SUART_BIT_TIME = 0x17;
        break;
    case 2400:
        SUART_BIT_TIME_Prescaler = 0x03;
        SUART_BIT_TIME = 0x2F;
        break;
    default:
        SUART_BIT_TIME_Prescaler = 0x02;
        SUART_BIT_TIME = 0x5F;
        return -1;
    }
    outp(SUART_BIT_TIME, OCR2); // setting CompareRegister to SUART_BIT_TIME   
    return 0;
}


/*!
 * \brief Query the USART software status.
 * 
 * Returns status of following errors:
 * - framing
 * - buffer overrun
 * - party
 *
 * \return Status flags.
 */
static u_long AvrUsartGetStatus(void)
{
    u_long rc = 0;
    /*
     * Set receiver error flags.
     */
    if ((rx_errors & _BV(FE)) != 0) {
        rc |= UART_FRAMINGERROR;
    }
    if ((rx_errors & _BV(DOR)) != 0) {
        rc |= UART_OVERRUNERROR;
    }
    if ((rx_errors & _BV(UPE)) != 0) {
        rc |= UART_PARITYERROR;
    }
    return rc;
}

/*!
 * \brief Set the USART software to the specified parity mode.
 *
 * This routine is called by ioctl function of the upper level USART 
 * driver through the USARTDCB jump table.
 *
 * \param mode 0 (disabled), 1 (odd) or 2 (even)
 *
 * \return 0 on success, -1 otherwise.
 */
static int AvrUsartSetParity(u_char mode)
{
    if (mode < 3) {
        SUART_Parity = mode;
        return 0;
    } else {
        SUART_Parity = UART_PARITY_NONE;
        return -1;
    }
}

/*!
 * \brief Query the USART software for the parity mode.
 *
 * This routine is called by ioctl function of the upper level USART 
 * driver through the USARTDCB jump table.
 *
 * \return Parity mode, either 0 (disabled), 1 (odd) or 2 (even).
 */
static u_char AvrUsartGetParity(void)
{
    return SUART_Parity;
}

/*!
 * \brief Set the USART software to the number of stop bits.
 *
 * This routine is called by ioctl function of the upper level USART 
 * driver through the USARTDCB jump table.
 *
 * \return 0 on success, -1 otherwise.
 */
static int AvrUsartSetStopBits(u_char bits)
{
    if ((bits - 1) < 2) {
        stop_bits = bits;
        return 0;
    } else
        return -1;
}

/*!
 * \brief Query the USART software for the number of stop bits.
 *
 * This routine is called by ioctl function of the upper level USART 
 * driver through the USARTDCB jump table.
 *
 * \return The number of stop bits set, either 1 or 2.
 */
static u_char AvrUsartGetStopBits(void)
{
    return stop_bits;
}

#else
/** to avoid warnings during linking if compiled for unix emulation, we add a dummy variable */
u_char btn_suart_dummy = 0;
#endif
