/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */


/**
 * \file support/rprog.c
 *
 * \date 14.04.2005
 *
 * \author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 * \author Matthias Ringwald <mringwal@inf.ethz.ch>
 *
 * \brief btnode library to add remote programming cability (over L2CAP)
 *
 * \note using buffer handling from btnode/bt/bt_rfcomm.c
 *       Ole Reinhardt <ole.reinhardt@embedded-it.de>
 */

#include <arch/btn-hardware.h>
#include <sys/types.h>
#include <bt/bt_l2cap.h>

#ifdef MCU_ATMEGA128

#include <string.h>
#include <hardware/btn-bat.h>
#include <hardware/ram_banks.h>
#include <bt/bt_hci_cmds.h>
#include <sys/timer.h>
#include <sys/heap.h>
#include <sys/event.h>
#include <sys/semaphore.h>
#include <sys/thread.h>
#include <sys/semaphore.h>

#include <support/bootloader.h>

#include <avr/wdt.h>

#if __AVR_LIBC_VERSION__ >= 10400UL
#include <util/crc16.h>
#else
#include <avr/crc16.h>
#endif

#include <support/bt_remoteprog.h>


/* header for bootloader
 * ----------------------------------------------------------------------------
 * | prog_type | prog_ver | active_flag | prog_len | CRC |  ...data...  | CRC |
 * ----------------------------------------------------------------------------
 *       1           4           1           4        2      prog_len      2
 */

/* SET_PROG_MODE packet
 * --------------------------
 * | SET_PROG_MODE | length |
 * --------------------------
 *         1           3
 */

/* SET_PROG_MODE_ARG packet
 * --------------------------------
 * | SET_PROG_MODE | length | arg |
 * --------------------------------
 *         1           3       1
 */

/* data packet
 * ---------------------------------
 * | DATA | SEQ_NUM | ...data_i... |
 * ---------------------------------
 *     1       1          rest
 */

// data packets will be ACKED?
#define ACKED 1

// debug mode
#define TDEBUG 0

#define MAXMTU 672

// nr of packets received without ack (needs to 2^n -1)
#define ACK_MODULO 3

// nr of packets buffers to allocate
#define NR_BUFFERS 8

// PSM (my default for Remote Programming)
#define BTN_PSM 0xFFEF

// stacksize of thread PROG
#define STACKSIZE 512

// Maximum length of upload program
#define PROG_MAXLENGTH XBANK_PREND-XBANK_PRSTART

#define GET_PAYLOAD_LEN(l2cap_buffer_entry) (l2cap_buffer_entry->pkt->len[0])+((l2cap_buffer_entry->pkt->len[1])*256)

#define BUFF_FREE 0x00
#define BUFF_USED 0x01

#if TDEBUG > 0
#define INFO(text, ...) printf_P(PSTR(text "\n"),## __VA_ARGS__);
#define WARN(text, ...) printf_P(PSTR("WARN: " text "\n"),## __VA_ARGS__);
#define ERROR(text, ...) printf_P(PSTR("ERROR: " text "\n"),## __VA_ARGS__);
#else
#define INFO(text, ...)
#define WARN(text, ...)
#define ERROR(text, ...)
#endif


/** 
 * types
 */

struct pkt_buffer_entry
{
    struct bt_l2cap_acl_pkt *pkt;
    u_short channel_id;
    u_short sequence_nr;
    u_char state;
} __attribute__ ((packed));


/**
 * globals
 */

static SEM packetsReady;

static u_short l2cap_sequence_nr;

static struct pkt_buffer_entry *bt_reprog_buffer;
static u_char buffer_size;

static u_char connected = 0;

// packet for sending
static struct bt_l2cap_acl_pkt *spkt;

// buffer for sending bytes
static u_char sendbuf[10];

static u_short prog_channel_id;

static u_long prog_len = 0;

static u_long prog_counter = 0;

static u_char prog_mode = PROG_MODE_READY;

static u_int seq_num = 0;

RP_RESET_CB;

static u_char arg = 0;

static u_char clear[1] = {0};

static void clear_bootloader_header(void)
{
    // set AKTIV_FLAG to 0
    cpy_to_xbank(clear, XBANK_PRSTART+MEM_OFFSET_AKTIV_FLAG, 1);

    INFO("clear bootloader header");
}

static void rp_l2cap_con_cb(u_char type, u_char detail, u_char service_nr,
    u_short channel_id, void *arg)
{
    if ( type == BT_L2CAP_CONNECT )
    {
        INFO("connect...\n");
        connected = 1;
    }
    else
    {
        INFO("disconnect...\n");
        connected = 0;

        if (prog_mode == PROG_MODE_PROGRAMMING)
        {
            clear_bootloader_header();
            INFO("programming mode off\n");
            prog_mode = PROG_MODE_READY;
        }
    }
}

static void rp_l2cap_rcv_cb(struct bt_l2cap_acl_pkt *pkt, u_char service_nr,
    u_short channel_id, void *arg)
{
    u_char idx;

    for (idx=0; idx<buffer_size; idx++)
    {
        if (bt_reprog_buffer[idx].state == BUFF_FREE)
            break;
    }

    if (idx == buffer_size)
    {
        ERROR("No ressource free... drop l2cap pkt\n");
        bt_l2cap_complete_pkt(pkt);
        return;
    }

#if TDEBUG > 0
    printf("Received (%d): ", idx);
    int i;
    for (i=0; i<3 ; i++)
        printf("  0x%02X", pkt->payload[i]);
    printf("\n");
#endif
    
    bt_reprog_buffer[idx].pkt = pkt;
    bt_reprog_buffer[idx].channel_id = channel_id;
    bt_reprog_buffer[idx].state = BUFF_USED;
    l2cap_sequence_nr++;
    bt_reprog_buffer[idx].sequence_nr = l2cap_sequence_nr;

    NutSemPost( &packetsReady );
}

#if ACKED > 0
static u_short get_crc(u_char *buffer, u_int len)
{
    u_short crc16 = 0;

    int i;

    for (i = 0; i< len; i++)
    {
        crc16 = _crc16_update(crc16, buffer[i]);
    }

    return crc16;
}
#endif

static void complete_buffer(struct pkt_buffer_entry *buffer)
{
    bt_l2cap_complete_pkt(buffer->pkt);
    buffer->pkt = NULL;
    buffer->channel_id = 0;
    buffer->sequence_nr = 0;
    buffer->state = BUFF_FREE;
}

/*
 * send message
 */
static void sendmsg(short len)
{
    INFO("sending reply...");
    if (TDEBUG)
    {
        int i;
        for (i=0; i<len; i++)
            printf("  0x%02X", sendbuf[i]);
    }
    INFO("");

    memcpy(spkt->payload, sendbuf, len);
    if (connected)
        bt_l2cap_send(prog_channel_id, spkt, len);
}

static void sendack(void)
{
    sendbuf[0] = ACK;
    sendmsg(1);
}

static void sendnack(u_char errorcode)
{
    sendbuf[0] = NACK & errorcode;
    sendmsg(1);
}

static void warnlength(u_char len)
{
    WARN("payload length is not %d", len);
    sendnack(16);
}

static void handle_prog_mode(struct pkt_buffer_entry *buffer)
{
    INFO("length in hex: %02x %02x %02x",  buffer->pkt->payload[1],  buffer->pkt->payload[2],  buffer->pkt->payload[3]);

    prog_len = ( ((u_long) buffer->pkt->payload[3]) << 16 |
                 ((u_long) buffer->pkt->payload[2]) <<  8 | 
                 ((u_long) buffer->pkt->payload[1]));

    INFO("length of prog: %lu", prog_len);

    if ( prog_len>0 && prog_len<=PROG_MAXLENGTH )
    {
        prog_counter = 0;

        seq_num = 1;

        prog_mode = PROG_MODE_PROGRAMMING;

        INFO("programming mode on");

        sendack();
    }
    else
    {
        WARN("program length overflow");
        sendnack(17);
    }
}

static void handle_data(struct pkt_buffer_entry *buffer)
{
    u_char failed;
#if ACKED > 0  
    u_short c;
    u_char crc[ACK_LEN];
#endif
    INFO("storing data seq: (%u) (%u) @ (%u).", buffer->pkt->payload[1] + (buffer->pkt->payload[2]<<8), GET_PAYLOAD_LEN(buffer) - DATA_LEN, prog_counter);

    // dont forget the crc...
    if ( prog_counter < prog_len + CRC_LEN )
    {

        failed = cpy_to_xbank(&buffer->pkt->payload[DATA_LEN],
            XBANK_PRSTART+MEM_LEN_HEADER+MEM_CRC+prog_counter, GET_PAYLOAD_LEN(buffer) - DATA_LEN);

       INFO("result (%d).", failed);

        if ( !failed )
        {
            prog_counter += GET_PAYLOAD_LEN(buffer) - DATA_LEN;

            // dont forget the crc...
            if ( prog_len + CRC_LEN == prog_counter )
            {
                INFO("programm data successful uploaded");

                // write the bootloader header
                u_char header[MEM_LEN_HEADER];
                // prog_type
                header[MEM_OFFSET_PROG_TYPE] = REPROG_BTNODE_PROGRAM_DATA;
                // prog_ver
                header[MEM_OFFSET_PROG_VER] = 0;
                header[MEM_OFFSET_PROG_VER+1] = 0;
                header[MEM_OFFSET_PROG_VER+2] = 0;
                header[MEM_OFFSET_PROG_VER+3] = 0;
                // active_flag
                header[MEM_OFFSET_AKTIV_FLAG] = REPROG_BOOT_ACTIVE;
                // prog_len
                header[MEM_OFFSET_PROG_LEN]   = 0;
                header[MEM_OFFSET_PROG_LEN+1] = (prog_len>>16) & 0xff;
                header[MEM_OFFSET_PROG_LEN+2] = (prog_len>>8)  & 0xff;
                header[MEM_OFFSET_PROG_LEN+3] =  prog_len      & 0xff;

                failed = cpy_to_xbank(header, XBANK_PRSTART, MEM_LEN_HEADER);

                // check prog checksum
                if (!failed && !check_xbank_crc(
                    XBANK_PRSTART+MEM_LEN_HEADER+MEM_CRC,
                    XBANK_PRSTART+MEM_LEN_HEADER+MEM_CRC+prog_len) )
                {
                    INFO("write bootloader header");

                    update_xbank_crc(XBANK_PRSTART,
                        XBANK_PRSTART+MEM_LEN_HEADER);

                    INFO("write bootloader crc");

                    prog_mode = PROG_MODE_PROGRAMMED;

                    INFO("programming mode locked");

                    sendbuf[0] = ACK;
                    sendbuf[1] = END;
                    sendmsg(2);

                    u_char doReset = 1;

                    if (reset_cb)
                        doReset = reset_cb(arg);

                    if (doReset)
                    {
                        // enable watchdog timer
                        wdt_enable(WDTO_500MS);

                        NutSleep(500);

                        // reset in 0.5 s and boot into new image...
                    }
                }
                else
                {
                    if (failed)
                    {
                        ERROR("cannot write checksum for header");
                    }
                    else
                    {
                        ERROR("checksum of program data not correct");
                        INFO("0x%04X calculated, but transmitted was 0x%04X",
                            get_xbank_crc(XBANK_PRSTART+MEM_LEN_HEADER+MEM_CRC,
                                XBANK_PRSTART+MEM_LEN_HEADER+MEM_CRC+prog_len),
                            (buffer->pkt->payload[2] << 8) +
                                buffer->pkt->payload[1]);
                    }

                    prog_mode = PROG_MODE_READY;
                    INFO("programming mode off");

                    sendnack(32);
                }
            }
            else
            {
#if ACKED > 0       
                c = get_crc(buffer->pkt->payload, GET_PAYLOAD_LEN(buffer) );
                crc[0] = ACK;
                crc[1] =  seq_num       & 0xff;
                crc[2] = (seq_num >> 8) & 0xff;
                crc[3] =  c       & 0xff;
                crc[4] = (c >> 8) & 0xff;
                if ( (prog_len == prog_counter ) ||
                     ((seq_num & ACK_MODULO) == 0)    )  {
                    memcpy(sendbuf, crc, ACK_LEN);
                    sendmsg(ACK_LEN);
                }
#endif
                seq_num++;
            }
        }
        else
        {
            WARN("write not successful");
            sendnack(48);
        }
    }
    else
    {
        ERROR("data overrun.");

        prog_mode = PROG_MODE_READY;
        ERROR("programming mode off");

        sendnack(18);
    }
}

static void handle_pkt(struct pkt_buffer_entry *buffer)
{
    prog_channel_id = buffer->channel_id;

    switch (prog_mode)
    {
        // not programmed
        case (PROG_MODE_READY):
        {
            switch (buffer->pkt->payload[0])
            {
                case (PUT_PROG_MODE):
                {
                    INFO("put_prog_mode");

                    if ( GET_PAYLOAD_LEN(buffer) != PUT_PROG_MODE_LEN)
                    {
                        warnlength(PUT_PROG_MODE_LEN);
                        break;
                    }

                    arg = 0;

                    handle_prog_mode(buffer);

                    break;
                }
                case (PUT_PROG_MODE_ARG):
                {
                    INFO("put_prog_mode_arg");

                    if ( GET_PAYLOAD_LEN(buffer) != PUT_PROG_MODE_ARG_LEN)
                    {
                        warnlength(PUT_PROG_MODE_ARG_LEN);
                        break;
                    }

                    arg = buffer->pkt->payload[4];

                    INFO("argument: 0x%02X", arg);

                    handle_prog_mode(buffer);

                    break;
                }
                case (GET_MAX_MTU):
                {
                    INFO("get_max_mtu");

                    if ( GET_PAYLOAD_LEN(buffer) != GET_MAX_MTU_LEN)
                    {
                        warnlength(GET_MAX_MTU_LEN);
                        break;
                    }

                    sendbuf[0] = ACK;
                    sendbuf[1] = (MAXMTU >> 8) & 0xff;
                    sendbuf[2] =  MAXMTU       & 0xff;
                    sendmsg(3);

                    break;
                }
                default:
                {
                    WARN("unknown code (0): 0x%02X", buffer->pkt->payload[0]);
                    sendnack(prog_mode);
                }
            }

            break;
        }
        // programming...
        case (PROG_MODE_PROGRAMMING):
        {
            switch (buffer->pkt->payload[0])
            {
                case (DATA):
                {
                    if (GET_PAYLOAD_LEN(buffer) <= DATA_LEN)
                    {
                        WARN("no data in payload\n");
                        break;
                    }

                    // check sequence number
                    if (seq_num != buffer->pkt->payload[1] + (buffer->pkt->payload[2]<<8))
                    {
                        ERROR("sequence number in payload is wrong");
                        INFO("sequence number is 0x%02X, but received 0x%02X",
                            seq_num, buffer->pkt->payload[1]);

                        sendnack(64);

                        break;
                    }

                    handle_data(buffer);

                    break;
                }
                case (CANCEL_PROG_MODE):
                {
                    INFO("cancel_prog_mode");

                    if ( GET_PAYLOAD_LEN(buffer) != CANCEL_PROG_MODE_LEN)
                    {
                        warnlength(CANCEL_PROG_MODE_LEN);
                        break;
                    }

                    prog_mode = PROG_MODE_READY;

                    INFO("programming mode off");

                    sendack();

                    break;
                }
                default:
                {
                    WARN("unknown code (1): 0x%02X", buffer->pkt->payload[0]);
                    sendnack(prog_mode);
                }
            }

            break;
        }
        // programmed
        case (PROG_MODE_PROGRAMMED):
        {
            switch (buffer->pkt->payload[0])
            {
                case (CANCEL_PROG_MODE):
                {
                    INFO("cancel_prog_mode");

                    if ( GET_PAYLOAD_LEN(buffer) != CANCEL_PROG_MODE_LEN)
                    {
                        warnlength(CANCEL_PROG_MODE_LEN);
                        break;
                    }

                    clear_bootloader_header();

                    INFO("reset bootloader header");

                    prog_mode = PROG_MODE_READY;

                    INFO("programming mode off");

                    sendack();

                    break;
                }
                default:
                {
                    WARN("unknown code (2): 0x%02X", buffer->pkt->payload[0]);
                    sendnack(prog_mode);
                }
            }

            break;
        }
    }

    INFO("");

    // free packet
    complete_buffer(buffer);
}



THREAD(PROG,arg)
{
    u_short l2cap_sequence_nr = 0x0000;
    u_char idx;
    struct pkt_buffer_entry *buffer;

    NutSemInit( &packetsReady, 0);

    for (;;)
    {
        NutSemWait( &packetsReady );

        for (idx=0; idx<buffer_size; idx++)
        {
            buffer = &bt_reprog_buffer[idx];
            if ( (buffer->state == BUFF_USED) &&
                 (buffer->sequence_nr == (l2cap_sequence_nr+1)) )
            {
                handle_pkt(buffer);
                l2cap_sequence_nr++;
            }
        }
    }
}

u_char bt_remoteprog_init(struct bt_l2cap_stack* l2cap_stack,
    u_char (*my_reset_cb) (u_char arg))
{
    u_char idx;
    INFO("allocate pkt buffer.")

    buffer_size = NR_BUFFERS;
    bt_reprog_buffer = NutHeapAllocClear(sizeof(struct pkt_buffer_entry) * buffer_size);

    if (bt_reprog_buffer == NULL)
    {
        ERROR("out of memory...\n");
        return -1;
    }

    for (idx=0; idx<buffer_size; idx++)
    {
        bt_reprog_buffer[idx].pkt = NULL;
        bt_reprog_buffer[idx].sequence_nr = 0x0000;
        bt_reprog_buffer[idx].state = BUFF_FREE;
    }
    
    // buffer for sending
    spkt = NutHeapAlloc(10 + BT_L2CAP_ACL_PKT_HDR_LEN);

    INFO("register service for Remote Programming.");

    if ( bt_l2cap_register_service(BTN_PSM, 0, BT_L2CAP_MIN_MTU, MAXMTU,
        rp_l2cap_con_cb, rp_l2cap_rcv_cb, NULL) == BT_L2CAP_SERVICENR_INVALID )
    {
        ERROR("cannot register service...\n");
        return -2;
    }

    reset_cb = my_reset_cb;

    INFO("max. MTU: %u\n", MAXMTU);

    INFO("start listener thread.\n");
    NutThreadCreate("prog", PROG, 0, STACKSIZE);

    return 0;

}
#else // non-avr
u_char bt_remoteprog_init(struct bt_l2cap_stack* l2cap_stack,
                          u_char (*my_reset_cb) (u_char arg)) {
    return 0;
}

#endif
