#include <io.h>
#include <stdio.h>
#include <string.h>
#include <dev/usart.h>
#include <terminal/btn-terminal.h>
#include <bt/bt_hci_api.h>
#include <ctype.h>
#include <debug/toolbox.h>

#define HEX2BYTE(c) ((u_char)(((c)<='9') ? (c)-'0' : tolower(c) - 'a' + 10))

static char _dbg_bt_addr_buf[18];

char* dbg_str_to_hex_str(char* buf, u_char* str, u_short size) {
	u_char i;
   	char* ptr = buf;
   	for (i=0; i<size; i++) {
   		ptr += sprintf(ptr, "%.2x ", str[i]);
   	}
   	return buf;
}


void bt_print_bt_addr(bt_addr_t addr)
{
    tprintf("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x", addr[5], addr[4], addr[3], addr[2], addr[1], addr[0]);
}


char* dbg_bt_addr_to_str(bt_addr_t addr)
{
    sprintf( _dbg_bt_addr_buf, "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x",
               addr[5], addr[4], addr[3], addr[2], addr[1], addr[0]);
    return _dbg_bt_addr_buf;
}

char* string_to_bt_addr(char* str, char* addr)
{
    char i;
    char *strp = str;
    // skip whitespace
    while(*strp == ' ')
        strp++;
        
    for(i = BD_ADDR_LEN-1; i >= 0; i--){
        if(isxdigit(strp[0]) && isxdigit(strp[1])){
            addr[(u_char) i] = HEX2BYTE(strp[0]) << 4 | HEX2BYTE(strp[1]);
            strp+=2;
        }else{
            break;
        }
        // skip ':'
        if(i > 0){
            if(*strp == ':')
                strp++;
            else
                break;
        }
    }
    
    // set addr to bt_addr_null, if no address read
    if(i >= 0){
        memcpy(addr, bt_addr_null, BD_ADDR_LEN);
        return str;
    }
    return strp;
}

u_char user_input( FILE* stream, char *buffer, u_char count)
{
    u_char pos = 0;
    while (pos < count-1) {
        _read(_fileno(stream), buffer + pos, 1);
        
        // backspace?
        if (buffer[pos] == 0x8 || buffer[pos] == 0x7f) {
            if (pos > 0) {
                tprintf("\b \b");
                pos--;
            }
        // return?
        } else if (buffer[pos] == '\n' || buffer[pos] == '\r') {
            tprintf("\n");
            break;
        } else {  
            // echo char              
            tprintf("%c", *(buffer+pos));
            pos++;
        }
    }
    // null terminate input
    buffer[pos] = '\0';
    // return length of the string
    return pos+1;
}

u_char get_uart_errors(int fd)
{
    u_long parameter;
    u_char errors;
    // check driver status
    _ioctl(fd, UART_GETSTATUS, &parameter);

    if (parameter & UART_ERRORS) {
       errors = (u_char) (parameter & UART_ERRORS);
       // set error flags back to normal
       parameter = UART_ERRORS;
       _ioctl(fd, UART_SETSTATUS, &parameter);
    } else {
       errors = 0;
    }
    return errors;
}
