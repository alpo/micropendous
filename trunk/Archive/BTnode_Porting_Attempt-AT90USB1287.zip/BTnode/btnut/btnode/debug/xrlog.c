#include <string.h>
#include <debug/xrlog.h>
#include <sys/heap.h>
#include <hardware/ram_banks.h>
#include <stdio.h>

#define XRLOG_MAX_NR_HANDLES	3

struct xrlog_hdl_s {
	xrlog_t* xrlog;
	u_short pos;
	u_short rem_size;	// nr of valid remaining bytes
	u_char state;
};

// Note: modulo operations would clearify the code, but would be inefficient!

// log ring buf
struct xrlog_s {
	u_long mem_start;
        ///< Start address of the buffer (in extended memory)
	u_short pos;
        ///< Current position in the buffer (most recent byte written)
	u_short size;		///< Number of currently buffered bytes
	u_short max_size;	///< Maximal nr. of bytes that can be buffered
	xrlog_hdl_t hdls[XRLOG_MAX_NR_HANDLES];
};


// writes data to the log ring buffer
short xrlog_write(xrlog_t* xrlog, u_char* buf, u_short len)
{
	u_char i;
    u_short rem;	// nr of remaining bytes

    // don't write more data than buffer is able to handle
    if (len > xrlog->max_size)
    {
		return XRLOG_ERR_INVALID_DATA_ACCESS;
    }
    
    // adjust buffer size
    if (xrlog->size > xrlog->max_size - len)
    {
        xrlog->size = xrlog->max_size;
    }
    else
    {
        xrlog->size += len;
    }
        
    // update handles
    for (i=0; i<XRLOG_MAX_NR_HANDLES; i++)
    {
    	// only update valid handles
    	if (xrlog->hdls[i].state == XRLOG_HDL_VALID)
    	{
    		// if the log buffer is full, we have to decrease the nr of remaining bytes
    		if (xrlog->size == xrlog->max_size)
    		{
    			// invalidate handle if necessary
    			if (xrlog->hdls[i].rem_size < len)
    			{
    				xrlog->hdls[i].state = XRLOG_HDL_INVALID;
    				xrlog->hdls[i].rem_size = 0;
    			}
    			// else, just update nr of remaining bytes
    			else
    			{
    				xrlog->hdls[i].rem_size -= len;
    			}
    		}
    	}
    }

    // if data cannot be written contiguously, we write 'til start of memspace
    // has been reached
    rem = xrlog->max_size - xrlog->pos;
    if (len > rem)
    {
        // write data
        cpy_to_xbank(buf, xrlog->mem_start + xrlog->pos, rem);
        // do wrap-around of position pointer & adjust sizes
        xrlog->pos = 0;
        len -= rem;
        buf += rem;
    }
    // write (remaining) data
    cpy_to_xbank(buf, xrlog->mem_start + xrlog->pos, len);
    xrlog->pos += len;
    return 0;
}


/**
 * \brief Reads data from the ring buffer log.
 * 
 * Reads \param len bytes from the ring buffer. Start position is given by
 * the data pointer \param rbuf_p passed.
 * 
 * \return memory location (offset) until where data has been read
 * 
 */
short xrlog_read(xrlog_hdl_t* hdl, u_char* buf, u_short len)
{
	// get pointer to the log buffer
	xrlog_t* xrlog = hdl->xrlog;
	
	// get pointer to the corresponding xrlog - return error if invalid
	if (!hdl || (hdl->state == XRLOG_HDL_INVALID))
	{
		return XRLOG_ERR_INVALID_HANDLE;
	}
	
    // return error if read access is invalid (nr of remaining bytes in the buffer
    // is smaller than the nr of bytes to be read)
    if (hdl->rem_size < len)
    {
    	hdl->state = XRLOG_HDL_INVALID;
    	return XRLOG_ERR_INVALID_DATA_ACCESS;
    }
    // else, adjust distance counter
    hdl->rem_size -= len;
    
	/* read data */
    // do wrap-around if necessary
    if (hdl->pos < len)
    {
    	// nr. of remainig bytes after wrap-around
    	len -= hdl->pos;
        // read data 'til the beginning of memspace
        // Note: we have to leave space for 'len' bytes at the beginning of
        // the read buffer (for that the wrapped-around bytes fit)
        cpy_from_xbank(buf + len, xrlog->mem_start, hdl->pos);
        // adjust remaining sizes & do wrap-around
        hdl->pos = xrlog->max_size;
    }
    // read (remaining) data & adjust handle
    hdl->pos -= len;
    cpy_from_xbank(buf, xrlog->mem_start + hdl->pos, len);
    return 0;
}


/**
 * \brief Seeks the log pointer passed by \p len bytes
 * 
 * Reads \param len bytes from the ring buffer. Start position is given by
 * the log handle \p hdl passed.
 * 
 * Note this function exists because seeking is faster than reading:
 * when reading, data from xmem has to be accessed.
 * 
 * \return 0 on success, or
 * - XRLOG_ERR_INVALID_HANDLE
 * - XRLOG_ERR_INVALID_DATA_ACCESS
 */
short xrlog_seek(xrlog_hdl_t* hdl, u_short len)
{
	// get pointer to the log buffer
	xrlog_t* xrlog = hdl->xrlog;
	
	// get pointer to the corresponding xrlog - return error if invalid
	if (!hdl || (hdl->state == XRLOG_HDL_INVALID))
	{
		return XRLOG_ERR_INVALID_HANDLE;
	}
	
    // return error if read access is invalid (nr of remaining bytes in the buffer
    // is smaller than the nr of bytes to be read)
    if (hdl->rem_size < len)
    {
    	hdl->state = XRLOG_HDL_INVALID;
    	return XRLOG_ERR_INVALID_DATA_ACCESS;
    }
    // else, adjust distance counter
    hdl->rem_size -= len;
    
	/* seek */
    // do wrap-around if necessary
    if (hdl->pos < len)
    {
    	// nr. of remainig bytes after wrap-around
    	len -= hdl->pos;
        // adjust remaining sizes & do wrap-around
        hdl->pos = xrlog->max_size;
    }
    // read (remaining) data & adjust handle
    hdl->pos -= len;
    return 0;
}


xrlog_hdl_t* xrlog_open(xrlog_t* xrlog)
{
	u_char i;
	
	// get a free handle
	for (i=0; i<XRLOG_MAX_NR_HANDLES; i++)
	{
		if (xrlog->hdls[i].state == XRLOG_HDL_FREE)
		{
			// initialize handle & return pointer it
			xrlog->hdls[i].pos = xrlog->pos;
			xrlog->hdls[i].rem_size = xrlog->size;
			xrlog->hdls[i].state = XRLOG_HDL_VALID;
			return &xrlog->hdls[i];
		}
	}
	return 0;
}


void xrlog_close(xrlog_hdl_t* hdl)
{
	u_char i;
	xrlog_t* xrlog;
	
	// get pointer to xrlog - return if invalid handle
	if (!hdl) return;
	xrlog = hdl->xrlog;
	
	// invalidate handle
	for (i=0; i<XRLOG_MAX_NR_HANDLES; i++)
	{
		if (&xrlog->hdls[i] == hdl)
		{
			hdl->state = XRLOG_HDL_FREE;
		}
	}
}
    

void xrlog_empty(xrlog_t* xrlog)
{
	u_char i;
	
	// invalidate handles in use
	for (i=0; i<XRLOG_MAX_NR_HANDLES; i++)
	{
		if (xrlog->hdls[i].state == XRLOG_HDL_VALID)
		{
			xrlog->hdls[i].state = XRLOG_HDL_INVALID;
		}
	}
	// reset buffer pointers 
	xrlog->pos = 0;
	xrlog->size = 0;
}

u_char xrlog_is_handle_valid(xrlog_hdl_t* hdl)
{
	if (hdl->state == XRLOG_HDL_VALID)
	{
		return 1;
	}
	return 0;
}


xrlog_t* xrlog_init(u_long mem_addr, u_short max_size)
{
	u_char i;
	xrlog_t* xrlog;
	
	// dyn. allocate ring buffer
	xrlog = NutHeapAllocClear(sizeof(xrlog_t));
	xrlog->mem_start = mem_addr;
	xrlog->max_size = max_size;
	xrlog->pos = 0;
	xrlog->size = 0;
	
	// init handles
	for (i=0; i<XRLOG_MAX_NR_HANDLES; i++)
	{
		xrlog->hdls[i].xrlog = xrlog;
		xrlog->hdls[i].state = XRLOG_HDL_FREE;
	}
	return xrlog;
}
