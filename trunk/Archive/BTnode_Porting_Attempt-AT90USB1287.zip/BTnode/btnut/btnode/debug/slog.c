#include <string.h>
#include <bt/bt_defs.h>
#include <debug/logging.h>
#include <debug/slog.h>
#include <debug/toolbox.h>
#include <bt/bt_psm.h>
#include <mhop/mhop_cl.h>
#include <sys/timer.h>
#include <sys/heap.h>

#define SLOG_STATE_READY		1
#define SLOG_STATE_BUSY			2

#define MIN(a, b) (((a) > (b))? (b) : (a))

typedef struct slog_rqst_pkt_s {
	u_char psm[2];
	u_char nr_msgs[2];
	u_char class;
	u_char mask;
} slog_rqst_pkt_t;

typedef struct _slog_target_s {
	bt_addr_t addr;
	u_short psm;
	u_short nr_msgs;
	u_short id_newer;
	u_char class;
	u_char mask;
	u_char is_valid;		// indicates if the target is valid or not
} _slog_target_t;

struct slog_stack_s {
	_slog_target_t send_target;
	_slog_target_t verbose_target;
	log_filter_t verbosity;
	u_char* send_buf;
	u_short max_payload;
	u_char state;
};

struct slog_stack_s slog_stack;

void _slog_send_msg(u_char* data, log_msg_tail* msgtail, void* cb_arg)
{
    u_short data_len;                // amount of log data to send
    u_short remain = msgtail->len;   // amount of remaining data to send
    long retval = 0;
    u_char frag_nr = 0;              // packet fragment counter
    u_char msg_end = 0;              // flag, indicating if end of log message
                                     // has been reached

    char* curr_pos = (char*) data;
    _slog_target_t* target = (_slog_target_t*)cb_arg;

    // return if no verbose target is set yet
    if (!target->is_valid) return;

    while(remain) {
        frag_nr++;
        // if message data to send is too large
        if (remain + LOG_MSG_TAIL_SIZE > slog_stack.max_payload)
        {
            // split message
            data_len = slog_stack.max_payload - LOG_MSG_TAIL_SIZE;
        }
        else {
            data_len = remain;
            msg_end = 1;
        }
        // we use the len field for pkt fragmentation information
        msgtail->len = frag_nr | (msg_end << 8);
        // copy header to send buf
        memcpy(slog_stack.send_buf, msgtail, LOG_MSG_TAIL_SIZE);
        // copy msg data to send buf
        memcpy(slog_stack.send_buf + LOG_MSG_TAIL_SIZE, curr_pos, data_len);
        // send part of message, including msg header
        retval = mhop_cl_send_pkt(slog_stack.send_buf,
                                  LOG_MSG_TAIL_SIZE + data_len,
                                  target->addr, target->psm, 
                                  MHOP_CL_UNICAST, MHOP_CL_TTL_INFINITE);

        // sleep some time after we sent a message
        NutSleep(30);

        // adjust pointers
        remain -= data_len;
        curr_pos += data_len;
    }
}

THREAD(SEND_LOG, arg)
{
	_slog_target_t* target = (_slog_target_t*)arg;
	
	// switch back to calling thread & decrease priority
	NutThreadSetPriority(100);
	
	// set target valid. This is necessary, because the callback _slog_send_msg()
	// only sends a log message if this flag is set
	target->is_valid = 1;
	
	// this while loop is only used for being conform
	while (1)
	{
		// if a class is set, we call 'log_get()'
		if (target->class)
		{
			log_get(target->nr_msgs, target->class, target->mask, _slog_send_msg, target);
		}
		// else, we call 'log_get_messages()'
		else
		{
			log_get_messages(target->id_newer, target->nr_msgs, _slog_send_msg, target);
		}
		
		// exit
		slog_stack.state = SLOG_STATE_READY;
		NutThreadExit();
	}
}

void slog_verbose_target_set(bt_addr_t target, u_short psm)
{
	// store target address
	memcpy(slog_stack.verbose_target.addr, target, BD_ADDR_LEN);
	// store target psm
	slog_stack.verbose_target.psm = psm;
	// set flag to indicate that a verbose target exists
	slog_stack.verbose_target.is_valid = 1;
}

inline u_char* slog_verbose_target_get(void)
{
	return slog_stack.verbose_target.addr;
}

void slog_verbose_target_clear(void)
{
	slog_stack.verbose_target.is_valid = 0;
}

void slog_verbosity_set(u_char class, u_char mask)
{
	if ((class > 0) && (class < LOG_MAX_CLASSES)) {
		slog_stack.verbosity[class] = mask;
	}
}

u_char slog_verbosity_get(u_char class)
{
	return slog_stack.verbosity[class];
}

int slog_verbosity_on(void)
{
	// register event listener
	return log_evt_listener_register(_slog_send_msg, &slog_stack.verbose_target, slog_stack.verbosity);
}

void slog_send_messages(bt_addr_t target_addr, u_short target_psm, u_short id_newer, u_short nr_msgs)
{
	_slog_target_t* target = &slog_stack.send_target;
	
	if (slog_stack.state == SLOG_STATE_READY)
	{
		// temporarily store target addr & psm
		memcpy(target->addr, target_addr, BD_ADDR_LEN);
		target->psm = target_psm;
		target->nr_msgs = nr_msgs;
		target->id_newer = id_newer;
		target->class = 0;
		target->mask = 0;
		
		// create send thread
		slog_stack.state = SLOG_STATE_BUSY;
		NutThreadCreate("SendLog", SEND_LOG, target, 2048);
	}
}

void slog_send(bt_addr_t target_addr, u_short target_psm, u_short nr_msgs, u_char class, u_char mask)
{
	_slog_target_t* target = &slog_stack.send_target;
	
	if (slog_stack.state == SLOG_STATE_READY)
	{
		// temporarily store target addr & psm
		memcpy(target->addr, target_addr, BD_ADDR_LEN);
		target->psm = target_psm;
		target->nr_msgs = nr_msgs;
		target->id_newer = 0;
		target->class = class;
		target->mask = mask;
		
		// create send thread
		slog_stack.state = SLOG_STATE_BUSY;
		NutThreadCreate("SendLog", SEND_LOG, target, 2048);
	}
}

void slog_init(bt_psm_t* psmux, u_short rqst_psm)
{
	u_char i;
	
	// init stack
	slog_stack.state = SLOG_STATE_READY;
	slog_stack.max_payload = mhop_cl_max_payload_size();
	slog_stack.send_buf = NutHeapAllocClear(slog_stack.max_payload);
	
	// invalidate verbose target
	slog_stack.verbose_target.is_valid = 0;
	slog_stack.send_target.is_valid = 0;
	
	// init verbosity filter
	for (i=0; i<LOG_MAX_CLASSES; i++)
	{
		slog_stack.verbosity[i] = 0;
	}
}
