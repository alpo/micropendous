/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file logging.c
 * 
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Implementation of the event logger.
 */

#include <stdio.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <time/btn-time.h>
#include <sys/mutex.h>
#include <string.h>
#include <debug/xrlog.h>
#include <debug/logging.h>
#include <sys/tracer.h>
#include <sys/timer.h>

#define LOG_BANK_START   			(129L * 1024)
#define LOG_BANK_SIZE				(50U * 1024U)

// max size of a line that can be logged - excluding newline & null termination
#define LOG_MAX_LINE_SIZE			254

#define LOG_MAX_LISTENERS			3

#define LOG_MSG_TAIL_SIZE			(sizeof(log_msg_tail))

// returns true if the log level filter for the level passed is on.
#define LOG_FILTER_ON(filter, level) 		(filter & (1 << (level - 1)))

#define MIN(a, b) ((a > b)? b : a)

// trace setup - used to measure the time needed for logging a line
#define LOG_TRACE_CREATE_TSTAMP		0
#define LOG_TRACE_CREATE_MSG		1
#define LOG_TRACE_WRITE				2
#define LOG_TRACE_DONE				3


typedef struct _log_listener_s {
	u_char* log_filter;
	LOG_DATA_CB;
	void* cb_arg;
} _log_listener;

typedef struct _log_stack {
    xrlog_t* log_buf;
    log_filter_t logmask;
    char read_buf[LOG_MAX_LINE_SIZE + 2];
    int linesize;
    u_short log_id;
    HANDLE line_added;
    _log_listener listener;
    u_char vpause;
    HANDLE vresume;
} _log_stack_t;

static _log_stack_t log_stack;

extern int _putf(int _putb(int, CONST void *, size_t), int fd, CONST char *fmt, va_list ap);

// this callback function is called by _putf(): it copies \p count bytes from
// \p buf to the log ringbuffer in xmem
static int _log_sput_xrlog(int fd, CONST void *buf, size_t count)
{
	int len;
	
	// limit lenght to copy
    len = MIN(count, LOG_MAX_LINE_SIZE - log_stack.linesize);
    // write data to xrlog
    xrlog_write(log_stack.log_buf, (u_char*)buf, count);
    // adjust size of logged line
    log_stack.linesize += len;
    return len;
}


void log_write(u_char class, u_char level, CONST char* fmt, ...)
{
	va_list ap;
	u_short msg_len;
	log_msg_tail msgtail;
	
    if(LOG_FILTER_ON(log_stack.logmask[class], level))
    {	
//		TRACE_ADD_ITEM(TRACE_TAG_USER, LOG_TRACE_CREATE_TSTAMP);
		
		/* get time stamp */
		msgtail.t_stamp = btn_time_global();
		
//		TRACE_ADD_ITEM(TRACE_TAG_USER, LOG_TRACE_CREATE_MSG);
		
		/* write message data to xrlog */
		log_stack.linesize = 0;
		// write message data
		va_start(ap, fmt);
		_putf(_log_sput_xrlog, 0, fmt, ap);
		va_end(ap);
		// get nr of bytes written
		msg_len = log_stack.linesize;
		// add newline if the string is cutted
	    if (log_stack.linesize == LOG_MAX_LINE_SIZE)
	    {
	    	xrlog_write(log_stack.log_buf, (u_char*) "\n", 1);
	    	msg_len++;
	    }
		// add null termination
		xrlog_write(log_stack.log_buf, (u_char*) "\0", 1);
		msg_len++;
	    
	    /* build msg tail */
	    msgtail.id = log_stack.log_id++;
		msgtail.class = class;
		msgtail.level = level;
		msgtail.len = msg_len;
	    
//	    TRACE_ADD_ITEM(TRACE_TAG_USER, LOG_TRACE_WRITE);
	    
	    // write msg tail to xrlog
	    xrlog_write(log_stack.log_buf, (u_char*)&msgtail, LOG_MSG_TAIL_SIZE);
	    
//	    TRACE_ADD_ITEM(TRACE_TAG_USER, LOG_TRACE_DONE);

	    /* wake up event listeners */
	    NutEventBroadcastAsync(&log_stack.line_added);
    }
}


inline void log_empty(void)
{
	// just empty the log buffer
	xrlog_empty(log_stack.log_buf);
}


void log_get(u_short nr_msgs, u_char class, u_char mask, LOG_DATA_CB, void* cb_arg)
{
	xrlog_hdl_t* hdl;
	log_msg_tail tail;
	u_short cnt;
	
	// get a handle
	hdl = xrlog_open(log_stack.log_buf);
	if (!hdl) return;
	
	cnt = 0;
	while (1)
	{
		// read message tail - stop execution if error
		if (xrlog_read(hdl, (u_char*) &tail, sizeof(log_msg_tail)))
		{
			break;
		}
		// read log message & write it to the buffer passed
		// TODO: split message if it is too long
		if (xrlog_read(hdl, (u_char*) log_stack.read_buf, tail.len))
		{
			break;
		}
		// signal caller
		if(((class == LOG_ALL_CLASSES) || (tail.class == class)) && (LOG_FILTER_ON(mask, tail.level)))
		{
			log_data_cb((u_char*) log_stack.read_buf, &tail, cb_arg);
		}
		// increment nr of messages read
		cnt++;
		// break if nr_msgs have been returned
		if (nr_msgs && (nr_msgs == cnt))
		{
			break;
		}
		// give other threads a chance
		NutThreadYield();
	}
	
	// release log handle
	xrlog_close(hdl);
}

void log_get_messages(u_short id_newer, u_short nr_msgs, LOG_DATA_CB, void* cb_arg)
{
	xrlog_hdl_t* hdl;
	log_msg_tail tail;
	u_short id_start;
	u_char start_id_found;
	
	// get a handle
	hdl = xrlog_open(log_stack.log_buf);
	if (!hdl) return;
	
	// get start id
	if (nr_msgs)
	{
		id_start = id_newer + nr_msgs;
	}
	else
	{
		id_start = log_stack.log_id - 1;
	}
	
	// return messages from start id to end id
	start_id_found = 0;
	while (1)
	{
		// read message tail - stop execution if error
		if (xrlog_read(hdl, (u_char*) &tail, sizeof(log_msg_tail)))
		{
			break;
		}
		// check if we've reached the requested endpoint
		if (tail.id == id_newer)
		{
			break;
		}
		// read log message & write it to the buffer passed
		// TODO: split message if it is too long
		if (xrlog_read(hdl, (u_char*) log_stack.read_buf, tail.len))
		{
			break;
		}		
		// check if we've found the requested starting point
		if (tail.id == id_start)
		{
			start_id_found = 1;
		}
		// call callback if class and level matches
		if (start_id_found)
		{
			log_data_cb((u_char*) log_stack.read_buf, &tail, cb_arg);
		}
		// give other threads a chance!
		NutThreadYield();
	}
	
	// release log handle
	xrlog_close(hdl);
}


short log_get_logmask(u_char class)
{
	// get desired mask and return it
	if (class > 0 && class < LOG_MAX_CLASSES)
		return log_stack.logmask[class];
	// return error if class not valid
	return -1;
}


void log_set_logmask( u_char class, u_char mask)
{
    if( class > 0 && class < LOG_MAX_CLASSES) {
        log_stack.logmask[class] = mask;
    }
}


THREAD(log_evt_listener, arg)
{
	xrlog_hdl_t* hdl;
	u_short start_id;
	u_short stop_id;
	log_msg_tail msgtail;
	u_char buf[LOG_MAX_LINE_SIZE + 2];
	_log_listener* listener = &log_stack.listener;
	
	// run this service in background
	NutThreadSetPriority(200);
	
	// init handles to the log buffer
	stop_id = 0;
	
	// wait 'til the first line has been logged
	NutEventWait(&log_stack.line_added, NUT_WAIT_INFINITE);
		
	while(1)
	{
		// get a log handle
		hdl = xrlog_open(log_stack.log_buf);
		start_id = log_stack.log_id - 1;
		
		/* return new log messages only */
		while (1)
		{
			// pause verbosity if we are adviced to
			if (log_stack.vpause)
			{
				NutEventWait(&log_stack.vresume, NUT_WAIT_INFINITE);
				// if our handle is invalid, we start from scratch
				if (!xrlog_is_handle_valid(hdl))
				{
					// reset start id
					stop_id = log_stack.log_id - 1;
					// get new log handle
					xrlog_close(hdl);
					hdl = xrlog_open(log_stack.log_buf);
				}
				// make shure that we do not block 'til next line is added
				NutEventPostAsync(&log_stack.line_added);
			}
			
			// read next message tail
			if (xrlog_read(hdl, (u_char*)&msgtail, LOG_MSG_TAIL_SIZE))
			{
				break;
			}
			// stop if we've already returned this message
			if (msgtail.id == stop_id)
			{
				break;
			}
			
			// signal listener, if filter matches
			if (listener->log_data_cb && LOG_FILTER_ON(listener->log_filter[msgtail.class], msgtail.level))
			{
				// get data from xmem & signal listener
				if (xrlog_read(hdl, buf, msgtail.len))
				{
					break;
				}
				listener->log_data_cb(buf, &msgtail, listener->cb_arg);
			}
			else
			{
				xrlog_seek(hdl, msgtail.len);
			}
			
			// give other threads a chance!
			NutThreadYield();
		}
		
		/* update last returned id.
		 * Note: we do not care if there was an error while reading the log buf -
		 * we simply state that we've returned _all_ the messages up to the
		 * start message.
		 * This is because a read error may only occur if some messages are already
		 * lost (i.e. some msgs have been overwritten by newer messages). But in that
		 * case, we already did our best to return as many log messages as possible.
		 */
		stop_id = start_id;
		
		// release log handle
		xrlog_close(hdl);
		
		// if there are no new logs to return, wait
		if (start_id == (log_stack.log_id - 1))
		{
			NutEventWait(&log_stack.line_added, NUT_WAIT_INFINITE);
		}
	}
}

short log_evt_listener_register(LOG_DATA_CB, void* cb_arg, log_filter_t filter)
{
	_log_listener* listener = &log_stack.listener;
	
	// if a listener is already registered, return error
	if (listener->log_data_cb)
	{
		return -1;
	}
	// else, register listener
	listener->log_data_cb = log_data_cb;
	listener->cb_arg = cb_arg;
	listener->log_filter = filter;
	return 0;
}

void log_evt_listener_clear(void)
{
	_log_listener* listener = &log_stack.listener;
	
	listener->log_data_cb = NULL;
	listener->cb_arg = NULL;
	listener->log_filter = NULL;
}

void log_evt_listener_pause(void)
{
	log_stack.vpause = 1;
}

void log_evt_listener_resume(void)
{
	log_stack.vpause = 0;
	// only post if the log evt thread is waiting (paused)
	if (log_stack.vresume)
	{
		NutEventPost(&log_stack.vresume);
	}
}


void log_init(void)
{
	u_short i;
	_log_listener* listener = &log_stack.listener;
    
    // stack init
    log_stack.log_id = 0;
    log_stack.linesize = 0;
    log_stack.line_added = NULL;
    log_stack.vpause = 0;
    log_stack.vresume = 0;
    
    // init xrlog
    log_stack.log_buf = xrlog_init(LOG_BANK_START, LOG_BANK_SIZE);

	// init logmasks
	for (i=0; i<LOG_MAX_CLASSES; i++) {
		log_stack.logmask[i] = LOG_MASK_ALL;
	}
	
	// init listener
	listener->log_data_cb = NULL;
	listener->cb_arg = NULL;
	listener->log_filter = NULL;
	
	// init verbosity thread
	NutThreadCreate("LogEvt", log_evt_listener, NULL, 1024);
	
//	// trace setup
//	for(i = TRACE_TAG_FIRST; i <= TRACE_TAG_LAST; i++)
//      NutTraceMaskClear(i);
//
//	NutTraceRegisterUserTag(LOG_TRACE_CREATE_TSTAMP, "creating tstamp... ");
//  NutTraceRegisterUserTag(LOG_TRACE_CREATE_MSG, "building log msg... ");
//  NutTraceRegisterUserTag(LOG_TRACE_WRITE, "write to log... ");
//  NutTraceRegisterUserTag(LOG_TRACE_DONE, "done.");
//    
//  NutTraceMaskSet(TRACE_TAG_USER);
//  NutTraceInit(1000, TRACE_MODE_CIRCULAR);
}
