/*
 * Copyright (C) 2005 Mario Strasser <mast@gmx.net>,
 *                    Swiss Federal Institute of Technology (ETH) Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * $Id: bmac.c,v 1.6 2006/10/03 08:08:39 freckle Exp $
 */

#ifdef __BTNODE3__
 
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/timer.h>
#include <sys/atom.h>
#include <sys/mutex.h>
#include <sys/event.h>
#include <sys/thread.h>
#include <dev/irqreg.h>
#include <arch/avr/timer.h>
#include <hardware/btn-hardware.h>
#include <hardware/btn-timer.h>
#include <led/btn-led.h>
#include <cc/crc.h>
#include <cc/cc1000_defs.h>
#include <cc/cc1000.h>
#include <cc/cca.h>
#include <cc/bmac.h>

#define PREAMBLE_BYTE0      0xaa
#define PREAMBLE_BYTE1      0x55
#define SYNC_BYTE           0x33
#define FLUSH_BYTE          0xff
#define ACK_BYTE            0x66

#define MIN_PREAMBLE_LENGTH 6
#define MAX_ACK_LENGTH      12
#define PREAMBLE_TIMEOUT    18

typedef enum {
    STATE_IDLE = 0,  
    STATE_TX = 10, 
    STATE_TX_PRE_LONG,
    STATE_TX_PRE_SHORT,
    STATE_TX_HEADER,
    STATE_TX_PAYLOAD,
    STATE_TX_FOOTER,
    STATE_TX_RECV_ACK,
    STATE_TX_POST,
    STATE_RX = 20,
    STATE_RX_PRE_START,    
    STATE_RX_PRE,    
    STATE_RX_SYNC,
    STATE_RX_HEADER,
    STATE_RX_PAYLOAD,
    STATE_RX_FOOTER,
    STATE_RX_SEND_ACK,
    STATE_RX_POST,    
} bmac_state_t;

#define FLAG_ACK        0x80
#define FLAG_FEC        0x40
#define FLAG_RESERVED   0x20
#define FLAG_FRAG_FIRST 0x10
#define FLAG_FRAG_MASK  0x0f 

#define BMAC_MTU        ((FLAG_FRAG_MASK + 1) * 255)

typedef struct bmac_header_st {
    u_short source;
    u_short destination;    
    u_char length;
    u_char flags;       
} __attribute__((__packed__)) bmac_header_t;

typedef struct bmac_packet_st {
    bmac_header_t header;
    u_char *data;
    union { 
        u_short crc; 
        struct { u_char crc_hi, crc_lo; } __attribute__((__packed__)); 
    };
} bmac_packet_t;

static u_short bmac_address = BROADCAST_ADDR;
static u_char bmac_init_backoff = 5;
static u_char bmac_cong_backoff = 10;
static u_char bmac_use_ack = 0;
static u_char bmac_disable_timer = 1;
static u_char bmac_use_led = 0;
static u_char bmac_use_irq = 1;

static volatile bmac_state_t bmac_state = STATE_IDLE;
static u_short lpl_interval = 100;
static u_short preamble_length = 258;
static u_char txmode = 0;
static bmac_packet_t recv_buffer[4];
static u_char buf_in = 0;
static u_char buf_out = 0;
static bmac_packet_t send_packet;
static u_short timer_counter = 0;

static MUTEX send_mutex;
static HANDLE send_handle = NULL;
static HANDLE recv_handle = NULL;
static HANDLE idle_handle = NULL;

static u_long recv_count = 0;
static u_long failed_count = 0;

/* NutOS system ticks */
extern u_long nut_ticks;

/* SPI and timer handling */

static inline void spi_enable(void) 
{ 
    sbi(SPCR, SPIE); 
}

static inline void spi_disable(void) 
{ 
    cbi(SPCR, SPIE); 
}

static inline void timer_enable(void) 
{ 
    timer_counter--;
    if (bmac_disable_timer && !timer_counter) NutEnableTimerIrq();
}

static inline void timer_disable(void) 
{ 
    if (bmac_disable_timer && !timer_counter) NutDisableTimerIrq();
    timer_counter++;
}

static inline void bmac_rxmode(void)
{
    txmode = 0; cc1000_rxmode();
}

static inline void bmac_txmode(void)
{
    txmode = 1; cc1000_txmode();
}

/*
 * The SPI interrupt handler is very time critical when used for sending
 * data, as the SPI output register is only single buffered. If the delay
 * between interrupt signalisation and actual execution of the handler
 * is greater than ca. 25us the write command to SPDR is ignored and its
 * old value is sent again. This duplication, however, will lead in
 * most cases to an overall incorrect packet transmission.
 *
 * An evaluation showed that most delays are caused by the higher
 * prioritised system timer, which therefore can be disabled during
 * a transmission (see bmac_disable_timer_interrupt).
 */
static void spi_handler(void *arg)
{    
    static u_short count = 0;      /* data counter */
    static u_short timeout = 0;    /* preamble timeout-counter */
    static u_char cur_data;        /* current data */         
    static u_char prev_data;       /* previous data */    
    static u_char offset;          /* bit-offset of the received data */
    static u_short crc;            /* crc of the incoming packet */
    static u_char stay_online = 0; /* true if there are more fragments to come */
                
    /* first of all check whether we are in TX/RM mode and send/receive the
       current data, respectively */
    if (txmode) SPDR = cur_data; else cur_data = SPDR;
    
    /* then evaluate the state machine to get the next state and data */                                    
    switch (bmac_state) {
                            
        /* TX state-machine */
        
        case STATE_TX_PRE_LONG:    
            if (++count <= preamble_length) {
                cur_data = PREAMBLE_BYTE0;                
            } else {                
                cur_data = SYNC_BYTE;                
                bmac_state = STATE_TX_HEADER;
                count = 0;
            }  
            if (count == 1 && bmac_use_led) btn_led_set(LED0);            
            break;
            
        case STATE_TX_PRE_SHORT:
            if (++count <= MIN_PREAMBLE_LENGTH * 2) {
                cur_data = PREAMBLE_BYTE0;                
            } else {                
                cur_data = SYNC_BYTE;                
                bmac_state = STATE_TX_HEADER;
                count = 0;
            }  
            if (count == 1 && bmac_use_led) btn_led_set(LED0);            
            break;

        case STATE_TX_HEADER:
            cur_data = ((u_char*)&send_packet.header)[count];            
            if (++count >= sizeof(bmac_header_t)) {                         
                bmac_state = STATE_TX_PAYLOAD;
                count = 0;    
            }
            break;
            
        case STATE_TX_PAYLOAD:
            cur_data = send_packet.data[count];                                                                        
            if (++count >= send_packet.header.length) {
                bmac_state = STATE_TX_FOOTER;
                count = 0;
            }            
            break; 
                
        case STATE_TX_FOOTER:
            if (count == 0) {   
                cur_data = send_packet.crc_hi;                
                count++;
            } else if (count == 1) {
                cur_data = send_packet.crc_lo;
                count++;
            } else if (count == 2) {
                cur_data = FLUSH_BYTE;
                count++;   
            } else {
                cur_data = FLUSH_BYTE;
                if (send_packet.header.flags & FLAG_ACK) {
                    send_packet.header.flags &= ~FLAG_ACK;
                    bmac_state = STATE_TX_RECV_ACK;
                    count = 0;                    
                    bmac_rxmode();
                } else {
                    bmac_state = STATE_TX_POST;  
                    count = 0;                   
                    NutEventPostFromIrq(&send_handle);                    
                }
            }             
            break;
            
        case STATE_TX_RECV_ACK:
            for (offset = 0; offset < 8; offset++) {
                if ((((prev_data << offset) 
                   | (cur_data >> (8 - offset))) & 0xff) == ACK_BYTE) {
                   send_packet.header.flags |= FLAG_ACK;
                   break;
                }    
            }  
            if (++count >= MAX_ACK_LENGTH 
                || (send_packet.header.flags & FLAG_ACK)) {            
                bmac_state = STATE_TX_POST;
                count = 0;                
                NutEventPostFromIrq(&send_handle);                
            }
            prev_data = cur_data;            
            break;
            
        /* RX state-machine */
        
        case STATE_RX_PRE_START:
            if (cur_data == 0xaa || cur_data == 0x55) {
                if (++count >= MIN_PREAMBLE_LENGTH) bmac_state = STATE_RX_PRE;    
            } else {
                count = 0;
                if (++timeout >= PREAMBLE_TIMEOUT) {
                    bmac_state = STATE_RX_POST;   
                    timeout = 0;
                }
            }            
            prev_data = cur_data;            
            break;            
                                    
        case STATE_RX_PRE:
            if (cur_data != 0xaa && cur_data != 0x55) {
                if (count < MIN_PREAMBLE_LENGTH) {
                    bmac_state  = STATE_RX_POST;  
                    count = 0;
                } else               
#if 0                
                /* the MSB of the sync byte might be the LSB of the 
                   last preamble byte => offset = 7 and no sync state */                              
                if (((prev_data << 7) | (cur_data >> 1)) == SYNC_BYTE) {
                    offset = 7;
                    bmac_state = STATE_RX_HEADER;
                    count = 0;
                } else 
#endif                
                {
                    bmac_state = STATE_RX_SYNC;                    
                }                
            } else if (++count > preamble_length) {
                bmac_state = STATE_RX_POST;  
                count = 0;
            }                
            prev_data = cur_data;                       
            break;
            
        case STATE_RX_SYNC:            
            offset = 0;
            while (prev_data != SYNC_BYTE && offset < 8) {
               prev_data = (prev_data << 1) | (cur_data >> (7 - offset));
               offset++;
            }            
            if (offset < 8) {
                bmac_state = STATE_RX_HEADER;
                count = 0;
            } else {
                bmac_state = STATE_RX_POST;  
                count = 0;
            }      
            prev_data = cur_data;                 
            crc = 0xffff;
            break;    
            
        case STATE_RX_HEADER:
            ((u_char*)&recv_buffer[buf_out].header)[count] =
                (prev_data << offset) | (cur_data >> (8 - offset)); 
            crc = crc_ccitt_update(crc, ((u_char*)&recv_buffer[buf_out].header)[count]);
            if (++count >= sizeof(bmac_header_t)) {
                u_short dst = ntohs(recv_buffer[buf_out].header.destination);                
                if (dst != bmac_address 
                    && (dst != MULTICAST_ADDR(bmac_address))
                    && (dst != BROADCAST_ADDR)) {
                    bmac_state = STATE_RX_POST;
                    count = 0;    
                } else {                                       
                    bmac_state = STATE_RX_PAYLOAD;
                    count = 0;
                    if (bmac_use_led) btn_led_set(LED0);
                }
            }  
            prev_data = cur_data;                        
            break;
            
        case STATE_RX_PAYLOAD:
            recv_buffer[buf_out].data[count] =
                (prev_data << offset) | (cur_data >> (8 - offset));
            crc = crc_ccitt_update(crc, recv_buffer[buf_out].data[count]);
            if (++count >= recv_buffer[buf_out].header.length) {
                bmac_state = STATE_RX_FOOTER;                
                count = 0;
            } 
            prev_data = cur_data;            
            break;
            
        case STATE_RX_FOOTER:            
            if (count == 0) {                   
                recv_buffer[buf_out].crc_hi = 
                    (prev_data << offset) | (cur_data >> (8 - offset));                
                count++;
            } else if (count == 1) {
                recv_buffer[buf_out].crc_lo =
                    (prev_data << offset) | (cur_data >> (8 - offset));
                /* verify crc and send ack if required */
                if (ntohs(recv_buffer[buf_out].crc) == crc) {
                    if (recv_buffer[buf_out].header.flags & FLAG_FRAG_MASK) {
                        stay_online = 1;
                    }
                    if (recv_buffer[buf_out].header.flags & FLAG_ACK) {
                        bmac_state = STATE_RX_SEND_ACK;
                        count = 0;                        
                        bmac_txmode();
                    } else {                        
                        bmac_state = STATE_RX_POST;
                        count = 0;
                        /* add packet to ring buffer */
                        buf_out = (buf_out + 1) & 3;                            
                        NutEventPostFromIrq(&recv_handle);
                        if (buf_out == buf_in) {
                            buf_in = (buf_in + 1) & 3;
                            ++failed_count;
                            if (bmac_use_led) btn_led_set(LED1);                            
                        } else {
                            ++recv_count;
                        }                                                           
                    }                   
                } else {
                    ++failed_count;
                    bmac_state = STATE_RX_POST;
                    count = 0;
                    if (bmac_use_led) btn_led_set(LED1);
                }
            }
            prev_data = cur_data;
            break;
            
        case STATE_RX_SEND_ACK:
            /* note that the optimal length of the acknowledge depends on the 
               duration of cc1000_txmode() and cc1000_rxmode(), resp. */             
            if (count < 4) {
                cur_data = PREAMBLE_BYTE0;
                count++;
            } else if (count < 6) {
                cur_data = ACK_BYTE;
                count++;
            } else {
                cur_data = FLUSH_BYTE;
                bmac_state = STATE_RX_POST;
                count = 0;                  
                bmac_rxmode();
                /* add packet to ring buffer */ 
                buf_out = (buf_out + 1) & 3;                            
                NutEventPostFromIrq(&recv_handle);
                if (buf_out == buf_in) {
                    buf_in = (buf_in + 1) & 3;
                    ++failed_count;
                    if (bmac_use_led) btn_led_set(LED1);
                } else {
                    ++recv_count;
                }                                              
            }            
            break;
         
        /* idle state-machine */
               
        case STATE_IDLE:
        default:            
            if (cur_data == 0xaa || cur_data == 0x55) {
                if (++count >= MIN_PREAMBLE_LENGTH) bmac_state = STATE_RX_PRE;    
            } else {
                count = 0;                
            }            
            prev_data = cur_data;            
            break;
    }    

    /* clean up states */
    if (bmac_state == STATE_TX_POST || bmac_state == STATE_RX_POST) {
        if (bmac_use_led) btn_led_clear(LED0);
        count = 0;
        timeout = 0;
        if (stay_online) {
            /* if there are more fragments to come, stay on-line ... */
            bmac_state = STATE_RX_PRE_START;
            stay_online = 0;
        } else {
            /* ... otherwise go into idle state and reset timer and LPL */
            if (lpl_interval > 0 || bmac_state == STATE_TX_POST) spi_disable();
            bmac_state = STATE_IDLE;
            NutEventPostFromIrq(&idle_handle);
        }                          
    }
}


/* low power listening (LPL) */

static inline u_short compute_preamble_length(u_short interval)
{   
    /* preamble length := 2400 bytes/s * interval + constant */
    return 24 * interval / 10 + MIN_PREAMBLE_LENGTH + 12;
}

static void lpl_handler(void *arg)
{         
    static int toggle = 0;
    if (bmac_state == STATE_IDLE) {
        /* show LPL activity by means of LED3 */
        if (bmac_use_led) {
            if (toggle) toggle = 0, btn_led_set(LED3);
            else toggle = 1, btn_led_clear(LED3);  
        }
        /* wake up radio and check the channel */
        cc1000_wakeup();              
        if (!cca_is_clear()) {
            /* if there is an ongoing transmission try to receive the packet */
            bmac_state = STATE_RX_PRE_START;                 
            spi_enable(); 
            if (bmac_use_led) btn_led_clear(LED3);
        } else {
            spi_disable();
            cc1000_sleep();
            if (bmac_use_led) btn_led_clear(LED1);
        }
    }
}

static void lpl_init(u_short interval)
{
    lpl_interval = interval;
    preamble_length = compute_preamble_length(interval);
    if (lpl_interval > 0) {
        btn_timer_start(lpl_interval, lpl_handler, NULL);
    } else {
        spi_enable();
    }
}

static void lpl_start(void)
{
    NutEnterCritical();      
    if (!btn_timer_is_running() && lpl_interval > 0) 
        btn_timer_start(lpl_interval, lpl_handler, NULL);
    NutExitCritical();        
}

static void lpl_stop(void)
{
    NutEnterCritical();     
    if (btn_timer_is_running()) btn_timer_stop(); 
    NutExitCritical(); 
    if (bmac_use_led) btn_led_clear(LED3);
}

void bmac_set_lpl_interval(u_short interval)
{    
    NutEnterCritical();
    if (interval != lpl_interval) {
        lpl_stop();
        lpl_interval = interval;        
        preamble_length = compute_preamble_length(interval);
        bmac_state = STATE_IDLE;
        if (lpl_interval > 0) {
            spi_disable();
            lpl_start();
        } else {            
            if (cc1000_is_sleeping()) cc1000_wakeup();        
            spi_enable();
        }
    }        
    NutExitCritical();      
}

/* b-mac configuration */

void bmac_set_initial_backoff(u_char max_duration)
{
    bmac_init_backoff = max_duration;
}

void bmac_set_congestion_backoff(u_char max_duration)
{
    bmac_cong_backoff = max_duration;
}

void bmac_enable_ack(int enable_ack)
{
    bmac_use_ack = (enable_ack) ? 1 : 0;
}

void bmac_disable_timer_interrupt(int disable_timer)
{
    bmac_disable_timer = (disable_timer) ? 1 : 0;
}

void bmac_enable_led(int enable_led)
{
    bmac_use_led = (enable_led) ? 1 : 0;
}

void bmac_use_interrupt_to_send(int use_irq)
{
    bmac_use_irq = (use_irq) ? 1 : 0;
}

u_short bmac_get_address(void)
{
    return bmac_address;
}

u_short bmac_get_mtu(void)
{
    return BMAC_MTU;
}

/* simple send and receive functions */

static int bmac_send_fragment(u_short dst, u_char *data, u_char data_len, 
                              u_char is_first, u_char rem_frags)
{
    u_int crc = 0xffff;
    u_int i;
    int use_ack = (bmac_use_ack && dst != BROADCAST_ADDR 
                   && dst != MULTICAST_ADDR(bmac_address));       
    /* setup header and calc crc */
    send_packet.header.destination = htons(dst);
    send_packet.header.source = htons(bmac_address);    
    send_packet.header.length = data_len;
    send_packet.header.flags = rem_frags & FLAG_FRAG_MASK;
    if (use_ack) send_packet.header.flags |= FLAG_ACK; 
    if (is_first) send_packet.header.flags |= FLAG_FRAG_FIRST;             
    for (i=0;i<sizeof(bmac_header_t);i++){
        crc = crc_ccitt_update(crc, ((u_char*) &send_packet.header)[i]);
    }
    send_packet.data = data;   
    for (i=0;i<data_len;i++){
        crc = crc_ccitt_update(crc, data[i]);
    }
    send_packet.crc = htons(crc);
    
    /* transfer data */        
    if (is_first) bmac_state = STATE_TX_PRE_LONG;
    else bmac_state = STATE_TX_PRE_SHORT;
    bmac_txmode();
    if (bmac_use_irq) {
        /* use the SPI interrupt to send */
        timer_disable();
        spi_enable();    
        /* wait until the packet was transmitted */
        NutEventWaitNext(&send_handle, NUT_WAIT_INFINITE);
        if (bmac_disable_timer) {
            /* update system ticks */
            u_short ms = 10 * (data_len 
                + (is_first ? preamble_length : (2 * MIN_PREAMBLE_LENGTH))
                + (use_ack ? (MAX_ACK_LENGTH / 2) : 0)) / 24;
            nut_ticks += ms * 1000L / NutGetTickClock();
        }
        timer_enable();
    } else {
        /* use busy-waiting to send */
        NutEnterCritical();
        while (bmac_state != STATE_IDLE) {
            while (!bit_is_set(SPSR, SPIF));
            spi_handler(NULL);
        }
        /* update system ticks */
        u_short ms = 10 * (data_len
            + (is_first ? preamble_length : (2 * MIN_PREAMBLE_LENGTH))
            + (use_ack ? (MAX_ACK_LENGTH / 2) : 0)) / 24;
        nut_ticks += ms * 1000L / NutGetTickClock();
        NutExitCritical();
    } 
    return (use_ack && !(send_packet.header.flags & FLAG_ACK)) ? -1 : 0;
} 

int bmac_send(u_short dst, u_char *data, u_short data_len)
{ 
    u_char num_frags = (data_len + 254) / 255;
    if (num_frags > (FLAG_FRAG_MASK + 1)) return -1;
    /* get send mutex and stop LPL */
    NutMutexLock(&send_mutex);
    BMAC_DEBUG("bmac_send(%04x, %d) = ", dst, data_len);
    lpl_stop();
    /* wake up radio if necessary */
    if (cc1000_is_sleeping()) cc1000_wakeup();    
    NutEnterCritical();  
    /* wait until logical channel is free */
    while (bmac_state != STATE_IDLE) {        
        NutEventWaitNext(&idle_handle, NUT_WAIT_INFINITE);       
    }    
    bmac_state = STATE_TX_PRE_LONG;
    spi_disable();
    NutExitCritical();
    /* initial backoff */
    NutDelay(((rand() & 0xff) * bmac_init_backoff) >> 8);
    /* wait until physical and logical channel are free */
    while (!cca_is_clear()) {
        /* if another node was faster, try to receive its packet */
        bmac_state = STATE_RX_PRE_START;
        spi_enable();  
        NutEnterCritical();
        while (bmac_state != STATE_IDLE) {         
            NutEventWaitNext(&idle_handle, NUT_WAIT_INFINITE); 
        }
        bmac_state = STATE_TX_PRE_LONG;
        spi_disable();
        NutExitCritical();
        NutDelay(((rand() & 0xff) * bmac_cong_backoff) >> 8);
    }
    /* send data */
    u_char len = (data_len < 255) ? data_len : 255;
    int res = bmac_send_fragment(dst, data, len, 1, --num_frags);
    data += len;
    data_len -= len;        
    while (num_frags > 0 && !res) {        
        len = (data_len < 255) ? data_len : 255;        
        res = bmac_send_fragment(dst, data, len, 0, --num_frags);
        BMAC_DEBUG("%d ", res);
        data += len;
        data_len -= len;       
    }
    /* go back to RX mode, restart LPL, and release the send mutex */
    bmac_rxmode();
    if (lpl_interval > 0) {
        cc1000_sleep();
        lpl_start(); 
    } else {
        spi_enable();
    }
    BMAC_DEBUG("%d\n", res);
    NutMutexUnlock(&send_mutex);
    return res;
}

int bmac_receive(u_short *src, u_short *dst, u_char *data, 
                 u_short *data_length, u_long ms)
{
    u_char fragment = 255, exp_fragment = 0;    
    u_char *buf = NULL;
    u_short length, buf_length = 0;
    
    *src = *dst = 0;
    while (*data_length != buf_length) {
        while (buf_in == buf_out) {
            if (NutEventWaitNext(&recv_handle, ms)) return -1;
        }
        length = recv_buffer[buf_in].header.length;
        fragment = recv_buffer[buf_in].header.flags & FLAG_FRAG_MASK;
        BMAC_DEBUG("Packet[%04x, %d, %d]:\n", 
            ntohs(recv_buffer[buf_in].header.source), fragment, length);
        if (recv_buffer[buf_in].header.flags & FLAG_FRAG_FIRST) {
            /* first fragment */            
            *src = ntohs(recv_buffer[buf_in].header.source);
            *dst = ntohs(recv_buffer[buf_in].header.destination);                                              
            if (buf_length + length > *data_length) 
                length = *data_length - buf_length;                            
            memcpy(data, recv_buffer[buf_in].data, length);
            buf = &data[length];
            buf_length = length;                   
            exp_fragment = fragment - 1; 
            /* if this is the last fragment adapt the data size */
            if (fragment == 0) *data_length = buf_length;    
        } else if (fragment == exp_fragment
                   && *src == ntohs(recv_buffer[buf_in].header.source)
                   && *dst == ntohs(recv_buffer[buf_in].header.destination)) {
            /* expected intermediate fragment */
            if (buf_length + length > *data_length) 
                length = *data_length - buf_length;                            
            memcpy(buf, recv_buffer[buf_in].data, length);                        
            buf += length;   
            buf_length += length;                       
            exp_fragment--; 
            /* if this is the last fragment adapt the data size */
            if (fragment == 0) *data_length = buf_length;
        } else {        
            /* ignore packet */            
        }
        /* remove processed packet from ring buffer */
        NutEnterCritical();
        buf_in = (buf_in + 1) & 3;
        NutExitCritical();
    }
    return 0;
}

/* b-mac and CC1000 initialisation */

static void cc1k_init(void) 
{
   btn_hardware_config_latch_set(CC1000_POWER_ON_PIN);
   NutRegisterIrqHandler(&sig_SPI, spi_handler, NULL); 
   NutSleep(10);
   cc1000_init(FREQ_868_500_MHZ);
   /* init RSSI */
   cc1000_write(CC1000_FRONT_END, 0x32);   
}

int bmac_init(u_short address)
{
    BMAC_DEBUG("bmac_init()\n");
    bmac_address = address;
    bmac_state = STATE_IDLE;
    bmac_use_ack = 0;
    bmac_init_backoff = 5;
    bmac_cong_backoff = 10;
    bmac_disable_timer = 1;
    bmac_use_led = 0;
    bmac_use_irq = 1;
    txmode = 0;
    timer_counter = 0;
    NutMutexInit(&send_mutex);
    recv_buffer[0].data = malloc(255);
    recv_buffer[1].data = malloc(255);
    recv_buffer[2].data = malloc(255);
    recv_buffer[3].data = malloc(255);
    if (recv_buffer[0].data == NULL || recv_buffer[1].data == NULL
        || recv_buffer[2].data == NULL || recv_buffer[3].data == NULL) {
        free(recv_buffer[0].data);
        free(recv_buffer[1].data);
        free(recv_buffer[2].data);
        free(recv_buffer[3].data);
        return -1;
    }
    buf_in = buf_out = 0;
    /* init CC1000 radio, CCA, and LPL */
    cc1k_init();
    cca_init();   
    lpl_init(100);             
    return 0;
}

mac_interface_t bmac_interface = {
  .get_address = bmac_get_address,
  .get_mtu     = bmac_get_mtu,
  .send        = bmac_send,
  .receive     = bmac_receive, 
};

#endif
