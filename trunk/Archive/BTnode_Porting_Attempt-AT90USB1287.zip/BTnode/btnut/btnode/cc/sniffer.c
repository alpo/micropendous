/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

#ifdef __BTNODE3__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <cc/cc1000.h>
#include <cc/cc1000_defs.h>
#include <cc/mac.h>
#include <sys/types.h>
#include <sys/event.h>
#include <sys/timer.h>
#include <sys/atom.h>
#include <dev/irqreg.h>
#include <cc/crc.h>
#include <hardware/btn-hardware.h>

#include <cc/sniffer.h>


#define PREAMBLE_THRESH 4 //number of preamble bytes need to see

extern u_long nut_ticks;

typedef enum {
    STATE_IDLE = 0,  
    STATE_RECV_IDLE = 10, 
    STATE_RECV_PRE,
    STATE_RECV_SYNC,
    STATE_RECV_SYNC_FIRST,
    STATE_RECV_SYNC_SECOND,
    STATE_RECV_SIZE,
    STATE_RECV_HEADER,
    STATE_RECV_DATA, 
    STATE_RECV_CRC_H,
    STATE_RECV_CRC_L, 
    
    STATE_SEND_PRE = 30,
    STATE_SEND_SYNC,
    STATE_SEND_SIZE,
    STATE_SEND_DATA, 
    STATE_SEND_FLUSH, 
    STATE_SEND_CRC_H, 
    STATE_SEND_CRC_L, 
    STATE_SEND_DONE 
} generic_state_t;

u_long ccFreq = 0;
u_char ccSopLength;
u_char ccSopFirst;
u_char ccSopSecond;
u_char ccHeaderSize; // equals packet size for fixed size packets, size of header otherwise
u_char ccPacketSize; // derived from header if not-fixed size
u_char ccCrcLength;
u_int  ccCrcPoly;
u_char ccCrcPos;
u_char ccFixedSize;
u_char ccLengthPos;
u_char ccLengthOffset;

static u_char sniffer_use_led;
static u_char buf_in;
static u_char buf_out;
static u_long recv_count;
static u_long failed_count;

#define buffMax 4

static struct Buff *realBuffer;
static struct Buff *RecvBuff;

static uint8_t state=STATE_RECV_IDLE;
static HANDLE RecvHandle=0;
static uint8_t state,prevData=0, spData,preambleCount=0,offset=0,dataCount=0;


/////////////////// ADC RSSI ///////////////////////

/* adc initialization*/
void sniffer_rssi_init(void){
    uint8_t temp;
    ADCSRA = (1 << ADEN);
    ADMUX = 2; //CC1000_RSSI_ADC; //2 for btnode, 0 for mica2
    ADMUX |= BV(ADLAR); //left adjusted, only read ADCH
    
    // first conversion takes 25 adc cycles
    ADCSRA |= (1 << ADSC);
    while(ADCSRA & (1<<ADSC));
    temp=ADCL;
    temp=ADCH;
}

u_char sniffer_rssi_read(void){
    // start
    ADCSRA |= BV(ADSC);
    // wait for finished
    while(ADCSRA & BV(ADSC));
    return ADCH;
}

/////////////////// PROTOCOL ///////////////////////


static void ccSnifferSpi(void* arg)
{
    // first get current byte
    spData=SPDR;
    
    switch(state)
    {
        case STATE_RECV_IDLE:
            if(spData == 0xAA || spData == 0x55) //we are in preamble
            {
                preambleCount = 0;
                dataCount = 0;
                state = STATE_RECV_PRE;
            }
            break;
            
        case STATE_RECV_PRE:
            if(spData != 0xAA && spData != 0x55) //not in preamble anymore
            {
                if(preambleCount > PREAMBLE_THRESH) //reached end of preamble
                {
                    // we might have received the (first byte of) 
                    // SOP together with last preamble byte
                    offset = 0;
                    while ( prevData != ccSopFirst && offset < 8){
                        prevData = (prevData << 1) | (spData >> (7-offset));
                        offset++;
                    }
                    if(offset >= 8) //didn't get the sync byte so far
                    {
                        state = STATE_RECV_SYNC_FIRST; // first SOP byte must come now
                    }
                    else {
                        if (ccSopLength == 1) {
                            state = STATE_RECV_HEADER;       // done with sync
                            // start ADC
                            ADCSRA |= BV(ADSC);
                        } else { 
                            state = STATE_RECV_SYNC_SECOND;  // check second byte
                        }
                    }
                }
                else //just looking at noise
                {
                    state = STATE_RECV_IDLE;
                }
            }
            else //just seeing more of the preamble
            {
                // prevent preamble counter from overflowing
                if(preambleCount <= PREAMBLE_THRESH) {
                    preambleCount++;
                }
            }
            prevData = spData; 
            break;

        case STATE_RECV_SYNC_FIRST:

            offset = 0;
            while ( prevData != ccSopFirst && offset < 8) {
                prevData = (prevData << 1) | (spData >> (7-offset));
                offset++;
            }
            if(offset >= 8) //didn't get the sync byte... Something is wrong
            {
                state = STATE_RECV_IDLE; // failed
            }
            else {
                if (ccSopLength == 1) {
                    //ready to recv data
                    state = STATE_RECV_HEADER;       // done with sync
                    // start ADC
                    ADCSRA |= BV(ADSC);
                } else { 
                    state = STATE_RECV_SYNC_SECOND;  // check second byte
                }
            }
            prevData = spData; 
            break;
            
        case STATE_RECV_SYNC_SECOND:
            
            if ( ((prevData << offset) | (spData >> (8-offset))) == ccSopSecond) {
                state = STATE_RECV_HEADER;       // done with sync
                // start ADC
                ADCSRA |= BV(ADSC);
            } else {
                state = STATE_RECV_IDLE; // failed
            }
            prevData = spData; 
            break;

        case STATE_RECV_HEADER:

            // store byte 
            RecvBuff->data[dataCount]   = (prevData << offset) | (spData >> (8-offset));
            // store RSSi
            RecvBuff->rssi[dataCount++] = ADCH;

            // check for size
            if ( dataCount == ccHeaderSize){
                if (ccFixedSize) {
                    state = STATE_RECV_CRC_H;
                } else {
                    // get data size
                    ccPacketSize = ccHeaderSize + RecvBuff->data[ccLengthPos] + ccLengthOffset;
                    state = STATE_RECV_DATA;
                }
            }

            // restart ADC
            ADCSRA |= BV(ADSC);

            prevData = spData; 
            break;
                    
        case STATE_RECV_DATA:
            // store byte 
            RecvBuff->data[dataCount]   = (prevData << offset) | (spData >> (8-offset));
            // store RSSi
            RecvBuff->rssi[dataCount++] = ADCH;

            /* Once we have the whole packet, get the crc*/
            if (dataCount == ccPacketSize) {
                state = STATE_RECV_CRC_H;
            } else {
                ADCSRA |= BV(ADSC);
            }
            prevData = spData;
            break;
            
        case STATE_RECV_CRC_H:
            // store byte 
            RecvBuff->data[dataCount]   = (prevData << offset) | (spData >> (8-offset));
            // store RSSi
            RecvBuff->rssi[dataCount++] = ADCH;

            //store high byte of crc
            RecvBuff->receivedCRCH = (prevData << offset) | (spData >> (8-offset));
            RecvBuff->receivedCRCH = (prevData << offset) | (spData >> (8-offset));
            state = STATE_RECV_CRC_L;
            ADCSRA |= BV(ADSC);
            prevData = spData;
            break;
            
        case STATE_RECV_CRC_L:
            // store byte 
            RecvBuff->data[dataCount]   = (prevData << offset) | (spData >> (8-offset));
            // store RSSi
            RecvBuff->rssi[dataCount++] = ADCH;

            // read low byte and assemble full crc
            if (ccCrcLength == 2) {
                RecvBuff->receivedCRCL = (prevData << offset) | (spData >> (8-offset));
            } else {
                RecvBuff->receivedCRCL = 0;
            }
            
            // store size
            RecvBuff->size = dataCount;
            
            // timestamp packet
            RecvBuff->timestamp = nut_ticks;

            // store used bit offset
            RecvBuff->offset = offset;
            
            /* add packet to ring buffer */ 
            buf_out = (buf_out + 1) & 3;                            
            if (buf_out == buf_in) {
                buf_in = (buf_in + 1) & 3;
                ++failed_count;
            } else {
                ++recv_count;
            }                                              
            RecvBuff = &realBuffer[buf_out];
                
            // done with this one
            state = STATE_RECV_IDLE;

            //resume the thread
            NutEventPostFromIrq(&RecvHandle);
        }
}


// returns NULL if no data received in time,
// pointer to buffer otherwise
// does not assure buffer is not overwritten
int  sniffer_receive_extra(u_short *src, u_short *dst, u_char *data, 
                               u_short *data_length, u_long timeout,
                               u_int *rssi, u_int * rssi_deviation, u_long *timestamp)
{
    u_short length = 0;
    u_int   average = 0;
    u_long  sqrDeviation = 0;
    u_char i;
    
    *src = *dst = 0;
    
    while (buf_in == buf_out) {
        if (NutEventWaitNext(&RecvHandle, timeout)) return -1;
    }
    
    length = realBuffer[buf_in].size + ccCrcLength;
    if (length > *data_length) 
        length = *data_length;                            
    memcpy(data, realBuffer[buf_in].data, length);
  
    // calc rssi values
    if (rssi) {

        for (i=0; i < realBuffer[buf_in].size; i++) {
            average += realBuffer[buf_in].rssi[i];
        }
        average = average /  realBuffer[buf_in].size;
        *rssi = average;
        
        if (rssi_deviation) {
            // calc deviation
            for (i=0; i < realBuffer[buf_in].size; i++) {
                sqrDeviation += (average-realBuffer[buf_in].rssi[i]) * (average-realBuffer[buf_in].rssi[i]);
            };
            sqrDeviation = sqrDeviation /  realBuffer[buf_in].size;
            
            // std deviation
            i = 0;
            while ( i*i < sqrDeviation) {
                i++;
            }
            *rssi_deviation = i;
        }
    }
    // set time stamp
    if (timestamp != 0) {
        *timestamp = realBuffer[buf_in].timestamp;
        
        // @todo: correct time stamp based on offset
        // at 19200 bits/s, a single bit ist roughly 52 uS, 8 bits lead to about 400 uS delay.
        // if timestamp is in ticks (and we have 1024 ticks per second), this is useles.
    }
    /* remove processed packet from ring buffer */
    NutEnterCritical();
    buf_in = (buf_in + 1) & 3;
    NutExitCritical();
    
    return 0;
}


int sniffer_receive(u_short *src, u_short *dst, u_char *data, 
                    u_short *data_length, u_long timeout)
{
    u_short length = 0;
    
    if (src != 0)
        *src = 0;
    if (dst != 0)
        *dst = 0;
    
    while (buf_in == buf_out) {
        if (NutEventWaitNext(&RecvHandle, timeout)) return -1;
    }

    length = realBuffer[buf_in].size + ccCrcLength;
    if (length > *data_length) 
        length = *data_length;    
    *data_length = length;
    memcpy(data, realBuffer[buf_in].data, length);
    
    /* remove processed packet from ring buffer */
    NutEnterCritical();
    buf_in = (buf_in + 1) & 3;
    NutExitCritical();
    
    return 0;
}

/* sniffer and CC1000 initialisation */

static void cc1k_init(void) 
{
    btn_hardware_config_latch_set(CC1000_POWER_ON_PIN);
    NutSleep(10);
    cc1000_init(FREQ_868_500_MHZ);
    /* init RSSI */
    cc1000_write(CC1000_FRONT_END, 0x32);   
}

/* starts data reception */
void sniffer_start(void){
    // receive mode
    cc1000_rxmode();  
    
    // set state machine
    state=STATE_RECV_IDLE;
    
    // reset recv handle
    RecvHandle = 0;
    
    //enable the spi interrupt
    SPCR |= (1 << SPIE);
}

/* stops data reception */

void sniffer_stop(void){
    
    //disable the spi interrupt
    SPCR &= ~(1 << SPIE);
    
    // reset state machine
    state=STATE_RECV_IDLE;
    
    // put cc into sleep mode
    cc1000_sleep();
}

int sniffer_init(void)
{
    sniffer_use_led = 0;
    state = STATE_IDLE;
    
    realBuffer = malloc( buffMax * sizeof( struct Buff));
    if (realBuffer == NULL) {
        return -1;
    }
    buf_in = buf_out = 0;
    RecvBuff = &realBuffer[buf_out];

    /* init CC1000 radio */
    cc1k_init();
    
    // init SPI
    NutRegisterIrqHandler(&sig_SPI, ccSnifferSpi, NULL); 
 
    /* get started */
    sniffer_start();
    return 0;
}


u_short sniffer_get_address(void);
u_short sniffer_get_address(void){
    return 0xffff;
}

u_short sniffer_get_mtu(void);
u_short sniffer_get_mtu(void){
    return MAX_DATA_SIZE;
}

int sniffer_send(u_short dst, u_char *data, u_short data_len);
int sniffer_send(u_short dst, u_char *data, u_short data_len){
    return -1;
}

/* ccc interface */
mac_interface_t sniffer_interface = {
    .get_address = sniffer_get_address,
    .get_mtu     = sniffer_get_mtu,
    .send        = sniffer_send,
    .receive     = sniffer_receive, 
};

#endif
