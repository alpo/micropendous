/**
* @file cc/cc1000_tuner.c
 *
 * @brief Chipcon CC1000 function to set to an arbitary frequency
 *        ported from TinyOS CC1000Control.nc by Matthias Ringwald for BTnut
 */

/*									tab:4
 *
 *
 * "Copyright (c) 2000-2002 The Regents of the University  of California.  
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 */
/*									tab:4
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.  By
 *  downloading, copying, installing or using the software you agree to
 *  this license.  If you do not agree to this license, do not download,
 *  install, copy or use the software.
 *
 *  Intel Open Source License 
 *
 *  Copyright (c) 2002 Intel Corporation 
 *  All rights reserved. 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are
 *  met:
 * 
 *	Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *	Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *      Neither the name of the Intel Corporation nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 *  PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE INTEL OR ITS
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * 
 */

/*
 *
 * Authors:		Philip Buonadonna, Jaein Jeong
 * Date last modified:  $Revision: 1.1 $
 *
 */

#ifdef __BTNODE3__

#include <stdio.h>
#include <dev/irqreg.h>
#include <arch/btn-hardware.h>
#include <cc/cc1000.h>
#include <cc/cc1000_defs.h>
#include <cc/cc1000_params.h>

uint32_t gCurrentChannel;
uint8_t gCurrentParameters[31];

enum {
	IF = 150000,
	FREQ_MIN = 4194304,
	FREQ_MAX = 16751615
};

const uint32_t FRefTbl[9] = {2457600,
	2106514,
	1843200,
	1638400,
	1474560,
	1340509,
	1228800,
	1134277,
	1053257};

const uint16_t CorTbl[9] = {1213,
	1416,
	1618,
	1820,
	2022,
	2224,
	2427,
	2629,
	2831};

const uint16_t FSepTbl[9] = {0x1AA,
	0x1F1,
	0x238,
	0x280,
	0x2C7,
	0x30E,
	0x355,
	0x39C,
	0x3E3};

/*
 * cc1000ComputeFreq(uint32_t desiredFreq);
 *
 * Compute an achievable frequency and the necessary CC1000 parameters from
 * a given desired frequency (Hz). The function returns the actual achieved
 * channel frequency in Hz.
 *
 * This routine assumes the following:
 *  - Crystal Freq: 14.7456 MHz
 *  - LO Injection: High
 *  - Separation: 64 KHz
 *  - IF: 150 KHz
 * 
 * Approximate costs for this function:
 *  - ~870 bytes FLASH
 *  - ~32 bytes RAM
 *  - 9400 cycles
 */
uint32_t cc1000_compute_freq(uint32_t desiredFreq) {
	
	uint32_t ActualChannel = 0;
	uint32_t RXFreq = 0, TXFreq = 0;
	int32_t Offset = 0x7fffffff;
	uint16_t FSep = 0;
	uint8_t RefDiv = 0;
	uint8_t i;
	
	for (i = 0; i < 9; i++) {
		
		uint32_t NRef = ((desiredFreq + IF));
		uint32_t FRef = FRefTbl[i];
		uint32_t Channel = 0;
		uint32_t RXCalc = 0, TXCalc = 0;
		int32_t  diff;
		
		NRef = ((desiredFreq + IF) << 2) / FRef;
		if (NRef & 0x1) {
			NRef++;
		}
		
		if (NRef & 0x2) {
			RXCalc = 16384 >> 1;
			Channel = FRef >> 1;
		}
		
		NRef >>= 2;
		
		RXCalc += (NRef * 16384) - 8192;
		if ((RXCalc < FREQ_MIN) || (RXCalc > FREQ_MAX)) 
			continue;
		
		TXCalc = RXCalc - CorTbl[i];
		if ((TXCalc < FREQ_MIN) || (TXCalc > FREQ_MAX)) 
			continue;
		
		Channel += (NRef * FRef);
		Channel -= IF;
		
		diff = Channel - desiredFreq;
		if (diff < 0)
			diff = 0 - diff;
		
		if (diff < Offset) {
			RXFreq = RXCalc;
			TXFreq = TXCalc;
			ActualChannel = Channel;
			FSep = FSepTbl[i];
			RefDiv = i + 6;
			Offset = diff;
		}
		
	}
	
	if (RefDiv != 0) {
		// FREQA
		gCurrentParameters[0x3] = (uint8_t)((RXFreq) & 0xFF);  // LSB
		gCurrentParameters[0x2] = (uint8_t)((RXFreq >> 8) & 0xFF);
		gCurrentParameters[0x1] = (uint8_t)((RXFreq >> 16) & 0xFF);  // MSB
																	 // FREQB
		gCurrentParameters[0x6] = (uint8_t)((TXFreq) & 0xFF); // LSB
		gCurrentParameters[0x5] = (uint8_t)((TXFreq >> 8) & 0xFF);
		gCurrentParameters[0x4] = (uint8_t)((TXFreq >> 16) & 0xFF);  // MSB
																	 // FSEP
		gCurrentParameters[0x8] = (uint8_t)((FSep) & 0xFF);  // LSB
		gCurrentParameters[0x7] = (uint8_t)((FSep >> 8) & 0xFF); //MSB
		
		if (ActualChannel < 500000000) {
			if (ActualChannel < 400000000) {
				// CURRENT (RX)
				gCurrentParameters[0x9] = ((8 << CC1000_VCO_CURRENT) | (1 << CC1000_LO_DRIVE));
				// CURRENT (TX)
				gCurrentParameters[0x1d] = ((9 << CC1000_VCO_CURRENT) | (1 << CC1000_PA_DRIVE));
			}
			else {
				// CURRENT (RX)
				gCurrentParameters[0x9] = ((4 << CC1000_VCO_CURRENT) | (1 << CC1000_LO_DRIVE));
				// CURRENT (TX)
				gCurrentParameters[0x1d] = ((8 << CC1000_VCO_CURRENT) | (1 << CC1000_PA_DRIVE));
			}
			// FRONT_END
			gCurrentParameters[0xa] = (1 << CC1000_IF_RSSI); 
			// MATCH
			gCurrentParameters[0x12] = (7 << CC1000_RX_MATCH);
		}
		else {
			// CURRENT (RX)
			gCurrentParameters[0x9] = ((8 << CC1000_VCO_CURRENT) | (3 << CC1000_LO_DRIVE));
			// CURRENT (TX)
			gCurrentParameters[0x1d] = ((15 << CC1000_VCO_CURRENT) | (3 << CC1000_PA_DRIVE));
			
			// FRONT_END
			gCurrentParameters[0xa] = ((1<<CC1000_BUF_CURRENT) | (2<<CC1000_LNA_CURRENT) | 
									   (1<<CC1000_IF_RSSI));
			// MATCH
			gCurrentParameters[0x12] = (2 << CC1000_RX_MATCH);
			
		}
		// PLL
		gCurrentParameters[0xc] = (RefDiv << CC1000_REFDIV);
	}
	
	gCurrentChannel = ActualChannel;
	return ActualChannel;
	
}


/* Set the radio to a specific frequency based on gCurrentParameters */
inline void cc1000_set_freq(void)
{
    int i;
	
    // FREQA, FREQB, FSEP, CURRENT(RX), FRONT_END, POWER, PLL, RFDIV
    for (i = 1; i < 0xd; i++){
        cc1000_write(i, gCurrentParameters[i]);
	}

    // MATCH
	cc1000_write(0x12, gCurrentParameters[0x12]);
	
    // test4 and the presacler have to be set separatedly
    // The default is written to be 38.2 KBaud, i.e. 19.2 bps in Manchester coding
    cc1000_write(CC1000_TEST4, cc1000_params_template[TEST4_INDEX]);
	
    cc1000_write(CC1000_PRESCALER, cc1000_params_template[PRESCALER_INDEX]);
	
    //recalibrate after setting the new frequency
    cc1000_calibrate();
	
    //set the cc1000 to the receive mode
    cc1000_rxmode();
}


//
// PUBLIC Module Functions
//
uint32_t cc1000_tune_manual(uint32_t DesiredFreq) {
	uint32_t actualFreq;
	
	actualFreq = cc1000_compute_freq(DesiredFreq);
	
	cc1000_set_freq();
	
	return actualFreq;
}
#endif
