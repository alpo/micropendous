#/*
 * Copyright (C) 2005 Mario Strasser <mast@gmx.net>,
 *                    Swiss Federal Institute of Technology (ETH) Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id: ccc.c,v 1.6 2006/03/23 07:22:25 dyerm Exp $
 */

#ifdef __BTNODE3__
 
#include <string.h>
#include <sys/atom.h>
#include <sys/event.h>
#include <sys/timer.h>
#include <sys/thread.h>
#include <cc/mac.h>
#include <cc/ccc.h>
 
#define MAX_PACKET_HANDLERS         16
#define HANDLER_THREAD_STACK_SIZE   768

static struct {
    u_char type;
    ccc_packet_handler_t handler;
} *packet_handlers;
static u_char num_packet_handlers = 0;
static ccc_packet_t *ccc_packet = NULL;
static u_char ccc_run = 0;
static HANDLE ccc_thread = NULL;

static mac_interface_t *mac = NULL;

THREAD(ccc_receive_thread, arg)
{      
    int res;
    u_short src, dst, length;
    ccc_packet_handler_t handler;
    /* increase the thread's priority to make sure that available packets are 
       processed as soon as possible and are not delayed by low-priority 
       working threads */
    NutThreadSetPriority(16);
    while (ccc_run) {
        /* use a blocking receive to get the next packet ... */
        length = ccc_get_mtu();
		/* We need to pass a pointer to the entire packet, not the type! */	
		res = mac->receive(&src, &dst, (u_char *)ccc_packet, 
                           &length, NUT_WAIT_INFINITE);
        /* ... and if an appropriate handler is installed, call it */
        if (!res && (handler = ccc_get_packet_handler(ccc_packet->type))) {
            ccc_packet->src = ntohs(ccc_packet->src);
            ccc_packet->dst = ntohs(ccc_packet->dst);
            ccc_packet->length = length - sizeof(ccc_packet_t);
            handler(ccc_packet);
        }
    }  
    free(ccc_packet);
    NutThreadExit();
    for (;;);
}

int ccc_init(mac_interface_t *mac_interface)
{
    if (mac_interface == NULL) return -1;
    mac = mac_interface;
    int handlers_size = sizeof(packet_handlers[0]) * MAX_PACKET_HANDLERS;
    packet_handlers = malloc(handlers_size);
    ccc_packet = malloc(mac->get_mtu());
    if (packet_handlers == NULL || ccc_packet == NULL) {
        free(packet_handlers);
        free(ccc_packet);
        return -1;
    }
    num_packet_handlers = 0;
    memset(packet_handlers, 0, handlers_size);            
    ccc_run = 1;
    ccc_thread = NutThreadCreate("ccc_rec", ccc_receive_thread, 
                                 NULL, HANDLER_THREAD_STACK_SIZE);
    return 0;
}

void ccc_release(void)
{
    ccc_run = 0;    
}
 
u_short ccc_get_address(void)
{
    return mac->get_address();
}

u_short ccc_get_mtu(void)
{
    return mac->get_mtu() - sizeof(ccc_packet_t);
}

ccc_packet_t* new_ccc_packet(u_short data_length)
{
    return malloc(sizeof(ccc_packet_t) + data_length);
}
 
int ccc_send(u_short dst, u_char type, ccc_packet_t *pkt)
{
    int res;
    u_short length = pkt->length + sizeof(ccc_packet_t);
    pkt->src = htons(ccc_get_address());
    pkt->dst = htons(dst);
    pkt->length = htons(pkt->length);
    pkt->type = type;
    res = mac->send(dst, (u_char*)pkt, length);
    pkt->src = ccc_get_address();
    pkt->dst = dst;
    pkt->length = ntohs(pkt->length);
    return res;
}
 
int ccc_register_packet_handler(u_char type, ccc_packet_handler_t handler)
{
    u_char i;
    if (type == 0 || num_packet_handlers >= MAX_PACKET_HANDLERS) return -1;
    for (i = 0; i < num_packet_handlers; i++) {
        if (packet_handlers[i].type == type) return -1;        
    }
    packet_handlers[i].type = type;
    packet_handlers[i].handler = handler;
    ++num_packet_handlers;
    return 0;
}
 
void ccc_deregister_packet_handler(u_char type)
{
    u_char i, j;
    /* replace the specified handler with the last in the list 
       and shorten the list by one */
    for (i = 0; i < num_packet_handlers && type != 0; i++) {
        if (packet_handlers[i].type == type) {
            j = --num_packet_handlers;
            packet_handlers[i].type = packet_handlers[j].type;
            packet_handlers[i].handler = packet_handlers[j].handler;
            packet_handlers[j].type = 0;
            packet_handlers[j].handler = NULL;
            break;  
        }        
    }    
}
 
ccc_packet_handler_t ccc_get_packet_handler(u_char type)
{
    u_char i;
    for (i = 0; i < num_packet_handlers; i++) {
        if (packet_handlers[i].type == type) return packet_handlers[i].handler;        
    }
    return NULL;
}

#endif
