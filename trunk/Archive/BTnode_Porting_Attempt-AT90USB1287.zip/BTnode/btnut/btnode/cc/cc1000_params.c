/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */
 
 /**
 * @file cc/cc1000_params.c
 *
 * @brief Chipcon CC1000 params and frequency settings for both ISM 915 MHz and 868 MHz
 * 
 *
 * 2004/06/19 Matthias Ringwald <mringwal@inf.ethz.ch>
 *
 */

#include <sys/types.h>
#include <cc/cc1000_defs.h>

/** THe base template of the cc1000 radio templates */
u_char cc1000_params_template[PARAM_NUM] =
{ 
   // MAIN 00
   0x11,
   // FREQ2A,FREQ1A,FREQ0A 01 - 03 //this is different from setting to setting
   0xD6,0x40,0x00,					
   // FREQ2B,FREQ1B,FREQ0B 04 - 06 //this is different from setting to setting
   0xD6,0x47,0x2B,					
   // FSEP1, FSEP0 07 08
   0X03,0xE3,
   // CURRENT (RX MODE VALUE) 09
   0x8F,	
   // FRONT_END 0a
   0x30,  //0x30-rssi-off, 0x32-rssi-on 
   // PA_POW 0b
   0xFF,
   // PLL RX 0c
   0x70,		 
   // LOCK 0d 
   0x10, 
   // CAL 0e 
   0x26,	 
   // MODEM2 0f 
   0x90, 	
   // MODEM1 10 
   0x6F,  
   // MODEM0	11  //decide the speed, varied from setting to setting
   0x55, // 0x55-manchaster, 0x51-NRZ
   // MATCH 12h 
   0x20, 
   // FSCTRL 13h 
   0x01,			 
   // FSHAPE7 - FSHAPE1 14,15,16,17,18,19,1a 
   0x00,0x00,0x00,0x00,0x00,0x00,0x00,	 
   // FSDELAY 1bh 
   0x00,	 
   // PRESCALER 1ch 
   0x00, 
   // TEST6 - TEST0; 40 - 46h 
   0x00,0x00,0x3f,0x00,0x00,0x00,0x00, 
   // CURRENT (TX MODE VALUE) index=29 
   0xf3, 
   // PLL_TX 
   0x70   
};



u_char cc1000_params[FREQS_NUM][SETTING_NUM] =
{
   // 902.265, 19.2 kBoudrate      0x00
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD6,0x00,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD6,0x07,0x2B
   }, 

   // 902.791, 19.2 kBoudrate      0x01
   { 
      // FREQ2A,FREQ1A,FREQ0A 01 - 03
           0xD6,0x20,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
           0xD6,0x27,0x2B					
   }, 

   // 903.318, 19.2 kBoudrate      0x02
   { 
      // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD6,0x40,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD6,0x47,0x2B
   }, 

   // 903.845, 19.2 kBoudrate        0x03
   {    // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD6,0x60,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD6,0x67,0x2B					
   }, 

   // 904.371, 19.2 kBoudrate       0x04
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD6,0x80,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD6,0x87,0x2B					
   }, 

   // 904.898, 19.2 kBoudrate       0x05
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD6,0xa0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD6,0xa7,0x2B  
   }, 
   // 905.43f, 19.2 kBoudrate       0x06
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD6,0xc0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD6,0xc7,0x2B
   }, 
   //#define FREQ_905_951_MHZ        0x07
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD6,0xE0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD6,0xE7,0x2B
   }, 

   //#define FREQ_906_478_MHZ	0x08
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD7,0x00,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD7,0x07,0x2B
   }, 

   //#define FREQ_907_004_MHZ        0x0a
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD7,0x20,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD7,0x27,0x2B
   }, 

   //#define FREQ_907_531_MHZ        0x0a
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD7,0x40,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD7,0x47,0x2B
   }, 

   //#define FREQ_908_058_MHZ        0x0b
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD7,0x60,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD7,0x67,0x2B
   }, 

   //#define FREQ_908_584_MHZ	0x0c
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD7,0x80,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD7,0x87,0x2B					
   }, 

   //#define FREQ_909_111_MHZ	0x0d
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD7,0xA0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD7,0xA7,0x2B					
   }, 

   //#define FREQ_909_638_MHZ        0x0e
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD7,0xc0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD7,0xc7,0x2B					
   }, 

   //#define FREQ_910_164_MHZ        0x0f
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD7,0xE0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD7,0xE7,0x2B					
   }, 

   //#define FREQ_910_691_MHZ	0x10
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD8,0x00,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD8,0x07,0x2B
   }, 

   //#define FREQ_911_217_MHZ	0x11
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD8,0x20,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD8,0x27,0x2B
   }, 

   //#define FREQ_911_744_MHZ        0x12
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD8,0x40,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD8,0x47,0x2B
   }, 

   //#define FREQ_912_271_MHZ        0x13
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD8,0x60,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD8,0x67,0x2B
   }, 

   //#define FREQ_912_797_MHZ	0x14
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD8,0x80,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD8,0x87,0x2B
   }, 

   //#define FREQ_913_324_MHZ	0x15
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD8,0xA0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD8,0xA7,0x2B
   }, 

   //#define FREQ_913_851_MHZ        0x16
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD8,0xc0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD8,0xc7,0x2B
   }, 

   //#define FREQ_914_377_MHZ        0x17
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD8,0xE0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD8,0xE7,0x2B
   }, 

   //#define FREQ_914_907_MHZ        0x18
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD9,0x00,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD9,0x07,0x2B
   }, 

   //#define FREQ_915_430_MHZ        0x19
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD9,0x20,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD9,0x27,0x2B
   }, 

   //#define FREQ_915_957_MHZ        0x1a
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD9,0x40,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD9,0x47,0x2B
   }, 

   //#define FREQ_916_484_MHZ        0x1b
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD9,0x60,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD9,0x67,0x2B
   }, 

   //#define FREQ_917_010_MHZ        0x1c
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD9,0x80,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD9,0x87,0x2B
   }, 

   //#define FREQ_917_537_MHZ        0x1d
   {  // FREQ2A,FREQ1A,FREQ0A 01 - 03
      0xD9,0xA0,0x00,					
      // FREQ2B,FREQ1B,FREQ0B 04 - 06
      0xD9,0xA7,0x2B
   }, 

    // #define FREQ_863_100_MHZ   30 
    {
        0xCC,0xB4,0x32,
        0xCC,0xBB,0x5E
    },
    
    // #define FREQ_863_300_MHZ   31 
    {
        0xCC,0xC0,0x59,
        0xCC,0xC7,0x85
    },
    
    // #define FREQ_863_500_MHZ   32 
    {
        0xCC,0xCC,0x80,
        0xCC,0xD3,0xAC
    },
    
    // #define FREQ_863_700_MHZ   33 
    {
        0xCC,0xD8,0xA7,
        0xCC,0xDF,0xD3
    },
    
    // #define FREQ_863_900_MHZ   34 
    {
        0xCC,0xE4,0xCF,
        0xCC,0xEB,0xFA
    },
    
    // #define FREQ_864_100_MHZ   35 
    {
        0xCC,0xF0,0xF6,
        0xCC,0xF8,0x21
    },
    
    // #define FREQ_864_300_MHZ   36 
    {
        0xCC,0xFD,0x1D,
        0xCD,0x04,0x48
    },
    
    // #define FREQ_864_500_MHZ   37 
    {
        0xCD,0x09,0x44,
        0xCD,0x10,0x6F
    },
    
    // #define FREQ_864_700_MHZ   38 
    {
        0xCD,0x15,0x6B,
        0xCD,0x1C,0x97
    },
    
    // #define FREQ_864_900_MHZ   39 
    {
        0xCD,0x21,0x92,
        0xCD,0x28,0xBE
    },
    
    // #define FREQ_865_100_MHZ   40 
    {
        0xCD,0x2D,0xB9,
        0xCD,0x34,0xE5
    },
    
    // #define FREQ_865_300_MHZ   41 
    {
        0xCD,0x39,0xE0,
        0xCD,0x41,0x0C
    },
    
    // #define FREQ_865_500_MHZ   42 
    {
        0xCD,0x46,0x07,
        0xCD,0x4D,0x33
    },
    
    // #define FREQ_865_700_MHZ   43 
    {
        0xCD,0x52,0x2F,
        0xCD,0x59,0x5A
    },
    
    // #define FREQ_865_900_MHZ   44 
    {
        0xCD,0x5E,0x56,
        0xCD,0x65,0x81
    },
    
    // #define FREQ_866_100_MHZ   45 
    {
        0xCD,0x6A,0x7D,
        0xCD,0x71,0xA8
    },
    
    // #define FREQ_866_300_MHZ   46 
    {
        0xCD,0x76,0xA4,
        0xCD,0x7D,0xCF
    },
    
    // #define FREQ_866_500_MHZ   47 
    {
        0xCD,0x82,0xCB,
        0xCD,0x89,0xF7
    },
    
    // #define FREQ_866_700_MHZ   48 
    {
        0xCD,0x8E,0xF2,
        0xCD,0x96,0x1E
    },
    
    // #define FREQ_866_900_MHZ   49 
    {
        0xCD,0x9B,0x19,
        0xCD,0xA2,0x45
    },
    
    // #define FREQ_867_100_MHZ   50 
    {
        0xCD,0xA7,0x40,
        0xCD,0xAE,0x6C
    },
    
    // #define FREQ_867_300_MHZ   51 
    {
        0xCD,0xB3,0x67,
        0xCD,0xBA,0x93
    },
    
    // #define FREQ_867_500_MHZ   52 
    {
        0xCD,0xBF,0x8F,
        0xCD,0xC6,0xBA
    },
    
    // #define FREQ_867_700_MHZ   53 
    {
        0xCD,0xCB,0xB6,
        0xCD,0xD2,0xE1
    },
    
    // #define FREQ_867_900_MHZ   54 
    {
        0xCD,0xD7,0xDD,
        0xCD,0xDF,0x08
    },
    
    // #define FREQ_868_100_MHZ   55 
    {
        0xCD,0xE4,0x04,
        0xCD,0xEB,0x2F
    },
    
    // #define FREQ_868_300_MHZ   56 
    {
        0xCD,0xF0,0x2B,
        0xCD,0xF7,0x57
    },
    
    // #define FREQ_868_500_MHZ   57 
    {
        0xCD,0xFC,0x52,
        0xCE,0x03,0x7E
    },
    
    // #define FREQ_868_700_MHZ   58 
    {
        0xCE,0x08,0x79,
        0xCE,0x0F,0xA5
    },
    
    // #define FREQ_868_900_MHZ   59 
    {
        0xCE,0x14,0xA0,
        0xCE,0x1B,0xCC
    },
    
    // #define FREQ_869_100_MHZ   60 
    {
        0xCE,0x20,0xC7,
        0xCE,0x27,0xF3
    },
    
    // #define FREQ_869_300_MHZ   61 
    {
        0xCE,0x2C,0xEF,
        0xCE,0x34,0x1A
    },
    
    // #define FREQ_869_500_MHZ   62 
    {
        0xCE,0x39,0x16,
        0xCE,0x40,0x41
    },
    
    // #define FREQ_869_700_MHZ   63 
    {
        0xCE,0x45,0x3D,
        0xCE,0x4C,0x68
    },
    
    // #define FREQ_869_900_MHZ   64 
    {
        0xCE,0x51,0x64,
        0xCE,0x58,0x8F
    },
    
}; 
