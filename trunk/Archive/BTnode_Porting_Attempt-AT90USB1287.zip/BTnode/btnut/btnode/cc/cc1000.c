/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

 /**
 * @file cc/cc1000.c
 *
 * @brief Chipcon CC1000 driver
 * 
 *
 * 2004/06/19 Matthias Ringwald <mringwal@inf.ethz.ch>
 *
 */

/* This module provides the functionality to control the CC1000 radio */

#ifdef __BTNODE3__

#include <stdio.h>
#include <dev/irqreg.h>
#include <arch/btn-hardware.h>
#include <cc/cc1000.h>
#include <cc/cc1000_defs.h>
#include <cc/cc1000_params.h>


/* Delay the clock tick */
u_char delay_time(int u_sec)
{
    while (u_sec > 0) {
        asm volatile ("nop"::);
        asm volatile ("nop"::);
        asm volatile ("nop"::);
        asm volatile ("nop"::);
        asm volatile ("nop"::);
        asm volatile ("nop"::);
        asm volatile ("nop"::);
        asm volatile ("nop"::);
        u_sec--;
    }
    return 1;
}


// *********   Radio Configuration Functions **********/

// variables for the current frequency and the power level
u_char curFreq;
static u_char rfPower;

/* Init the cc1000 radio */
void cc1000_init(u_char freq)
{

    // record the current setting frequency
    curFreq = freq;

    rfPower = 0xff;

    CC1000_CONFIG_PORT_REG |= ((1 << CC1000_PALE) | (1 << CC1000_PCLK) | (1 << CC1000_PDATA));

    // Set the three configuration pin high
    CC1000_CONFIG_PORT |= ((1 << CC1000_PALE) | (1 << CC1000_PCLK) | (1 << CC1000_PDATA));

    // Reset and turning on the crystal oscillator core
    // 00111010
    // RXTX = 0 F_REG = 0 RX_PD = 1 TX_PD = 1 FS_PD = 1 CORE_PD = 0 BIAS_PD = 1 RESET_N = 0
    cc1000_write(CC1000_MAIN, ((1 << CC1000_RX_PD) | (1 << CC1000_TX_PD) | (1 << CC1000_FS_PD) | (1 << CC1000_BIAS_PD)));

    // RESET
    cc1000_write(CC1000_MAIN, ((1 << CC1000_RX_PD) |
                               (1 << CC1000_TX_PD) | (1 << CC1000_FS_PD) | (1 << CC1000_BIAS_PD) | (1 << CC1000_RESET_N)));
    // wait 2 ms
    // Time to wait depends on the crystal frequency and the load capacitance
    delay_time(2000);

    // Program all registers, Calibrate VCO and PLL and set the frequency
    cc1000_set(freq);

    //SPI bus initialization
    cc1000_SPI_init();

}


/* Set the radio to a specific frequency */
void cc1000_set(u_char newFreq)
{
    int i;

    // record the current setting frequency    
    curFreq = newFreq;

    // record the current setting power
    rfPower = 0xff;

    // write the corresponding FREQ registers
    for (i = 1; i < 7; i++)
        cc1000_write(i, cc1000_params[curFreq][i - 1]);

    // First write the template to the registers
    for (i = 7; i < 29; i++)
        cc1000_write(i, cc1000_params_template[i]);

    // test4 and the presacler have to be set separatedly
    // The default is written to be 38.2 KBaud, i.e. 19.2 bps in Manchester coding
    cc1000_write(CC1000_TEST4, cc1000_params_template[TEST4_INDEX]);

    cc1000_write(CC1000_PRESCALER, cc1000_params_template[PRESCALER_INDEX]);

    //recalibrate after setting the new frequency
    cc1000_calibrate();

    //set the cc1000 to the receive mode
    cc1000_rxmode();
}

/**  Write a value to a single CC1000 register
 * @param addr Address of the register to write to
 * @param data Data to be written
 */
void cc1000_write(u_char addr, u_char data)
{
    short val;
    val = (addr & 0x7F) << 9 | (data & 0xFF);
    cc1000_config(1, &val);
}

/** Calibrates the CC1000, required
 * Follows the steps listed in the cc1000 data sheet
 */
void cc1000_calibrate()
{
    //the following procedure are follwing the data sheet
    // int i;

    // Write FREQ_A, FREQ_B If DR>=38kBd then write TEST4: L2KIO=3Fh Write CAL: CAL_DUAL = 0
    cc1000_write(CC1000_PA_POW, 0x00);  // turn off radio power
    cc1000_write(CC1000_TEST4, cc1000_params_template[TEST4_INDEX]);

    // RX frequency register A is calibrated first
    // Write MAIN: RXTX = 0; F_REG = 0 RX_PD = 0; TX_PD = 1; FS_PD = 0 CORE_PD = 0; BIAS_PD = 0; RESET_N=1
    cc1000_write(CC1000_MAIN, ((1 << CC1000_TX_PD) | (1 << CC1000_RESET_N)));

    // Calibration is performed in RX mode, Result is stored in TEST0 and TEST2, RX register
    // Write CAL: CAL_START=1, set the wait
    cc1000_write(CC1000_CAL, ((1 << CC1000_CAL_START) | (1 << CC1000_CAL_WAIT) | (6 << CC1000_CAL_ITERATE)));

    // Calibration time depend on the reference frequency, see text.
    // Wait for maximum 34 ms, or Read CAL and wait until CAL_COMPLETE=1
    // for (i = 0; i < 34; i++)
    //     delay_time(1000);
    while (!(cc1000_read(CC1000_CAL) & (1 << CC1000_CAL_COMPLETE))) delay_time(1000);

    // Write CAL: CAL_START=0
    cc1000_write(CC1000_CAL, ((1 << CC1000_CAL_WAIT) | (6 << CC1000_CAL_ITERATE)));


    // TX frequency register B is calibrated second
    // Write MAIN: RXTX = 1; F_REG = 1 RX_PD = 1; TX_PD = 0; FS_PD = 0 CORE_PD = 0; BIAS_PD = 0; RESET_N=1
    cc1000_write(CC1000_MAIN, ((1 << CC1000_RXTX) | (1 << CC1000_F_REG) | (1 << CC1000_RX_PD) | (1 << CC1000_RESET_N)));

    //  TX current  is the VCO current to be used in TX mode
    cc1000_write(CC1000_CURRENT, cc1000_params_template[TXCURRENT_INDEX]);

    //PA is turned off to prevent spurious emission
    cc1000_write(CC1000_PA_POW, 0x00);

    // Write CAL: CAL_START=1
    cc1000_write(CC1000_CAL, ((1 << CC1000_CAL_START) | (1 << CC1000_CAL_WAIT) | (6 << CC1000_CAL_ITERATE)));

    // Wait for 34 ms, or Read CAL and wait until CAL_COMPLETE=1
    // for (i = 0; i < 34; i++)
    //     delay_time(1000);
    while (!(cc1000_read(CC1000_CAL) & (1 << CC1000_CAL_COMPLETE))) delay_time(1000);

    // Write CAL: CAL_START=0
    cc1000_write(CC1000_CAL, ((1 << CC1000_CAL_WAIT) | (6 << CC1000_CAL_ITERATE)));

}


/* Puts the CC1000 into RX mode */
void cc1000_rxmode()
{
    u_char current = cc1000_params_template[RXCURRENT_INDEX];
    // Procedures on the data sheet 
    // Turn on RX: RX_PD = 0, FS_PD = 0 RX_PD = 0, FS_PD = 0
    cc1000_write(CC1000_MAIN, ((1 << CC1000_TX_PD) | (1 << CC1000_RESET_N)));

    // Writing current
    cc1000_write(CC1000_CURRENT, current);

    // Wait 250 us
    delay_time(250);

}

/* Puts the CC1000 into TX mode */
void cc1000_txmode()
{
    u_char current = cc1000_params_template[TXCURRENT_INDEX];
    // Turn on TX: PA_POW = 00h MAIN: RXTX = 1, F_REG = 1 TX_PD = 0, FS_PD = 0
    cc1000_write(CC1000_MAIN, ((1 << CC1000_RXTX) | (1 << CC1000_F_REG) | (1 << CC1000_RX_PD) | (1 << CC1000_RESET_N)));

    // CURRENT =  TX current  
    cc1000_write(CC1000_CURRENT, current);

    // Wait 250 us
    delay_time(250);

    // PA_POW =  Output power 
    cc1000_write(CC1000_PA_POW, rfPower);

    // Wait 250 us
    delay_time(250);

}



/** The following are the actual low level read/write function, dealing directly with the timing and register  */

/** Configure the cc1000 radio, based on bit bashing (general I/O pin use)
 * This is the function that deals with the low level stuff, check the 
 * timing diagram for details of timing sequency
 * @param count Length of the configuration array
 * @param configuration[] array of configuration data, first byte is addr,
 *                        second byte is data
 */
void cc1000_config(u_char count, short configuration[])
{
    u_char bitCounter;
    u_char wordCounter;
    short data;

    //set ALE high
    CC1000_CONFIG_PORT |= (1 << CC1000_PALE);

    for (wordCounter = 0; wordCounter < count; wordCounter++) {
        data = configuration[wordCounter];

        CC1000_CONFIG_PORT &= ~(1 << CC1000_PALE);      // set ALE low

        // Send 7 address bits 
        for (bitCounter = 0; bitCounter < 7; bitCounter++) {
            CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);   // CC1000_PCLK=1
            if ((data & 0x8000) == 0) {
                CC1000_CONFIG_PORT &= ~(1 << CC1000_PDATA);     // CC1000_PDATA=0
            } else {
                CC1000_CONFIG_PORT |= (1 << CC1000_PDATA);      // CC1000_PDATA=1
            }
            data = data << 1;
            CC1000_CONFIG_PORT &= ~(1 << CC1000_PCLK);  //CC1000_PCLK=0;

        }

        // Send read/write bit 
        CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);       //CC1000_PCLK=1
        CC1000_CONFIG_PORT |= (1 << CC1000_PDATA);      //CC1000_PDATA=1, write mode
        CC1000_CONFIG_PORT &= ~(1 << CC1000_PCLK);      //CC1000_PCLK=0
        data = data << 1;       //ignore the last bit in the address byte 

        CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);       //CC1000_PCLK=1
        CC1000_CONFIG_PORT |= (1 << CC1000_PALE);       //CC1000_PALE=1

        // Send 8 data bits    
        for (bitCounter = 0; bitCounter < 8; bitCounter++) {
            CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);   //CC1000_PCLK=1
            if ((data & 0x8000) == 0) {
                CC1000_CONFIG_PORT &= ~(1 << CC1000_PDATA);     // CC1000_PDATA=0
            } else {
                CC1000_CONFIG_PORT |= (1 << CC1000_PDATA);      // CC1000_PDATA=1
            }
            data = data << 1;
            CC1000_CONFIG_PORT &= ~(1 << CC1000_PCLK);  //CC1000_PCLK=0 done on the negative edge of CC1000_PCLK
        }                       //
        CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);       //CC1000_PCLK=1
    }                           // for wordCount   

    //  Set the three configuration pin high 
    CC1000_CONFIG_PORT |= ((1 << CC1000_PALE) | (1 << CC1000_PCLK) | (1 << CC1000_PDATA));

}


/** Reads from a single CC1000 register
 * @param addr Address of the register to read from
 * @return Data read
 */
u_char cc1000_read(u_char addr)
{
    u_char bitCounter;
    u_char data;
    u_char debug;

    CC1000_CONFIG_PORT |= (1 << CC1000_PALE);   //CC1000_PALE=1

    data = addr << 1;
    CC1000_CONFIG_PORT &= ~(1 << CC1000_PALE);

    // Send 7 address bits 
    for (bitCounter = 0; bitCounter < 7; bitCounter++) {
        CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);       // CC1000_PCLK=1
        if ((data & 0x80) == 0) {
            CC1000_CONFIG_PORT &= ~(1 << CC1000_PDATA); // CC1000_PDATA=0
        } else {
            CC1000_CONFIG_PORT |= (1 << CC1000_PDATA);  // CC1000_PDATA=1
        }
        data = data << 1;
        CC1000_CONFIG_PORT &= ~(1 << CC1000_PCLK);      //CC1000_PCLK=0;
    }

    // Send read/write bit 
    CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);   //CC1000_PCLK=1
    CC1000_CONFIG_PORT &= ~(1 << CC1000_PDATA); //CC1000_PDATA=0
    CC1000_CONFIG_PORT &= ~(1 << CC1000_PCLK);  //CC1000_PCLK=0


    CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);   //CC1000_PCLK=1
    CC1000_CONFIG_PORT |= (1 << CC1000_PALE);   //CC1000_PALE=1

    // Receive data bits 
    CC1000_CONFIG_PORT |= (1 << CC1000_PDATA);  //CC1000_PDATA=1  
    CC1000_CONFIG_PORT_REG &= ~(1 << CC1000_PDATA);     // Set up CC1000_PDATA as an input

    //data is 0 at this moment
    for (bitCounter = 0; bitCounter < 8; bitCounter++) {
        CC1000_CONFIG_PORT &= ~(1 << CC1000_PCLK);      //CC1000_PCLK=0
        data = data << 1;
        debug = (1 << CC1000_PDATA);
        if ((PIND & debug) == 0) {      // PINC - error
            data &= 0xFE;
        } else {
            data |= 0x01;
        }
        CC1000_CONFIG_PORT |= (1 << CC1000_PCLK);       //CC1000_PCLK=1

    }

    CC1000_CONFIG_PORT_REG |= (1 << CC1000_PDATA);      // Set up CC1000_PDATA as an output again 

    return data;
}

void cc1000_sleep(void)
{
    // put the cc1000 to sleep
    cc1000_write(CC1000_MAIN, ((1 << CC1000_RX_PD) |
                               (1 << CC1000_TX_PD) |
                               (1 << CC1000_FS_PD) | (1 << CC1000_CORE_PD) | (1 << CC1000_BIAS_PD) | (1 << CC1000_RESET_N)));
}

/* Wakes the CC1000  */
void cc1000_wakeup(void)
{
    cc1000_on();
    delay_time(500);
}

/* Turns on the cc1000 radio */
void cc1000_on(void)
{
    cc1000_write(CC1000_MAIN, ((1 << CC1000_RX_PD) |
                               (1 << CC1000_TX_PD) | (1 << CC1000_FS_PD) | (1 << CC1000_BIAS_PD) | (1 << CC1000_RESET_N)));

    delay_time(2000);
    cc1000_rxmode();
}

/* checks, if CC1000 is sleeping */
inline int cc1000_is_sleeping(void) {
    return cc1000_read(CC1000_MAIN) & (1 << CC1000_CORE_PD);   
}

void cc1000_SPI_init()
{
    cbi(DDRB, 0);               // SS   as input (overridden)
    cbi(DDRB, 1);               // SCLK as input (overridden)
    cbi(DDRB, 2);               // MOSI as input (overridden)
    sbi(DDRB, 3);               // MISO as output

    //enable the spi device
    SPCR = (1 << SPE);

    //register handler 
    // TODO: properly register handler for the protocol 
    // NutRegisterIrqHandler(&sig_SPI,Protocol,0);

}

void cc1000_set_RF_power( u_char rfp )
{
	rfPower = rfp;
}

void cc1000_get_RF_power( u_char* rfp )
{
	*rfp = rfPower;
}

#endif
