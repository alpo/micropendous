/*
 * Copyright (C) 2005 Mario Strasser <mast@gmx.net>,
 *                    Swiss Federal Institute of Technology (ETH) Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id: cca.c,v 1.2 2006/09/22 15:14:50 freckle Exp $
 */

#ifdef __BTNODE3__
 
#include <string.h>
#include <sys/types.h>
#include <hardware/btn-hardware.h>
#include <cc/bmac.h>
#include <cc/cca.h>
#include <dev/adc2.h>
 
/* clear channel assessment (CCA) */

#define CCA_INIT_VALUE 300
#define CCA_FIFO_SIZE  9

static u_short cca_fifo[CCA_FIFO_SIZE];
static u_short cca_fifo_head;
static u_short cca_level;

static u_short adc_handle = 0;

static int cmp_ushort(const void *a, const void *b)
{
    if (*(u_short*)a < *(u_short*)b) return -1;
    if (*(u_short*)a > *(u_short*)b) return +1;
    return 0;
}


static void cca_update(u_short value)
{   
    cca_fifo[cca_fifo_head] = value;
    cca_fifo_head = (cca_fifo_head + 1) % CCA_FIFO_SIZE;
    /* get the median of the values in the FIFO queue */
    u_short tmp_fifo[CCA_FIFO_SIZE];
    memcpy(tmp_fifo, cca_fifo, sizeof(cca_fifo));
    qsort(tmp_fifo, CCA_FIFO_SIZE, sizeof(u_short), cmp_ushort);
    u_short median = tmp_fifo[CCA_FIFO_SIZE >> 1];
    /* cca_level := (1-a) * cca_level + a * median, with a = 0.06 */
    cca_level = (((u_long)cca_level * 94 + (u_long)median * 6) / 100) & 0xffff;
}

int cca_is_clear(void)
{
    u_short i, res = 0;    
    /* Check 5 samples, if at least one of them is above the threshold level
       (3/4 of the CCA_level) the channel is assumed to be clear (note that
       the RSSI value is inversely proportional to the signal strength). */
    u_short threshold = cca_level - (cca_level >> 2);
    for (i = 0; i < 5; i++) {  
        u_short rssi_value = adc2_read(adc_handle);
        if (rssi_value > threshold) { 
            cca_update(rssi_value);
            res = 1; 
            break; 
        }
    }    
    return res;
}

void cca_init(void)
{
    int i;
	adc_handle = adc2_init( ADC2_MODE_SINGLE_CONVERSION,
							   ADC2_INTERRUPT_DISABLE,
							   ADC2_PRESCALE_DIV2,
							   CC1000_RSSI_ADC,
							   ADC2_REF_INTERNAL_256 );
    
    BMAC_DEBUG( "cca_init(): Handle = 0x%04X\n", adc_handle );
    for (i = 0; i < CCA_FIFO_SIZE; i++) cca_fifo[i] = CCA_INIT_VALUE;   
    cca_fifo_head = 0;
    cca_level = CCA_INIT_VALUE; 
    for (i = 0; i < 100; i++) {
        u_short rssi_value = adc2_read( adc_handle );
        if (rssi_value > cca_level) cca_update(rssi_value);  
    }
    BMAC_DEBUG("initial cca_level: %d\n", cca_level);
}

#endif
