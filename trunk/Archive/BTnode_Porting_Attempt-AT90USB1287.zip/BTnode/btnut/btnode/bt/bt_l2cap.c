/*
 * Copyright (C) 2000-2006 by ETH Zurich
 * Copyright (C) 2004 by Ole Reinhardt <ole.reinhardt@embedded-it.de>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */
 
/* 
 * bt_l2cap.c
 *
 * Implementation of an L2CAP layer for BTNut
 *
 * This code supports the basic l2cap operation. Extended features are not supported
 * This means: No flowcontrol, no retransmission
 * Connectionless data transfer is also not supported at the moment
 * The max MTU is limited by the externel memory and can't reach the 64K limit defined in the standard 
 * If a device with larger memory is used have a look to the receive / transmit functions to change the appropriate code.
 * Reconfiguration of an just opened channel is not supported too.
 * 
 * $Log: bt_l2cap.c,v $
 * Revision 1.49  2006/10/27 12:04:41  olereinhardt
 * Changed code to only add a void* pointer to the acl packets instead of the
 * whole channel info struct. ACL packets now need 2 byte more ram than the
 * designated size of the packet.
 *
 * Revision 1.48  2006/03/27 14:16:12  kevmarti
 * Moved back to btnut version 1.4
 *
 * Revision 1.46  2006/01/21 16:44:52  yuecelm
 * rename RFCOMM_DEVICE_SLIMDOWN to BT_{L2CAP|RFCOMM}_SLIMDOWN
 * and remove some slimdown mods that are not in agreement with bluetooth specification.
 *
 * Revision 1.45  2006/01/20 14:39:06  yuecelm
 * set L2CAP_DEBUG to 0 (disables debug messages)
 *
 * Revision 1.44  2006/01/20 14:23:15  yuecelm
 * add (#ifndef) RFCOMM_DEVICE_SLIMDOWN macros (reduce size demand (~6 KB) of l2cap- and rfcomm-stack)
 *
 * Revision 1.43  2006/01/17 14:14:30  yuecelm
 * move bt_l2cap_get_outgoing_mtu out of bt_l2cap_tools.c (used in rfcomm.c), enable cvs log
 *
 * 
 */

#include <string.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/atom.h>
#include <bt/bt_defs.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>

#define BT_L2CAP_FREE 0
#define BT_L2CAP_NOT_FREE 1
#define BT_L2CAP_WAIT 2

#define MIN(a,b) ((a>b)?b:a)

#ifndef L2CAP_DEBUG 
#define L2CAP_DEBUG 0
#endif

#if     L2CAP_DEBUG >= 3  
#define INFO(text, ...) printf_P(PSTR("L2CAP:" text),## __VA_ARGS__)
#else
#define INFO(text, ...) 
#endif

#if     L2CAP_DEBUG >= 2  
#define WARNING(text, ...) printf_P(PSTR("L2CAP: WARNING:" text),## __VA_ARGS__)
#else
#define WARNING(text, ...) 
#endif

#if     L2CAP_DEBUG >= 1  
#define ERROR(text, ...) printf_P(PSTR("L2CAP: ERROR:" text),## __VA_ARGS__)
#else
#define ERROR(text, ...) 
#endif

struct l2cap_echo_cmd echo_cmd;
struct bt_l2cap_stack *l2cap_stack;

static void _bt_l2cap_dummy_rcv_cb(struct bt_l2cap_acl_pkt *pkt, u_char service_nr, u_short channel_id, void *arg)
{
    INFO("Received data. No callback registered\n");
    bt_l2cap_complete_pkt(pkt);
}

static void _bt_l2cap_dummy_con_cb(u_char type, u_char detail, u_char service_nr, u_short channel_id, void *arg)
{  
    if (type == BT_L2CAP_CONNECT)
        INFO("Connect. No callback registered\n"); 
    else
        INFO("Disconnect. No callback registered\n"); 
}

u_char _bt_l2cap_get_new_sigid(struct bt_l2cap_bb_connection* bb_con)
{
    u_char * sig_id = &bb_con->sig_id;
    (*sig_id)++;
    if (*sig_id == 0) (*sig_id)++;
    return *sig_id;
}

static u_short _bt_l2cap_get_new_channel_id(u_char service_nr)
{
    u_short id;         // lower 5 bits encode the service nr
    id = (l2cap_stack->channel_id >> 5) + 1;  
    if ((id & 0x3FF) == 0x00) id ++;
    l2cap_stack->channel_id = (id << 5) + (service_nr & 0x1F);
    return l2cap_stack->channel_id;
}

struct bt_l2cap_bb_connection* _bt_l2cap_handle2baseband(bt_hci_con_handle_t con_handle)
{
    register u_char idx;
    for (idx = 0; idx < BT_HCI_MAX_NUM_CON; idx++)
        if (l2cap_stack->bb_con[idx].con_handle == con_handle)
            return &l2cap_stack->bb_con[idx];
    return NULL;
}
struct bt_l2cap_service * _bt_l2cap_get_service_from_channel_id(u_short channel_id)
{    
    if ((channel_id == BT_L2CAP_HANDLE_INVALID) ||
        ((channel_id & 0x1F) > BT_L2CAP_MAX_SERVICES))
    {
        ERROR("Invalid channel_id\n");
        return NULL;
    }
    
    if (l2cap_stack->services[channel_id & 0x1F].channel_id != channel_id)
    {
        ERROR("Invalid channel_id\n");
        return NULL;
    }
    return &l2cap_stack->services[channel_id & 0x1F];
}

struct bt_l2cap_channel * _bt_l2cap_get_channel_from_channel_id(u_short channel_id)
{
    struct bt_l2cap_service * service;
    struct bt_l2cap_channel * channel;
        
    service = _bt_l2cap_get_service_from_channel_id(channel_id);
    if (service == NULL) {
        return NULL;
    }
    
    channel = _bt_l2cap_handle2baseband(service->con_handle)->channels[service->channel_nr];
    
    if (channel == NULL) {
        ERROR("Invalid channel_id\n");
        return NULL;
    } else return channel; 
}

static struct bt_l2cap_channel *_bt_l2cap_allocate_channel(struct bt_l2cap_bb_connection* bb_con, u_char* ch_nr)
{
    u_char channel_nr;
    u_char idx;
    
    for (channel_nr = 0; channel_nr < l2cap_stack->max_channel; channel_nr ++)
    {
        if (l2cap_stack->channels[channel_nr].state == BT_L2CAP_CH_NOT_ASSIGNED)
            break;
    }
    
    if (channel_nr == l2cap_stack->max_channel)
    {
        WARNING("No ressources free...\n");      
        return NULL;
    }
    
    for (idx = 0; idx < l2cap_stack->max_channel; idx++)
        if (bb_con->channels[idx] == NULL)
            break;

    bb_con->channels[idx] = &l2cap_stack->channels[channel_nr];
    *ch_nr = idx;
    return bb_con->channels[idx];
}


u_char bt_l2cap_register_service(u_short psm, u_char nr_buffer, u_short min_mtu, u_short max_mtu, BT_L2CAP_CON_CB, BT_L2CAP_RCV_CB, void* cb_arg)
{
    u_char idx;
    u_char count;
    struct bt_l2cap_service *service;
    INFO("Register Service: Min. MTU = %d, Max. MTU = %d\n", min_mtu, max_mtu);
    if ((min_mtu > max_mtu) || (min_mtu < BT_L2CAP_MIN_MTU)) 
    {
        WARNING("Register service: MTU too large or too small\n");
        return BT_L2CAP_SERVICENR_INVALID;
    }
    
    if ((min_mtu > l2cap_stack->acl_len) && (nr_buffer == 0))
    {
        ERROR("Need to register l2cap packet buffers since mtu is larger than one acl packet\n");
        return BT_L2CAP_SERVICENR_INVALID;
    }
    
    if (rcv_cb == NULL) rcv_cb = _bt_l2cap_dummy_rcv_cb;
    if (con_cb == NULL) con_cb = _bt_l2cap_dummy_con_cb;
    
    for (idx = 0; idx < BT_L2CAP_MAX_SERVICES; idx++)
    {
        service = &l2cap_stack->services[idx];
        if ((service->psm == BT_L2CAP_PSM_INVALID) && 
            (service->channel_nr == BT_L2CAP_CHNR_INVALID) &&
            (service->con_handle == BT_HCI_HANDLE_INVALID))
        {
            service->psm = psm;
            service->rcv_cb = rcv_cb;
            service->con_cb = con_cb;
            service->min_mtu = min_mtu;
            service->max_mtu = max_mtu;
            service->buffer_size = nr_buffer;
            service->cb_arg = cb_arg;
            service->buffer = NutHeapAlloc(nr_buffer * sizeof(struct bt_l2cap_pkt_buffer_entry));
            if (service->buffer == NULL)
            {
                ERROR("Out of memory\n");
                service->psm = BT_L2CAP_PSM_INVALID;
                service->channel_nr = BT_L2CAP_CHNR_INVALID;
                service->con_handle = BT_HCI_HANDLE_INVALID;
                return BT_L2CAP_SERVICENR_INVALID;
            }            
            for (count = 0; count < nr_buffer; count++) 
            {
                // Now allocate l2cap_stack->max_mtu bytes for service buffer... not mtu as before
                service->buffer[count].pkt = NutHeapAllocClear(max_mtu + BT_L2CAP_ACL_PKT_HDR_LEN + BT_L2CAP_CHANNEL_INFO_SIZE);
                if (service->buffer[count].pkt == NULL)
                {
                    u_char bcount;
                    ERROR("Out of memory\n");
                    for (bcount = 0; bcount < count; count++) {
                        NutHeapFree(service->buffer[count].pkt);
                        service->buffer[count].pkt = NULL;
                    }
                    NutHeapFree(service->buffer);
                    service->buffer = NULL;
                    service->psm = BT_L2CAP_PSM_INVALID;
                    service->channel_nr = BT_L2CAP_CHNR_INVALID;
                    service->con_handle = BT_HCI_HANDLE_INVALID;
                    return BT_L2CAP_SERVICENR_INVALID;                    
                }
                service->buffer[count].state = BT_L2CAP_FREE;
            }
                        
            return idx;
        }
    }
    return BT_L2CAP_SERVICENR_INVALID;
}

u_char bt_l2cap_clear_service(u_char service_nr)
{
    u_char count;
    struct bt_l2cap_service *service = &l2cap_stack->services[service_nr];
    if ((service->channel_nr != BT_L2CAP_CHNR_INVALID) ||
        (service->con_handle != BT_HCI_HANDLE_INVALID))
        return BT_L2CAP_ERR_IN_USE;
    
    service->psm = BT_L2CAP_PSM_INVALID;
    service->channel_nr = BT_L2CAP_CHNR_INVALID;
    service->con_handle = BT_HCI_HANDLE_INVALID;
    service->rcv_cb      = _bt_l2cap_dummy_rcv_cb;
    service->con_cb      = _bt_l2cap_dummy_con_cb;
    service->cb_arg      = NULL;
    service->channel_id  = 0x0000;
    service->min_mtu     = BT_L2CAP_MIN_MTU;
    for (count = 0; count < service->buffer_size; count++) {
        NutHeapFree(service->buffer[count].pkt);
        service->buffer[count].pkt = NULL;
    }
    service->buffer_size = 0;
    NutHeapFree(service->buffer);
    service->buffer = NULL;
    
    return BT_L2CAP_ERR_SUCCESS;
}

static struct bt_l2cap_acl_pkt *_bt_l2cap_get_service_packet_buffer(u_char service_nr)
{
    u_char count;
    struct bt_l2cap_service *service = &l2cap_stack->services[service_nr];
        
    for (count = 0; count < service->buffer_size; count++) {
        if (service->buffer[count].state == BT_L2CAP_FREE)
        {
            service->buffer[count].state = BT_L2CAP_NOT_FREE;
            return service->buffer[count].pkt;
        }
    }

    return NULL;
}

static void _bt_l2cap_clear_channel(struct bt_l2cap_bb_connection* bb_con, u_char channel_nr)
{
    u_char count;
    struct bt_l2cap_channel *channel = bb_con->channels[channel_nr];
    struct bt_l2cap_service *service;
        
    channel->state      = BT_L2CAP_CH_NOT_ASSIGNED;
    channel->con_handle = BT_HCI_HANDLE_INVALID;
    channel->remote_cid = 0x0000;
    channel->local_cid  = 0x0000;
    channel->flags      = 0x00;
    channel->sig_id     = 0x00;
    channel->omtu       = BT_L2CAP_MTU_DEFAULT;
    channel->imtu       = BT_L2CAP_MTU_DEFAULT;
    channel->error      = BT_L2CAP_ERR_SUCCESS;
    channel->pending    = 0;
    channel->sig_con_rsp  = NULL;    
    channel->sig_conf_rsp = NULL;
    channel->sig_disc_rsp = NULL;
    channel->sig_timeout  = NULL;    
    channel->received   = 0;
    channel->buf_state  = BT_L2CAP_FREE;
    if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
    {
        service = &l2cap_stack->services[channel->service_nr];
        for (count = 0; count < service->buffer_size; count++)
            service->buffer[count].state = BT_L2CAP_FREE;
        service->channel_nr = BT_L2CAP_CHNR_INVALID;
        service->con_handle = BT_HCI_HANDLE_INVALID;
    }
    channel->pkt          = NULL;
    channel->last_acl_pkt = NULL;
    channel->service_nr = BT_L2CAP_SERVICENR_INVALID;
    bb_con->channels[channel_nr] = NULL;
}

static void _bt_l2cap_free_packet(struct bt_hci_pkt_acl *pkt)
{
    u_char idx;
    bt_hci_con_handle_t con_handle;
    struct bt_l2cap_acl_buffer_entry *buffer;
    
    for (idx = 0; idx < l2cap_stack->buffer_size; idx++)
        if (l2cap_stack->buffer[idx].pkt == (struct bt_l2cap_acl_pkt *)pkt)
            break;
        
    if (idx == l2cap_stack->buffer_size)
    {
        ERROR("Invalid packet to free\n");
        return;
    }
    
    buffer = &l2cap_stack->buffer[idx];
    //set state to free and send bluetooth module the free cmd for flowcontrol
    con_handle = buffer->con_handle;
    buffer->state = BT_L2CAP_FREE;
    buffer->con_handle = BT_HCI_HANDLE_INVALID;

    buffer->channel_id = BT_L2CAP_CHNR_INVALID;
//    buffer->buf_used = 0;
    buffer->channel = NULL;
    
    // Zeevo Fix: post async that acl buffers are available. This resumes acl_callback if paused 
    // again called as early as possible (as there is no event to an bt_hci_acl_free_buffer call
    // it is not required, but done anyway)
    NutEventPost(&l2cap_stack->sig_acl_buffer_free);

    bt_hci_acl_free_buffer(l2cap_stack->bt_stack, con_handle, 1);
}

void bt_l2cap_complete_pkt(struct bt_l2cap_acl_pkt *pkt)
{
    u_char idx;

    struct bt_l2cap_acl_buffer_entry  *buffer;
    struct bt_l2cap_service *service;
    bt_hci_con_handle_t con_handle;
    
    buffer = *((struct bt_l2cap_acl_buffer_entry**)&pkt->payload[pkt->len[0] | pkt->len[1] << 8]);
    
    if (buffer->channel->service_nr != BT_L2CAP_SERVICENR_INVALID)                       // Channel is just closed. Service is just cleared
    {
        service = &l2cap_stack->services[buffer->channel->service_nr];
        
        if (service->channel_id == buffer->channel_id)
        {
            for (idx = 0; idx < service->buffer_size; idx++)
            {            
                if (service->buffer[idx].pkt == pkt)
                {
                    service->buffer[idx].state = BT_L2CAP_FREE;
                    break;
                }
            }
            if (idx == service->buffer_size)
            {
                ERROR("Complete packet: Buffer not found...\n");
            }
        } else
        {   // this better should never happen.
            if (buffer->channel_id != 0x0000)
                WARNING("Complete packed of just closed channel...\n");
        }
    }
    
    for (idx = 0; idx < l2cap_stack->buffer_size; idx++)
        if (l2cap_stack->buffer[idx].pkt == buffer->pkt)
        {             
            con_handle = l2cap_stack->buffer[idx].con_handle;
            l2cap_stack->buffer[idx].state = BT_L2CAP_FREE;
            l2cap_stack->buffer[idx].con_handle = BT_HCI_HANDLE_INVALID;
            l2cap_stack->buffer[idx].channel_id = BT_L2CAP_CHNR_INVALID;
//            l2cap_stack->buffer[idx].buf_used = 0;
            l2cap_stack->buffer[idx].channel = NULL;            
            // Zeevo Fix: post async that acl buffers are available. 
            // moved before the sig_acl_data_avail call, as we can't receive an event
            // before resuming hci thread
            NutEventPost(&l2cap_stack->sig_acl_buffer_free);
            bt_hci_acl_free_buffer(l2cap_stack->bt_stack, con_handle, 1);
            NutEventPostAsync(&l2cap_stack->sig_acl_data_avail);

            return;
        }
    ERROR("Invalid packet handle\n");
}

static void _bt_l2cap_wait_packet(struct bt_hci_pkt_acl *pkt)
{
    u_char idx;
    
    for (idx = 0; idx < l2cap_stack->buffer_size; idx++)
        if (l2cap_stack->buffer[idx].pkt == (struct bt_l2cap_acl_pkt *)pkt)
            break;
        
    if (idx == l2cap_stack->buffer_size)
    {
        ERROR("Invalid packet to wait\n");
    }
    l2cap_stack->buffer[idx].state = BT_L2CAP_WAIT;
}

u_char bt_l2cap_get_outgoing_mtu(u_short channel_id, u_short *mtu)
{
    struct bt_l2cap_channel * channel;
    
    channel = _bt_l2cap_get_channel_from_channel_id(channel_id);

    if (channel == NULL)
        return BT_L2CAP_ERR_INVALID_HANDLE;

    *mtu = channel->omtu;
    return BT_L2CAP_ERR_SUCCESS;
}

u_long bt_l2cap_send(u_short channel_id, struct bt_l2cap_acl_pkt* pkt, u_short len)
{
    struct bt_l2cap_channel * channel;
    u_short count;
    u_short pos;     // WARNING: This will fail with 65535 byte mtu But AVRs can't handle such large packets either
    u_long  error = BT_L2CAP_ERR_SUCCESS;
    u_short sending_length;
    
    channel = _bt_l2cap_get_channel_from_channel_id(channel_id);
    if (channel == NULL)
        return BT_L2CAP_ERR_INVALID_CID;

    if (channel->state != BT_L2CAP_CH_OPEN) {
        ERROR("Send: Channel is not in open state\n");
        return BT_L2CAP_ERR_CH_NOT_OPEN;
    }

    if (len > channel->omtu)
    {
        WARNING("Datalength exceeds omtu\n");
        return BT_L2CAP_ERR_DATASIZE;
    }
    
    count = 0;
    pos = 0;
    
    while (pos < len + BT_L2CAP_HEADER_LEN)
    {
        if (count == 0)
        {
            pkt->cid[0] = (u_char)(channel->remote_cid & 0xFF);
            pkt->cid[1] = (u_char)(channel->remote_cid >> 8);
            pkt->len[0] = (u_char)(len & 0xFF);
            pkt->len[1] = (u_char)(len >> 8);
            sending_length = MIN(l2cap_stack->acl_len, len + BT_L2CAP_HEADER_LEN);
        } else
        {
            if ((pos + l2cap_stack->acl_len) < len + BT_L2CAP_HEADER_LEN) {
                sending_length = l2cap_stack->acl_len;
            } else {
                sending_length = len + BT_L2CAP_HEADER_LEN - pos;
            }
            memcpy(&((struct bt_hci_pkt_acl *) pkt)->payload[0], 
                &((struct bt_hci_pkt_acl *) pkt)->payload[pos], sending_length); 
        }
        error = bt_hci_send_acl_pkt(l2cap_stack->bt_stack, channel->con_handle, 
            count == 0 ? HCI_PB_FIRST_FRAGMENT : HCI_PB_CONTD_FRAGMENT, HCI_BC_UNICAST,
            sending_length, (struct bt_hci_pkt_acl *) pkt);            

        if (error) return error;
        count++;
        pos += l2cap_stack->acl_len;
    }
    
    return BT_L2CAP_ERR_SUCCESS;
}

u_char bt_l2cap_connect(u_char service_nr, bt_addr_t bt_addr, 
                        u_char page_scan_rep_mode, u_short clock_offset, 
                        u_short psm, u_short *channel_id)
{
#ifndef BT_L2CAP_SLIMDOWN
    bt_hci_con_handle_t con_handle;
    struct bt_l2cap_signal  *signal = (struct bt_l2cap_signal *) &l2cap_stack->tmp_pkt->payload;    
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_service *service;
    struct bt_l2cap_bb_connection* bb_con;
    
    long    retval;
    u_char  channel_nr;
    u_short local_cid;
    u_char  error;
    
    if (channel_id)
        *channel_id = 0x0000;
    
    if (service_nr > BT_L2CAP_MAX_SERVICES)
    {
        ERROR("Service nr invalid\n");
        return BT_L2CAP_ERR_INVALID_HANDLE;
    }
    
    if (l2cap_stack->services[service_nr].con_handle != BT_HCI_HANDLE_INVALID)
    {
        ERROR("Service just in use\n");
        return BT_L2CAP_ERR_NO_RESSOURCE;
    }
    
    if ((!(psm & 0x0001)) || (psm & 0x0100)) {
        ERROR("Invalid PSM\n");
        return BT_L2CAP_ERR_INVALID_PSM;
    }
   
    service = &l2cap_stack->services[service_nr];
    
    // Look if we just have an opened baseband connection, if not, open a new one
    retval = bt_hci_get_con_handle(l2cap_stack->bt_stack, bt_addr);
    if (retval == BT_ERR_NO_CON)
    {            
        if (l2cap_stack->bb_connections == BT_HCI_MAX_NUM_CON)
        {
            ERROR("Can't create new bb connection. Maximum number of connections just opend.\n");
            return BT_L2CAP_ERR_BB_CON_FAILED;
        }
        retval = bt_hci_create_connection(l2cap_stack->bt_stack, BT_HCI_SYNC, bt_addr, l2cap_stack->pkt_types,
                                         0, 0, BT_HCI_ROLE_SWITCH_MASTER);

        if (retval >= 0) {
            con_handle = retval;
        } else 
        {
            ERROR("opening baseband connection failed\n");
            return BT_L2CAP_ERR_BB_CON_FAILED;
        }
    } else con_handle = retval;
    
    bb_con = _bt_l2cap_handle2baseband(con_handle);
    
    channel = _bt_l2cap_allocate_channel(bb_con, &channel_nr);
    if (channel == NULL) {
        return BT_L2CAP_ERR_NO_RESSOURCE;
    }
        
    local_cid = channel_nr + BT_L2CAP_CID_USER;// simply assign new cid by displacing next free channel nr up to user cids...
    channel->state = BT_L2CAP_CH_W4_L2CAP_CONNECT_RSP;
    channel->con_handle = con_handle;
    //channel->remote_cid = BT_L2CAP_CID_MAX;
    channel->local_cid = local_cid;
    channel->flags |= BT_L2CAP_FLAG_CON_RSP | BT_L2CAP_FLAG_CONF_REQ | BT_L2CAP_FLAG_CONF_RSP; 
    channel->flags |= BT_L2CAP_FLAG_INITIATOR | BT_L2CAP_FLAG_WAS_CON;
    //channel->buf_state = BT_L2CAP_FREE;
    //channel->omtu   = BT_L2CAP_MTU_DEFAULT; // default omtu value
    //channel->imtu   = BT_L2CAP_MTU_DEFAULT; 
    //channel->error  = BT_L2CAP_ERR_SUCCESS;
    //channel->pkt    = NULL;
    //channel->pending = 0;
    
    channel->service_nr = service_nr;
    channel->sig_id = _bt_l2cap_get_new_sigid(bb_con);
    
    l2cap_stack->tmp_pkt->cid[0] = (u_char)(BT_L2CAP_CID_SIG & 0xFF);
    l2cap_stack->tmp_pkt->cid[1] = (u_char)(BT_L2CAP_CID_SIG >> 8);
    l2cap_stack->tmp_pkt->len[0] = 4 + BT_L2CAP_SIG_HEADER_LEN;
    l2cap_stack->tmp_pkt->len[1] = 0;
    signal->id = channel->sig_id;
    signal->code = BT_L2CAP_SIG_CON_REQ;
    signal->len[0] = 4;
    signal->len[1] = 0;
    signal->payload[0] = (u_char) (psm & 0xFF);
    signal->payload[1] = (u_char) (psm >> 8);
    signal->payload[2] = (u_char) (local_cid & 0xFF);
    signal->payload[3] = (u_char) (local_cid >> 8);
    
    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                    (l2cap_stack->tmp_pkt->len[0] | (l2cap_stack->tmp_pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) (l2cap_stack->tmp_pkt));

    if (NutEventWait(&channel->sig_con_rsp, BT_L2CAP_SIGNAL_TIMEOUT) != 0)
    {  
        ERROR("Timeout on connect request\n");
        return BT_L2CAP_ERR_TIMEOUT;
    }
    
    if (channel->pending) {
        if (NutEventWait(&channel->sig_con_rsp, BT_L2CAP_SIGNAL_TIMEOUT_PENDING) != 0)
        {  
            ERROR("Timeout on connect request, connection pending.\n");
            return BT_L2CAP_ERR_TIMEOUT;
        };
    }
    
    if (channel->error != BT_L2CAP_ERR_SUCCESS)
    {
        error = channel->error;
        _bt_l2cap_clear_channel(bb_con, channel_nr);
        return error;
    }
    
    channel->sig_id = _bt_l2cap_get_new_sigid(bb_con);
    channel->flags |= BT_L2CAP_FLAG_INITIATOR;
    channel->state = BT_L2CAP_CH_CONFIG;
    
    l2cap_stack->tmp_pkt->len[0] = 4 + BT_L2CAP_SIG_HEADER_LEN;
    l2cap_stack->tmp_pkt->len[1] = 0;
    signal->id = channel->sig_id;
    signal->len[0] = 4;
    signal->len[1] = 0;
    signal->code = BT_L2CAP_SIG_CONF_REQ;
    
    signal->payload[0] = (u_char)(channel->remote_cid & 0xFF);
    signal->payload[1] = (u_char)(channel->remote_cid >> 8);
    signal->payload[2] = 0x00;      // No Continue flag set
    signal->payload[3] = 0x00;
    
    if (service->max_mtu != BT_L2CAP_MTU_DEFAULT) {
        signal->payload[4] = BT_L2CAP_CONF_OPT_MTU;
        signal->payload[5] = 2; // Length = 2 Bytes
        signal->payload[6] = (u_char) (service->max_mtu & 0xFF);
        signal->payload[7] = (u_char) (service->max_mtu >> 8);
        signal->len[0] += 4;
        l2cap_stack->tmp_pkt->len[0] += 4;
    } 

    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                    (l2cap_stack->tmp_pkt->len[0] | (l2cap_stack->tmp_pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) (l2cap_stack->tmp_pkt));

    if (NutEventWait(&channel->sig_conf_rsp, BT_L2CAP_SIGNAL_TIMEOUT) != 0)
    {  
        ERROR("Timeout on connect request\n");
        return BT_L2CAP_ERR_TIMEOUT;
    };
    
    if ((channel->state == BT_L2CAP_CH_CLOSED) || (channel->state == BT_L2CAP_CH_NOT_ASSIGNED)) {
        ERROR("L2CAP connection failed...\n");
        return BT_L2CAP_ERR_CH_CONFIG;
    }
    if (channel_id)
        *channel_id = service->channel_id;
    
    return BT_L2CAP_ERR_SUCCESS;
#else
    return BT_L2CAP_ERR_NO_RESSOURCE;
#endif
}


u_char bt_l2cap_disconnect(u_short channel_id)
{
    struct bt_l2cap_service *service;
    struct bt_l2cap_signal  *signal = (struct bt_l2cap_signal *) &l2cap_stack->tmp_pkt->payload;
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_bb_connection* bb_con;
    
    service = _bt_l2cap_get_service_from_channel_id(channel_id);

    if (service == NULL)
        return BT_L2CAP_ERR_INVALID_HANDLE;

    bb_con = _bt_l2cap_handle2baseband(service->con_handle);

    channel = bb_con->channels[service->channel_nr];
    
    if (channel->state != BT_L2CAP_CH_OPEN) {
        ERROR("Disconnect: Channel is not in open state\n");
        return BT_L2CAP_ERR_CH_NOT_OPEN;
    }

    channel->state = BT_L2CAP_CH_W4_L2CAP_DISCONNECT_RSP;
    channel->flags |= BT_L2CAP_FLAG_DISC_RSP;
    channel->sig_id = _bt_l2cap_get_new_sigid(bb_con);

    l2cap_stack->tmp_pkt->cid[0] = (u_char)(BT_L2CAP_CID_SIG & 0xFF);
    l2cap_stack->tmp_pkt->cid[1] = (u_char)(BT_L2CAP_CID_SIG >> 8);
    
    l2cap_stack->tmp_pkt->len[0] = 4 + BT_L2CAP_SIG_HEADER_LEN;
    l2cap_stack->tmp_pkt->len[1] = 0;
    signal->id = channel->sig_id;
    signal->code = BT_L2CAP_SIG_DISC_REQ;
    signal->len[0] = 4;
    signal->len[1] = 0;
    signal->payload[0] = (u_char) (channel->remote_cid & 0xFF);
    signal->payload[1] = (u_char) (channel->remote_cid >> 8);
    signal->payload[2] = (u_char) (channel->local_cid & 0xFF);
    signal->payload[3] = (u_char) (channel->local_cid >> 8);
    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, service->con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                    (l2cap_stack->tmp_pkt->len[0] | (l2cap_stack->tmp_pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) (l2cap_stack->tmp_pkt));

    if (NutEventWait(&channel->sig_disc_rsp, BT_L2CAP_SIGNAL_TIMEOUT) != 0)
    {  
        ERROR("Timeout on disconnect request\n");
        return BT_L2CAP_ERR_TIMEOUT;
    }

    _bt_l2cap_clear_channel(bb_con, service->channel_nr);
    if (bb_con->connections > 0)
        bb_con->connections --;
    return BT_L2CAP_ERR_SUCCESS;
}

static void _bt_l2cap_send_cmd_rej(bt_hci_con_handle_t con_handle, u_short reason, u_short local_cid, 
                            u_short remote_cid, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;    
    
    pkt->len[0] = 2 + BT_L2CAP_SIG_HEADER_LEN;
    pkt->len[1] = 0;
    signal->len[0] = 2;
    signal->len[1] = 0;
    signal->code = BT_L2CAP_SIG_CMD_REJ;
    signal->payload[0] = (u_char) (reason & 0xFF);
    signal->payload[1] = (u_char) (reason >> 8);
    
    INFO("_bt_l2cap_send_cmd_rej\n");
    
    switch (reason) {
        case BT_L2CAP_REJ_CMD_NOT_UNDERSTOOD:
            break;
        case BT_L2CAP_REJ_INVALID_CID:
            signal->payload[2] = (u_char) (local_cid & 0xFF);
            signal->payload[3] = (u_char) (local_cid >> 8);
            signal->payload[4] = (u_char) (remote_cid & 0xFF);
            signal->payload[5] = (u_char) (remote_cid >> 8);
            signal->len[0] += 4;
            pkt->len[0] += 4;
            break;
        case BT_L2CAP_REJ_MTU_EXCEEDED:
            signal->payload[2] = (u_char) (l2cap_stack->max_signal_mtu & 0xFF);
            signal->payload[3] = (u_char) (l2cap_stack->max_signal_mtu >> 8);
            signal->len[0] += 2;
            pkt->len[0] += 2;
            break;
    }
    
    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                        (pkt->len[0] | (pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) pkt);
}

static void _bt_l2cap_cmd_rej(struct bt_l2cap_bb_connection* bb_con, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;  
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_service *service;
    u_char channel_nr;

    INFO("_bt_l2cap_cmd_rej\n");
    
    if (signal->id == echo_cmd.id) {
        echo_cmd.id = 0;
        ERROR("l2ping error.\n");
        return;
    }

    for (channel_nr = 0; channel_nr < bb_con->connections; channel_nr ++)
    {
        channel = bb_con->channels[channel_nr];
        service = &l2cap_stack->services[channel->service_nr];
        
        if (channel->sig_id == signal->id)
        {
            if (channel->flags & BT_L2CAP_FLAG_DISC_RSP) 
            {
                if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
                {
                    if ((channel->state == BT_L2CAP_CH_OPEN) || 
                        (channel->state == BT_L2CAP_CH_W4_L2CAP_DISCONNECT_RSP))
                        service->con_cb(BT_L2CAP_DISCONNECT, BT_L2CAP_UNKNOWN,
                            channel->service_nr, service->channel_id,
                            service->cb_arg);
                }
                _bt_l2cap_clear_channel(bb_con, channel_nr);
                return;
            }
            if ((channel->flags & 
                (BT_L2CAP_FLAG_CON_RSP | BT_L2CAP_FLAG_CONF_RSP)) &&
                (channel->flags & BT_L2CAP_FLAG_WAS_CON)) {
                if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
                {
                    if ((channel->state == BT_L2CAP_CH_OPEN) || 
                        (channel->state == BT_L2CAP_CH_W4_L2CAP_DISCONNECT_RSP))
                        service->con_cb(BT_L2CAP_DISCONNECT, BT_L2CAP_UNKNOWN,
                            channel->service_nr, service->channel_id,
                            service->cb_arg);
                }
                _bt_l2cap_clear_channel(bb_con, channel_nr);
                return;
            }
            WARNING("Can't associate rej cmd.\n");
            return;
        }
    }
}

static void _bt_l2cap_con_req(struct bt_l2cap_bb_connection* bb_con, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;    
    u_short psm     = signal->payload[0] | signal->payload[1] << 8;
    u_short local_cid = BT_L2CAP_CID_MAX;
    u_char  channel_nr;
    u_char  service_nr;
    u_short result  = BT_L2CAP_CON_SUCCESS;
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_service *service;
    
    INFO("_bt_l2cap_con_req\n");
    
    for (service_nr = 0; service_nr < BT_L2CAP_MAX_SERVICES; service_nr++)
    {
        service = &l2cap_stack->services[service_nr];
        if ((service->psm == psm) && 
#ifdef ASSERT_PARANOID
            (service->channel_nr == BT_L2CAP_CHNR_INVALID) &&
#endif
            (service->con_handle == BT_HCI_HANDLE_INVALID))        
            break;
    }
    
    if (service_nr == BT_L2CAP_MAX_SERVICES)
    {
        for (service_nr = 0; service_nr < BT_L2CAP_MAX_SERVICES; service_nr++)
        {
            if (l2cap_stack->services[service_nr].psm == psm)
                break;
        }
        if (service_nr < BT_L2CAP_MAX_SERVICES)
        {
            WARNING("PSM supported but no ressources free...\n");        
            result = BT_L2CAP_CON_REJ_NO_RESSOURCE;
        } else
        {
            WARNING("PSM not supported: %d\n", psm);        
            result = BT_L2CAP_CON_PSM_NOT_SUPPORTED;
        }
    }

    if (result == BT_L2CAP_CON_SUCCESS)
    {
        channel = _bt_l2cap_allocate_channel(bb_con, &channel_nr);
        if (channel == NULL) {
            result = BT_L2CAP_CON_REJ_NO_RESSOURCE;
        } else {
            
            local_cid = channel_nr + BT_L2CAP_CID_USER;// simply assign new cid by displacing next free channel nr up to user cids...
            
            channel->state = BT_L2CAP_CH_CONFIG;
            channel->con_handle = bb_con->con_handle; 
            channel->remote_cid = signal->payload[2] | (signal->payload[3] << 8);
            channel->local_cid = local_cid;
            channel->flags |= BT_L2CAP_FLAG_CONF_REQ | BT_L2CAP_FLAG_CONF_RSP; 
            channel->flags |= BT_L2CAP_FLAG_WAS_CON;
//            channel->buf_state = BT_L2CAP_FREE;
//            channel->omtu   = BT_L2CAP_MTU_DEFAULT; // default OMTU value
//            channel->imtu   = BT_L2CAP_MTU_DEFAULT;
//            channel->error  = BT_L2CAP_ERR_SUCCESS;
//            channel->pkt    = NULL;
            channel->service_nr = service_nr;
            service->channel_nr = channel_nr;
            service->con_handle = bb_con->con_handle;
        }
    }

    pkt->len[0] = 8 + BT_L2CAP_SIG_HEADER_LEN;
    pkt->len[1] = 0;

    signal->code = BT_L2CAP_SIG_CON_RSP;
    signal->len[0] = 8;
    signal->len[1] = 0;
    signal->payload[0] = (u_char) (local_cid & 0xFF);    
    signal->payload[1] = (u_char) (local_cid >> 8);
    // leave payload[2] and payload[3] as it is (remote_cid)
    signal->payload[4] = (u_char) (result & 0xFF);
    signal->payload[5] = (u_char) (result >> 8);
    signal->payload[6] = (u_char) (BT_L2CAP_NO_FURTHER_INFO & 0xFF);
    signal->payload[7] = (u_char) (BT_L2CAP_NO_FURTHER_INFO >> 8);
    
    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, bb_con->con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                        (pkt->len[0] | (pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) pkt);
}

#ifndef BT_L2CAP_SLIMDOWN
static void _bt_l2cap_con_rsp(struct bt_l2cap_bb_connection* bb_con, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;    
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_service *service;
    u_short local_cid = signal->payload[2] | signal->payload[3] << 8;
    u_char  channel_nr= local_cid - BT_L2CAP_CID_USER;

    u_short result    = signal->payload[4] | signal->payload[5] << 8;
    
    INFO("_bt_l2cap_con_rsp\n");
    
    if ((channel_nr > bb_con->connections) || (bb_con->channels[channel_nr] == NULL))    
    {
        ERROR("L2CAP connect response for invalid cid.\n");
        _bt_l2cap_send_cmd_rej(bb_con->con_handle, BT_L2CAP_REJ_INVALID_CID, local_cid, 0x0000, pkt);
        return;
    }

    channel = bb_con->channels[channel_nr];
    
    if (channel->state != BT_L2CAP_CH_W4_L2CAP_CONNECT_RSP)
    {
        ERROR("Invalid channel state\n");
        return;
    }

    channel->flags &= ~BT_L2CAP_FLAG_CON_RSP;
    if (channel->error == BT_L2CAP_ERR_CON_PENDING) {
        channel->error = BT_L2CAP_ERR_SUCCESS;
    }

    if (result != BT_L2CAP_CON_SUCCESS) {
        switch (result){
            case BT_L2CAP_CON_PENDING:
                channel->error = BT_L2CAP_ERR_CON_PENDING;
                channel->pending = 1;
                break;
            case BT_L2CAP_CON_PSM_NOT_SUPPORTED:
                channel->error = BT_L2CAP_ERR_PSM_NOT_SUPPORTED;
                break;
            case BT_L2CAP_CON_SECURITY_BLOCK:
                channel->error = BT_L2CAP_ERR_SECURITY_BLOCK;
                break;
            case BT_L2CAP_CON_REJ_NO_RESSOURCE:
                channel->error = BT_L2CAP_ERR_NO_RESSOURCE;
                break;
        }
    } else {
        channel->remote_cid = signal->payload[0] | (signal->payload[1] << 8);
        channel->con_handle = bb_con->con_handle;
        if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
        {
            service = &l2cap_stack->services[channel->service_nr];
            service->channel_nr = channel_nr;
            service->con_handle = bb_con->con_handle;
        }
        channel->pending = 0;
    }
    NutEventPostAsync(&channel->sig_con_rsp);
}
#endif

static void _bt_l2cap_conf_timeout_cb(HANDLE handle, void *arg)
{
    struct bt_l2cap_channel *channel = (struct bt_l2cap_channel *)arg;
    struct bt_l2cap_service *service;

    ERROR("Timeout on configuration\n");
    if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
    {
        service = &l2cap_stack->services[channel->service_nr];
        if (channel->state == BT_L2CAP_CH_OPEN) {
            service->con_cb(BT_L2CAP_DISCONNECT, BT_L2CAP_UNKNOWN,
                            channel->service_nr, service->channel_id, service->cb_arg);
        }
    } else
    { 
        ERROR("Invalid service nr. Nothing done in timeout handler\n");
        return;
    }

    _bt_l2cap_clear_channel(_bt_l2cap_handle2baseband(service->con_handle), service->channel_nr);
}

static void _bt_l2cap_conf_req(struct bt_l2cap_bb_connection* bb_con, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;    
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_service *service;
    u_short local_cid = signal->payload[0] | signal->payload[1] << 8;
    u_short flags     = signal->payload[2] | signal->payload[3] << 8;
    u_char  channel_nr= local_cid - BT_L2CAP_CID_USER;
    u_char  *options  = &signal->payload[4];
    u_char  option_length;
    u_short result    = BT_L2CAP_CONF_SUCCESS;
    u_short mtu       = BT_L2CAP_MTU_DEFAULT;
    u_char  conf_flags= 0x00;
    u_char  count;

    INFO("_bt_l2cap_conf_req\n");
        
    channel = bb_con->channels[channel_nr];
    
    channel->flags &= ~BT_L2CAP_FLAG_CONF_REQ;

    if (flags)
    {
        INFO("Continuation bit set.\n");
    }

    service = &l2cap_stack->services[channel->service_nr];
    
    option_length = (signal->len[0] | signal->len[1] << 8) - 4;
    while (option_length) {
        switch (*options) {
            case BT_L2CAP_CONF_OPT_NONE:
                options += 2;
                option_length -= 2;
                break;
            
            case BT_L2CAP_CONF_OPT_MTU:
                mtu = options[2] | options[3] << 8;
                
                if (mtu < service->min_mtu)                     // an MTU larger than the own one will be accepted.
                {                                               // But our own value will be send back.
                    result = BT_L2CAP_CONF_UNACCAPTABLE;        // a smaller one will be rejected.
                    mtu = service->min_mtu;                     // if outgoing too small set to our desired
                    conf_flags |= 1 << (*options-1);            // Bluez only sends an answer if we have to change the mtu
                } else {
                    channel->omtu = MIN(mtu, service->max_mtu);
                }
                options += 4;
                option_length -= 4;     // two bytes header + two bytes length field
                break;
            case BT_L2CAP_CONF_OPT_FLUSH:
                options += 4;           // TODO: At the moment we ignore the flush timeout
                option_length -= 4;     // two bytes header + two bytes timeout field
                break;
                
            case BT_L2CAP_CONF_OPT_QOS: 
                if (options[3] != BT_L2CAP_QOS_BEST_EFFORT)
                {
                    result = BT_L2CAP_CONF_UNACCAPTABLE; // we do not support guarateed service
                    conf_flags |= 1 << (*options-1);        
                }
                options += 22;  
                option_length -= 22;
                break;
            
            case BT_L2CAP_CONF_OPT_RTR_FLOW:
                if (options[2] != BT_L2CAP_MODE_BASIC)
                {
                    result = BT_L2CAP_CONF_UNACCAPTABLE;
                    conf_flags |= 1 << (*options-1);        
                }
                options += 9;
                option_length -= 9;
                break;

            default:
                option_length = 0;      // stop further operation
                break;
        }
    }
    // sending configuration response
    pkt->len[0] = BT_L2CAP_SIG_HEADER_LEN;
    pkt->len[1] = 0;
    signal->len[0] = 0;
    signal->len[1] = 0;
    signal->code = BT_L2CAP_SIG_CONF_RSP;
    // signal_id remains the same
    signal->payload[0] = (u_char)channel->remote_cid & 0xFF;
    signal->payload[1] = (u_char)channel->remote_cid >> 8;
    
    signal->payload[2] = (u_char) flags & 0xFF;         // if continuation bit is set, than set it again.
    signal->payload[3] = (u_char) flags >> 8;
    
    switch (result) {                                  
        case BT_L2CAP_CONF_UNACCAPTABLE:
        case BT_L2CAP_CONF_UNKNOWN_OPTIONS:
        case BT_L2CAP_CONF_REJECT:
                pkt->len[0] += 6;          
                signal->len[0] += 6;
                signal->payload[4] = BT_L2CAP_CONF_REJECT & 0xFF;
                signal->payload[5] = BT_L2CAP_CONF_REJECT >> 8;
                break;
        default:
                pkt->len[0] += 6;
                signal->len[0] += 6;
                signal->payload[4] = BT_L2CAP_CONF_SUCCESS & 0xFF;
                signal->payload[5] = BT_L2CAP_CONF_SUCCESS >> 8;
                break;
    }
    options = &signal->payload[6];
    // Now check wich option has to be set 
    
    if (conf_flags & (1 << (BT_L2CAP_CONF_OPT_MTU-1))) // we have to include the mtu.
    {
        mtu = MIN(service->max_mtu, mtu);                // select the minimum of our max and the calculated mtu (desired or outgoing)
        *(options++) = BT_L2CAP_CONF_OPT_MTU;
        *(options++) = 2;
        *(options++) = (u_char) mtu & 0xFF;
        *(options++) = (u_char) mtu >> 8;
        pkt->len[0] += 4;
        signal->len[0] += 4;
    }

    if (conf_flags & (1 << (BT_L2CAP_CONF_OPT_FLUSH-1)))
    {
        *(options++) = BT_L2CAP_CONF_OPT_FLUSH;
        *(options++) = 2;
        *(options++) = 0xFF;
        *(options++) = 0xFF;        
        pkt->len[0] += 4;
        signal->len[0] += 4;
    }
    
    if (conf_flags & (1 << (BT_L2CAP_CONF_OPT_QOS)))
    {
        *(options++) = BT_L2CAP_CONF_OPT_FLUSH;
        *(options++) = 22;
        *(options++) = 0;
        *(options++) = BT_L2CAP_QOS_BEST_EFFORT;
        for (count = 0; count < 12; count++)    // next three parameters = 0x00000000
            *(options++) = 0x00;
        for (count = 0; count < 8; count++)
            *(options++) = 0xFF;                // next two parameters = 0xFFFFFFFF
        pkt->len[0] += 24;
        signal->len[0] += 24;
    }
    
    if (conf_flags & (1 << (BT_L2CAP_CONF_OPT_RTR_FLOW)))
    {
        *(options++) = BT_L2CAP_CONF_OPT_RTR_FLOW;
        *(options++) = 9;
        *(options++) = BT_L2CAP_MODE_BASIC;
        for (count = 0; count < 8; count++)
            *(options++) = 0x00;                // ignore the following options
        pkt->len[0] += 11;
        signal->len[0] += 11;
    }
    
    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, bb_con->con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                    (pkt->len[0] | (pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) pkt);

    // End of Response sending...               
    if (!flags)  // there are no more parts in this configuration cycle... so let's go on...
    {
        if (!(channel->flags & BT_L2CAP_FLAG_INITIATOR)) {
            channel->sig_id = _bt_l2cap_get_new_sigid(bb_con);
    
            pkt->len[0] = 4 + BT_L2CAP_SIG_HEADER_LEN;
            pkt->len[1] = 0;
            signal->id = channel->sig_id;
            signal->len[0] = 4;
            signal->len[1] = 0;
            signal->code = BT_L2CAP_SIG_CONF_REQ;
            signal->payload[0] = (u_char)(channel->remote_cid & 0xFF);
            signal->payload[1] = (u_char)(channel->remote_cid >> 8);
            signal->payload[2] = 0x00;      // No Continue flag set
            signal->payload[3] = 0x00;
            
            if (service->max_mtu != BT_L2CAP_MTU_DEFAULT) {
                signal->payload[4] = BT_L2CAP_CONF_OPT_MTU;
                signal->payload[5] = 2; // Length = 2 Bytes
                signal->payload[6] = (u_char) (service->max_mtu & 0xFF);
                signal->payload[7] = (u_char) (service->max_mtu >> 8);
                signal->len[0] += 4;
                pkt->len[0] += 4;
            } 

            bt_hci_send_acl_pkt(l2cap_stack->bt_stack, bb_con->con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                                (pkt->len[0] | (pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) pkt);
    
            // Start timeout timer... this is the only direct timer used in our l2cap implementation.
            
            channel->sig_timeout = 
                NutTimerStart(BT_L2CAP_SIGNAL_TIMEOUT, _bt_l2cap_conf_timeout_cb, (void *) channel, TM_ONESHOT);
        } else
        {
            if (result == BT_L2CAP_CONF_SUCCESS) // we had success so we don't need to change anything. let's go on...
            {
                // Check if we got config response
                if (!(channel->flags & BT_L2CAP_FLAG_CONF_RSP))
                {
                    channel->state = BT_L2CAP_CH_OPEN;
                    bb_con->connections++;
                    if (channel->flags & BT_L2CAP_FLAG_INITIATOR) {
                        channel->flags &= ~BT_L2CAP_FLAG_INITIATOR;
                        NutEventPostAsync(&channel->sig_conf_rsp);
                    }
                    
                    if (channel->flags & BT_L2CAP_FLAG_WAS_CON)
                    {
                        channel->flags &= ~BT_L2CAP_FLAG_WAS_CON;
                    } 
                    if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
                    {
                        service = &l2cap_stack->services[channel->service_nr];
                        service->channel_id = _bt_l2cap_get_new_channel_id(channel->service_nr);
                        service->con_cb(BT_L2CAP_CONNECT, BT_L2CAP_CON_ACTIVE,
                                        channel->service_nr, service->channel_id,
                                        service->cb_arg);
                    }
                }
            }
        }
    }
}

void _bt_l2cap_conf_rsp(struct bt_l2cap_bb_connection* bb_con, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;    
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_service *service;
    u_short local_cid = signal->payload[0] | signal->payload[1] << 8;
    u_char  channel_nr= local_cid - BT_L2CAP_CID_USER;
    u_short result    = BT_L2CAP_CONF_SUCCESS;
    u_char  *options;
    u_short length;
    u_char  option_length;
    u_short mtu;
    
    INFO("_bt_l2cap_conf_rsp\n");
        
    channel = bb_con->channels[channel_nr];
    
    result = signal->payload[4] | signal->payload[5] << 8;

    switch (result) {
        case BT_L2CAP_CONF_SUCCESS:
            channel->flags &= ~BT_L2CAP_FLAG_CONF_RSP;
            break;
        case BT_L2CAP_CONF_UNACCAPTABLE:
        case BT_L2CAP_CONF_REJECT:
        case BT_L2CAP_CONF_UNKNOWN_OPTIONS:
            WARNING("Configuration not successfull...\n");
            break;
    }

    if (result != BT_L2CAP_CONF_SUCCESS)   // Sorry... we have to close the channel... so send a disconnect request...
    {
        channel->state = BT_L2CAP_CH_W4_L2CAP_DISCONNECT_RSP;
        channel->flags |= BT_L2CAP_FLAG_DISC_RSP;
        channel->sig_id = _bt_l2cap_get_new_sigid(bb_con);
        
        pkt->cid[0] = (u_char)(BT_L2CAP_CID_SIG & 0xFF);
        pkt->cid[1] = (u_char)(BT_L2CAP_CID_SIG >> 8);
        
        pkt->len[0] = 4 + BT_L2CAP_SIG_HEADER_LEN;
        pkt->len[1] = 0;
        signal->id = channel->sig_id;
        signal->code = BT_L2CAP_SIG_DISC_REQ;
        signal->len[0] = 4;
        signal->len[1] = 0;
        signal->payload[0] = (u_char) (channel->remote_cid & 0xFF);
        signal->payload[1] = (u_char) (channel->remote_cid >> 8);
        signal->payload[2] = (u_char) (local_cid & 0xFF);
        signal->payload[3] = (u_char) (local_cid >> 8);
        bt_hci_send_acl_pkt(l2cap_stack->bt_stack, bb_con->con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                        (pkt->len[0] | (pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) (pkt));
    
        // let's close the channel...
    } else
    {
        options = &signal->payload[6];
        length  = signal->len[0] | (signal->len[1]<<8);
        mtu = BT_L2CAP_MTU_DEFAULT;            
            
        if (length > 6) {       // We have options
            // Handle options...
            
            option_length = length - 6;
            while (option_length) {
                switch (*options) {
                    case BT_L2CAP_CONF_OPT_NONE:
                        options += 2;
                        option_length -= 2;
                        break;
                    
                    case BT_L2CAP_CONF_OPT_MTU:
                        mtu = options[2] | options[3] << 8;
                        options += 4;
                        option_length -= 4;     // two bytes header + two bytes length field
                        break;
                        
                    case BT_L2CAP_CONF_OPT_FLUSH:
                        options += 4;           // TODO: At the moment we ignore the flush timeout
                        option_length -= 4;     // two bytes header + two bytes timeout field
                        break;
                        
                    case BT_L2CAP_CONF_OPT_QOS: 
                        options += 22;  
                        option_length -= 22;
                        break;
                    
                    case BT_L2CAP_CONF_OPT_RTR_FLOW:
                        options += 9;
                        option_length -= 9;
                        break;
                    default:
                        option_length = 0;      // stop further operation
                        break;
                }
            }
        }
        if (channel->sig_timeout != NULL)
            NutTimerStop(channel->sig_timeout);
        channel->sig_timeout = NULL;
        if (!(channel->flags & BT_L2CAP_FLAG_CONF_REQ))
        {
            channel->state = BT_L2CAP_CH_OPEN;
            channel->imtu  = mtu;
            bb_con->connections++;        
            
            if (channel->flags & BT_L2CAP_FLAG_INITIATOR) {
                channel->flags &= ~BT_L2CAP_FLAG_INITIATOR;
                NutEventPostAsync(&channel->sig_conf_rsp);
            }
            
            if (channel->flags & BT_L2CAP_FLAG_WAS_CON) {
                
                channel->flags &= ~BT_L2CAP_FLAG_WAS_CON;
            }
            if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
            {
                service = &l2cap_stack->services[channel->service_nr];
                service->channel_id = _bt_l2cap_get_new_channel_id(channel->service_nr);
                service->con_cb(BT_L2CAP_CONNECT, BT_L2CAP_CON_PASSIVE,
                                channel->service_nr, service->channel_id,
                                service->cb_arg);
            }
        }
    }
}

static void _bt_l2cap_disc_req(struct bt_l2cap_bb_connection* bb_con, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;    
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_service *service;
    u_short local_cid  = signal->payload[0] | signal->payload[1] << 8;
    u_short remote_cid = signal->payload[2] | signal->payload[3] << 8;
    u_char  channel_nr = local_cid - BT_L2CAP_CID_USER;

    INFO("_bt_l2cap_disc_req\n");

    channel = bb_con->channels[channel_nr];

    pkt->len[0] = 4 + BT_L2CAP_SIG_HEADER_LEN;
    pkt->len[1] = 0;
    signal->len[0] = 4;
    signal->len[1] = 0;
    signal->code = BT_L2CAP_SIG_DISC_RSP;
    signal->payload[0] = (u_char) (local_cid & 0xFF);
    signal->payload[1] = (u_char) (local_cid >> 8);
    signal->payload[2] = (u_char) (remote_cid & 0xFF);
    signal->payload[3] = (u_char) (remote_cid >> 8);

    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, bb_con->con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                        (pkt->len[0] | (pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) pkt);
    
    if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
    {
        service = &l2cap_stack->services[channel->service_nr];
        if ((channel->state == BT_L2CAP_CH_OPEN) || (channel->state == BT_L2CAP_CH_W4_L2CAP_DISCONNECT_RSP))
            service->con_cb(BT_L2CAP_DISCONNECT, BT_L2CAP_UNKNOWN,
                channel->service_nr, service->channel_id, service->cb_arg);
    }
    
    // We are still waiting for a signal. Before we clear the channel we better should send this signal to avoid waiting too long.

    if (channel->state == BT_L2CAP_CH_CONFIG) {
        channel->state = BT_L2CAP_CH_CLOSED;
        NutEventPostAsync(&channel->sig_conf_rsp);
    } else {
        channel->state = BT_L2CAP_CH_CLOSED;
    }
    
    _bt_l2cap_clear_channel(bb_con, channel_nr);
    if (bb_con->connections > 0)
        bb_con->connections --;
}

static void _bt_l2cap_disc_rsp(struct bt_l2cap_bb_connection* bb_con, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;    
    struct bt_l2cap_channel *channel;
    struct bt_l2cap_service *service;
    u_short local_cid  = signal->payload[2] | signal->payload[3] << 8;
    u_char  channel_nr = local_cid - BT_L2CAP_CID_USER;

    INFO("_bt_l2cap_disc_rsp\n");

    channel = bb_con->channels[channel_nr];
  // l2cap disconnect successful
    channel->flags &= ~BT_L2CAP_FLAG_DISC_RSP;
    
    if (channel->service_nr != BT_L2CAP_SERVICENR_INVALID)
    {
        service = &l2cap_stack->services[channel->service_nr];
        if (channel->state == BT_L2CAP_CH_W4_L2CAP_DISCONNECT_RSP)
            service->con_cb(BT_L2CAP_DISCONNECT, BT_L2CAP_UNKNOWN,
                            channel->service_nr, service->channel_id, service->cb_arg);
    }  
    
    if (channel->flags & BT_L2CAP_FLAG_CONF_RSP)  // we send our disconnect request in config response handler
    {
        _bt_l2cap_clear_channel(bb_con, channel_nr);
    } else        
    {
        NutEventPostAsync(&channel->sig_disc_rsp); // we send our disconnect request normaly
    }
}

static void _bt_l2cap_echo_req(bt_hci_con_handle_t con_handle, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;

    INFO("_bt_l2cap_echo_req\n");

    pkt->len[0] = (u_char)((BT_L2CAP_SIG_HEADER_LEN) & 0xFF);
    pkt->len[1] = (u_char)((BT_L2CAP_SIG_HEADER_LEN) >> 8);
    signal->len[0] = 0;
    signal->len[1] = 0;
    signal->code = BT_L2CAP_SIG_ECHO_RSP;

    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                        (pkt->len[0] | (pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) pkt);
}

#ifndef BT_L2CAP_SLIMDOWN
static void _bt_l2cap_echo_rsp(struct bt_l2cap_acl_pkt *pkt)
{
    INFO("_bt_l2cap_echo_rsp\n");
    
    NutEventPostAsync(&echo_cmd.echo_ev);
    echo_cmd.id = 0;
}
#endif

static void _bt_l2cap_info_req(bt_hci_con_handle_t con_handle, struct bt_l2cap_acl_pkt *pkt)
{
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) & pkt->payload;
 
    INFO("_bt_l2cap_info_req\n");
 
    //if ((signal->payload[1] << 8 || signal->payload[0]) == BT_L2CAP_INFO_CONLESS_MTU) {
    //    // Do not support this at this moment
    //    // TODO: Implement connection less data transfer
    //    pkt->len[0] = 4 + BT_L2CAP_SIG_HEADER_LEN;     // 4 Bytes of info payload (info type + answer)
    //    pkt->len[1] = 0;
    //    signal->code = BT_L2CAP_SIG_INFO_RSP;
    //    signal->len[0] = 4;
    //    signal->len[1] = 0;
    //    signal->payload[2] = (u_char) (BT_L2CAP_INFO_NOT_SUPPORTED & 0xFF);
    //    signal->payload[3] = (u_char) (BT_L2CAP_INFO_NOT_SUPPORTED >> 8);
    //} else {
        pkt->len[0] = 4 + BT_L2CAP_SIG_HEADER_LEN;
        pkt->len[1] = 0;
        signal->code = BT_L2CAP_SIG_INFO_RSP;
        signal->len[0] = 4;
        signal->len[1] = 0;
        signal->payload[2] = (u_char) (BT_L2CAP_INFO_NOT_SUPPORTED & 0xFF);
        signal->payload[3] = (u_char) (BT_L2CAP_INFO_NOT_SUPPORTED >> 8);
    //}

    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                        (pkt->len[0] | (pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) pkt);
}

static void _bt_l2cap_signal_pkt(struct bt_l2cap_bb_connection* bb_con, struct bt_l2cap_acl_pkt * pkt)
{
    INFO("_bt_l2cap_signal_pkt\n");
        
    switch (((struct bt_l2cap_signal *) & pkt->payload)->code) {

    case BT_L2CAP_SIG_CMD_REJ:
        _bt_l2cap_cmd_rej(bb_con, pkt);
        break;
    case BT_L2CAP_SIG_CON_REQ:
        _bt_l2cap_con_req(bb_con, pkt);
        break;
#ifndef BT_L2CAP_SLIMDOWN
    case BT_L2CAP_SIG_CON_RSP:
        _bt_l2cap_con_rsp(bb_con, pkt);
        break;
#endif
    case BT_L2CAP_SIG_CONF_REQ:
        _bt_l2cap_conf_req(bb_con, pkt);
        break;
    case BT_L2CAP_SIG_CONF_RSP:
        _bt_l2cap_conf_rsp(bb_con, pkt);
        break;
    case BT_L2CAP_SIG_DISC_REQ:
        _bt_l2cap_disc_req(bb_con, pkt);
        break;
    case BT_L2CAP_SIG_DISC_RSP:
        _bt_l2cap_disc_rsp(bb_con, pkt);
        break;
    case BT_L2CAP_SIG_ECHO_REQ:
        _bt_l2cap_echo_req(bb_con->con_handle, pkt);
        break;
#ifndef BT_L2CAP_SLIMDOWN
    case BT_L2CAP_SIG_ECHO_RSP:
        _bt_l2cap_echo_rsp(pkt);
        break;
#endif
    case BT_L2CAP_SIG_INFO_REQ:
        _bt_l2cap_info_req(bb_con->con_handle, pkt);
        break;
#ifndef BT_L2CAP_SLIMDOWN
    case BT_L2CAP_SIG_INFO_RSP:
        // Do nothing as we do not support request of l2cap info yet.
        // So we should never receive such a signal.
        break;
#endif
    default:
        WARNING("_bt_l2cap_signal_pkt: signal %02x unknown\n", ((struct bt_l2cap_signal *) & pkt->payload)->code);
        _bt_l2cap_send_cmd_rej(bb_con->con_handle, BT_L2CAP_REJ_CMD_NOT_UNDERSTOOD, 0x0000, 0x0000, pkt);
        break;

    }                           // end switch ( sig_code )
}

static void _bt_l2cap_handle_continued_pkt(bt_hci_con_handle_t con_handle, struct bt_l2cap_acl_buffer_entry *buffer)
{
    struct bt_l2cap_channel *channel = NULL;
    struct bt_l2cap_service *service;
    struct bt_l2cap_signal_buffer  *signal;
    struct bt_l2cap_bb_connection* bb_con;
    struct bt_l2cap_acl_pkt *pkt = buffer->pkt;
    u_short len = buffer->len;
    u_char channel_nr = (pkt->cid[0] | pkt->cid[1] << 8) - BT_L2CAP_CID_USER;        // displace cid down to get service nr;
    INFO("_bt_l2cap_handle_continued_pkt\n");
    
    bb_con = _bt_l2cap_handle2baseband(con_handle);
    signal = &bb_con->signal;

    /* We got a continued packet. But we don't know if the data belongs to a signal 
       packet or to a data packet... So first search for a signal packet to continue.
       If not found any, it has to be a data packet.     
    */
    
    if ((signal->received < (signal->signal->len[0] | signal->signal->len[1] << 8)) && 
        (signal->state == BT_L2CAP_NOT_FREE)) 
    {
        /* Ok, we have found a signal packet to continue... Copy data and correct length */
#ifdef ASSERT_PARANOID
        if (signal->received < l2cap_stack->acl_len) {
#endif
        memcpy(&signal->signal->payload[signal->received],
            &((struct bt_hci_pkt_acl *) pkt)->payload, MIN(len, l2cap_stack->acl_len-signal->received));
#ifdef ASSERT_PARANOID
        }
#endif
        
        signal->received += len;
        _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt);
        /* Check if the packet got completed... If yes, call signal handler. */       
        if (signal->received >= (signal->signal->len[0] | signal->signal->len[1] << 8)) {
            _bt_l2cap_signal_pkt(bb_con, signal->signal);
            signal->received = 0;
            signal->state = BT_L2CAP_FREE;
        }
    } else {
        /* Data belongs to a channel. So find the channel the data belongs to. */
        for (channel_nr = 0; channel_nr < bb_con->connections; channel_nr ++) {
            channel = bb_con->channels[channel_nr];
            if ((channel->buf_state == BT_L2CAP_NOT_FREE) &&
                (channel->received < (channel->pkt->len[0] | channel->pkt->len[1] << 8))) // this should be the packet to continue
                break;
        }
        
        /* This should realy never happen. But we still have it for debug reasons */
        if (channel_nr == bb_con->connections)
        {
            ERROR("Can't find packet to continue...\n"); 
            _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt);
        } else
        {

            if (channel->pkt == NULL) {
                ERROR("No L2CAP Channel buffer space allocated\n");
                _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt);
            } else {
                /* Copy data to fill up our packet */        
                memcpy(&channel->pkt->payload[channel->received], &((struct bt_hci_pkt_acl *) pkt)->payload, len);
                       
                channel->received += len;
                /* Check if the packet got completed... If yes add channel info data to pkt and call signal handler. */       
                if (channel->received >= (channel->pkt->len[0] | channel->pkt->len[1] << 8)) {
                    _bt_l2cap_wait_packet((struct bt_hci_pkt_acl *) pkt);
                        
                    service = &l2cap_stack->services[channel->service_nr];

                    buffer->channel = channel;
//                    buffer->buf_used = 1;
                    buffer->channel_id = service->channel_id;
                    *((struct bt_l2cap_acl_buffer_entry **)&channel->pkt->payload[channel->pkt->len[0] | channel->pkt->len[1] << 8]) = buffer;
                    
                    service->rcv_cb(channel->pkt, channel->service_nr, service->channel_id, service->cb_arg);  
                    channel->buf_state = BT_L2CAP_FREE;
                    channel->received = 0;
                } else {
                    _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt);
                }
            }
        }
    }
}

static u_char _bt_l2cap_handle_pkt(bt_hci_con_handle_t con_handle, struct bt_l2cap_acl_buffer_entry *buffer)
{   
    struct bt_l2cap_channel *channel = NULL;
    struct bt_l2cap_service *service;
    struct bt_l2cap_signal_buffer  *signal;
    struct bt_l2cap_bb_connection* bb_con;
    struct bt_l2cap_acl_pkt *pkt = buffer->pkt;
    u_short len = buffer->len;
    u_char channel_nr = (pkt->cid[0] | pkt->cid[1] << 8) - BT_L2CAP_CID_USER;        // displace cid down to get service nr;
    
    INFO("_bt_l2cap_handle_pkt\n");

    bb_con = _bt_l2cap_handle2baseband(con_handle);
    signal = &bb_con->signal;

    if (bb_con->pkt_types != l2cap_stack->pkt_types)        // TODO: This is a hack to initialize the packet types for this connection...
    {
        if (bt_hci_change_con_pkt_type(l2cap_stack->bt_stack, BT_HCI_SYNC, bb_con->con_handle, l2cap_stack->pkt_types) < 0)
            ERROR("Pkt change error\n"); 
        bb_con->pkt_types = l2cap_stack->pkt_types;
    }    

    /* What kind of packet do we have received? */
    
    if ((pkt->cid[0] | pkt->cid[1] << 8) == BT_L2CAP_CID_CONNECTIONLESS)
    {
        ERROR("No connectionless data transfer supported\n");
        _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt); 
    } else 
    if ((pkt->cid[0] | pkt->cid[1] << 8) == BT_L2CAP_CID_SIG) {
        /* We got a signal packet. Check if the packet it complete and call signal handler*/
        if (len - BT_L2CAP_HEADER_LEN == (pkt->len[0] | pkt->len[1] << 8))
        {
            _bt_l2cap_signal_pkt(bb_con, pkt);     // directly call signal handler without copying first
            _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt); 
        } else   /* Check that the packet will not exceed the maximum signal mtu */
        if ((pkt->len[0] | pkt->len[1] << 8) > l2cap_stack->max_signal_mtu)
        {
            _bt_l2cap_send_cmd_rej(bb_con->con_handle, BT_L2CAP_REJ_MTU_EXCEEDED, 0, 0, pkt);
            _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt); 
        } else   /* So we have a packet that will be continued. Copy data and don't call signal handler */
        {    
            if (signal->state == BT_L2CAP_FREE) {
                signal->received = len - BT_L2CAP_HEADER_LEN;
                
                signal->signal->cid[0] = pkt->cid[0];
                signal->signal->cid[1] = pkt->cid[1];
                signal->signal->len[0] = pkt->len[0];
                signal->signal->len[1] = pkt->len[1];
                memcpy(signal->signal->payload, pkt->payload, signal->received);
                signal->state = BT_L2CAP_NOT_FREE;
            }
            _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt); 
        }
    } else /* This packet is user data...*/
    {
        if ((channel_nr >= bb_con->connections) || (bb_con->channels[channel_nr]==NULL)) {
            ERROR("Invalid local cid. No such channel assigned\n");
            _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt);
        } else 
        {
            channel = bb_con->channels[channel_nr];

            if (channel->state == BT_L2CAP_CH_NOT_ASSIGNED) {
                ERROR("Invalid local cid. No such channel assigned\n");
                _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt);
            }
            else {
                // Check if we have enough buffer space...
                if (channel->buf_state == BT_L2CAP_FREE) {
                    channel->received = len - BT_L2CAP_HEADER_LEN;
                    channel->buf_state = BT_L2CAP_NOT_FREE;
                    /* Have we got a complete packet? If so, add channel info and call receive callback */
                    if (channel->received == (pkt->len[0] | pkt->len[1] << 8)) {   
                        _bt_l2cap_wait_packet((struct bt_hci_pkt_acl *) pkt);
        
                        service = &l2cap_stack->services[channel->service_nr];
                        
                        channel->last_acl_pkt = pkt;

                        buffer->channel = channel;
//                        buffer->buf_used = 0;
                        buffer->channel_id = 0x0000;
                        *((struct bt_l2cap_acl_buffer_entry **)&pkt->payload[pkt->len[0] | pkt->len[1] << 8]) = buffer;
                        
                        service->rcv_cb(pkt, channel->service_nr, service->channel_id, service->cb_arg); 
                        channel->buf_state = BT_L2CAP_FREE;
                        channel->received = 0;
                    } else {    // The packet is the first part... more will follow
                        channel->pkt = _bt_l2cap_get_service_packet_buffer(channel->service_nr);
                        if (channel->pkt == NULL) {
                            channel->received = 0;
                            channel->buf_state = BT_L2CAP_FREE;
                            return BT_L2CAP_ERR_NO_RESSOURCE;
                        }
                        channel->pkt->cid[0] = pkt->cid[0];
                        channel->pkt->cid[1] = pkt->cid[1];
                        channel->pkt->len[0] = pkt->len[0];
                        channel->pkt->len[1] = pkt->len[1];
                        memcpy(channel->pkt->payload, pkt->payload, channel->received);                   
                        _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt);
                    }
                }
                else {
                    ERROR("Buffer overrun...\n");
                    _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) pkt);
                }
            }
        }
    }
    return BT_L2CAP_ERR_SUCCESS;
}


THREAD(BT_L2CAP, arg)
{
    u_char  idx;
    u_short acl_sequence_nr = 0x0000;
    u_char  retval;
    struct bt_l2cap_acl_buffer_entry *buffer;

    for (;;) {
        NutEventWait(&l2cap_stack->sig_acl_data_avail, NUT_WAIT_INFINITE);

        retval = 0;
        
        while (!retval) {            // repeat until we could send our packet to higher layer...
            retval = 1;
            for (idx = 0; idx < l2cap_stack->buffer_size; idx++) {
                buffer = &l2cap_stack->buffer[idx];
                if ((buffer->state == BT_L2CAP_NOT_FREE) &&
#ifdef ASSERT_PARANOID
                    (buffer->con_handle != BT_HCI_HANDLE_INVALID) &&
#endif    
                    (buffer->sequence_nr == acl_sequence_nr + 1))
                {
                    if (buffer->pb_flag == HCI_PB_CONTD_FRAGMENT) {
                        _bt_l2cap_handle_continued_pkt(buffer->con_handle, buffer);
                        acl_sequence_nr++;
                    } else {    
                        if (_bt_l2cap_handle_pkt(buffer->con_handle, buffer) == BT_L2CAP_ERR_SUCCESS) {
                                retval = 1;
                                acl_sequence_nr++;
                        } else {
                            retval = 0;
                            break;
                        }
                    }
                }
            }
        
            if (!retval) {
                NutThreadYield();
            }
        }
    }
}

/*
 * this callback function will be called after a acl packet arrives and is stored
 * in a acl buffer (pkt points to this acl buffer entry).
 */
static struct bt_hci_pkt_acl *_bt_l2cap_acl_cb(void *arg, struct bt_hci_pkt_acl *pkt,
                                        bt_hci_con_handle_t con_handle, u_char pb_flag, u_char bc_flag, u_short len, u_long t_arrive)
{
    u_char idx;
    struct bt_l2cap_acl_buffer_entry *buffer;

    for (idx = 0; idx < l2cap_stack->buffer_size; idx++)
    {   
        if (l2cap_stack->buffer[idx].pkt == (struct bt_l2cap_acl_pkt *)pkt)
            break;
    }

    buffer = &l2cap_stack->buffer[idx];
    
    buffer->con_handle = con_handle;
    buffer->pb_flag = pb_flag;
    buffer->len = len;
    l2cap_stack->acl_sequence_nr++;
    buffer->sequence_nr = l2cap_stack->acl_sequence_nr;
    
    NutEventPostAsync(&l2cap_stack->sig_acl_data_avail);

    //return free acl pkt
    do {
        for (idx = 0; idx < l2cap_stack->buffer_size; idx++) {
            if (l2cap_stack->buffer[idx].state == BT_L2CAP_FREE)
                break;
        }
    
        if (idx == l2cap_stack->buffer_size) {
            WARNING("Running out of ACL buffer...\n");
            NutEventWait(&l2cap_stack->sig_acl_buffer_free, NUT_WAIT_INFINITE);
        }
    } while (idx == l2cap_stack->buffer_size);
    buffer = &l2cap_stack->buffer[idx];
    
    buffer->state = BT_L2CAP_NOT_FREE;
    buffer->con_handle = BT_HCI_HANDLE_INVALID;

    //there is always a free buffer otherwise the module would not send a pkt!
    return (struct bt_hci_pkt_acl *) buffer->pkt;
}

static void _bt_l2cap_hci_con_table_cb(u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg)
{
    u_char con_nr;       
    u_char channel_nr;
    struct bt_l2cap_bb_connection *bb_con;
    struct bt_l2cap_service *service;
    struct bt_l2cap_channel *channel;
        
    if (type == BT_HCI_CONNECTION)
    {
        for (con_nr = 0; con_nr < BT_HCI_MAX_NUM_CON; con_nr++)
        {
            if (l2cap_stack->bb_con[con_nr].con_handle == BT_HCI_HANDLE_INVALID) break;
        }
        if (con_nr == BT_HCI_MAX_NUM_CON)
        {
            ERROR("No ressource free! Too much BB connections...\n");
            return;
        } else {    
            bb_con = &l2cap_stack->bb_con[con_nr];
            bb_con->con_handle = con_handle;
            bb_con->signal.received = 0;
            bb_con->signal.state = BT_L2CAP_FREE;            
            bb_con->sig_id = 0;
            bb_con->pkt_types = 0;
            
            for (channel_nr = 0; channel_nr < l2cap_stack->max_channel; channel_nr++) {
               bb_con->channels[channel_nr] = NULL;
            }    
            l2cap_stack->bb_connections++;
        }
        INFO("Created connection for handle: %d at index %d\n", con_handle, con_nr);
        
    } else
    if (type == BT_HCI_DISCONNECTION)
    {
        // TODO: Is this behavior correct?
        // We will now clear every baseband packet in the state BT_L2CAP_NOT_FREE
        // The ones in state BT_L2CAP_WAIT will not be cleared since they are just 
        // passed to higher layers.
        for (con_nr = 0; con_nr < l2cap_stack->buffer_size; con_nr++) 
            if ((l2cap_stack->buffer[con_nr].state == BT_L2CAP_NOT_FREE) &&
                (l2cap_stack->buffer[con_nr].con_handle == con_handle)) 
            {
                INFO("DISCON_FREE: %08x, con_nr: %d\n", &l2cap_stack->buffer[con_nr], con_nr);
                _bt_l2cap_free_packet((struct bt_hci_pkt_acl *) &l2cap_stack->buffer[con_nr]); 
            }
                    
        
        INFO("Close connection for handle: %d at index %d\n", con_handle, con_nr);                    
        
        bb_con = _bt_l2cap_handle2baseband(con_handle);            
            
        bb_con->con_handle = BT_HCI_HANDLE_INVALID;
                    
        bb_con->signal.received = 0;
        bb_con->signal.state = BT_L2CAP_FREE;            
        
        for (channel_nr = 0; channel_nr < bb_con->connections; channel_nr ++) {
            if (bb_con->channels[channel_nr] != NULL)
            {
                channel = bb_con->channels[channel_nr];
                
                if ((channel->state == BT_L2CAP_CH_OPEN) || 
                    (channel->state == BT_L2CAP_CH_W4_L2CAP_DISCONNECT_RSP))
                {
                    u_char l2cap_detail = BT_L2CAP_UNKNOWN;
                    if( detail == BT_HCI_DISCON_LINK_LOST) {
                        l2cap_detail = BT_L2CAP_DISCON_LINK_LOST;
                    }
                    service = &l2cap_stack->services[channel->service_nr];
                    service->con_cb(BT_L2CAP_DISCONNECT, l2cap_detail, 
                                    channel->service_nr, service->channel_id,
                                    service->cb_arg);
                }
                _bt_l2cap_clear_channel(bb_con, channel_nr);
            }
        }             
                    
        l2cap_stack->bb_connections--;
    }
}


//------------------------------------------------------------------------------
struct bt_l2cap_stack *bt_l2cap_init(struct btstack *bt_stack, u_char nr_buffer, u_char max_channel, u_short pkt_types)
{
    u_char  idx;
    u_char  channel_nr;
    long    retval;
    u_short host_buffer_size;
    struct bt_l2cap_bb_connection *con;
    struct bt_l2cap_service *service;
    struct bt_l2cap_channel *channel;
        
    if (max_channel > BT_L2CAP_MAX_CHANNELS) {
        ERROR("Max channels too large. Setting max_channels to %d\n", BT_L2CAP_MAX_CHANNELS);
        max_channel = BT_L2CAP_MAX_CHANNELS;
    }
    
    l2cap_stack = NutHeapAllocClear(sizeof(struct bt_l2cap_stack));
    if (l2cap_stack == NULL)
    {
        ERROR("Out of memory...\n");
        return NULL;
    }

    //dyn alloc acl buffer
    l2cap_stack->buffer = NutHeapAllocClear(sizeof(struct bt_l2cap_acl_buffer_entry) * nr_buffer);
    if (l2cap_stack->buffer == NULL)
    {
        ERROR("Out of memory...\n");
#ifndef BT_L2CAP_SLIMDOWN
        NutHeapFree(l2cap_stack);
#endif
        return NULL;
    }
    
    l2cap_stack->buffer_size = nr_buffer;
    //set bt_stack
    l2cap_stack->bt_stack = bt_stack;
    l2cap_stack->bb_connections = 0;
    
    l2cap_stack->pkt_types = pkt_types;
    l2cap_stack->max_channel = max_channel;
    l2cap_stack->channel_id = 0x0000;
    l2cap_stack->acl_sequence_nr = 0x0000;
    l2cap_stack->sig_acl_buffer_free = NULL;
    l2cap_stack->sig_acl_data_avail = NULL;
    
    l2cap_stack->channels = NutHeapAllocClear(sizeof(struct bt_l2cap_channel) * max_channel);
    if (l2cap_stack->channels == NULL)
    {
        ERROR("Out of memory...\n");
#ifndef BT_L2CAP_SLIMDOWN
        NutHeapFree(l2cap_stack->buffer);
        NutHeapFree(l2cap_stack);
#endif
        return NULL;
    }
    
    for (channel_nr = 0; channel_nr < max_channel; channel_nr ++) {
        channel = &l2cap_stack->channels[channel_nr];
        channel->state      = BT_L2CAP_CH_NOT_ASSIGNED;
        channel->con_handle = BT_HCI_HANDLE_INVALID;
        channel->remote_cid = 0x0000;
        channel->local_cid  = 0x0000;
        channel->flags      = 0x00;
        channel->sig_id     = 0x00;
        channel->omtu       = BT_L2CAP_MTU_DEFAULT; // default omtu value
        channel->imtu       = BT_L2CAP_MTU_DEFAULT;
        channel->error      = BT_L2CAP_ERR_SUCCESS;
        channel->pending    = 0;
        channel->sig_con_rsp  = NULL;
        channel->sig_conf_rsp = NULL;
        channel->sig_disc_rsp = NULL;
        channel->sig_timeout  = NULL;        
        channel->received   = 0;
        channel->buf_state  = BT_L2CAP_FREE;
        channel->pkt        = NULL;
        channel->last_acl_pkt = NULL;
        channel->service_nr = BT_L2CAP_SERVICENR_INVALID;
    }    

    l2cap_stack->acl_len = host_buffer_size = BT_L2CAP_ACL_SIZE_DM1;
    if (pkt_types & BT_HCI_PACKET_TYPE_DH1) l2cap_stack->acl_len = BT_L2CAP_ACL_SIZE_DH1;
    if (pkt_types & BT_HCI_PACKET_TYPE_DM3) l2cap_stack->acl_len = BT_L2CAP_ACL_SIZE_DM3;
    if (pkt_types & BT_HCI_PACKET_TYPE_DH3) l2cap_stack->acl_len = BT_L2CAP_ACL_SIZE_DH3;
    if (pkt_types & BT_HCI_PACKET_TYPE_DM5) l2cap_stack->acl_len = BT_L2CAP_ACL_SIZE_DM5;
    if (pkt_types & BT_HCI_PACKET_TYPE_DH5) l2cap_stack->acl_len = BT_L2CAP_ACL_SIZE_DH5;
    host_buffer_size = l2cap_stack->acl_len;
    l2cap_stack->acl_len -= 2;
    l2cap_stack->max_signal_mtu = l2cap_stack->acl_len;
    
    l2cap_stack->tmp_pkt = NutHeapAlloc(l2cap_stack->acl_len + BT_L2CAP_ACL_PKT_HDR_LEN);
    if (l2cap_stack->tmp_pkt == NULL)
    {
        ERROR("Out of memory...\n");
#ifndef BT_L2CAP_SLIMDOWN
        NutHeapFree(l2cap_stack->buffer);
        NutHeapFree(l2cap_stack->channels);
        NutHeapFree(l2cap_stack);
#endif
        return NULL;
    }
    
#if (BT_RADIO_TYPE == ERICSSON)
    //ericsson module demands at least 339 bytes
    if (host_buffer_size < 339)
        host_buffer_size = 339;
#endif
    //set number of buffer to module for flowcontrol!
    retval = bt_hci_host_buffer_size(bt_stack, BT_HCI_SYNC, host_buffer_size, 0, nr_buffer-1, 0);
    if (retval < 0)
        ERROR("Could not set host buffer size\n");
    // register acl callback function in lower layer l2cap_stack and give first
    // acl buffer
    for (idx = 0; idx < l2cap_stack->buffer_size; idx++) {
        l2cap_stack->buffer[idx].pkt = NutHeapAlloc(l2cap_stack->acl_len + BT_L2CAP_ACL_PKT_HDR_LEN + BT_L2CAP_CHANNEL_INFO_SIZE);
        if (l2cap_stack->buffer[idx].pkt == NULL)
        {
            ERROR("Out of memory...\n");
#ifndef BT_L2CAP_SLIMDOWN

            u_char bcount;

            for (bcount = 0; bcount < idx; bcount++)
                NutHeapFree(l2cap_stack->buffer[bcount].pkt);
            NutHeapFree(l2cap_stack->buffer);
            NutHeapFree(l2cap_stack->channels);
            NutHeapFree(l2cap_stack->tmp_pkt);
            NutHeapFree(l2cap_stack);
#endif
            return NULL;
        }
        l2cap_stack->buffer[idx].state = BT_L2CAP_FREE;
        l2cap_stack->buffer[idx].con_handle = BT_HCI_HANDLE_INVALID;
        l2cap_stack->buffer[idx].sequence_nr = 0;
        l2cap_stack->buffer[idx].channel_id = BT_L2CAP_CHNR_INVALID;
//        l2cap_stack->buffer[idx].buf_used = 0;
        l2cap_stack->buffer[idx].channel = NULL;
    }
    l2cap_stack->buffer[0].state = BT_L2CAP_NOT_FREE;

    for (idx = 0; idx < BT_L2CAP_MAX_SERVICES; idx++) {
        service = &l2cap_stack->services[idx];
        service->psm = BT_L2CAP_PSM_INVALID;
        service->channel_nr  = BT_L2CAP_CHNR_INVALID;
        service->con_handle  = BT_HCI_HANDLE_INVALID;
        service->rcv_cb      = _bt_l2cap_dummy_rcv_cb;
        service->con_cb      = _bt_l2cap_dummy_con_cb;
        service->cb_arg      = NULL;
        service->channel_id  = 0x0000;
        service->min_mtu     = BT_L2CAP_MIN_MTU;
        service->max_mtu     = BT_L2CAP_MTU_DEFAULT;
        service->buffer_size = 0;
        service->buffer      = NULL;
    }
    
    for (idx = 0; idx < BT_HCI_MAX_NUM_CON; idx++)
    {
        con = &l2cap_stack->bb_con[idx];
        con->con_handle = BT_HCI_HANDLE_INVALID;
        con->sig_id = 0;
        con->pkt_types = 0;
        //now alloc a buffer for the ACL signalling packets. It's an ACL buffer with larger payload. (MAX L2CAP Payload)
        con->signal.signal = NutHeapAllocClear(l2cap_stack->acl_len + BT_L2CAP_ACL_PKT_HDR_LEN);
        if (con->signal.signal == NULL)
        {
            ERROR("Out of memory...\n");
#ifndef BT_L2CAP_SLIMDOWN

            u_char bcount;

            for (bcount = 0; bcount < l2cap_stack->buffer_size; bcount++)
                NutHeapFree(l2cap_stack->buffer[bcount].pkt);
            for (bcount = 0; bcount < idx; bcount++)
            {
                NutHeapFree(l2cap_stack->bb_con[bcount].signal.signal);
                NutHeapFree(l2cap_stack->bb_con[bcount].channels);
            }
            NutHeapFree(l2cap_stack->buffer);
            NutHeapFree(l2cap_stack->channels);
            NutHeapFree(l2cap_stack->tmp_pkt);
            NutHeapFree(l2cap_stack);
#endif
            return NULL;
        }            
        con->signal.received = 0;
        con->signal.state = BT_L2CAP_FREE;            
        con->connections = 0;
        con->channels = NutHeapAlloc(sizeof (struct bt_l2cap_channel *) * max_channel);
        if (con->channels == NULL)
        {
            ERROR("Out of memory...\n");
#ifndef BT_L2CAP_SLIMDOWN

            u_char bcount;

            for (bcount = 0; bcount < l2cap_stack->buffer_size; bcount++)
                NutHeapFree(l2cap_stack->buffer[bcount].pkt);
            for (bcount = 0; bcount < idx; bcount++)
            {
                NutHeapFree(l2cap_stack->bb_con[bcount].signal.signal);
                NutHeapFree(l2cap_stack->bb_con[bcount].channels);
            }
            NutHeapFree(l2cap_stack->buffer);
            NutHeapFree(l2cap_stack->channels);
            NutHeapFree(l2cap_stack->tmp_pkt);
            NutHeapFree(l2cap_stack);
#endif
            return NULL;
        }            

        for (channel_nr = 0; channel_nr < max_channel; channel_nr++)
            con->channels[channel_nr] = NULL;
    }
    echo_cmd.id = 0;
    if (NutThreadCreate("bt_l2cap", BT_L2CAP, NULL, 1024) == NULL)
    {
        ERROR("Could not create l2cap thread...\n");
#ifndef BT_L2CAP_SLIMDOWN
        if (con->channels == NULL)
        {

            u_char bcount;

            ERROR("Out of memory...\n");
            for (bcount = 0; bcount < l2cap_stack->buffer_size; bcount++)
                NutHeapFree(l2cap_stack->buffer[bcount].pkt);
            for (bcount = 0; bcount < BT_HCI_MAX_NUM_CON; bcount++)
            {
                NutHeapFree(l2cap_stack->bb_con[bcount].signal.signal);
                NutHeapFree(l2cap_stack->bb_con[bcount].channels);
            }
            NutHeapFree(l2cap_stack->buffer);
            NutHeapFree(l2cap_stack->channels);
            NutHeapFree(l2cap_stack->tmp_pkt);
            NutHeapFree(l2cap_stack);
        }
#endif         
    }
    
    bt_hci_register_con_table_cb(bt_stack, _bt_l2cap_hci_con_table_cb, NULL); 
    bt_hci_register_acl_cb(bt_stack, _bt_l2cap_acl_cb, (struct bt_hci_pkt_acl *) l2cap_stack->buffer[0].pkt, NULL);
    
    return l2cap_stack;
}
