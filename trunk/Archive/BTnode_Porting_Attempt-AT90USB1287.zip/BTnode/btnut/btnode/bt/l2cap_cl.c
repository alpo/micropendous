/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

 /**
 * @file l2cap_cl.c
 *
 *\author Kevin Martin <kevmarti@tik.ee.ethz.ch>
 * 
 *\date 03-22-06
 * 
 *\brief Implementation of the connection-less l2cap layer
 *
 */
#include <string.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/thread.h>
#include <sys/mutex.h>
#include <sys/timer.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_acl_defs.h>
#include <terminal/btn-terminal.h>
#include <bt/l2cap_cl.h>
#include <debug/toolbox.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_L2CAP_CL
#define LOG_LEVEL SYSLOG_LEVEL_L2CAP_CL
#include <debug/log_set.h>

#if LOG_LEVEL >= 4
// string buffers for debugging
u_char _l2cap_cl_addr_buf_1[18];
u_char _l2cap_cl_addr_buf_2[18];
#endif

char _l2cap_cl_dbg_buf[3*121];

#define L2CAP_CL_TRACE_BEFORE_GEN_TSTAMP	0
#define L2CAP_CL_TRACE_AFTER_GEN_TSTAMP		1

/// Channel id of the connection-less L2CAP channel.
#define L2CAP_CL_CONLESS_CID 	0x0002

/**
 * \brief l2cap connection-less stack.
 *  
 * This struct contains all the data needed by the l2cap connection-less
 * layer itself. Basically, it holds information about the services registered
 * on the connection-less l2cap channel, as well as the information about
 * how to forward connection-oriented l2cap packets to the higher layer l2cap
 * stack.
 */
struct _l2cap_cl_stack_t {
    struct btstack* bt_stack;    ///< Pointer to the lower layer bt-stack
    bt_psm_t* psmux;             ///< The protocol/service multiplexor
    bt_acl_pkt_buf* pkt_buf;
    u_long t_arrive;
    HCI_ACL_CB;                  ///< Callback handling connection-oriented data
    void* acl_cb_arg;            ///< Callback argument
    u_long pkt_cnt_in;
    u_long pkt_cnt_out;
    u_long pkt_cnt_dropped;
} _l2cap_cl_stack;

/**
 * \brief Definition of the l2cap_cl pkt header.
 *
 \verbatim ---------------------------------------
 | len | cid | psm |       data         |
 ---------------------------------------
 .  2     2     2         len - 2\endverbatim
 *
 * - len: size of the data in bytes. Note: includes psm field!
 * - cid: L2CAP channel id. Set to #L2CAP_CL_CONLESS_CID for connection-less L2CAP packets.
 * - psm: Protocol/Service Multiplexer
 * 
 * See BT specification 1.2, Vol. 3, Part A, p. 34 for further details.
 */
typedef struct _l2cap_cl_pkt_hdr {
    u_char len[2];			/// size of payload (including the psm field)
    u_char cid[2];			/// channel id, set to #L2CAP_CL_CONLESS_CID
    u_char psm[L2CAP_CL_PSM_FIELD_SIZE];   	/// Protocol/Service Multiplexer
} l2cap_cl_pkt_hdr;

// this callback will be called after reception of an acl data packet
struct bt_hci_pkt_acl* _l2cap_cl_acl_cb(void* cb_arg, struct bt_hci_pkt_acl* pkt,
                                        bt_hci_con_handle_t con_handle, u_char pb_flag,
                                        u_char bc_flag, u_short len, u_long t_arrive)
{
    short retval;
    u_short cid;
    u_short psm;
    bt_acl_pkt_buf* free_buf;
	
    // update pkt counter
    _l2cap_cl_stack.pkt_cnt_in++;
    
    // get pointer to l2cap_cl packet header
    u_char* data = pkt->payload;
    l2cap_cl_pkt_hdr* hdr = (l2cap_cl_pkt_hdr*) data;

    // get channel id - if not connectionless (=0x02), call next higher layer
    cid = hdr->cid[0] | hdr->cid[1] << 8;
    if (cid != L2CAP_CL_CONLESS_CID)
    {
        // call l2cap callback if registered
        if (_l2cap_cl_stack.hci_acl_cb)
        {
            return _l2cap_cl_stack.hci_acl_cb(cb_arg, pkt, con_handle, pb_flag, bc_flag, len, t_arrive);
        }
    }
	
    // get con handle - if not valid, discard (return) packet
    con_handle = bt_acl_get_con_handle(pkt);
    if (con_handle == BT_HCI_HANDLE_INVALID)
    {
        WARNING("pkt with invalid hdl!\n");
        _l2cap_cl_stack.pkt_cnt_dropped++;
        return pkt;
    }

    // else, get psm
    psm = hdr->psm[0] | hdr->psm[1] << 8;
    // get data len
    len = hdr->len[0] | hdr->len[1] << 8;
    // Note: size of PSM field is included in data size field
    // (see BT specification 1.2, Vol. 3, Part A, p. 34)
    len -= L2CAP_CL_PSM_FIELD_SIZE;
    // adjust data pointer
    data += sizeof(l2cap_cl_pkt_hdr);

    INFO("acl cb! msg: %p, hdl: %d, psm: %.4x, len: %d\n", _l2cap_cl_stack.pkt_buf, con_handle, psm, len);
    //DEBUG_STR("data: %s\n", dbg_str_to_hex_str(_l2cap_cl_dbg_buf, data, len));
	
    // store arrival time & deliver msg
    _l2cap_cl_stack.pkt_buf->tstamp = t_arrive;
    _l2cap_cl_stack.pkt_buf->pkt = pkt;
    retval = bt_psm_deliver_msg(_l2cap_cl_stack.psmux, _l2cap_cl_stack.pkt_buf,	data, len, psm,	&free_buf);

    INFO("msg: %p, hdl: %d, psm: 0x%04X, len: %d\n",
    _l2cap_cl_stack.pkt_buf, con_handle, psm, len);

    if (retval)
    {
        WARNING("deliver pkt to psm 0x%04x: failed: %d!\n", psm, retval);
        _l2cap_cl_stack.pkt_cnt_dropped++;
        return pkt;
    }
    // else, we store the pointer to the (empty) pkt buf obtained and return
    // the free packet it contains
    _l2cap_cl_stack.pkt_buf = free_buf;
    return free_buf->pkt;
}

long l2cap_cl_acquire_write_lock(bt_hci_con_handle_t hdl, u_short psm, u_short len)
{
    long result;
    l2cap_cl_pkt_hdr hdr;

    INFO("ctxt: %s, hdl: %d, psm: 0x%04x, len: %d\n", runningThread->td_name, hdl, psm, len);
	
    /* build the packet header */
    // Note: size of PSM field has to be added to payload size
    // (see BT specification 1.2, Vol. 3, Part A, p. 34)
    hdr.len[0] = BTN_LO(len + L2CAP_CL_PSM_FIELD_SIZE);
    hdr.len[1] = BTN_HI(len + L2CAP_CL_PSM_FIELD_SIZE);
    // write connection-less channel-id to pkt
    hdr.cid[0] = BTN_LO(L2CAP_CL_CONLESS_CID);
    hdr.cid[1] = BTN_HI(L2CAP_CL_CONLESS_CID);
    // write psm to packet
    hdr.psm[0] = BTN_LO(psm);
    hdr.psm[1] = BTN_HI(psm);
    
    /* get access to the desired acl link */
    result = bt_acl_acquire_write_lock(_l2cap_cl_stack.bt_stack, hdl, HCI_PB_FIRST_FRAGMENT,
                                       HCI_BC_UNICAST, len + sizeof(l2cap_cl_pkt_hdr));
    // if error, return
    if (result < 0) return result;

    // send header
    result = bt_acl_lowlevel_write(_l2cap_cl_stack.bt_stack, (u_char*)&hdr, sizeof(l2cap_cl_pkt_hdr));
    // if error, close acl link and return
    if (result < 0)
    {
        bt_acl_write_lock_release(_l2cap_cl_stack.bt_stack);
    }
    return result;
}	

inline void l2cap_cl_release_write_lock(void)
{
    // update pkt counter (outgoing packets)
    _l2cap_cl_stack.pkt_cnt_out++;
	
    // close acl link
    bt_acl_write_lock_release(_l2cap_cl_stack.bt_stack);
    INFO("ctxt: %s, hdl: %d, written: %d, max len: %d\n", runningThread->td_name, chan_hdl->acl_hdl.con_hdl,
         chan_hdl->acl_hdl.written - sizeof(l2cap_cl_pkt_hdr), chan_hdl->acl_hdl.data_len - sizeof(l2cap_cl_pkt_hdr));
}

inline long l2cap_cl_lowlevel_write(u_char* data, u_short len)
{
    return bt_acl_lowlevel_write(_l2cap_cl_stack.bt_stack, data, len);
}

inline u_char* l2cap_cl_get_data_ptr(struct bt_hci_pkt_acl* pkt)
{
    return bt_acl_get_data_pointer(pkt) + sizeof(l2cap_cl_pkt_hdr);
}

inline u_short l2cap_cl_max_payload(void)
{
    return bt_acl_get_max_pkt_len(_l2cap_cl_stack.bt_stack) - sizeof(l2cap_cl_pkt_hdr);
}

inline u_long l2cap_cl_get_arrival_time(bt_acl_pkt_buf* pkt_buf)
{
    return pkt_buf->tstamp;
}

inline u_long l2cap_cl_get_outgoing_traffic(void)
{
    return _l2cap_cl_stack.pkt_cnt_out;
}

inline u_long l2cap_cl_get_incoming_traffic(void)
{
    return _l2cap_cl_stack.pkt_cnt_in;
}

inline u_long l2cap_cl_get_dropped_traffic(void)
{
    return _l2cap_cl_stack.pkt_cnt_dropped;
}

/**
 * Sends a packet over the link corresponding to the handle passed. On the
 * receiving side, the incoming packet will be handled by the service that
 * is registered at the psm specified.
 */
long l2cap_cl_send(u_char* data, u_short len, bt_hci_con_handle_t hdl, u_short psm)
{
    long result;

    // get access to the l2cap cl channel
    result = l2cap_cl_acquire_write_lock(hdl, psm, len);
    if (result)
    {
        ERROR("l2cap cl channel access (%d)!\n", result);
        return result;
    }

    // write data
    result = l2cap_cl_lowlevel_write(data, len);
    if (result)
    {
        ERROR("send data (%d)!\n", result);
    }

    // close link
    l2cap_cl_release_write_lock();
    return result;
}

/**
 * Initializes the connection-less l2cap protocol stack
 */
void l2cap_cl_init(struct btstack* bt_stack, bt_psm_t* mux)
{
    long retval;
    int host_buffer_size;

    // store pointer to bt-stack
    _l2cap_cl_stack.bt_stack = bt_stack;
    // store pointer to the protocol/service multiplexor
    _l2cap_cl_stack.psmux = mux;

    // initialize first packet buffer
    _l2cap_cl_stack.pkt_buf = bt_acl_pkt_buf_create(bt_stack);

    // register acl data callback & give first acl pkt buffer
    bt_hci_register_acl_cb(bt_stack, _l2cap_cl_acl_cb, _l2cap_cl_stack.pkt_buf->pkt, NULL);

    // initialize l2cap data callback
    _l2cap_cl_stack.hci_acl_cb = NULL;
    _l2cap_cl_stack.acl_cb_arg = NULL;

    // determine host_buffer_size
    host_buffer_size = BT_ACL_HCI_PKT_HDR_LEN + bt_acl_get_max_pkt_len(bt_stack);
#if (BT_RADIO_TYPE == ERICSSON)
    //ericsson module demands at least 339 bytes
    if (host_buffer_size < 339)
        host_buffer_size = 339;
#endif
	
    // init packet counters
    _l2cap_cl_stack.pkt_cnt_in = 0;
    _l2cap_cl_stack.pkt_cnt_out = 0;
    _l2cap_cl_stack.pkt_cnt_dropped = 0;
       
    _l2cap_cl_stack.t_arrive = 0;

    //set number of buffer to module for flowcontrol!
    retval = bt_hci_host_buffer_size(bt_stack, BT_HCI_SYNC, host_buffer_size, 0, bt_psm_get_nr_default_bufs(mux), 0);
    if (retval < 0)
        ERROR("set host buf size: %d! bufs: %d\n", host_buffer_size, bt_psm_get_nr_default_bufs(mux));
}

void l2cap_cl_register_acl_cb(struct btstack* bt_stack, HCI_ACL_CB, void* arg)
{
    _l2cap_cl_stack.hci_acl_cb = hci_acl_cb;
    _l2cap_cl_stack.acl_cb_arg = arg;
}
