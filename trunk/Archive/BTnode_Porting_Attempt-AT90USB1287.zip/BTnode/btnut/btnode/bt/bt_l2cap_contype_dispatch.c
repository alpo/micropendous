/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * @file bt_l2cap_contype_dispatch.c
 *
 *\author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 * 
 *\date 2006-08-19
 * 
 *\brief A dispatcher for L2CAP connection-oriented and connectionless
 *
 */

#include <sys/heap.h>
#include <bt/bt_defs.h>
#include <bt/bt_hci_api.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

// Channel ID of the connectionless L2CAP channel.
#define L2CAP_CL_CID 	0x0002

struct _bt_l2cap_contype_dispatch_stack_t {
    u_char con_table_cb_registered;
    void (*co_con_table_cb) (u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg);
    void (*cl_con_table_cb) (u_char type, u_char detail, bt_hci_con_handle_t con_handle, void* cb_arg);
    void* co_con_table_cb_arg;
    void* cl_con_table_cb_arg;
    u_char acl_cb_registered;
    struct bt_hci_pkt_acl *(*co_acl_cb) (void *arg, struct bt_hci_pkt_acl *pkt, bt_hci_con_handle_t con_handle, u_char pb_flag, u_char bc_flag, u_short len, u_long t_arrive);
    struct bt_hci_pkt_acl *(*cl_acl_cb) (void *arg, struct bt_hci_pkt_acl *pkt, bt_hci_con_handle_t con_handle, u_char pb_flag, u_char bc_flag, u_short len, u_long t_arrive);
    void* co_acl_cb_arg;
    void* cl_acl_cb_arg;
};

static struct _bt_l2cap_contype_dispatch_stack_t * l2cap_contype_stack = NULL;

static void _con_table_cb(u_char type, u_char detail, 
                          bt_hci_con_handle_t con_handle, void* cb_arg)
{
    if (l2cap_contype_stack->co_con_table_cb)
    {
        l2cap_contype_stack->co_con_table_cb(type, detail, con_handle, 
                                             l2cap_contype_stack->co_con_table_cb_arg);
    }
    if (l2cap_contype_stack->cl_con_table_cb)
    {
        l2cap_contype_stack->cl_con_table_cb(type, detail, con_handle, 
                                             l2cap_contype_stack->cl_con_table_cb_arg);
    }
}

static void _bt_l2cap_contype_dispatch_register_con_table_cb(struct btstack *stack)
{
    if (!l2cap_contype_stack->con_table_cb_registered)   
    {
        l2cap_contype_stack->con_table_cb_registered = 1;
        bt_hci_register_con_table_cb(stack, _con_table_cb, NULL);
    }
}

void bt_l2cap_contype_dispatch_register_co_con_table_cb(struct btstack *stack, 
                                                        HCI_CON_TABLE_CB, 
                                                        void *arg)
{
    if (l2cap_contype_stack)
    {
        l2cap_contype_stack->co_con_table_cb = con_table_cb;
        l2cap_contype_stack->co_con_table_cb_arg = arg;
        _bt_l2cap_contype_dispatch_register_con_table_cb(stack);
    }
}

void bt_l2cap_contype_dispatch_register_cl_con_table_cb(struct btstack *stack, 
                                                        HCI_CON_TABLE_CB, 
                                                        void *arg)
{
    if (l2cap_contype_stack)
    {
        l2cap_contype_stack->cl_con_table_cb = con_table_cb;
        l2cap_contype_stack->cl_con_table_cb_arg = arg;
        _bt_l2cap_contype_dispatch_register_con_table_cb(stack);
    }
}

static struct bt_hci_pkt_acl * _hci_acl_cb (void *arg,
                                            struct bt_hci_pkt_acl *pkt, 
                                            bt_hci_con_handle_t con_handle, 
                                            u_char pb_flag, u_char bc_flag, 
                                            u_short len, u_long t_arrive)
{
    if (pkt->payload[2] == BTN_LO(L2CAP_CL_CID) &&
        pkt->payload[3] == BTN_HI(L2CAP_CL_CID))
    {
        // L2CAP connectionless
        if (l2cap_contype_stack->cl_acl_cb)
        {
            return l2cap_contype_stack->cl_acl_cb(l2cap_contype_stack->cl_acl_cb_arg, 
                                                  pkt, con_handle, pb_flag, 
                                                  bc_flag, len, t_arrive);
        }
    }
    else
    {
        // L2CAP connection-oriented
        if (l2cap_contype_stack->co_acl_cb)
        {
            return l2cap_contype_stack->co_acl_cb(l2cap_contype_stack->co_acl_cb_arg, 
                                                  pkt, con_handle, pb_flag, 
                                                  bc_flag, len, t_arrive);
        }
    }
    
    return pkt;
}

static void _bt_l2cap_contype_dispatch_register_acl_cb(struct btstack *stack, 
                                                       struct bt_hci_pkt_acl *pkt)
{
    if (!l2cap_contype_stack->acl_cb_registered)   
    {
        l2cap_contype_stack->acl_cb_registered = 1;
        bt_hci_register_acl_cb(stack, _hci_acl_cb, pkt, NULL);
    }
}

void bt_l2cap_contype_dispatch_register_co_acl_cb(struct btstack *stack, 
                                                  HCI_ACL_CB, 
                                                  struct bt_hci_pkt_acl *pkt, 
                                                  void *arg)
{
    if (l2cap_contype_stack)
    {
        l2cap_contype_stack->co_acl_cb = hci_acl_cb;
        l2cap_contype_stack->co_acl_cb_arg = arg;
        _bt_l2cap_contype_dispatch_register_acl_cb(stack, pkt);
    }
}

void bt_l2cap_contype_dispatch_register_cl_acl_cb(struct btstack *stack, 
                                                  HCI_ACL_CB, 
                                                  struct bt_hci_pkt_acl *pkt, 
                                                  void *arg)
{
    if (l2cap_contype_stack)
    {
        l2cap_contype_stack->cl_acl_cb = hci_acl_cb;
        l2cap_contype_stack->cl_acl_cb_arg = arg;
        _bt_l2cap_contype_dispatch_register_acl_cb(stack, pkt);
    }
}

void bt_l2cap_contype_dispatch_init(void)
{
    if (!l2cap_contype_stack)
    {
        l2cap_contype_stack = NutHeapAllocClear(sizeof(
                                    struct _bt_l2cap_contype_dispatch_stack_t));
        /*
        l2cap_contype_stack->con_table_cb_registered = 0;
        l2cap_contype_stack->co_con_table_cb = NULL;
        l2cap_contype_stack->cl_con_table_cb = NULL;
        l2cap_contype_stack->acl_cb_registered = 0;
        l2cap_contype_stack->co_acl_cb = NULL;
        l2cap_contype_stack->cl_acl_cb = NULL;
        */
    }
}
