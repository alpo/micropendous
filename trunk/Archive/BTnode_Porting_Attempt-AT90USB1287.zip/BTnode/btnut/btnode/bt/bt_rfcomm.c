/*
 * Copyright (C) 2000-2006 by ETH Zurich
 * Copyright (C) 2004 by Ole Reinhardt <ole.reinhardt@embedded-it.de>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 * 
 * Author: Ole Reinhardt <ole.reinhardt@embedded-it.de>
 *
 *
 * Some parts are taken from or inspired by the lwBT Bluetooth stack.
 * 
 * (lwBT author: Conny Ohult <conny@sm.luth.se>)
 * Copyright (c) 2003 EISLAB, Lulea University of Technology.)
 * 
 * Some additions / hints made by Chi Keung, KI <kichikeung@gmail.com>
 *
 */


 /**
 * @file bt_rfcomm.c
 *
 * @brief Implementation of the RFCOMM protocol for BTNut. 
 * A subset of the ETSI TS 07.10 standard with some Bluetooth-specific 
 * adaptations.
 * 
 * \author Ole Reinhardt <ole.reinhardt@embedded-it.de>
 * \date
 * 
 * TODO: Need to wait on multiple events... (i.E. listening but stop when l2cap disconnect
 *
 * TODO: New signalling concept to handle errors on open channels. prevent multipe close callbacks.
 *       Always send signal on close ore open...
 * 
 * $Log: bt_rfcomm.c,v $
 * Revision 1.17  2006/03/23 07:22:19  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.13.2.2  2006/03/22 14:07:30  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.16  2006/02/15 22:39:58  yuecelm
 * fixed bug: first byte was *lost* if sending 127 or more bytes at once
 *
 * Revision 1.13.2.1  2006/02/02 08:10:27  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.15  2006/01/21 16:44:53  yuecelm
 * rename RFCOMM_DEVICE_SLIMDOWN to BT_{L2CAP|RFCOMM}_SLIMDOWN
 * and remove some slimdown mods that are not in agreement with bluetooth specification.
 *
 * Revision 1.14  2006/01/20 14:23:15  yuecelm
 * add (#ifndef) RFCOMM_DEVICE_SLIMDOWN macros (reduce size demand (~6 KB) of l2cap- and rfcomm-stack)
 *
 * Revision 1.13  2005/06/20 15:39:05  olereinhardt
 * Changed API: bt_l2cap_connect now returns channel_id of
 * the service (call by ref)
 *
 * Revision 1.12  2005/06/17 10:13:05  olereinhardt
 * Moved _bt_rfcomm_setup_listening(void) in code
 * Fixed fcs precalculation for incomming connections
 *
 * Revision 1.11  2005/05/25 15:20:46  olereinhardt
 * Changed APU. Now one can set the max MFS on rfcomm init.
 * This will be used to set the max MTU for the rfcomm service
 * in the l2cap layer
 *
 * Changes in bt_rfcomm_init
 *
 * Revision 1.10  2005/05/24 10:08:53  olereinhardt
 * Added Daniel Hobi <hobid@ee.ethz.ch> changes:
 *
 * Added an additional parameter to the connection callback -
 * u_char detail - which can be used to provide information
 * about the callbacks reason. Values are:
 *
 * #define BT_L2CAP_UNKNOWN               0x01
 * #define BT_L2CAP_CON_ACTIVE            0x02
 * #define BT_L2CAP_CON_PASSIVE           0x03
 * #define BT_L2CAP_DISCON_LINK_LOST      0x04
 *
 * Revision 1.9  2005/04/21 10:39:04  olereinhardt
 * Fixed MTU handling... Now the MFS (maximum frame size is only limited
 * by the l2caps omtu. MFS will be determined right after l2cap
 * connection establishment.
 *
 * Revision 1.8  2005/04/15 12:31:00  beutel
 * added link key requests and more pin code stuff
 *
 */

#include <string.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/atom.h>
#include <bt/bt_l2cap.h>
#include <bt/bt_rfcomm.h>
#include <bt/bt_crc.h>

#ifndef RFCOMM_DEBUG
#define RFCOMM_DEBUG 0
#endif

#if     RFCOMM_DEBUG >= 3
#define INFO(text, ...) printf_P(PSTR("RFCOMM: " text),## __VA_ARGS__)
#else
#define INFO(text, ...)
#endif

#if     RFCOMM_DEBUG >= 2
#define WARNING(text, ...) printf_P(PSTR("RFCOMM: WARNING: " text),## __VA_ARGS__)
#else
#define WARNING(text, ...)
#endif

#if     RFCOMM_DEBUG >= 1
#define ERROR(text, ...) printf_P(PSTR("RFCOMM: ERROR: " text),## __VA_ARGS__)
#else
#define ERROR(text, ...)
#endif

#define BT_RFCOMM_GET_DLCI(addr)        ((addr & 0xfc) >> 2)
#define BT_RFCOMM_CH_IS_ACTIVE(dlci)    ((dlci & 0x01) ^ stack->initiator)

#define BT_RFCOMM_FREE 0
#define BT_RFCOMM_NOT_FREE 1
#define BT_RFCOMM_WAIT 2

static struct bt_rfcomm_stack *stack;

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_clear_channel():
 *
 * Resets the channel and removes the channel from the listen and active list.
 * On channel 0 nothing will be done
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_clear_channel(struct bt_rfcomm_channel *channel)
{
    u_char dlci;
    u_char tmp_fcs_buf[BT_RFCOMM_UIHCRC_CHECK_LEN];
    
    dlci = channel->dlci;
    
    channel->state = BT_RFCOMM_CH_CLOSED;
    channel->dlci  = BT_RFCOMM_DLCI_INVALID;
    channel->convergency_layer = BT_RFCOMM_DEF_CL;
    channel->priority = 0x00;
    channel->max_framesize = BT_RFCOMM_DEF_MFS;
    channel->local_credits = 0x00;
    channel->remote_credits = 0x00;
    channel->config = 0x00;
    
    channel->rcv_cb    = NULL;
    channel->con_cb    = NULL;
    channel->line_cb   = NULL;
    channel->credit_cb = NULL;
    channel->cb_arg    = NULL;
    
    channel->credit_limit = 0;

    channel->uih_in_fcs = 0x00;
    channel->uihpf_in_fcs = 0x00;
    channel->uih_out_fcs = 0x00;
    channel->uihpf_out_fcs = 0x00;
    
    channel->response_type = 0;
    channel->sig_response = NULL;
    channel->sig_connected = NULL;
    channel->sig_credits = NULL;
    channel->listen = NULL;

    if (dlci == BT_RFCOMM_DLCI_MUX) {
        // configure the command channel with default values...
        channel->state = BT_RFCOMM_CH_LISTEN;
        channel->dlci  = BT_RFCOMM_DLCI_MUX;
        // precalculate the fcs values for the control channel
        tmp_fcs_buf[0] = (1 << 0) | (1 << 1) | (0 << 2) | (0x00 << 3); // set c/r bit to 0. We are the responder
        tmp_fcs_buf[1] = BT_RFCOMM_UIH;
        channel->uih_in_fcs = crc8_calc(tmp_fcs_buf, BT_RFCOMM_UIHCRC_CHECK_LEN);
        tmp_fcs_buf[0] = (1 << 0) | (0 << 1) | (0 << 2) | (0x00 << 3); // set c/r bit to 0. We are the responder
        tmp_fcs_buf[1] = BT_RFCOMM_UIH;
        channel->uih_out_fcs = crc8_calc(tmp_fcs_buf, BT_RFCOMM_UIHCRC_CHECK_LEN);        
    }
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_clear_channels():
 *
 * Resets the channels and removes them from the listen and active list.
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_clear_channels(void)
{
    u_char idx;
    struct bt_rfcomm_channel *channel;
        
    for (idx = 0; idx <= stack->max_dlci; idx++) {
        channel = stack->channels[idx];
        channel->state = BT_RFCOMM_CH_CLOSED;
        channel->dlci  = BT_RFCOMM_DLCI_INVALID;
        channel->convergency_layer = BT_RFCOMM_DEF_CL;
        channel->priority = 0x00;
        channel->max_framesize = BT_RFCOMM_DEF_MFS;
        channel->local_credits = 0x00;
        channel->remote_credits = 0x00;
        channel->config = 0x00;
        
        channel->rcv_cb    = NULL;
        channel->con_cb    = NULL;
        channel->line_cb   = NULL;
        channel->credit_cb = NULL;
        channel->cb_arg    = NULL;
        
        channel->credit_limit = 0;

        channel->uih_in_fcs = 0x00;
        channel->uihpf_in_fcs = 0x00;
        channel->uih_out_fcs = 0x00;
        channel->uihpf_out_fcs = 0x00;
        
        channel->response_type = 0;
        channel->sig_response = NULL;
        channel->sig_connected = NULL;
        channel->sig_credits = NULL;
        channel->listen = NULL;
    }
}


/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_setup_listening():
 *
 * Will be called after opening multiplexer channel. Setup all listening channels
 */
/*-----------------------------------------------------------------------------------*/

void _bt_rfcomm_setup_listening(void)
{
    struct bt_rfcomm_channel *channel = NULL;
    struct bt_rfcomm_listen  *listen = NULL;
    u_char dlci;
    u_char idx;
    
    
    for (idx = 1; idx <= stack->max_channel; idx ++) {
        listen = stack->listening[idx];
        if (listen->channel_nr != BT_RFCOMM_CHNR_INVALID)
        {
            dlci = (idx << 1) | stack->initiator;
    
            channel = stack->channels[dlci];
                
            if (channel->state != BT_RFCOMM_CH_CLOSED) {
                ERROR("bt_rfcomm_setup_listening: Channel %d with dlci %d is not closed. State: %02x\n", 
                        idx, dlci, channel->state);
                break;
            }
            
            channel->state = BT_RFCOMM_CH_LISTEN;
            channel->dlci  = dlci;
            channel->rcv_cb    = listen->rcv_cb;
            channel->con_cb    = listen->con_cb;
            channel->cb_arg    = listen->cb_arg;
            channel->line_cb   = listen->line_cb;
            channel->credit_cb = listen->credit_cb;
            channel->credit_limit = listen->credit_limit;
            channel->listen    = listen;
        }
    }
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_complete_buffer():
 *
 * Mark the input buffer as free and call bt_l2cap_complete_pkt for flow control reasons
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_complete_buffer(struct bt_rfcomm_l2cap_pkt_buf_entry *buffer)    
{
    bt_l2cap_complete_pkt(buffer->pkt);
    buffer->pkt = NULL;
    buffer->sequence_nr = 0;
    buffer->state = BT_RFCOMM_FREE;
}

#ifndef BT_RFCOMM_SLIMDOWN
/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_sabm():
 *
 * Send a set asynchronous balanced mode command (channel establishment)
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_send_sabm(u_char dlci)
{
    u_char *payload = stack->send_buffer->payload;

    // This is a command
    payload[0] = (1 << 0) | (stack->initiator << 1) | (dlci << 2);              // EA and C/R bit set

    payload[1] = BT_RFCOMM_SABM;        // control field
    payload[2] = 1;                     // set EA bit to 1 to indicate 7 bit length field
    payload[3] = crc8_calc(payload, BT_RFCOMM_CRC_CHECK_LEN);   // calc fcs, 3 bytes to be send...
    
    if (stack->l2cap_channel_id != BT_L2CAP_HANDLE_INVALID)     // the channel just got closed
        bt_l2cap_send(stack->l2cap_channel_id, stack->send_buffer, BT_RFCOMM_HDR_LEN_1 + BT_RFCOMM_FCS_LEN);
}
#endif

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_disc():
 *
 * Send a disconnect command (channel closedown)
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_send_disc(u_char dlci)
{
    u_char *payload = stack->send_buffer->payload;

    // This is a command
    payload[0] = (1 << 0) | (stack->initiator << 1) | (dlci << 2);              // EA and C/R bit set

    payload[1] = BT_RFCOMM_DISC;        // control field
    payload[2] = 1;                     // set EA bit to 1 to indicate 7 bit length field
    payload[3] = crc8_calc(payload, BT_RFCOMM_CRC_CHECK_LEN);   // calc fcs, 3 bytes to be send...
    
    if (stack->l2cap_channel_id != BT_L2CAP_HANDLE_INVALID)     // the channel just got closed
        bt_l2cap_send(stack->l2cap_channel_id, stack->send_buffer, BT_RFCOMM_HDR_LEN_1 + BT_RFCOMM_FCS_LEN);
}


/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_ua():
 *
 * Sends a RFCOMM unnumbered acknowledgement to respond to a connection request.
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_send_ua(u_char dlci)
{
    u_char *payload = stack->send_buffer->payload;
    // This is a response
    payload[0] = (1 << 0) | ((stack->initiator ^ 1) << 1) | (dlci << 2);        // EA and C/R bit set

    payload[1] = BT_RFCOMM_UA;  // control field
    payload[2] = 1;             // set EA bit to 1 to indicate 7 bit length field
    payload[3] = crc8_calc(payload, BT_RFCOMM_CRC_CHECK_LEN);   // calc fcs, 3 bytes to be send...
    
    if (stack->l2cap_channel_id != BT_L2CAP_HANDLE_INVALID)     // the channel just got closed
        bt_l2cap_send(stack->l2cap_channel_id, stack->send_buffer, BT_RFCOMM_UA_LEN);
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_dm():
 *
 * Sends a RFCOMM disconnected mode frame in response to a command when disconnected.
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_send_dm(u_char dlci)
{
    u_char *payload = stack->send_buffer->payload;
    
    // This is a response
    
    payload[0] = (1 << 0) | ((stack->initiator ^ 1) << 1) | (dlci << 2);          // EA and C/R bit set

    
    payload[1] = BT_RFCOMM_DM;  // control field
    payload[2] = 1;             // set EA bit to 1 to indicate 7 bit length field
    payload[3] = crc8_calc(payload, BT_RFCOMM_CRC_CHECK_LEN);   // calc fcs, 3 bytes to be send...

    if (stack->l2cap_channel_id != BT_L2CAP_HANDLE_INVALID)     // the channel just got closed
        bt_l2cap_send(stack->l2cap_channel_id, stack->send_buffer, BT_RFCOMM_DM_LEN);
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_uih():
 *
 * Sends a RFCOMM unnumbered information frame with header check.
 * Payload bytes and frame type / length needs to be filled in before calling
 */
/*-----------------------------------------------------------------------------------*/
static u_char _bt_rfcomm_send_uih(u_char dlci, u_short length)    
{
    u_char *payload = stack->send_buffer->payload;
    struct bt_rfcomm_channel *channel;

    channel = stack->channels[dlci];
    
    if (channel == NULL) {
        ERROR("Channel with DLCI %i is not available...\n", dlci);
        return BT_RFCOMM_ERR_INVALID_CH;
    }
    
    if (channel->state == BT_RFCOMM_CH_CLOSED)
    {
        ERROR("Channel with DLCI %i is still closed...\n", dlci);
        return BT_RFCOMM_ERR_CON_CLOSED;
    }

    // Do we use credit based flow control?
    if ((channel->convergency_layer == 0x0F) && (channel->state == BT_RFCOMM_CH_OPEN) && (dlci != BT_RFCOMM_DLCI_MUX) && (length != 0)) {
        // check wether there is enough credit
        if (channel->local_credits != 0) {
            channel->local_credits--;
        } else {            
            ERROR("Out of local credits...\n");
            return BT_RFCOMM_ERR_OOLCR;
        }
    }

    /* Setup RFCOMM header */
    
    // C/R Bit set according to TS 07.10 section 5.4.3.1 as stated in section 5.1.3 rfcomm documentation
    payload[0] = (1 << 0) | (stack->initiator << 1) | (dlci << 2);
    
    payload[1] = BT_RFCOMM_UIH;

    if (length < 127) {                                         // for EA = 1, 7 bits length -> 0 - 127
        payload[2] = 1 | ((length << 1) & 0xFF);                // EA = 1 
        length = length + BT_RFCOMM_HDR_LEN_1;
    } else {
        payload[2] = (u_char) (0 | ((length << 1) & 0xFF));     // EA = 0
        payload[3] = (u_char) (length >> 7);
        length = length + BT_RFCOMM_HDR_LEN_2;
    }

    payload[length] = channel->uih_out_fcs;

    if (stack->l2cap_channel_id != BT_L2CAP_HANDLE_INVALID)     // the channel just got closed
        bt_l2cap_send(stack->l2cap_channel_id, stack->send_buffer, length + BT_RFCOMM_FCS_LEN);
    
    return BT_RFCOMM_ERR_SUCCESS;
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_uih_credits():
 *
 * Sends a RFCOMM unnumbered information frame with header check and credit based flow control
 * Payload bytes and frame type / length needs to be filled in before calling
 */
/*-----------------------------------------------------------------------------------*/
static u_char _bt_rfcomm_send_uih_credits(u_char dlci, u_short length, u_char credits)
{
    u_char *payload = stack->send_buffer->payload;
    struct bt_rfcomm_channel *channel;

    channel = stack->channels[dlci];

    if (channel == NULL) {
        ERROR("Channel with DLCI %i is not available...\n", dlci);
        return BT_RFCOMM_ERR_INVALID_CH;
    }
    
    if (channel->state == BT_RFCOMM_CH_CLOSED)
    {
        ERROR("Channel with DLCI %i is still closed...\n", dlci);
        return BT_RFCOMM_ERR_CON_CLOSED;
    }    

    // Do we use credit based flow control?
    if ((channel->convergency_layer == 0x0F) && (channel->state == BT_RFCOMM_CH_OPEN) && (dlci != BT_RFCOMM_DLCI_MUX) && (length != 0)) {
        // check wether there is enough credit
        if (channel->local_credits != 0) {
            channel->local_credits--;
        } else {
            ERROR("Out of local credits...\n");
            return BT_RFCOMM_ERR_OOLCR;
        }
    }

    // C/R Bit set according to TS 07.10 section 5.4.3.1 as stated in section 5.1.3 rfcomm documentation
    payload[0] = (1 << 0) | (stack->initiator << 1) | (dlci << 2);
           
    payload[1] = BT_RFCOMM_UIH_PF;

    if (length < 127) {                                         // for EA = 1, 7 bits length -> 0 - 127
        payload[2] = 1 | ((length << 1) & 0xFF);                // EA = 1 
        payload[3] = credits;
        length = length + BT_RFCOMM_HDR_LEN_1 + 1;
    } else {
        payload[2] = (u_char) (0 | ((length << 1) & 0xFF));     // EA = 0
        payload[3] = (u_char) (length >> 7);
        payload[4] = credits;
        length = length + BT_RFCOMM_HDR_LEN_2 + 1;
    }

    payload[length] = channel->uihpf_out_fcs;
    
    channel->remote_credits += credits;
    
    if (stack->l2cap_channel_id != BT_L2CAP_HANDLE_INVALID)     // the channel just got closed
        bt_l2cap_send(stack->l2cap_channel_id, stack->send_buffer, length + BT_RFCOMM_FCS_LEN);
    
    return BT_RFCOMM_ERR_SUCCESS;
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_pn()
 *
 * Prepares a RFCOMM parameter negotiation multiplexer frame (command and response) 
 * to negotiate the parameters of a data link connection and then sends it with the 
 * _bt_rfcomm_send_uih command.
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_send_pn(u_char dlci, u_char is_cmd)
{
    u_char *payload = stack->send_buffer->payload;
    struct bt_rfcomm_channel *channel;
    u_char pos;

    channel = stack->channels[dlci];
        
    if (channel == NULL) {
        ERROR("Channel with DLCI %i is not available...\n", dlci);
        return;
    }
    
    if (channel->state == BT_RFCOMM_CH_CLOSED)
    {
        ERROR("Channel with DLCI %i is still closed...\n", dlci);
        return;
    } 
    
    pos = 3;

/*	PN message
	   0     1     2     3     4     5     6     7    bits 
	+-----+-----+-----+-----+-----+-----+-----+-----+
	| EA=1| C/R |           Type = 000001           |		3
	+-----+-----+-----+-----+-----+-----+-----+-----+
	|                     Length                    |		4
	+-----+-----+-----+-----+-----+-----+-----+-----+
	+-----+-----+-----+-----+-----+-----+-----+-----+
	|             DLC                   |   0b00    |		5
	+-----+-----+-----+-----+-----+-----+-----+-----+
        | I = 0b1000 for UIH    |     CL = 0b000        |   	        6
	+-----+-----+-----+-----+-----+-----+-----+-----+
	|          P (priority)             |   0b00    |		7
 	+-----+-----+-----+-----+-----+-----+-----+-----+
	|        T 60- second Timer = 0b00000000        |		8
	+-----+-----+-----+-----+-----+-----+-----+-----+
	|        N (Maxium Frame Size - 16 bits)        |		9
	|                                               |		10
	+-----+-----+-----+-----+-----+-----+-----+-----+
	|                 NA = 0b0000000                |		11
	+-----+-----+-----+-----+-----+-----+-----+-----+
	|    K = 0b000    |           0b00000           |		12
	+-----+-----+-----+-----+-----+-----+-----+-----+
	+-----+-----+-----+-----+-----+-----+-----+-----+
	|                      FCS                      |		13
	+-----+-----+-----+-----+-----+-----+-----+-----+
*/
    if (is_cmd)
        payload[pos++] = BT_RFCOMM_PN_CMD;                      // Command
    else
        payload[pos++] = BT_RFCOMM_PN_RSP;                      // Response
    payload[pos++] = 1 | (BT_RFCOMM_PNMSG_LEN << 1);            // Length with ea bit set to 1
    payload[pos++] = dlci;                                      // DLCI field

    if (channel->convergency_layer == 0x0F) {
        if (is_cmd) {                                           // type of frames and convergency layer
            payload[pos++] = BT_RFCOMM_FRAME_UIH | (0x0F << 4);
        } else {
            payload[pos++] = BT_RFCOMM_FRAME_UIH | (0x0E << 4);
        }
    } else {
        payload[pos++] = BT_RFCOMM_FRAME_UIH | (0x00 << 4);     // type of frames and convergency layer
    }
    payload[pos++] = BT_RFCOMM_DEF_PRIO;                        // priority (set to default. See bt_rfcomm.h for more information)
    payload[pos++] = 0x00;                                      // actual timeout timer value = 0x00
    payload[pos++] = (u_char) (channel->max_framesize & 0xFF);  // set max. framesize
    payload[pos++] = (u_char) (channel->max_framesize >> 8);
    payload[pos++] = 0x00;                                      // maximum nr. of retransmissions = 0x00!!
    payload[pos++] = BT_RFCOMM_DEF_CREDITS;

    _bt_rfcomm_send_uih(BT_RFCOMM_DLCI_MUX, BT_RFCOMM_PNMSG_LEN + BT_RFCOMM_MSGHDR_LEN);
}

#ifndef BT_RFCOMM_SLIMDOWN
/* 
 * rfcomm_test():
 *
 * send a test command message...
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_send_test(u_char *buffer, u_short len, u_char is_cmd) 
{
    u_char *payload = stack->send_buffer->payload;
    u_char pos;
    u_char idx;

    pos = 3;

    if (is_cmd)
        payload[pos++] = BT_RFCOMM_TEST_CMD;                    // Command
    else
        payload[pos++] = BT_RFCOMM_TEST_RSP;                    // Response
    payload[pos++] = 1 | (len << 1);                            // Length with ea bit set to 1
    
    for (idx = 0; idx < len; idx++)
        payload[pos] = buffer[idx];
    
    _bt_rfcomm_send_uih(BT_RFCOMM_DLCI_MUX, len + BT_RFCOMM_MSGHDR_LEN);
}
/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_fcon()
 *
 * Sends flow control enable flow command using _bt_rfcomm_send_uih
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_send_fcon(u_char is_cmd)
{
    u_char *payload = stack->send_buffer->payload;
    u_char pos;
        
    pos = 3;

    if (is_cmd)
        payload[pos++] = BT_RFCOMM_FCON_CMD;                    // Command
    else
        payload[pos++] = BT_RFCOMM_FCON_RSP;                    // Response
    payload[pos] = 1 | (BT_RFCOMM_FCONMSG_LEN << 1);            // Length with ea bit set to 1
    
    _bt_rfcomm_send_uih(BT_RFCOMM_DLCI_MUX, BT_RFCOMM_FCONMSG_LEN + BT_RFCOMM_MSGHDR_LEN);
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_fcoff()
 *
 * Sends flow control disable flow command using _bt_rfcomm_send_uih
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_send_fcoff(u_char is_cmd)
{
    u_char *payload = stack->send_buffer->payload;
    u_char pos;
    
    pos = 3;

    if (is_cmd)
        payload[pos++] = BT_RFCOMM_FCOFF_CMD;                   // Command
    else                
        payload[pos++] = BT_RFCOMM_FCOFF_RSP;                   // Response
    payload[pos] = 1 | (BT_RFCOMM_FCOFFMSG_LEN << 1);           // Length with ea bit set to 1
    
    _bt_rfcomm_send_uih(0, BT_RFCOMM_FCOFFMSG_LEN + BT_RFCOMM_MSGHDR_LEN);
}
#endif

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_msc(): (may be OK)
 *
 * Prepares a RFCOMM modem status multiplexer commannd or response frame and then sends 
 * it with the _bt_rfcomm_send_uih command.
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_send_msc(u_char dlci, u_char signals, u_char is_cmd)
{
    u_char *payload = stack->send_buffer->payload;
    u_char pos;

    if (stack->channels[dlci] == NULL) {
        ERROR("Channel with DLCI %i is not available...\n", dlci);
        return;
    }
    
    if (stack->channels[dlci]->state == BT_RFCOMM_CH_CLOSED)
    {
        ERROR("Channel with DLCI %i is still closed...\n", dlci);
        return;
    }     
    
    pos = 3;
    
    if (is_cmd)
        payload[pos++] = BT_RFCOMM_MSC_CMD;                     // Command
    else
        payload[pos++] = BT_RFCOMM_MSC_RSP;                     // Response
    payload[pos++] = 1 | (BT_RFCOMM_MSCMSG_LEN << 1);           // Length with ea bit set to 1
    
    
    payload[pos++] = (1 << 0) | (1 << 1) | (dlci << 2);         // DLCI field

    payload[pos] = (1 << 0) | signals;

    _bt_rfcomm_send_uih(BT_RFCOMM_DLCI_MUX, BT_RFCOMM_MSCMSG_LEN + BT_RFCOMM_MSGHDR_LEN);
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_nsc_rsp()
 *
 * Prepares a RFCOMM remote line status multiplexer command or response and then sends 
 * it with the _bt_rfcomm_send_uih command.
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_send_nsc_rsp(u_char type)
{
    u_char *payload = stack->send_buffer->payload;
    u_char pos;

    pos = 3;

    payload[pos++] = BT_RFCOMM_NSC_RSP;                         // Response

    payload[pos++] = 1 | (BT_RFCOMM_NSCMSG_LEN << 1);           // Length with ea bit set to 1
    payload[pos++] = type;

    _bt_rfcomm_send_uih(BT_RFCOMM_DLCI_MUX, BT_RFCOMM_NSCMSG_LEN + BT_RFCOMM_MSGHDR_LEN);
}

#ifndef BT_RFCOMM_SLIMDOWN
/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_rpn()
 *
 * Prepares a RFCOMM remote port negotiation multiplexer frame (command and response) 
 * to set communication settings at the remote end of the data link connection.
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_send_rpn(u_char dlci, u_char baudrate, u_char flags, u_char flow_control, u_char xon, u_char xoff, u_short mask, u_char is_cmd)
{
    u_char *payload = stack->send_buffer->payload;
    struct bt_rfcomm_channel *channel;
    u_char pos;

    // Setting remote settings. TODO: Make this more complete. Allow more parameters to be set.
    channel = stack->channels[dlci];
    if (channel == NULL) {
        ERROR("Channel with DLCI %i is not available...\n", dlci);
        return;
    }
    
    if (channel->state == BT_RFCOMM_CH_CLOSED)
    {
        ERROR("Channel with DLCI %i is still closed...\n", dlci);
        return;
    }  
    
    pos = 3;
    
    if (is_cmd)
        payload[pos++] = BT_RFCOMM_RPN_CMD;                     // Command
    else
        payload[pos++] = BT_RFCOMM_RPN_RSP;                     // Response
    payload[pos++] = 1 | (BT_RFCOMM_RPNMSG_LEN << 1);           // Length with ea bit set to 1
   
    payload[pos++] = (1 << 0) | (1 << 1) | (dlci << 2);         // DLCI field
    payload[pos++] = baudrate;                                  // baudrare settings
    payload[pos++] = flags;                                     // flags
    payload[pos++] = flow_control;                              // flowcontrol 
    payload[pos++] = xon;                                       // xon character
    payload[pos++] = xoff;                                      // xoff character
    payload[pos++] = (u_char)(mask & 0xFF);                     // mask 0
    payload[pos] = (u_char)(mask >> 8);                         // mask 1 

    _bt_rfcomm_send_uih(BT_RFCOMM_DLCI_MUX, BT_RFCOMM_RPNMSG_LEN + BT_RFCOMM_MSGHDR_LEN);
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_rls()
 *
 * Prepares a RFCOMM remote line status multiplexer command or response and then sends 
 * it with the _bt_rfcomm_send_uih command.
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_send_rls(u_char dlci, u_char signals, u_char is_cmd)
{
    u_char *payload = stack->send_buffer->payload;
    u_char pos;
    
    if (stack->channels[dlci] == NULL) {
        ERROR("Channel with DLCI %i is not available...\n", dlci);
        return;
    }
    
    if (stack->channels[dlci]->state == BT_RFCOMM_CH_CLOSED)
    {
        ERROR("Channel with DLCI %i is still closed...\n", dlci);
        return;
    }  
    
    pos = 3;
    if (is_cmd)
        payload[pos++] = BT_RFCOMM_RLS_CMD;                     // Command
    else
        payload[pos++] = BT_RFCOMM_RLS_RSP;                     // Response
    payload[pos++] = 1 | (BT_RFCOMM_RLSMSG_LEN << 1);           // Length with ea bit set to 1

    payload[pos++] = (1 << 0) | (1 << 1) | (dlci << 2);         // DLCI field

    payload[pos] = signals & 0x0F;

    _bt_rfcomm_send_uih(BT_RFCOMM_DLCI_MUX, BT_RFCOMM_RLSMSG_LEN + BT_RFCOMM_MSGHDR_LEN);
}
#endif

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send_credits()
 *
 * Prepares a RFCOMM uih packet that only contains credit information
 * and then sends it with the _bt_rfcomm_send_uih_credits command.
 */
/*-----------------------------------------------------------------------------------*/

u_char bt_rfcomm_send_credits(u_char dlci, u_char credits)
{
    struct bt_rfcomm_channel *channel;
    
    channel = stack->channels[dlci];
    if (channel == NULL) {
        ERROR("bt_rfcomm_send_credits: Channel with DLCI %i is not available...\n", dlci);
        return BT_RFCOMM_ERR_INVALID_CH;
    }
        
    if (channel->state == BT_RFCOMM_CH_CLOSED)
    {
        ERROR("bt_rfcomm_send_credits: Channel with DLCI %i is still closed...\n", dlci);
        return BT_RFCOMM_ERR_INVALID_CH;
    }     

    if ((channel->convergency_layer == 0x0F) && (channel->state == BT_RFCOMM_CH_OPEN) && (dlci != BT_RFCOMM_DLCI_MUX)) {
        return _bt_rfcomm_send_uih_credits(dlci, 0, credits);
    } else {
        return BT_RFCOMM_ERR_SUCCESS;
    }
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_send()
 *
 * Prepares a RFCOMM uih packet and copy user data to the send buffer
 * and then sends it with the _bt_rfcomm_send_uih_credits command.
 */
/*-----------------------------------------------------------------------------------*/
u_char bt_rfcomm_send(u_char dlci, u_char *data, u_short length)
{
    struct bt_rfcomm_channel *channel;
    u_char *payload = stack->send_buffer->payload;
    u_short idx;
    u_short pos;
    
    channel = stack->channels[dlci];
    
    if ((channel == NULL) || (dlci == BT_RFCOMM_DLCI_MUX)) {
        ERROR("bt_rfcomm_send: Channel with DLCI %i is not available...\n", dlci);
        return BT_RFCOMM_ERR_INVALID_CH;
    }
        
    if (channel->state != BT_RFCOMM_CH_OPEN) {
        ERROR("bt_rfcomm_send: Channel with DLCI %i is not open...\n", dlci);
        return BT_RFCOMM_ERR_CON_CLOSED;
    }     
    // ATT: If one would send with uih_pf length may be max: channel->max_framesize-1
    if ((length > channel->max_framesize) || (data == NULL) || (length == 0)) {
        ERROR("bt_rfcomm_send: Datasize %d or pointer invalid...\n", length);
        return BT_RFCOMM_ERR_DATASIZE;
    }
    
    if (channel->convergency_layer == 0x0F) {           // if we use credit based fc check if we
        while (channel->local_credits == 0) {           // have enough local credits. Otherwise wait...
            WARNING("Out of local credits. Now waiting for credits\n");
            NutEventWait(&channel->sig_credits, NUT_WAIT_INFINITE);
        }
    }   

    if (length < 127) {
        pos = 3;
    } else {
        pos = 4;
    }
    
    for (idx = 0; idx < length; idx ++) {
        payload[pos++] = data[idx];
    }
    _bt_rfcomm_send_uih(dlci, length);
    INFO("End of send...\n");
    return BT_RFCOMM_ERR_SUCCESS;
}

/*-----------------------------------------------------------------------------------*/
/* 
 * bt_rfcomm_test()
 *
 * Sends a test command to the connected rfcomm station. 
 */
/*-----------------------------------------------------------------------------------*/
u_char bt_rfcomm_test(u_long timeout)
{
#ifndef BT_RFCOMM_SLIMDOWN
    struct bt_rfcomm_channel *channel;

    channel = stack->channels[BT_RFCOMM_DLCI_MUX];

    if (channel == NULL) {
        ERROR("bt_rfcomm_test: Mulitplexer channel not available.\n");
        return BT_RFCOMM_ERR_NO_RESSOURCE;        
    }

    if (channel->state != BT_RFCOMM_CH_OPEN) {
        ERROR("bt_rfcomm_test: Mulitplexer channel not available\n");
        return BT_RFCOMM_ERR_CON_CLOSED;
    }
    
    _bt_rfcomm_send_test(NULL, 0, BT_RFCOMM_CMD);
    
    if (NutEventWaitNext(&channel->sig_response, timeout) != 0) {
        WARNING("bt_rfcomm_test: Timeout...\n");
        return BT_RFCOMM_ERR_TIMEOUT;
    } else {
        if (channel->response_type != BT_RFCOMM_TEST_RSP) {
            WARNING("bt_rfcomm_test: Test response expected...\n");
        }
    } 

    return BT_RFCOMM_ERR_SUCCESS;
#else
    return BT_RFCOMM_ERR_NO_RESSOURCE;
#endif
}

/*-----------------------------------------------------------------------------------*/
/* 
 * bt_rfcomm_start_session():
 *
 * Start a rfcomm session of no session is yet opened. In this case we are them
 * initiator. Start up multiplexer channel. Blocks until session is open ore timeout.
 */
/*-----------------------------------------------------------------------------------*/

u_char bt_rfcomm_start_session(bt_addr_t bt_addr, u_char page_scan_rep_mode, u_short clock_offset)
{
#ifndef BT_RFCOMM_SLIMDOWN
    u_char retval;
    u_short channel_id = 0x0000;
    struct bt_rfcomm_channel *channel = NULL;
        
    channel = stack->channels[BT_RFCOMM_DLCI_MUX];
    
    if (channel == NULL) {
        ERROR("bt_rfcomm_start_session: Multiplexer channel not available\n");
        return BT_RFCOMM_ERR_INVALID_CH;        
    }
        
    if ((channel->state != BT_RFCOMM_CH_CLOSED) && (channel->state != BT_RFCOMM_CH_LISTEN)) {
        ERROR("bt_rfcomm_start_session: Multiplexer channel just opened? State: %d\n", channel->state);
        return BT_RFCOMM_ERR_SESSION_EXISTS;
    }    
    
    if (stack->l2cap_channel_id == BT_L2CAP_HANDLE_INVALID) {
        retval = bt_l2cap_connect(stack->service_nr, bt_addr, page_scan_rep_mode, clock_offset, BT_L2CAP_PSM_RFCOMM, &channel_id);
        if (retval != BT_L2CAP_ERR_SUCCESS) {
            ERROR("bt_rfcomm_start_session: Error establishing l2cap connection. Err: %d\n", retval);
            return BT_RFCOMM_ERR_OFFS_L2CAP + retval;
        }
        // we now have an opened l2cap connection... Let's proceed...
        // but first wait for an established connection
        while (stack->l2cap_channel_id == BT_L2CAP_HANDLE_INVALID) {
            if (NutEventWait(stack->sig_l2cap_connected, BT_RFCOMM_DEF_TO) != 0)
            {
                ERROR("bt_rfcomm_start_session: Timeout on connection establishment\n");
                return BT_RFCOMM_ERR_TIMEOUT;
            }
        }
    }
    
    if (bt_l2cap_get_outgoing_mtu(stack->l2cap_channel_id, &channel->max_framesize) != BT_L2CAP_ERR_SUCCESS) {
        ERROR("bt_rfcomm_start_session: Get OMTU failed...\n");
        return BT_RFCOMM_ERR_INVALID_CH;
    }
    channel->max_framesize = channel->max_framesize - BT_RFCOMM_HDR_LEN_2 - BT_RFCOMM_FCS_LEN; // omtu - frame header (5 Bytes)
    
    channel->state = BT_RFCOMM_CH_W4_SABM_RSP;
    
    stack->initiator = 1;
    _bt_rfcomm_send_sabm(0);
    
    if (NutEventWait(&channel->sig_response, BT_RFCOMM_DEF_TO) != 0) {
        ERROR("bt_rfcomm_start_session: Timeout on multiplexer channel establishment\n");
        _bt_rfcomm_send_disc(BT_RFCOMM_DLCI_MUX);   // TODO: Is this allowed?
        return BT_RFCOMM_ERR_TIMEOUT;
    } else {
        if (channel->response_type == BT_RFCOMM_DM) {
            ERROR("bt_rfcomm_start_session: Connection refused\n");
            _bt_rfcomm_send_disc(BT_RFCOMM_DLCI_MUX);       // TODO: Is this allowed?
            return BT_RFCOMM_ERR_CON_REFUSED;
        } else 
        if (channel->response_type != BT_RFCOMM_UA) {
            ERROR("bt_rfcomm_start_session: Invalid answer...Connection refused?\n");
            _bt_rfcomm_send_disc(BT_RFCOMM_DLCI_MUX);       // TODO: Is this allowed?
            return BT_RFCOMM_ERR_CON_REFUSED;
        }
        
        channel->state = BT_RFCOMM_CH_OPEN;
        _bt_rfcomm_setup_listening();
        return BT_RFCOMM_ERR_SUCCESS;
    }
#else
    return BT_RFCOMM_ERR_NO_RESSOURCE;
#endif
}

/*-----------------------------------------------------------------------------------*/
/* 
 * bt_rfcomm_connect():
 *
 * Connect to the desired channel. If the mux channel is not open, open it first.
 */
/*-----------------------------------------------------------------------------------*/

u_char bt_rfcomm_connect(u_char channel_nr, BT_RFCOMM_CON_CB, BT_RFCOMM_RCV_CB, 
                         BT_RFCOMM_LINE_CB, BT_RFCOMM_CREDIT_CB, 
                         u_char credit_limit, void* cb_arg)
{
#ifndef BT_RFCOMM_SLIMDOWN
    struct bt_rfcomm_channel *channel = NULL;
    u_char dlci;
    
    dlci = (channel_nr << 1) | (stack->initiator ^ 1);

    if ((channel_nr > stack->max_channel) || (channel_nr == 0)) {
        ERROR("bt_rfcomm_connect: Invalid channel number %d\n", channel_nr);
        return BT_RFCOMM_ERR_INVALID_CH;
    }
    
    if (stack->channels[BT_RFCOMM_DLCI_MUX]->state != BT_RFCOMM_CH_OPEN) {
        ERROR("bt_rfcomm_connect: Multiplexer channel not yet established.\n");
        return BT_RFCOMM_ERR_NO_RESSOURCE;
    }
    
    channel = stack->channels[dlci];
    channel->dlci = dlci;
    channel->con_cb = con_cb;
    channel->rcv_cb = rcv_cb;
    channel->line_cb = line_cb;
    channel->credit_cb = credit_cb;
    channel->credit_limit = credit_limit;
    channel->cb_arg = cb_arg;

    if (channel == NULL) {
        ERROR("bt_rfcomm_connect: Channel %d not available.\n", channel_nr);
        return BT_RFCOMM_ERR_NO_RESSOURCE;        
    }

    if (channel->state != BT_RFCOMM_CH_CLOSED) {
        ERROR("bt_rfcomm_connect: Channel %d is not closed.\n", channel_nr);
        return BT_RFCOMM_ERR_INVALID_CH;
    }
    
    if (bt_l2cap_get_outgoing_mtu(stack->l2cap_channel_id, &channel->max_framesize) != BT_L2CAP_ERR_SUCCESS) {
        ERROR("bt_rfcomm_connect: Get OMTU failed...\n");
        return BT_RFCOMM_ERR_INVALID_CH;
    }
    channel->max_framesize = channel->max_framesize - BT_RFCOMM_HDR_LEN_2 - BT_RFCOMM_FCS_LEN; // omtu - frame header (5 Bytes)

    channel->state = BT_RFCOMM_CH_W4_MULTIPLEXER;
    
    _bt_rfcomm_send_pn(dlci, BT_RFCOMM_CMD);
    
    if (NutEventWait(&channel->sig_response, BT_RFCOMM_DEF_TO) != 0) {
        ERROR("bt_rfcomm_connect: Timeout on parameter negotiation\n");
        _bt_rfcomm_clear_channel(channel);
        return BT_RFCOMM_ERR_TIMEOUT;
    } else {
        if (channel->response_type == BT_RFCOMM_DM) {
            ERROR("bt_rfcomm_connect: Connection refused\n");
            _bt_rfcomm_clear_channel(channel);
            return BT_RFCOMM_ERR_CON_REFUSED;
        } else 
        if (channel->response_type != BT_RFCOMM_PN_RSP) {
            ERROR("bt_rfcomm_connect: Invalid answer...Connection refused?\n");
            _bt_rfcomm_clear_channel(channel);
            return BT_RFCOMM_ERR_CON_REFUSED;
        }
    }

    channel->state = BT_RFCOMM_CH_W4_SABM_RSP;
    _bt_rfcomm_send_sabm(dlci);

    if (NutEventWait(&channel->sig_response, BT_RFCOMM_DEF_TO) != 0) {
        ERROR("bt_rfcomm_connect: Timeout on channel establishment\n");
        _bt_rfcomm_clear_channel(channel);
        return BT_RFCOMM_ERR_TIMEOUT;
    } else {
        if (channel->response_type == BT_RFCOMM_DM) {
            ERROR("bt_rfcomm_connect: Connection refused\n");
            _bt_rfcomm_clear_channel(channel);
            return BT_RFCOMM_ERR_CON_REFUSED;
        } else 
        if (channel->response_type != BT_RFCOMM_UA) {
            ERROR("bt_rfcomm_connect: Invalid answer...Connection refused?\n");
            _bt_rfcomm_clear_channel(channel);
            return BT_RFCOMM_ERR_CON_REFUSED;
        }
        
    }

    channel->state = BT_RFCOMM_CH_CFG;
    _bt_rfcomm_send_msc(dlci, BT_RFCOMM_SIG_DEFAULT, BT_RFCOMM_CMD);

    if (NutEventWait(&channel->sig_connected, BT_RFCOMM_DEF_TO) != 0) {
        ERROR("bt_rfcomm_connect: Timeout. Clearing channel\n");
        _bt_rfcomm_clear_channel(channel);
        return BT_RFCOMM_ERR_TIMEOUT;
    }
    
    return BT_RFCOMM_ERR_SUCCESS;
#else
    return BT_RFCOMM_ERR_NO_RESSOURCE;
#endif
}

/*-----------------------------------------------------------------------------------*/
/* 
 * bt_rfcomm_disconnect():
 *
 * Sends a RFCOMM disconnect frame to close the channel.
 */
/*-----------------------------------------------------------------------------------*/
u_char bt_rfcomm_disconnect(u_char dlci)
{
    struct bt_rfcomm_channel *channel = NULL;
    u_char clean_up = 0;
    u_char idx;
    u_char open_count;
    
    
    if (dlci > stack->max_dlci) {
        ERROR("bt_rfcomm_disconnect: Invalid dlci %d\n", dlci);
        return BT_RFCOMM_ERR_INVALID_CH;
    }
    
    if (dlci == 0)
        clean_up = 1;
    
    channel = stack->channels[dlci];

    if (channel == NULL) {
        ERROR("bt_rfcomm_disconnect: Channel with dlci %d not available.\n", dlci);
        return BT_RFCOMM_ERR_INVALID_CH;        
    }
        
    if ((channel->state == BT_RFCOMM_CH_CLOSED) || (channel->state == BT_RFCOMM_CH_LISTEN)) {
        ERROR("bt_rfcomm_disconnect: Channel with dlci %d is not opened. State: %02x\n", 
                dlci, channel->state);
        return BT_RFCOMM_ERR_CON_CLOSED;
    }

    open_count = 0;
    for (idx = 1; idx <= stack->max_dlci; idx++) {
        if (stack->channels[idx] != NULL) {
            if ((stack->channels[idx]->state != BT_RFCOMM_CH_CLOSED) && 
                (stack->channels[idx]->state != BT_RFCOMM_CH_LISTEN)) open_count++;
        }
    }
    
    if (open_count == 1) clean_up = 1;
        
    if (clean_up) {
        INFO("Closing down connection. Cleaning up channels...\n");
        for (idx = 1; idx <= stack->max_dlci; idx++) {
            channel = stack->channels[idx];
            if (channel != NULL) {
                if ((channel->state != BT_RFCOMM_CH_CLOSED) && 
                    (channel->state != BT_RFCOMM_CH_LISTEN)) {
                    INFO("Closing dlci %d\n", idx);
                    channel->state = BT_RFCOMM_CH_W4_DISC_RSP;
                    _bt_rfcomm_send_disc(idx);
                    if (NutEventWait(&channel->sig_response, BT_RFCOMM_DEF_TO) != 0) {
                        WARNING("bt_rfcomm_disconnect: Timeout on dlci %d. Clearing channel\n", idx);
                    }
                    _bt_rfcomm_clear_channel(channel);
                }
            }
        }
        
        channel = stack->channels[BT_RFCOMM_DLCI_MUX];
        channel->state = BT_RFCOMM_CH_W4_DISC_RSP;
        _bt_rfcomm_send_disc(BT_RFCOMM_DLCI_MUX);
        stack->initiator = 0;
        
        if (channel != NULL)
            _bt_rfcomm_clear_channel(channel);
        
        bt_l2cap_disconnect(stack->l2cap_channel_id);
    } else {
        channel->state = BT_RFCOMM_CH_W4_DISC_RSP;
        _bt_rfcomm_send_disc(dlci);
        if (NutEventWait(&channel->sig_response, BT_RFCOMM_DEF_TO) != 0) {
            WARNING("bt_rfcomm_disconnect: Timeout on dlci %d. Clearing channel\n", dlci);
        }
        _bt_rfcomm_clear_channel(channel);        
    }
    return BT_RFCOMM_ERR_SUCCESS;
}

/*-----------------------------------------------------------------------------------*/
/* 
 * bt_rfcomm_listen():
 *
 * Listen on the specific channel for an incomming connection 
 */
/*-----------------------------------------------------------------------------------*/

u_char bt_rfcomm_listen(u_char channel_nr, BT_RFCOMM_CON_CB, BT_RFCOMM_RCV_CB, 
                        BT_RFCOMM_LINE_CB, BT_RFCOMM_CREDIT_CB, 
                        u_char credit_limit, void* cb_arg, u_long timeout)
{        
    struct bt_rfcomm_channel *channel = NULL;
    struct bt_rfcomm_listen  *listen = NULL;
    u_char dlci;

    if ((channel_nr > stack->max_channel) || (channel_nr == 0)) {
        ERROR("bt_rfcomm_listen: Invalid channel number %d\n", channel_nr);
        return BT_RFCOMM_ERR_INVALID_CH;
    }
    
    listen = stack->listening[channel_nr];

    if (listen == NULL) {
        ERROR("bt_rfcomm_listen: Channel %d not available.\n", channel_nr);
        return BT_RFCOMM_ERR_NO_RESSOURCE;        
    }
        
    if (listen->channel_nr != BT_RFCOMM_CHNR_INVALID) {
        ERROR("bt_rfcomm_listen: Channel %d just listening.\n", channel_nr);
        return BT_RFCOMM_ERR_NO_RESSOURCE;        
    }
    
    listen->channel_nr = channel_nr;
    listen->rcv_cb = rcv_cb;
    listen->con_cb = con_cb;
    listen->cb_arg = cb_arg;
    listen->line_cb = line_cb;
    listen->credit_cb = credit_cb;
    listen->credit_limit = credit_limit;
    listen->sig_connected = NULL;
    INFO("Listening on channel %d\n", channel_nr);
    if (stack->channels[BT_RFCOMM_DLCI_MUX]->state != BT_RFCOMM_CH_LISTEN) {    
    // The Mux channel is not closed anymore. So we know who opened the connection
        dlci = (channel_nr << 1) | stack->initiator;
        channel = stack->channels[dlci];
            
        if (channel->state != BT_RFCOMM_CH_CLOSED) {
            ERROR("bt_rfcomm_listen: Channel %d with dlci %d is not closed. State: %02x\n", 
                    channel_nr, dlci, channel->state);
            memset(listen, 0, sizeof(struct bt_rfcomm_listen));
            listen->channel_nr = BT_RFCOMM_CHNR_INVALID;            
            return BT_RFCOMM_ERR_INVALID_CH;
        }
        
        channel->state = BT_RFCOMM_CH_LISTEN;
        channel->dlci  = dlci;
        channel->rcv_cb    = listen->rcv_cb;
        channel->con_cb    = listen->con_cb;
        channel->cb_arg    = listen->cb_arg;
        channel->line_cb   = listen->line_cb;
        channel->credit_cb = listen->credit_cb;
        channel->credit_limit = listen->credit_limit;
        channel->listen    = listen;
    }    
    
    if (timeout != BT_RFCOMM_NO_TIMEOUT)
    {
        if (NutEventWait(&listen->sig_connected, timeout) != 0) {
            memset(listen, 0, sizeof(struct bt_rfcomm_listen));
            listen->channel_nr = BT_RFCOMM_CHNR_INVALID;
            WARNING("bt_rfcomm_listen: Timeout. Clearing channel\n");
            return BT_RFCOMM_ERR_TIMEOUT;
        } else {
            memset(listen, 0, sizeof(struct bt_rfcomm_listen));
            listen->channel_nr = BT_RFCOMM_CHNR_INVALID;
            return BT_RFCOMM_ERR_SUCCESS;
        }
    } else {
        return BT_RFCOMM_ERR_SUCCESS;
    }
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_process_mux_cmd():
 *
 * Handle multiplexer status commands. Never call _bt_rfcomm_complete_buffer.
 * The buffer is completed by handle pkt.
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_process_mux_cmd(struct bt_rfcomm_l2cap_pkt_buf_entry *buffer, u_char header_len)
{
/*	RFCOMM packet
	+---------+---------+---------+--------...------+---------+
	| address | control | length  |   information   |   FCS   |
	+---------+---------+---------+--------...------+---------+

	MULTIPLEXER CONTROL (in the information field)
	+---------+---------+---------+--...---+---------+
	|  type   | length  | value1  |        | value n |
	+---------+---------+---------+--...---+---------+
*/ 
    struct bt_rfcomm_channel *channel = NULL;
    struct bt_rfcomm_channel *chmux   = 0;
    u_char type;
    u_char dlci;
    u_short frame_size;
    u_char length;
    u_char pos;
    u_char signals;
#ifndef BT_RFCOMM_SLIMDOWN
    u_char idx;
#endif
    
    chmux = stack->channels[BT_RFCOMM_DLCI_MUX];
    
    pos  = header_len;
    type = buffer->pkt->payload[pos++];
    length = buffer->pkt->payload[pos++];

    switch (type) {
    case BT_RFCOMM_PN_CMD:
        INFO("_bt_rfcomm_process_mux_cmd: PN command\n");
        dlci = buffer->pkt->payload[pos++];
        // Check if the DLC is already established 
        channel = stack->channels[dlci];
        if (channel == NULL) {                          
            ERROR("bt_rfcomm_mux_cmd: PN cmd: Channel with dlci %d not available. Refuse connection.\n", dlci);
            _bt_rfcomm_send_dm(dlci);                   
            break;
        } else {
            if (channel->state == BT_RFCOMM_CH_CLOSED) {// There is no channel listening or connected by us...
                _bt_rfcomm_send_dm(dlci);
                break;
            } else
            if (channel->state == BT_RFCOMM_CH_LISTEN) {// Is this a listening channel??
                if (bt_l2cap_get_outgoing_mtu(stack->l2cap_channel_id, &channel->max_framesize) != BT_L2CAP_ERR_SUCCESS) {
                    ERROR("bt_rfcomm_mux_cmd: Get OMTU failed...\n");
                }
                channel->max_framesize = channel->max_framesize - BT_RFCOMM_HDR_LEN_2 - BT_RFCOMM_FCS_LEN; // omtu - frame header (5 Bytes)
                channel->state = BT_RFCOMM_CH_CFG;      // Set this channel into configure mode
            }                                           // else: This channel is just active or opened.
        }
        // Get suggested parameters 
        channel->convergency_layer = buffer->pkt->payload[pos++] >> 4;
        channel->priority = buffer->pkt->payload[pos++];

        pos++;                                          // skip the timeout field
        frame_size = (buffer->pkt->payload[pos]) | (buffer->pkt->payload[pos+1] << 8);
        pos +=2;

        if (frame_size > channel->max_framesize) {
            channel->max_framesize = frame_size;
        }
        
        pos++;                                          // skip number of retransmissions
        channel->local_credits = buffer->pkt->payload[pos];
        channel->remote_credits = BT_RFCOMM_DEF_CREDITS;
        _bt_rfcomm_send_pn(dlci, BT_RFCOMM_RSP);
        break;        
#ifndef BT_RFCOMM_SLIMDOWN
    case BT_RFCOMM_PN_RSP:
        INFO("_bt_rfcomm_process_mux_cmd: PN response\n");
        dlci = buffer->pkt->payload[pos++];
        
        channel = stack->channels[dlci];

        if (channel == NULL) {                          
            ERROR("bt_rfcomm_mux_cmd: PN rsp: Channel with dlci %d not available. .\n", dlci);
            // silently discard packet...
            break;
        }

        // Use negotiated settings that may have changed from the default ones 
        channel->convergency_layer = buffer->pkt->payload[pos++] >> 4;
        if (channel->convergency_layer == 0x0E)
            channel->convergency_layer = 0x0F;
        channel->priority = buffer->pkt->payload[pos++];
        pos++;                                          // skip the timeout field
        frame_size = (buffer->pkt->payload[pos]) | (buffer->pkt->payload[pos+1] << 8);
        pos += 2;
        pos++;                                          // skip number of retransmissions

        if (channel->convergency_layer == 0x0F) {
            channel->local_credits = buffer->pkt->payload[pos];
        } else {
            // we don't use any flow-control
            channel->local_credits = BT_RFCOMM_DEF_CREDITS;
        }

        if (frame_size > channel->max_framesize) {
            channel->max_framesize = frame_size;
        }
        
        channel->response_type = BT_RFCOMM_PN_RSP;
        NutEventPostAsync(&channel->sig_response);
        break;
    case BT_RFCOMM_TEST_CMD:
        INFO("_bt_rfcomm_process_mux_cmd: TEST command\n");
        _bt_rfcomm_send_test(&buffer->pkt->payload[pos], length, BT_RFCOMM_RSP);
        break;
    case BT_RFCOMM_TEST_RSP:
        INFO("_bt_rfcomm_process_mux_cmd: TEST response\n");
        chmux->response_type = BT_RFCOMM_TEST_RSP;
        NutEventPostAsync(&chmux->sig_response);
        break;
    case BT_RFCOMM_FCON_CMD:
        INFO("_bt_rfcomm_process_mux_cmd: FCON command\n");
        // Enable transmission of data on all channels in session except channel 0
        for (idx = 1; idx <= stack->max_dlci; idx++)
        {
            channel = stack->channels[idx];
            if (channel != NULL)
                channel->config |= BT_RFCOMM_CFG_FC;
        }
        
        _bt_rfcomm_send_fcon(BT_RFCOMM_RSP);
        break;
    case BT_RFCOMM_FCON_RSP:
        INFO("_bt_rfcomm_process_mux_cmd: FCON response\n");
            
        chmux->response_type = BT_RFCOMM_FCON_RSP;
        NutEventPostAsync(&chmux->sig_response);
        break;
    case BT_RFCOMM_FCOFF_CMD:
        INFO("_bt_rfcomm_process_mux_cmd: FCOFF command\n");
        // Disable transmission of data on all channels in session except channel 0
        for (idx = 1; idx <= stack->max_dlci; idx++)
        {
            channel = stack->channels[idx];
            if (channel != NULL)
                channel->config &= ~BT_RFCOMM_CFG_FC;
        }
        
        _bt_rfcomm_send_fcoff(BT_RFCOMM_RSP);
        break;
    case BT_RFCOMM_FCOFF_RSP:
        INFO("_bt_rfcomm_process_mux_cmd: FCOFF response\n");
        
        chmux->response_type = BT_RFCOMM_FCOFF_RSP;
        NutEventPostAsync(&chmux->sig_response);
        break;
#endif
    case BT_RFCOMM_MSC_CMD:
        INFO("_bt_rfcomm_process_mux_cmd: MSC command\n");
        dlci = buffer->pkt->payload[pos++] >> 2;
    
        channel = stack->channels[dlci];
    
        if (channel == NULL) {                          
            ERROR("bt_rfcomm_mux_cmd: MSC cmd: Channel with dlci %d not available. Refuse connection.\n", dlci);
            _bt_rfcomm_send_dm(dlci); 
            break;
        } else {
            if ((channel->state == BT_RFCOMM_CH_CLOSED) || (channel->state == BT_RFCOMM_CH_LISTEN)) {// There is no channel listening or connected by us...
                _bt_rfcomm_send_dm(dlci);
                break;
            }
        }    
        signals = buffer->pkt->payload[pos];
        if (signals & BT_RFCOMM_SIG_FC) {
            channel->config |= BT_RFCOMM_CFG_FC;
        } else {
            channel->config &= ~BT_RFCOMM_CFG_FC;
        }
        
        if (!BT_RFCOMM_CH_IS_ACTIVE(dlci) && !(channel->config & BT_RFCOMM_CFG_MSC_IN)) {
            // We did not send our own mux cmd so we should do this before sending a response
            _bt_rfcomm_send_msc(dlci, BT_RFCOMM_SIG_DEFAULT, BT_RFCOMM_CMD);
        }

        channel->config |= BT_RFCOMM_CFG_MSC_OUT;
        _bt_rfcomm_send_msc(dlci, signals, BT_RFCOMM_RSP);
                
        if ((channel->config & BT_RFCOMM_CFG_MSC_IN) && (channel->state != BT_RFCOMM_CH_OPEN)) {
            channel->state = BT_RFCOMM_CH_OPEN;
            if ((channel->listen != NULL) && (channel->listen->channel_nr != BT_RFCOMM_CHNR_INVALID)) {
                NutEventPostAsync(&channel->listen->sig_connected);
            } else {
                NutEventPostAsync(&channel->sig_connected);
            }
            
            if (channel->con_cb != NULL)
                channel->con_cb(dlci, BT_RFCOMM_CONNECT, channel->cb_arg);
        }
        break;
    case BT_RFCOMM_MSC_RSP:
        INFO("_bt_rfcomm_process_mux_cmd: MSC response\n");
        dlci = buffer->pkt->payload[pos++] >> 2;

        channel = stack->channels[dlci];
    
        if (channel == NULL) {                          
            ERROR("bt_rfcomm_mux_cmd: MSC rsp: Channel with dlci %d not available.\n", dlci);
            // silently discard packet
            break;
        }

        channel->config |= BT_RFCOMM_CFG_MSC_IN;
        if ((channel->config & BT_RFCOMM_CFG_MSC_OUT) && (channel->state != BT_RFCOMM_CH_OPEN)) {
            channel->state = BT_RFCOMM_CH_OPEN;
            if ((channel->listen != NULL) && (channel->listen->channel_nr != BT_RFCOMM_CHNR_INVALID)) {
                NutEventPostAsync(&channel->listen->sig_connected);
            } else {
                NutEventPostAsync(&channel->sig_connected);
            }
            
            if (channel->con_cb != NULL)
                channel->con_cb(dlci, BT_RFCOMM_CONNECT, channel->cb_arg);
        }
        break;
    case BT_RFCOMM_NSC_RSP:
        WARNING("_bt_rfcomm_process_mux_cmd: NSC response to cmd: %02x\n", buffer->pkt->payload[pos]);
        chmux->response_type = BT_RFCOMM_NSC_RSP;
        NutEventPostAsync(&chmux->sig_response);
        break;        
#ifndef BT_RFCOMM_SLIMDOWN
    case BT_RFCOMM_RPN_CMD:        
        INFO("_bt_rfcomm_process_mux_cmd: RPN command\n");
        dlci = buffer->pkt->payload[pos++];

        channel = stack->channels[dlci];
    
        if (channel == NULL) {                          
            ERROR("bt_rfcomm_mux_cmd: RPN cmd: Channel with dlci %d not available. Refuse connection.\n", dlci);
            _bt_rfcomm_send_dm(dlci);
            break;
        }
    
        if (length == 8) {                              // Send a RPN response 
            // RPN command was a request to set up the link's parameters 
            // All parameters accepted since this is a type 1 device 
            _bt_rfcomm_send_rpn(dlci, 
                                buffer->pkt->payload[pos], // baudrate
                                buffer->pkt->payload[pos+1], // flags
                                buffer->pkt->payload[pos+2], // flow_control,
                                buffer->pkt->payload[pos+3], // xon
                                buffer->pkt->payload[pos+4], // xoff
                                buffer->pkt->payload[pos+5] | (buffer->pkt->payload[pos+6] << 8), BT_RFCOMM_RPN_RSP);
        } else {
            // RPN command was a request for the link parameters.
            _bt_rfcomm_send_rpn(dlci, 
                                BT_RFCOMM_COM_BR_DEF,        // baudrate
                                BT_RFCOMM_COM_CFG_DEF,       // flags
                                BT_RFCOMM_COM_FC_DEF,        // flow_control
                                BT_RFCOMM_COM_XON_DEF,       // xon
                                BT_RFCOMM_COM_XOFF_DEF,      // xoff
                                0xFFFF, BT_RFCOMM_RPN_RSP);
        }
        break;
    case BT_RFCOMM_RPN_RSP:
        INFO("_bt_rfcomm_process_mux_cmd: RPN response\n");
        
        chmux->response_type = BT_RFCOMM_RPN_RSP;
        NutEventPostAsync(&chmux->sig_response);
        break;
    case BT_RFCOMM_RLS_CMD:
        INFO("_bt_rfcomm_process_mux_cmd: RLS command\n");
        dlci = buffer->pkt->payload[pos++];
    
        channel = stack->channels[dlci];
    
        if (channel == NULL) {                          
            ERROR("bt_rfcomm_mux_cmd: RLS cmd: Channel with dlci %d not available. Refuse connection.\n", dlci);
            _bt_rfcomm_send_dm(dlci);
            break;
        }    
    
        _bt_rfcomm_send_rls(dlci, buffer->pkt->payload[pos], BT_RFCOMM_RSP);
        break;
    case BT_RFCOMM_RLS_RSP:
        INFO("_bt_rfcomm_process_mux_cmd: RLS response\n");
        chmux->response_type = BT_RFCOMM_RLS_RSP;
        NutEventPostAsync(&chmux->sig_response);
        break;
#endif
    default:
        WARNING("_bt_rfcomm_process_mux_cmd: Unsupported cmd %02x\n", type);
        _bt_rfcomm_send_nsc_rsp(type);
        break;
    }
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_recv_data():
 *
 * Handle incomming user data
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_recv_data(struct bt_rfcomm_channel *channel, struct bt_rfcomm_l2cap_pkt_buf_entry *buffer, u_char header_len, u_short len)
{    
    INFO("_bt_rfcomm_recv_data: dlci: %d, len: %d, header_len: %d\n", channel->dlci, len, header_len);
    
    
    if ((len > 0) && (channel->dlci != 0) && (channel->rcv_cb != NULL))
    {
        channel->rcv_cb(channel->dlci, &buffer->pkt->payload[header_len], len, channel->cb_arg);
    }
    
    _bt_rfcomm_complete_buffer(buffer);
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_handle_pkt():
 *
 * Handle incomming rfcomm frames
 */
/*-----------------------------------------------------------------------------------*/
static void _bt_rfcomm_handle_pkt(struct bt_rfcomm_l2cap_pkt_buf_entry *buffer)
{
    struct bt_rfcomm_channel *channel;

    u_short length = 0;
    u_char header_len;
    u_char addr;
    u_char ctrl;
    u_char dlci;                        
    u_char fcs;
    u_char credits = 0x00;

    addr = buffer->pkt->payload[0];          // address field, RFCOMM PACKET FORMAT
    ctrl = buffer->pkt->payload[1];          // control field, RFCOMM PACKET FORMAT

/* Address field
     EA    C/R    D         Server Channel 
   +-----+-----+-----+-----+-----+-----+-----+-----+
   |  1  |     |     |                             |
   +-----+-----+-----+-----+-----+-----+-----+-----+
      1     2     3     4                       8     bits 
	EA: Extend Address, always be 1
	C/R: Command/Response, whether the frame is a command or a response
	D: Data Link Connection Idetifier, Initiator(D=1) Responder(D=0)
	Channel: 5 bits, 0-31, 0 and 31 are reserved by TS 07.10
*/
    
    
    dlci = BT_RFCOMM_GET_DLCI(addr);
    channel = NULL;
    // on rfcomm startup ch 0 is closed an in listen mode. So we won't find it
    // in our active struct.

    if (dlci <= stack->max_dlci) {
        channel = stack->channels[dlci];
    }

    if (channel == NULL) {                          
        ERROR("bt_rfcomm_handle_pkt: Channel with dlci %d not available.\n", dlci);
        _bt_rfcomm_send_dm(dlci);                   
        _bt_rfcomm_complete_buffer(buffer);
        return;
    }    

    
    if (BT_RFCOMM_CH_IS_ACTIVE(dlci)) {
        if (channel->state == BT_RFCOMM_CH_CLOSED) {
            WARNING("_bt_rfcomm_handle_pkt: Channel not active now. Send a DM response to DLCI %d ctrl == 0x%02x\n", dlci, ctrl);
            _bt_rfcomm_send_dm(dlci);
            _bt_rfcomm_complete_buffer(buffer);
            return;
        }
    } else {
        if (((channel->state == BT_RFCOMM_CH_LISTEN) || (channel->state == BT_RFCOMM_CH_CFG)) && (ctrl != BT_RFCOMM_SABM)) {
            WARNING("_bt_rfcomm_handle_pkt: Channel not listening. Send a DM response to DLCI %d ctrl == 0x%02x, state = %02x\n", dlci, ctrl, channel->state);
            _bt_rfcomm_send_dm(dlci);
            _bt_rfcomm_complete_buffer(buffer);
            return;
        }
    }
    
    // Any other command than SABM won't reach that point if the channel is not active
    
/* Check if length field is 1 or 2 bytes long and remove EA bit 

     E/A                 
   +-----+-----+-----+-----+-----+-----+-----+-----+
   |  1  |               length (7 bit)            |
   +-----+-----+-----+-----+-----+-----+-----+-----+
      1     2                                   8     bits        
   or
     E/A
   +-----+-----+-----+-----+-----+-----+-----+-----+--- ... ---+
   |  0  |               length (7+8=15 bit)       |           |
   +-----+-----+-----+-----+-----+-----+-----+-----+--- ... ---+
      1     2                                   8    9       16  bits
*/
    if ((buffer->pkt->payload[2] & 0x01) == 1) {
        header_len = BT_RFCOMM_HDR_LEN_1;
        length = (buffer->pkt->payload[2] >> 1) & 0x007F;
    } else {
        header_len = BT_RFCOMM_HDR_LEN_2;
        length = (buffer->pkt->payload[2] >> 1) | ((buffer->pkt->payload[3] << 7) & 0x7FFF);
    }

    if (ctrl == BT_RFCOMM_UIH_PF) {        
        if ((dlci != BT_RFCOMM_DLCI_MUX) && (channel->convergency_layer == 0x0F)) {
            credits = buffer->pkt->payload[header_len++];               // credits field
        }
    }

    fcs = buffer->pkt->payload[length + header_len];    // Get the fcs field

    if (ctrl == BT_RFCOMM_UIH) {                        // UIH, Unnumbered Information with Header Check, P/F = 0
        if (fcs != channel->uih_in_fcs) {
            ERROR("UIH packet discarded due to failing frame check sequence\n");
            _bt_rfcomm_complete_buffer(buffer);
            return;
        }
    } else if (ctrl == BT_RFCOMM_UIH_PF) {
        if (fcs != channel->uihpf_in_fcs) {             // Check against the precalculated fcs
            ERROR("UIH_PF packet discarded due to failing frame check sequence\n");
            _bt_rfcomm_complete_buffer(buffer);
            return;
        }
    } else {
        if (crc8_check(buffer->pkt->payload, header_len, fcs) != 0) {
            ERROR("Packet discarded due to failing frame check sequence\n");
            _bt_rfcomm_complete_buffer(buffer);
            return;
        }
    }

    switch (ctrl) {
        
    // We can get an SABM command on an inactive (listening) channel 0. We need to make it active.
    case BT_RFCOMM_SABM:
        INFO("_bt_rfcomm_handle_pkt: RFCOMM_SABM\n");

        if (dlci == BT_RFCOMM_DLCI_MUX) {               // this is the control channel
            channel->state = BT_RFCOMM_CH_OPEN; 
            if (bt_l2cap_get_outgoing_mtu(stack->l2cap_channel_id, &channel->max_framesize) != BT_L2CAP_ERR_SUCCESS) {
                ERROR("_bt_rfcomm_handle_pkt: Get OMTU failed...\n");
            }
            channel->max_framesize = channel->max_framesize - BT_RFCOMM_HDR_LEN_2 - BT_RFCOMM_FCS_LEN; // omtu - frame header (5 Bytes)
            stack->initiator = 0;
            _bt_rfcomm_setup_listening();
            _bt_rfcomm_send_ua(dlci);
            _bt_rfcomm_complete_buffer(buffer);
            break;
        } 
        if ((channel->state != BT_RFCOMM_CH_LISTEN) && (channel->state != BT_RFCOMM_CH_CFG)) {
            if (channel->state == BT_RFCOMM_CH_OPEN) {  // channel just exists
                channel->state = BT_RFCOMM_CH_CONNECTED;
                _bt_rfcomm_send_ua(dlci);
                _bt_rfcomm_complete_buffer(buffer);
                break;
            }
        }
        
        // At this point we have found a channel that we could use.

        channel->dlci = dlci;
        channel->state = BT_RFCOMM_CH_CONNECTED;
        
        // Send UA frame as response to SABM frame 
        _bt_rfcomm_send_ua(dlci);

        // now do some strange things :-) We change some bytes in our header and precalculate 
        // the fcs for different UIH frames...

        // We change the header values to reflect an UIH frame send to the initiator
        buffer->pkt->payload[0] = (1 << 0) | (stack->initiator << 1) | (dlci << 2);
        buffer->pkt->payload[1] = BT_RFCOMM_UIH;
        channel->uih_out_fcs = crc8_calc(buffer->pkt->payload, BT_RFCOMM_UIHCRC_CHECK_LEN);
        buffer->pkt->payload[1] = BT_RFCOMM_UIH_PF;
        channel->uihpf_out_fcs = crc8_calc(buffer->pkt->payload, BT_RFCOMM_UIHCRC_CHECK_LEN);


        // Change the header values to reflect an UIH frame received from the initiator
        buffer->pkt->payload[0] = (1 << 0) | ((stack->initiator ^ 1) << 1) | (dlci << 2);
        buffer->pkt->payload[1] = BT_RFCOMM_UIH;
        channel->uih_in_fcs = crc8_calc(buffer->pkt->payload, BT_RFCOMM_UIHCRC_CHECK_LEN);
        buffer->pkt->payload[1] = BT_RFCOMM_UIH_PF;
        channel->uihpf_in_fcs = crc8_calc(buffer->pkt->payload, BT_RFCOMM_UIHCRC_CHECK_LEN);
        _bt_rfcomm_complete_buffer(buffer);
        break;
#ifndef BT_RFCOMM_SLIMDOWN
    case BT_RFCOMM_UA:                    
        // We got an UA answer to our SABM request. Remote channel is now open.
        INFO("_bt_rfcomm_handle_pkt: RFCOMM_UA\n");

        if (channel->state == BT_RFCOMM_CH_W4_SABM_RSP) {
            if (dlci != BT_RFCOMM_DLCI_MUX) {
                channel->state = BT_RFCOMM_CH_CFG;
            } else {
                channel->state = BT_RFCOMM_CH_W4_MULTIPLEXER;
            }
            
            channel->dlci = dlci;
            
            // FCS precalculation for UIH frames
            // Change the header values to reflect an UIH frame received from the initiator
            buffer->pkt->payload[0] = (1 << 0) | (stack->initiator << 1) | (dlci << 2);
            buffer->pkt->payload[1] = BT_RFCOMM_UIH;
            channel->uih_out_fcs = crc8_calc(buffer->pkt->payload, BT_RFCOMM_UIHCRC_CHECK_LEN);
            buffer->pkt->payload[1] = BT_RFCOMM_UIH_PF;
            channel->uihpf_out_fcs = crc8_calc(buffer->pkt->payload, BT_RFCOMM_UIHCRC_CHECK_LEN);

            // We change the header values to reflect an UIH frame send to the initiator
            buffer->pkt->payload[0] = (1 << 0) | ((stack->initiator ^ 1) << 1) | (dlci << 2);
            buffer->pkt->payload[1] = BT_RFCOMM_UIH;
            channel->uih_in_fcs = crc8_calc(buffer->pkt->payload, BT_RFCOMM_UIHCRC_CHECK_LEN);
            buffer->pkt->payload[1] = BT_RFCOMM_UIH_PF;
            channel->uihpf_in_fcs = crc8_calc(buffer->pkt->payload, BT_RFCOMM_UIHCRC_CHECK_LEN);
            channel->response_type = BT_RFCOMM_UA;
            NutEventPostAsync(&channel->sig_response);
        } else if (channel->state == BT_RFCOMM_CH_W4_DISC_RSP) {
            channel->state = BT_RFCOMM_CH_CLOSED;
            channel->response_type = BT_RFCOMM_UA;
            NutEventPostAsync(&channel->sig_response);
            if (channel->con_cb != NULL)
                channel->con_cb(dlci, BT_RFCOMM_DISCONNECT, channel->cb_arg);
            // We don't clear the channel here and don't remove it from the active list
            // This needs to be done in the disconnect routine.
        } else {
            // A response without an outstanding request is silently discarded 
        }
        _bt_rfcomm_complete_buffer(buffer);
        break;
    case BT_RFCOMM_DM_PF:                               // We got a DM. Signal the upper layer.
    case BT_RFCOMM_DM:
        INFO("_bt_rfcomm_handle_pkt: RFCOMM_DM\n");
    
        channel->state = BT_RFCOMM_CH_CLOSED;
        channel->response_type = BT_RFCOMM_DM;
        NutEventPostAsync(&channel->sig_response);
        _bt_rfcomm_complete_buffer(buffer);
        // We don't call the disconnect callback since the channel was not open yet
        // We don't clear the channel here and don't remove it from the active list
        // This needs to be done in the connect routine.
        break;
#endif
    case BT_RFCOMM_DISC:
        INFO("_bt_rfcomm_handle_pkt: RFCOMM_DISC\n");
        _bt_rfcomm_send_ua(dlci);                   // send ua_message as response to DISC command
        channel->state = BT_RFCOMM_CH_CLOSED;
        if (channel->con_cb != NULL)
            channel->con_cb(dlci, BT_RFCOMM_DISCONNECT, channel->cb_arg);
        _bt_rfcomm_clear_channel(channel);
        _bt_rfcomm_complete_buffer(buffer);
        break;                                  
    case BT_RFCOMM_UIH_PF:                              
        INFO("_bt_rfcomm_handle_pkt: RFCOMM_UIH_PF\n");
        if (dlci == BT_RFCOMM_DLCI_MUX) {
            _bt_rfcomm_process_mux_cmd(buffer, header_len);
            _bt_rfcomm_complete_buffer(buffer);
        } else 
        if (channel->convergency_layer == 0x0F) {
            INFO("RFCOMM_UIH_PF: We got %d credits\n", credits);
            if (channel->remote_credits != 0x00) {
                channel->remote_credits --;
                if (channel->remote_credits <= channel->credit_limit) {
                    if (channel->credit_cb != NULL) {
                        channel->credit_cb(dlci, channel->remote_credits, channel->cb_arg);
                    }
                } 
            }

            if (channel->local_credits + credits < 0xFF) {
                channel->local_credits += credits;
            } else {
                channel->local_credits = 0xFF;
            }
            
            _bt_rfcomm_recv_data(channel, buffer, header_len, length);
            NutEventPostAsync(&channel->sig_credits);
        } else {
            _bt_rfcomm_recv_data(channel, buffer, header_len, length);
        }
        break;
    case BT_RFCOMM_UIH:                         
        INFO("_bt_rfcomm_handle_pkt: RFCOMM_UIH\n");
        if (dlci == BT_RFCOMM_DLCI_MUX) {
            _bt_rfcomm_process_mux_cmd(buffer, header_len);
            _bt_rfcomm_complete_buffer(buffer);
        } else {
            if (channel->convergency_layer == 0x0F) {
                if (channel->remote_credits != 0x00) {
                    channel->remote_credits --;
                    if (channel->remote_credits <= channel->credit_limit) {
                        if (channel->credit_cb != NULL) {
                            channel->credit_cb(dlci, channel->remote_credits, channel->cb_arg);
                        }
                    } 
                }
            }
            _bt_rfcomm_recv_data(channel, buffer, header_len, length);
        }
        break;
    default:
        // Unknown or illegal frame type. Throw it away!
        WARNING("_bt_rfcomm_handle_pkt: Unsupported frame type %02x\n", ctrl);
        _bt_rfcomm_complete_buffer(buffer);
        break;
    }
    return;
}

/*-----------------------------------------------------------------------------------*/
/* 
 * THREAD(BT_RFCOMM, arg):
 *
 * This is the main rfcomm thread
 */
/*-----------------------------------------------------------------------------------*/

THREAD(BT_RFCOMM, arg) {
    u_short l2cap_sequence_nr = 0x0000;
    u_char idx;
    struct bt_rfcomm_l2cap_pkt_buf_entry *buffer;
    struct bt_rfcomm_channel *channel;
    u_char tmp_fcs_buf[BT_RFCOMM_UIHCRC_CHECK_LEN];

    for (;;) {
        NutEventWait(&stack->sig_l2cap_data_avail, NUT_WAIT_INFINITE);
        
        buffer = stack->buffer;
        for (idx = 0; idx < stack->buffer_size; idx++) {
            if ((buffer->state == BT_RFCOMM_NOT_FREE) && (buffer->sequence_nr == l2cap_sequence_nr + 1)) {
                _bt_rfcomm_handle_pkt(buffer);
                l2cap_sequence_nr++;
            }
            buffer = (struct bt_rfcomm_l2cap_pkt_buf_entry*)((size_t) buffer + sizeof(struct bt_rfcomm_l2cap_pkt_buf_entry));
        }

        if (stack->l2cap_disconnected) {        // l2cap has been disconnected. now clean up...
            stack->l2cap_disconnected = 0;

            for (idx = 1; idx <= stack->max_dlci; idx++)
            {
                channel = stack->channels[idx];
                if ((channel->state == BT_RFCOMM_CH_OPEN) && (channel->con_cb != NULL))
                {
                    channel->con_cb(channel->dlci, BT_RFCOMM_DISCONNECT, channel->cb_arg);
                }
            }

            _bt_rfcomm_clear_channels();
            
            channel = stack->channels[BT_RFCOMM_DLCI_MUX];
            // configure the command channel with default values...
            channel->state = BT_RFCOMM_CH_LISTEN;
            channel->dlci  = BT_RFCOMM_DLCI_MUX;
            // precalculate the fcs values for the control channel
            tmp_fcs_buf[0] = (1 << 0) | (1 << 1) | (0 << 2) | (0x00 << 3); // set c/r bit to 0. We are the responder
            tmp_fcs_buf[1] = BT_RFCOMM_UIH;
            channel->uih_in_fcs = crc8_calc(tmp_fcs_buf, BT_RFCOMM_UIHCRC_CHECK_LEN);
            tmp_fcs_buf[0] = (1 << 0) | (0 << 1) | (0 << 2) | (0x00 << 3); // set c/r bit to 0. We are the responder
            tmp_fcs_buf[1] = BT_RFCOMM_UIH;
            channel->uih_out_fcs = crc8_calc(tmp_fcs_buf, BT_RFCOMM_UIHCRC_CHECK_LEN);  
            stack->initiator = 0;
        }
    }
}


/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_l2cap_rcv_cb():
 *
 * This callback will be called from the l2cap layer whenever a l2cap packet is received
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_l2cap_rcv_cb(struct bt_l2cap_acl_pkt *pkt, u_char service_nr, u_short channel_id, void *arg) {
    u_char idx;
    
    for (idx = 0; idx < stack->buffer_size; idx++) {
        if (stack->buffer[idx].state == BT_RFCOMM_FREE)
            break;
    }

    if (idx == stack->buffer_size) {
        ERROR("No ressource free... This should never happen... drop l2cap pkt\n");
        bt_l2cap_complete_pkt(pkt);
        return;
    }

    stack->buffer[idx].pkt = pkt;
    stack->buffer[idx].state = BT_RFCOMM_NOT_FREE;
    stack->l2cap_sequence_nr++;
    stack->buffer[idx].sequence_nr = stack->l2cap_sequence_nr;
    NutEventPostAsync(&stack->sig_l2cap_data_avail);
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_l2cap_con_cb():
 *
 * This callback will be called from the l2cap layer whenever a l2cap connection
 * to the rfcomm psm is opend or closed
 */
/*-----------------------------------------------------------------------------------*/

static void _bt_rfcomm_l2cap_con_cb(u_char type, u_char detail, u_char service_nr, u_short channel_id, void *arg) {                
    if (type == BT_L2CAP_CONNECT) {
        stack->l2cap_channel_id = channel_id;
        INFO("L2CAP connect . Unique handle: %04x\n", channel_id);
        NutEventPostAsync(&stack->sig_l2cap_connected);
    } else {
        stack->l2cap_channel_id = BT_L2CAP_HANDLE_INVALID;
        INFO("L2CAP disconnect. Unique handle: %04x\n", channel_id);

        stack->l2cap_disconnected = 1;
        NutEventPostAsync(&stack->sig_l2cap_data_avail);
    }
}

/*-----------------------------------------------------------------------------------*/
/* 
 * _bt_rfcomm_init():
 *
 * This function initializes the rfcomm layer and starts the main rfcomm thread
 */
/*-----------------------------------------------------------------------------------*/

struct bt_rfcomm_stack *bt_rfcomm_init(struct bt_l2cap_stack *l2cap_stack, u_short max_mfs, u_char nr_channels, u_char nr_l2cap_buffer) {
    u_char idx;
    u_char tmp_fcs_buf[BT_RFCOMM_UIHCRC_CHECK_LEN];
    u_short max_mtu;
    struct bt_rfcomm_channel *channel;

    max_mtu = max_mfs + BT_RFCOMM_HDR_LEN_2 + BT_RFCOMM_FCS_LEN;
    
    if (nr_channels > BT_RFCOMM_MAX_CHANNELS)
        return NULL;

    stack = NutHeapAllocClear(sizeof(struct bt_rfcomm_stack));
    stack->l2cap_channel_id = BT_L2CAP_HANDLE_INVALID;
    stack->l2cap_stack = l2cap_stack;
    stack->max_channel = nr_channels;
    stack->max_dlci = nr_channels << 1;
    stack->sig_l2cap_data_avail = NULL;
    stack->sig_l2cap_connected  = NULL;
    stack->l2cap_sequence_nr = 0;
    stack->initiator = 0;
    stack->l2cap_disconnected = 0;
    
    for (idx = 0; idx <= (BT_RFCOMM_MAX_CHANNELS << 1); idx++) {
        stack->channels[idx] = NULL;
    }

    for (idx = 0; idx <= stack->max_dlci; idx++) {
        stack->channels[idx] = NutHeapAllocClear(sizeof(struct bt_rfcomm_channel));
    }
    
    for (idx = 1; idx <= stack->max_channel; idx++) {
        stack->listening[idx] = NutHeapAllocClear(sizeof(struct bt_rfcomm_listen));
        stack->listening[idx]->channel_nr = BT_RFCOMM_CHNR_INVALID;
    }
    
    _bt_rfcomm_clear_channels();
    
    channel = stack->channels[BT_RFCOMM_DLCI_MUX];
    // configure the command channel with default values...
    channel->state = BT_RFCOMM_CH_LISTEN;
    channel->dlci  = BT_RFCOMM_DLCI_MUX;
    // precalculate the fcs values for the control channel
    tmp_fcs_buf[0] = (1 << 0) | (1 << 1) | (0 << 2) | (0x00 << 3); // set c/r bit to 0. We are the responder
    tmp_fcs_buf[1] = BT_RFCOMM_UIH;
    channel->uih_in_fcs = crc8_calc(tmp_fcs_buf, BT_RFCOMM_UIHCRC_CHECK_LEN);
    tmp_fcs_buf[0] = (1 << 0) | (0 << 1) | (0 << 2) | (0x00 << 3); // set c/r bit to 0. We are the responder
    tmp_fcs_buf[1] = BT_RFCOMM_UIH;
    channel->uih_out_fcs = crc8_calc(tmp_fcs_buf, BT_RFCOMM_UIHCRC_CHECK_LEN);

    stack->buffer_size = l2cap_stack->buffer_size + nr_l2cap_buffer;    // Need at least enough space to save acl_buffer_size + nr_buffers of l2cap packet references
    stack->buffer = NutHeapAllocClear(sizeof(struct bt_rfcomm_l2cap_pkt_buf_entry) * stack->buffer_size);

    if (stack->buffer == NULL) {
        ERROR("Out of memory...\n");
#ifndef BT_RFCOMM_SLIMDOWN
        stack->buffer_size = 0;
        for (idx = 0; idx <= stack->max_dlci; idx++) 
            NutHeapFree(stack->channels[idx]);
#endif
        return NULL;
    }
    
    stack->send_buffer = NutHeapAllocClear(max_mtu + BT_L2CAP_ACL_PKT_HDR_LEN);
    if (stack->send_buffer == NULL) {
        ERROR("Out of memory...\n");
#ifndef BT_RFCOMM_SLIMDOWN
        for (idx = 0; idx <= stack->max_dlci; idx++)
            NutHeapFree(stack->channels[idx]);
        NutHeapFree(stack->send_buffer);
#endif
        return NULL;
    }

    for (idx = 0; idx < stack->buffer_size; idx++) {
        stack->buffer[idx].pkt = NULL;
        stack->buffer[idx].sequence_nr = 0x0000;
        stack->buffer[idx].state = BT_RFCOMM_FREE;
    }

    if (NutThreadCreate("bt_rfcomm", BT_RFCOMM, NULL, 1024) == NULL) {
        ERROR("Can't create bt_rfcomm thread...\n");
#ifndef BT_RFCOMM_SLIMDOWN
        for (idx = 0; idx <= stack->max_dlci; idx++)
            NutHeapFree(stack->channels[idx]);
        NutHeapFree(stack->send_buffer);
        NutHeapFree(stack->buffer);
#endif
        return NULL;
    }
    // Changed MTU handling. Now we have to pass the minimum needed MTU to bt_l2cap_register_service
    stack->service_nr = bt_l2cap_register_service(BT_L2CAP_PSM_RFCOMM, nr_l2cap_buffer, 
                            BT_L2CAP_MIN_MTU, max_mtu, _bt_rfcomm_l2cap_con_cb, 
                            _bt_rfcomm_l2cap_rcv_cb, NULL);
    return stack;
}
