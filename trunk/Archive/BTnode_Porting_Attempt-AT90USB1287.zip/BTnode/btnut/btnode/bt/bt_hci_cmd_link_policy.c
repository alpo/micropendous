/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

 /**
 * @file bt_hci_link_policy.c
 *
 * @brief Deals with link-policy hci-cmds
 * 
 *
 * 2004/05/04 Mathias Payer <payerm@student.ethz.ch>
 * 2006/02/16 Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/event.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <sys/heap.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

/*******************************************************************************
 * bt_hci_role_discovery
 ******************************************************************************/
/**
 * Returns the Role of the specified con_handle
 *
 * Do not confuse this command with bt_hci_local_role_discovery(...)!
 * The above mentioned cmd. only checks the con.table.
 * This cmd actually goes over the wire and asks the remote controller
 *
 * BT_HCI_MY_ROLE_MASTER (this device is master of this connection)
 * BT_HCI_MY_ROLE_SLAVE (this device is slave of this connection)
 *
 * @param stack The bt-stack to use
 * @param response a bt_hci_cmd_response struct for async. calls or BT_HCI_SYNC
 * @param con_handle The pointer where the result will be stored
 *
 * @return {BT_HCI_MY_ROLE_MASTER | BT_HCI_MY_ROLE_SLAVE} if everything was ok, or BT_ERR_NO_CON on error
 * Possible Errors: BT_ERR_NO_CON
 */
long bt_hci_role_discovery(struct btstack *stack, struct bt_hci_cmd_response *response,
                           bt_hci_con_handle_t app_con_handle)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_ROLE_DISCOVERY);

    stack->cmd.payload[2] = 0x02;       // cmd-length
    stack->cmd.payload[3] = BTN_LO(module_con_handle);
    stack->cmd.payload[4] = BTN_HI(module_con_handle);

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_ROLE_DISCOVERY),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_role_set
 ******************************************************************************/
long bt_hci_role_set(struct btstack *stack, struct bt_hci_cmd_response *response,
                     bt_hci_con_handle_t app_con_handle, u_char role)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    if (_bt_hci_get_module_con_handle(stack, app_con_handle) == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_ROLE_CHANGE);

    stack->cmd.payload[2] = 0x07;       // cmd-length
    bt_hci_get_remote_bt_addr(stack, app_con_handle, (stack->cmd.payload + 3));
    stack->cmd.payload[9] = role;

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_ROLE_CHANGE),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_read_link_policy_settings
 ******************************************************************************/
long bt_hci_read_link_policy_settings(struct btstack *stack, struct bt_hci_cmd_response *response,
                                       bt_hci_con_handle_t app_con_handle)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_READ_LINK_POLICY_SETTINGS);

    stack->cmd.payload[2] = 0x02;       // cmd-length
    stack->cmd.payload[3] = BTN_LO(module_con_handle);
    stack->cmd.payload[4] = BTN_HI(module_con_handle);

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_READ_LINK_POLICY_SETTINGS),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_write_link_policy_settings
 ******************************************************************************/
long bt_hci_write_link_policy_settings(struct btstack *stack, struct bt_hci_cmd_response *response,
                                       bt_hci_con_handle_t app_con_handle, u_short settings)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_WRITE_LINK_POLICY_SETTINGS);

    stack->cmd.payload[2] = 0x04;       // cmd-length
    stack->cmd.payload[3] = BTN_LO(module_con_handle);
    stack->cmd.payload[4] = BTN_HI(module_con_handle);
    stack->cmd.payload[5] = BTN_LO(settings);
    stack->cmd.payload[6] = BTN_HI(settings);

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_WRITE_LINK_POLICY_SETTINGS),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_read_default_link_policy_settings
 ******************************************************************************/
long bt_hci_read_default_link_policy_settings(struct btstack *stack, struct bt_hci_cmd_response *response)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_READ_DEFAULT_LINK_POLICY_SETTINGS);

    stack->cmd.payload[2] = 0x00;       // cmd-length

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_READ_DEFAULT_LINK_POLICY_SETTINGS),
                             BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_write_default_link_policy_settings
 ******************************************************************************/
long bt_hci_write_default_link_policy_settings(struct btstack *stack, struct bt_hci_cmd_response *response,
                                               u_short settings)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_WRITE_DEFAULT_LINK_POLICY_SETTINGS);

    if (params->default_link_policy_settings == NULL)
    {
        params->default_link_policy_settings = NutHeapAlloc(sizeof(u_short));   
    }
    *(params->default_link_policy_settings) = settings;

    stack->cmd.payload[2] = 0x02;       // cmd-length
    stack->cmd.payload[3] = BTN_LO(settings);
    stack->cmd.payload[4] = BTN_HI(settings);

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_WRITE_DEFAULT_LINK_POLICY_SETTINGS),
                             BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_hold_mode
 ******************************************************************************/
long bt_hci_hold_mode(struct btstack *stack, struct bt_hci_cmd_response *response,
                      bt_hci_con_handle_t app_con_handle, u_short max_interval, u_short min_interval)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_HOLD_MODE);

    stack->cmd.payload[2] = 0x06;
    stack->cmd.payload[3] = BTN_LO(module_con_handle);
    stack->cmd.payload[4] = BTN_HI(module_con_handle);
    stack->cmd.payload[5] = BTN_LO(max_interval);
    stack->cmd.payload[6] = BTN_HI(max_interval);
    stack->cmd.payload[7] = BTN_LO(min_interval);
    stack->cmd.payload[8] = BTN_HI(min_interval);

    // no response returned, only trigger a mode change event
    
    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_HOLD_MODE),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_sniff_mode
 ******************************************************************************/
long bt_hci_sniff_mode(struct btstack *stack, struct bt_hci_cmd_response *response,
                       bt_hci_con_handle_t app_con_handle, u_short max_interval, u_short min_interval,
                       u_short attempt, u_short timeout)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_SNIFF_MODE);

    stack->cmd.payload[2]  = 0x0A;
    stack->cmd.payload[3]  = BTN_LO(module_con_handle);
    stack->cmd.payload[4]  = BTN_HI(module_con_handle);
    stack->cmd.payload[5]  = BTN_LO(max_interval);
    stack->cmd.payload[6]  = BTN_HI(max_interval);
    stack->cmd.payload[7]  = BTN_LO(min_interval);
    stack->cmd.payload[8]  = BTN_HI(min_interval);
    stack->cmd.payload[9]  = BTN_LO(attempt);
    stack->cmd.payload[10] = BTN_HI(attempt);
    stack->cmd.payload[11] = BTN_LO(timeout);
    stack->cmd.payload[12] = BTN_HI(timeout);

    // no response returned, only trigger a mode change event

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_SNIFF_MODE),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_exit_sniff_mode
 ******************************************************************************/
long bt_hci_exit_sniff_mode(struct btstack *stack, struct bt_hci_cmd_response *response,
                            bt_hci_con_handle_t app_con_handle)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_EXIT_SNIFF_MODE);

    stack->cmd.payload[2]  = 0x02;
    stack->cmd.payload[3]  = BTN_LO(module_con_handle);
    stack->cmd.payload[4]  = BTN_HI(module_con_handle);

    // no response returned, only trigger a mode change event

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_EXIT_SNIFF_MODE),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_park_state
 ******************************************************************************/
long bt_hci_park_state(struct btstack *stack, struct bt_hci_cmd_response *response,
                       bt_hci_con_handle_t app_con_handle,
                       u_short beacon_max_interval, u_short beacon_min_interval)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_PARK_STATE);

    stack->cmd.payload[2] = 0x06;
    stack->cmd.payload[3] = BTN_LO(module_con_handle);
    stack->cmd.payload[4] = BTN_HI(module_con_handle);
    stack->cmd.payload[5] = BTN_LO(beacon_max_interval);
    stack->cmd.payload[6] = BTN_HI(beacon_max_interval);
    stack->cmd.payload[7] = BTN_LO(beacon_min_interval);
    stack->cmd.payload[8] = BTN_HI(beacon_min_interval);

    // no response returned, only trigger a mode change event

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_PARK_STATE),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_exit_park_state
 ******************************************************************************/
long bt_hci_exit_park_state(struct btstack *stack, struct bt_hci_cmd_response *response,
                            bt_hci_con_handle_t app_con_handle)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_POLICY,
                                    HCI_OCF_LP_EXIT_PARK_STATE);

    stack->cmd.payload[2]  = 0x02;
    stack->cmd.payload[3]  = BTN_LO(module_con_handle);
    stack->cmd.payload[4]  = BTN_HI(module_con_handle);

    // no response returned, only trigger a mode change event

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_EXIT_PARK_STATE),
                             app_con_handle);
}
