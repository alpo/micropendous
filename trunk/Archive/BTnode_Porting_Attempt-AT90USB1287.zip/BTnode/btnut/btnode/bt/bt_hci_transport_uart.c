/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/**
 * $Log: bt_hci_transport_uart.c,v $
 * Revision 1.43  2006/11/08 16:51:22  yuecelm
 * fixed minor bug, code size shrinking, cosmetic changes
 *
 * Revision 1.42  2006/10/26 13:25:10  kevmarti
 * - Included syslog debug definitions
 *
 * Revision 1.41  2006/10/20 17:23:06  freckle
 * provide API to construct hci packet on the fly (will be used by bt_acl.c)
 *
 * Revision 1.40  2006/09/19 13:27:14  kevmarti
 * Removed acl pkt mutex (was used for self-delivery)
 *
 * Revision 1.39  2006/09/10 20:12:14  yuecelm
 * add INFO logs to determine the address of each bt_semaphore
 *
 * Revision 1.38  2006/08/29 15:44:18  freckle
 * moved post on cmd queue and packet statistics where they belong
 *
 * Revision 1.37  2006/04/05 10:59:09  kevmarti
 * chanded DEBUG_STR statements back to DEBUG statements because it is not necessary to use DEBUG_STR: 
 * the strings to print are constant during runtime
 *
 * Revision 1.36  2006/04/05 05:31:27  dyerm
 * changed DEBUG statements that use %s to DEBUG_STR
 *
 * Revision 1.35  2006/03/23 07:22:19  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.34.2.3  2006/03/20 09:44:46  kevmarti
 * Adapted to new logging / terminal printing macros
 *
 * Revision 1.34.2.2  2006/02/21 13:55:55  kevmarti
 * Changed interface of bt_hci_get_pkt()
 *
 * Revision 1.34.2.1  2006/02/01 15:05:34  kevmarti
 * - Some smaller adaptions due to the separation of the ACL layer
 * - Added public functions for accessing the bt uart
 * - Added bt stack hci debug info to the system-wide logging service (/debug/logging)
 *
 * Revision 1.34  2005/10/06 09:27:19  lwinterhalter
 * Simple Bluetooth packet statistics added.
 *
 * Revision 1.33  2005/06/03 14:03:36  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.32  2004/11/15 10:24:07  freckle
 * restored older tx/tx buffer size & watermark settings
 *
 * Revision 1.31  2004/11/15 09:29:38  freckle
 * removed commented code
 *
 * Revision 1.30  2004/11/15 09:28:06  freckle
 * more debug output on buffer overrun, removed previous uart buffer adjustments, flushes uart buffer in init_dev
 *
 * Revision 1.29  2004/11/09 15:03:58  freckle
 * added 200 ms delay after sending the change baudrate command
 *
 * Revision 1.28  2004/11/08 11:19:24  freckle
 * finished bt_hci_set_baudrate for zeevo modules, tested 57600,115200,230400
 *
 * Revision 1.27  2004/11/05 17:43:55  freckle
 * print out hci packet type value, if not correct
 *
 * Revision 1.26  2004/10/29 09:15:59  dyerm
 * bd_addr -> bt_addr
 * can not -> cannot
 *
 * Revision 1.25  2004/10/27 17:00:22  freckle
 * zeevo shows erroneous behaviour during RESET cmd. Stack ignores them now
 *
 * Revision 1.24  2004/10/22 14:57:06  freckle
 * removed temp fix for unix emulation. not necessary with more recent nut
 *
 * Revision 1.23  2004/10/13 10:36:25  freckle
 * removed compare between sign and unsign variables (potential bug..)
 *
 * Revision 1.22  2004/08/11 13:03:20  martinhinz
 * all printf now with PSTR
 *
 * Revision 1.21  2004/08/11 12:25:04  martinhinz
 * doku change: www.ethernut.de to www.btnode.ethz.ch
 *
 * Revision 1.20  2004/08/09 23:17:37  freckle
 * After set_speed, only wait on atmel ( not on unix emulation )
 *
 * Revision 1.19  2004/07/27 14:08:42  martinhinz
 * debugoutput nicer format
 *
 * Revision 1.18  2004/07/16 13:41:21  dyerm
 * small change in debug
 *
 * Revision 1.16  2004/07/12 09:07:52  freckle
 * Beautified uart transport data hexdump
 *
 * Revision 1.15  2004/07/12 08:55:32  freckle
 * Cleaned formating to 4 chars indention, no tabs
 */

/**
 *
 * @file bt_hci_transport_uart.c
 *
 * @brief UART specific funtions
 * 
 * This file implements the functions defined in bt_hci_transport_uart.h
 * as a general transport layer for the bt_hci stack.
 *
 * 2004/04/14 19:47:09 Mathias Payer <payerm@student.ethz.ch>
 * - 2004/05/2 15:00:00 Mathias Payer <payerm@student.ethz.ch>
 *	(corrected many errors)
 *
 */

#include <stdio.h>
#include <sys/event.h>
#include <sys/atom.h>
#include <sys/timer.h>
#include <io.h>
#include <dev/usart.h>
#include <dev/usartavr.h>

#include <bt/bt_hci_api.h>      // For specific structs and types
#include <bt/bt_hci_dispatch.h>
#include <bt/bt_hci_event.h>    // for zeevo fix
#include <bt/bt_semaphore.h>

#include <terminal/btn-terminal.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

//to turn on the debug set this value to 1
u_char _bt_hci_debug_uart = 0;

// Low-Level routines to set the baud-rate (of the atmel-uart)
int _bt_hci_lowlevel_set_baudrate(int uart, u_long baud);


/*******************************************************************************
 * _bt_hci_initdev
 ******************************************************************************/
int _bt_hci_initdev(struct btstack *stack)
{
#if LOG_LEVEL >= LOG_WARNING
    char intro[] = "BT_HCI_TRANSPORT_UART: Failed ";
    char reg_err[] = " registering device\n";
    char open_err[] = " opening device\n";
    char baud_err[] = " to set baud rate to";
    char config_err[] = " to set uart config\n";
    char handshake_err[] = " to set handshake mode\n";
    char cooked_err[] = " to set cooked mode to RAW\n";
    char buffer_err[] = " to set tx buffer\n";
#endif

    struct bt_hci_uart *uart_dev;
    u_long parameter;
    long result;

    DEBUG("-- bt_hci_initdev\n");

    uart_dev = &(stack->transport);

    // Initialize the outgoing mutex
    _bt_semaphore_init(&(uart_dev->sem_write), 1);
    INFO("sem_write: %p\n", &(uart_dev->sem_write));

    // Register Device
    if (NutRegisterDevice(uart_dev->hwdev, 0, 0) != 0) {
    	WARNING("%s%s%s", intro, reg_err, uart_dev->hwdev->dev_name);
        return BT_ERR_UART_COM;
    }

    uart_dev->uart = fopen(uart_dev->hwdev->dev_name, "r+");
    if (_fileno(uart_dev->uart) <= 0) {
    	WARNING("%s%s%s", intro, open_err, uart_dev->hwdev->dev_name);
        return BT_ERR_UART_COM;
    }
    // Set speed to BT_UART_INITIAL_SPEED to communicate with the bt-controller
    if (_bt_hci_lowlevel_set_baudrate(_fileno(uart_dev->uart), BT_UART_INITIAL_SPEED) != 0) {
		WARNING("%s%s %d\n", intro, baud_err, BT_UART_INITIAL_SPEED);
        return BT_ERR_UART_COM;
    }
    // Set parity for uart.
    parameter = BT_UART_INITIAL_PARITY;
    if (_ioctl(_fileno(uart_dev->uart), UART_SETPARITY, &parameter) != 0) {
    	WARNING("%s%s", intro, config_err);
        return BT_ERR_UART_COM;
    }
    // Set # databits for uart.
    parameter = BT_UART_INITIAL_DATABITS;
    if (_ioctl(_fileno(uart_dev->uart), UART_SETDATABITS, &parameter) != 0) {
    	WARNING("%s%s", intro, config_err);
        return BT_ERR_UART_COM;
    }
    // Set # stopbits for uart.
    parameter = BT_UART_INITIAL_STOPBITS;
    if (_ioctl(_fileno(uart_dev->uart), UART_SETSTOPBITS, &parameter) != 0) {
    	WARNING("%s%s", intro, config_err);
        return BT_ERR_UART_COM;
    }
    // Set cooked mode to raw for uart.
    parameter = 0;
    if (_ioctl(_fileno(uart_dev->uart), UART_SETCOOKEDMODE, &parameter) != 0) {
    	WARNING("%s%s", intro, cooked_err);
        return BT_ERR_UART_COM;
    }
    // Set handshake-type for uart.
    parameter = BT_UART_INITIAL_FLOWCONTROL;
    if (_ioctl(_fileno(uart_dev->uart), UART_SETFLOWCONTROL, &parameter) != 0) {
    	WARNING("%s%s", intro, handshake_err);
        return BT_ERR_UART_COM;
    }
#if (BT_RADIO_TYPE == ZEEVO)
    // Fix to deal with erroneous behaviour of zeevo (firmware ???)
    uart_dev->reset_pending = 0;
#endif

    // Flush uart input buffer
    _read(_fileno(uart_dev->uart), 0, 0);



#if 0
    /*

       MR 2004-11-15. on going work: replace buffer adjustments below 

       trial & error: btstreamer fails if all buffer adjustmenets are removed
       further testing missing, which of those are important, and why..

       before: txsize & rxsize = 512, rxwml & txwml = 450, rxwmh = 500 and helpded
       during JAWS demo in july

     */

    // use bigger tx buffer (big enough for one complete acl packet)
    parameter = 400;
    result = _ioctl(_fileno(uart_dev->uart), UART_SETTXBUFSIZ, &parameter);
    parameter -= 10;
    result += _ioctl(_fileno(uart_dev->uart), UART_SETTXBUFHWMARK, &parameter);

    if (result) {
    	WARNING("%s%s", intro, buffer_err);
        return BT_ERR_UART_COM;
    }
#endif

    // Set UART buffer
    // TODO: temp. fix.. might not be necessary.. or other values would make more sense
    // this was inserted during acl testing
    // by martin hinz for the btnode2 target and it fixed the JAWS demo

    parameter = 512;
    result = _ioctl(_fileno(uart_dev->uart), UART_SETTXBUFSIZ, &parameter);
    result += _ioctl(_fileno(uart_dev->uart), UART_SETRXBUFSIZ, &parameter);
    parameter = 500;
    result += _ioctl(_fileno(uart_dev->uart), UART_SETTXBUFHWMARK, &parameter);
    result += _ioctl(_fileno(uart_dev->uart), UART_SETRXBUFHWMARK, &parameter);
    parameter = 450;
    result += _ioctl(_fileno(uart_dev->uart), UART_SETTXBUFLWMARK, &parameter);
    result += _ioctl(_fileno(uart_dev->uart), UART_SETRXBUFLWMARK, &parameter);
    if (result) {
    	WARNING("%s%s", intro, buffer_err);
        return BT_ERR_UART_COM;
    }

    return 0;
}



/*******************************************************************************
 * _bt_hci_lowlevel_set_baudrate
 ******************************************************************************/
/** @brief Sets the baudrate of the host
 * 
 * Sets the baudrate of the uart (not the bt controller!) to the given value.
 * This function should only be called by internal functions like
 * bt_hci_set_baudrate() !
 *
 * @param uart_dev The uart to change.
 * @param baud New baudrate
 *
 * @return O, or -1 on error.
 *
 * @see  bt_hci_set_baudrate()
 */
int _bt_hci_lowlevel_set_baudrate(int uart, u_long baud)
{
    // make sure, all outgoing data is written (although it is already done by _UARTwrite)
    _write(uart, 0, 0);

    // TODO: the nut/os usart driver waits 10 us after the last byte
    // this is ok for a baud rate of at least 9600 baud. If we would support LOWER
    // baudrates, we would have to add here an additional wait command and/or fix
    // the nut/os drivers to wait for the last byte to be transmitted acurately

    // TODO: In theory, the following statement should not be necessary, but its needed
    NutDelay(100);              // wait 200 ms ( at 7.3 MHz )

    // set new speed NOW
    if (_ioctl(uart, UART_SETSPEED, &baud) != 0)
        return -1;

    return 0;
}


/**
 * Reads exactly len bytes from the uart to the buffer.
 * We can't inline this function because the uart could run empty
 * and then we would return a half read pkt, which is really bad,
 * because in the next call to get_pkt the other half of the pkt
 * would be interpreted as a new pkt !
 *
 * @param uart device from which to read
 * @param buffer where to write?
 * @param len how much to read?
*/
int _UARTread(struct bt_hci_uart *uart_dev, u_char * buffer, u_short len)
{
    FILE *uart = uart_dev->uart;
    u_short read = 0;
    u_short i;
    short imm;
    long parameter;

    char uart_read_error[] = "_UARTread error!\n";
    char framing_error[] = "framing error\n";
    char buffer_overrun_error[] = "buffer overrun error\n";
    char parity_error[] = "parity error\n";
#if LOG_LEVEL >= LOG_ERROR
    char intro[] = "bt_hci_get_pkt: ";
    char get_status_failed[] = "GET STATUS failed\n";
    char uart_error[] = "UART_ERROR! status = 0x";
#endif

    while (read < len) {

        imm = _read(_fileno(uart), buffer + read, len - read);
        if (imm == -1) {
            ERROR(uart_read_error);
            btn_set_error(11, uart_read_error);
            return -1;
        }
        read += imm;

        // check driver status
        if (_ioctl(_fileno(uart), UART_GETSTATUS, &parameter) != 0) {
            ERROR("%s%s", intro, get_status_failed);
        }
#if (BT_RADIO_TYPE == ZEEVO)
        // Fix to deal with erroneous behaviour of zeevo (firmware ver ???)
        if (uart_dev->reset_pending) {
            //set error flags back to normal
            parameter = UART_ERRORS;
            _ioctl(_fileno(uart), UART_SETSTATUS, &parameter);
            continue;
        }
#endif

        if (parameter & UART_ERRORS) {

            ERROR("%s%s%lx\n", intro, uart_error, parameter);
            if (parameter & UART_FRAMINGERROR) {
                ERROR(framing_error);
                btn_set_error(11, framing_error);
            } else if (parameter & UART_OVERRUNERROR) {
                ERROR(buffer_overrun_error);
                ERROR("req bytes: %d, read bytes: %d\n", len, read);
                btn_set_error(11, buffer_overrun_error);
            } else if (parameter & UART_PARITYERROR) {
                ERROR(parity_error);
                btn_set_error(11, parity_error);
            }
            // set error flags back to normal
            parameter = UART_ERRORS;
            _ioctl(_fileno(uart), UART_SETSTATUS, &parameter);
        }
    }

    if (_bt_hci_debug_uart) {
        for (i = 0; i < len; i++)
            printf_P(PSTR("r%.2x "), buffer[i]);
        printf_P(PSTR("|"));
    }

    return 0;
}


/**
 * Writes exactly len bytes from the buffer to the uart.
 * We can't inline this function because of timeout problems
 * and then we have only written half the pkt to the uart, which is bad
 *
 * @param uart device
 * @param buffer where to write
 * @param len Length
 * @return 0 or -1 on error
*/
int _UARTwrite(FILE * uart, u_char * buffer, u_short len)
{
    u_short written = 0;
    u_short i;
    short imm;

    char uart_write_error[] = "_UARTwrite error!\n";

    if (_bt_hci_debug_uart)
        printf_P(PSTR("\n"));
    while (written < len) {
        imm = _write(_fileno(uart), buffer + written, len - written);
        if (imm == -1) {
            ERROR(uart_write_error);
            btn_set_error(11, uart_write_error);
            return -1;
        }
        written += imm;
    }

    if (_bt_hci_debug_uart) {
        for (i = 0; i < len; i++)
            printf_P(PSTR("w%.2x "), buffer[i]);
        printf_P(PSTR("\n"));
    }
    if (fflush(uart) == EOF)
        return -1;

    return 0;
}
/*******************************************************************************
* _bt_hci_aquire_write_lock
******************************************************************************/
void _bt_hci_aquire_write_lock( struct btstack * stack ){
    struct bt_hci_uart *uart_dev;
    uart_dev = &stack->transport;
    // acquire lock on uart
    _bt_semaphore_wait(&(uart_dev->sem_write));
}

/*******************************************************************************
* _bt_hci_relase_write_lock
******************************************************************************/
void _bt_hci_relase_write_lock( struct btstack * stack ) {
    struct bt_hci_uart *uart_dev;
    uart_dev = &stack->transport;
    // acquire lock on uart
    _bt_semaphore_post(&(uart_dev->sem_write));
}

/*******************************************************************************
* _bt_hci_lowlevel_write
******************************************************************************/
int _bt_hci_lowlevel_write( struct btstack * stack, u_char * buffer, u_short len ){
    struct bt_hci_uart *uart_dev;
    uart_dev = &stack->transport;
    return _UARTwrite(uart_dev->uart, buffer, len);
}

/*******************************************************************************
 * _bt_hci_send_pkt
 ******************************************************************************/
int _bt_hci_send_pkt(struct btstack *stack, u_char * pktptr)
{

    u_short len;
    struct bt_hci_pkt_cmd *cmd;
    struct bt_hci_uart *uart_dev;
    short result;
    uart_dev = &stack->transport;

    // Construct the actual length of the pkt.
    switch (pktptr[0]) {
    case HCI_COMMAND_DATA_PACKET:
        cmd = (struct bt_hci_pkt_cmd *) pktptr;
        len = pktptr[3] + HCI_CMD_DATA_PKT_HDR;
        // DEBUG("Command: ogf:0x%X ocf: 0x%X len: %d\n",BT_HCI_GET_OGF(&(cmd->payload[0])), BT_HCI_GET_OCF(&(cmd->payload[0])), cmd->payload[2]);

#if (BT_RADIO_TYPE == ZEEVO)
        // Fix to deal with erroneous behaviour of zeevo (firmware ver ???)
        if ((BT_HCI_GET_OGF(&pktptr[1]) == HCI_OGF_HOST_CONTROL) && (BT_HCI_GET_OCF(&pktptr[1]) == HCI_OCF_HC_RESET)) {
            uart_dev->reset_pending = 1;
        }
#endif

        break;
    case HCI_ACL_DATA_PACKET:
        len = ((pktptr[4] << 8) | pktptr[3]) + HCI_ACL_DATA_PKT_HDR;
        break;
    case HCI_SCO_DATA_PACKET:
        len = pktptr[3] + HCI_SCO_DATA_PKT_HDR;
        break;
    case HCI_EVENT_PACKET:
        len = pktptr[2] + HCI_EVENT_PKT_HDR;
        break;
    default:
        return -1;
    }

    // Increment len to account for the hci packet type 
    len++;

    // acquire lock on uart
    _bt_hci_aquire_write_lock( stack );

    // Send the pkt to the uart. 
    result = _bt_hci_lowlevel_write( stack, pktptr, len);

    // release lock on uart
    _bt_hci_relase_write_lock( stack );

    // Free the pkt buffer
    stack->cmd.type = HCI_FREE_BUFFER;

    // write ok ?
    if (result < 0)
        return -1;
    return 0;
}


/*******************************************************************************
 * bt_hci_get_pkt
 ******************************************************************************/
u_char *_bt_hci_get_pkt(struct btstack * stack, u_short* len, u_long* t_arrive)
{
    u_char type;
    u_char *pkt;
    struct bt_hci_uart *uart_dev = &stack->transport;
    FILE *uart = (&stack->transport)->uart;

    char error_hci[] = "packet out of sync to BT uart!\n";

    if (_read(_fileno(uart), &type, 1) != 1)
        return 0;
    if (_bt_hci_debug_uart) {
        printf_P(PSTR("r%.2x|"), type);
    }
    // Hooray, we've got a packet!
    // Now we read it and return it to the hci-level!
    switch (type) {
    case HCI_ACL_DATA_PACKET:
    	// write local arrival time to the variable passed
    	*t_arrive = NutGetMillis();
    	// store hci pkt type
		pkt = (u_char*)stack->acl_pkt;
        pkt[0] = type;
        // write acl hci header to packet buffer
        if (_UARTread(uart_dev, pkt + 1, HCI_ACL_DATA_PKT_HDR) != 0)
        {
            return NULL;
        }
        // read acl data
        *len = ((pkt[4] << 8) | pkt[3]);
        if (*len > 0) {
            if (_UARTread(uart_dev, pkt + 1 + HCI_ACL_DATA_PKT_HDR, *len) != 0)
            {
                return NULL;
            }
        }
        break;
    case HCI_SCO_DATA_PACKET:
        pkt = (u_char *) stack->sco_pkt;
        pkt[0] = type;
        if (_UARTread(uart_dev, pkt + 1, HCI_SCO_DATA_PKT_HDR) != 0)
            return 0;
        *len = pkt[3];
        if (*len > 0) {
            if (_UARTread(uart_dev, pkt + 1 + HCI_SCO_DATA_PKT_HDR, *len) != 0)
                return NULL;
        }
        break;
    case HCI_EVENT_PACKET:
        pkt = (u_char *) & stack->evt;
        pkt[0] = type;
        if (_UARTread(uart_dev, pkt + 1, HCI_EVENT_PKT_HDR) != 0)
            return 0;
        *len = pkt[2];
        if (*len > 0) {
            if (_UARTread(uart_dev, pkt + 1 + HCI_EVENT_PKT_HDR, *len) != 0)
                return NULL;
        }
#if (BT_RADIO_TYPE == ZEEVO)
        // Fix to deal with erroneous behaviour of zeevo (firmware ver ???)
        if ((uart_dev->reset_pending) &&
            (pkt[1] == BT_HCI_COMMAND_COMPLETE) && (BT_HCI_GET_OGF(&(pkt[4])) == 0) && (BT_HCI_GET_OCF(&(pkt[4])) == 0)) {
            uart_dev->reset_pending = 0;
        }
#endif

        break;
    default:
#if (BT_RADIO_TYPE == ZEEVO)
        // Fix to deal with erroneous behaviour of zeevo (firmware ver ???)
        if (uart_dev->reset_pending)
            return NULL;
#endif
        ERROR(error_hci);
        ERROR("readed byte = 0x%02x", type);
        btn_set_error(12, error_hci);
        return NULL;
    }
    if (_bt_hci_debug_uart) {
        printf_P(PSTR("\n"));
    }
    return pkt;
}

