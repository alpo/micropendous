/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * @file bt_hci_cmd_link_control.c
 *
 * \author Mathias Payer <payerm@student.ethz.ch>
 *
 * \date 2004/05/04
 * 
 * @brief Deals with link-control hci-cmds
 * 
 * $Log: bt_hci_cmd_link_control.c,v $
 * Revision 1.45  2006/11/08 15:35:39  yuecelm
 * check connection limit before create connection
 *
 * Revision 1.44  2006/10/26 16:03:31  freckle
 * added new commands: bt_hci_read_clock and bt_hci_read_clock_offset
 *
 * Revision 1.43  2006/10/26 13:23:50  kevmarti
 * - Included syslog debug definitions
 *
 * Revision 1.42  2006/10/05 13:04:57  kevmarti
 * 'bt_hci_create_connection()': initializing role of connection to BT_HCI_MY_ROLE_MASTER.
 *
 * Revision 1.41  2006/09/25 14:36:30  kevmarti
 * bt_hci_create_connection(): corrected error handling: if the hci outro cmd fails, the con table will be cleaned up properly now.
 *
 * Revision 1.40  2006/09/12 12:41:00  kevmarti
 * 'bt_hci_create_connection()': invalidating con table entryif '_bt_hci_outro_cmd()' returns an error.
 * This is the case if either:
 * - the cmd packet could not be sent to the bt-module
 * - a duplicate response error occures (see btnode/bt/bt_hci_dispatch.c)
 *
 * Revision 1.39  2006/09/12 11:03:59  kevmarti
 * Bugfix #1557031 (sf)
 *
 * Revision 1.38  2006/09/12 10:53:16  kevmarti
 * Bugfix #1557031 (sf)
 *
 * Revision 1.37  2006/05/03 11:43:23  kevmarti
 * Added create connection cancel command
 *
 * Revision 1.36  2006/05/02 16:53:17  kevmarti
 * Added inquiry cancel command
 *
 * Revision 1.35  2006/04/05 05:31:27  dyerm
 * changed DEBUG statements that use %s to DEBUG_STR
 *
 * Revision 1.34  2006/03/23 07:22:19  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.33.2.3  2006/03/20 12:37:33  kevmarti
 * Log level set to zero
 *
 * Revision 1.33.2.2  2006/03/20 09:26:26  kevmarti
 * Adapted to new logging / terminal printing macros
 *
 * Revision 1.33.2.1  2006/02/01 14:59:49  kevmarti
 * Added bt stack hci debug info to the system-wide logging service (/debug/logging)
 *
 * Revision 1.33  2005/06/13 15:57:14  hobid
 * Added bt_hci_link_key_request_negative_reply.
 *
 * Revision 1.32  2005/06/06 12:09:27  hobid
 * Fixed PIN Code handling / Pairing.
 *
 * Revision 1.31  2005/06/03 15:00:07  olereinhardt
 * Removed my debug output...
 *
 * Revision 1.30  2005/06/03 14:15:27  olereinhardt
 * removed debug output
 *
 * Revision 1.29  2005/06/03 14:03:35  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.28  2005/04/19 18:26:32  beutel
 * added debug flags and more rfcommpin code stuff
 *
 * Revision 1.27  2005/04/15 12:21:59  beutel
 * added link key requests and more pin code stuff
 *
 * Revision 1.26  2005/04/15 09:11:57  beutel
 * minor typos resolved in pin request
 *
 * Revision 1.25  2005/04/15 08:42:21  beutel
 * added pin code request reply
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/event.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <debug/toolbox.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

/*******************************************************************************
 * bt_hci_inquiry
 ******************************************************************************/
long bt_hci_inquiry(struct btstack *stack, struct bt_hci_cmd_response *response, u_char time, u_char number,
                    struct bt_hci_inquiry_result *res)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY);

    // Wait until a cmd-pkt is at hand!
    _bt_semaphore_wait(&(stack->inquiry));

    wcmdpointer->response = 0;
    wcmdpointer->ptr = res;

    // 0x9E8B33: General/Unlimited Inquiry Access Code (GIAC). see
    // Bluetooth Assigned Numbers, 1.1 THE GENERAL AND DEVICE-SPECIFIC
    // INQUIRY ACCESS CODES (DIACS)
    stack->cmd.payload[2] = 0x05;       // cmd-length
    stack->cmd.payload[3] = 0x33;
    stack->cmd.payload[4] = 0x8b;
    stack->cmd.payload[5] = 0x9e;

    // Waiting time for the inquiry to complete
    if (time > 0x30)
        time = 0x30;
    stack->cmd.payload[6] = time;

    // at least one device has to be found ;)
    if (number == 0)
        number = 1;
    stack->cmd.payload[7] = number;

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY),
                             BT_HCI_HANDLE_INVALID);
}

long bt_hci_inquiry_cancel(struct btstack *stack, struct bt_hci_cmd_response *response)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY_CANCEL);
	
	// create the packet
	stack->cmd.payload[2] = 0x0; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY_CANCEL), BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_create_connection
 ******************************************************************************/
long bt_hci_create_connection(struct btstack *stack, struct bt_hci_cmd_response *response, bt_addr_t addr, u_short packet_type,
                              u_char page_scan_rep_mode, u_short clock_offset, u_char allow_role_switch)
{
    short con;
    u_short i;
    long retval;
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // check, if neither connection to this bt_addr already exists nor.. 
    retval = bt_hci_get_con_handle(stack, addr);
    if (retval != BT_ERR_NO_CON)
        return BT_ERR_CON_EXIST;

    // .. if there is an ongoing connection establishment
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (BD_ADDR_CMP(stack->connection[i].bdaddr, addr)) {
            if (stack->connection[i].state == BT_HCI_CONN_STATE_WAITACK)
                return BT_ERR_CON_PEND_ACTIVE;
            if (stack->connection[i].state == BT_HCI_CONN_STATE_ACK)
                return BT_ERR_CON_PEND_PASSIVE;
            if (stack->connection[i].state == BT_HCI_CONN_STATE_WAITPAS)
                return BT_ERR_CON_PEND_PASSIVE;
        }
    }
    
    // check connection limit
    con = 0;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (stack->connection[i].state == BT_HCI_CONN_STATE_OPEN &&
            stack->connection[i].role == BT_HCI_MY_ROLE_MASTER)
        {
            con++;
        }
    }    
    if (con >= BT_HCI_MAX_NUM_SLAVE_CON)
    {
        return BT_ERR_MAX_CON;
    }
        
    // get free entry in connection table - return error if no free entry available
    con = _bt_hci_get_free_con_entry_index(stack);
    if (con == -1)
    {
    	return BT_ERR_MAX_CON;
    }

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_CREATE_CONNECTION);

    stack->cmd.payload[2] = 0xD;        // cmd-length
    memcpy(stack->cmd.payload + 3, addr, BD_ADDR_LEN);  // Array.Pos 3-8
    stack->cmd.payload[9] = BTN_LO(packet_type);
    stack->cmd.payload[10] = BTN_HI(packet_type);
    stack->cmd.payload[11] = page_scan_rep_mode;        // page scan repetition mode
    stack->cmd.payload[12] = 0; // reserved
    stack->cmd.payload[13] = BTN_LO(clock_offset);
    stack->cmd.payload[14] = BTN_HI(clock_offset);
    stack->cmd.payload[15] = allow_role_switch;
    
    // initialize con table entry
    memcpy(stack->connection[con].bdaddr, addr, BD_ADDR_LEN);
    stack->connection[con].state = BT_HCI_CONN_STATE_WAITACK;
    stack->connection[con].app_con_handle = bt_hci_app_con_handle_counter++;
    stack->connection[con].role_change = allow_role_switch;
    stack->connection[con].role = BT_HCI_MY_ROLE_MASTER;
	
    // Send the pkt, wait if necessary and return the return value or an error
    retval = _bt_hci_outro_cmd(stack,
    							 wcmdpointer,
    							 response,
    							 SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_CREATE_CONNECTION),
                             	 stack->connection[con].app_con_handle);
    return retval;
}

/*******************************************************************************
* bt_hci_create_connection_cancel
******************************************************************************/

long bt_hci_create_connection_cancel(struct btstack *stack, struct bt_hci_cmd_response *response, bt_addr_t addr)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_CREATE_CONNECTION_CANCEL);
	
	stack->cmd.payload[2] = BD_ADDR_LEN; //cmd-length
	memcpy(stack->cmd.payload + 3, addr, BD_ADDR_LEN);  // Array.Pos 3-8
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_CREATE_CONNECTION_CANCEL), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_disconnect
 ******************************************************************************/
long bt_hci_disconnect(struct btstack *stack, struct bt_hci_cmd_response *response, bt_hci_con_handle_t app_con_handle,
                       u_char reason)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle;

    module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_DISCONNECT);

    stack->cmd.payload[2] = 0x3;        // cmd-length
    stack->cmd.payload[3] = BTN_LO(module_con_handle);
    stack->cmd.payload[4] = BTN_HI(module_con_handle);
    stack->cmd.payload[5] = reason;

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_DISCONNECT),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_accept_connection_request
 ******************************************************************************/
long bt_hci_accept_connection_request(struct btstack *stack, bt_addr_t addr, u_char role)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, BT_HCI_SYNC, &(stack->cmd), HCI_OGF_LINK_CONTROL,
                                    HCI_OCF_LC_ACCEPT_CONNECTION_REQUEST);

    stack->cmd.payload[2] = 0x7;        // cmd-length
    memcpy(stack->cmd.payload + 3, addr, BD_ADDR_LEN);  // Array.Pos 3-8
    stack->cmd.payload[9] = role;

    // Send the pkt, wait if necessary and return the return value or an error
    // We pass a null wcmdpointer. by this blocking is prevented
    return _bt_hci_outro_cmd(stack, 0, BT_HCI_SYNC, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_ACCEPT_CONNECTION_REQUEST),
                             BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_link_key_request_reply
 ******************************************************************************/
long bt_hci_link_key_request_reply(struct btstack *stack, bt_hci_con_handle_t con_handle, bt_addr_t addr, u_char * link_key)
{
    u_short i;
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle;

    module_con_handle = _bt_hci_get_module_con_handle(stack, con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

    // Init & wait 'till the pkt can be sent
    wcmdpointer =
        _bt_hci_intro_cmd(stack, &wcmd, BT_HCI_SYNC, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_LINK_KEY_REQUEST_REPLY);

    stack->cmd.payload[2] = 0x16;       // cmd-length 22
    memcpy(stack->cmd.payload + 3, addr, BD_ADDR_LEN);  // Array.Pos 3-8
    for (i = 0; i < 15; i++) {
        stack->cmd.payload[i + 9] = link_key[i];
        if (link_key[i] == '\0')
            break;
    }

    // Send the pkt, wait if necessary and return the return value or an error
    // We pass a null wcmdpointer. by this blocking is prevented
    return _bt_hci_outro_cmd(stack, 0, BT_HCI_SYNC, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_LINK_KEY_REQUEST_REPLY),
                             con_handle);
}

/*******************************************************************************
 * bt_hci_link_key_request_negative_reply
 ******************************************************************************/
long bt_hci_link_key_request_negative_reply(struct btstack *stack, bt_addr_t addr)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer =
        _bt_hci_intro_cmd(stack, &wcmd, BT_HCI_SYNC, &(stack->cmd),
            HCI_OGF_LINK_CONTROL, HCI_OCF_LC_LINK_KEY_REQUEST_NEGATIVE_REPLY);

    stack->cmd.payload[2] = 0x6; // cmd-length
    memcpy(stack->cmd.payload + 3, addr, BD_ADDR_LEN);  // Array.Pos 3-8

    // Send the pkt, wait if necessary and return the return value or an error
    // We pass a null wcmdpointer. by this blocking is prevented
    return _bt_hci_outro_cmd(stack, 0, BT_HCI_SYNC,
               SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_LINK_KEY_REQUEST_NEGATIVE_REPLY),
               BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_pin_code_request_reply
 ******************************************************************************/
long bt_hci_pin_code_request_reply(struct btstack *stack, bt_hci_con_handle_t con_handle, bt_addr_t addr, u_char pin_length,
                                   u_char * pin_code)
{
    u_short i;
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer =
        _bt_hci_intro_cmd(stack, &wcmd, BT_HCI_SYNC, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_PIN_CODE_REQUEST_REPLY);
    stack->cmd.payload[2] = 0x17;       // cmd-length 23
    memcpy(stack->cmd.payload + 3, addr, BD_ADDR_LEN);  // Array.Pos 3-8
    stack->cmd.payload[9] = pin_length;
    DEBUG_STR("HCI pin code request reply! %s with length %x\n", pin_code, pin_length);
    DEBUG("Sending code ");
    for (i = 0; i < pin_length; i++) {
        stack->cmd.payload[i + 10] = pin_code[i];
        DEBUG("%x ", pin_code[i]);
        if (pin_code[i] == '\0')
            break;
    }
    DEBUG("\n");

    /* FIXME _bt_hci_handle_event_cmd_complete() cannot fill in this address
     *       because we can't pass wcmdpointer to _bt_hci_outro_cmd() as it
     *       would block.
     */
    wcmdpointer->ptr = addr;

    // Send the pkt, wait if necessary and return the return value or an error
    // We pass a null wcmdpointer. by this blocking is prevented
    return _bt_hci_outro_cmd(stack, 0, BT_HCI_SYNC, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_PIN_CODE_REQUEST_REPLY),
                             con_handle);
}
/*******************************************************************************
* bt_hci_change_con_pkt_type
******************************************************************************/
long bt_hci_change_con_pkt_type(struct btstack *stack, struct bt_hci_cmd_response *response, bt_hci_con_handle_t app_con_handle,
                                u_short packet_type)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;
    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_CONTROL, CHANGE_CONNECTION_PACKET_TYPE);
    
    stack->cmd.payload[2] = 0x4;        // cmd-length
    stack->cmd.payload[3] = BTN_LO(module_con_handle);
    stack->cmd.payload[4] = BTN_HI(module_con_handle);
    stack->cmd.payload[5] = BTN_LO(packet_type);
    stack->cmd.payload[6] = BTN_HI(packet_type);
    
    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, BT_HCI_SYNC, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, CHANGE_CONNECTION_PACKET_TYPE),
                             app_con_handle);
}

/*******************************************************************************
 * bt_hci_authentication requested
 ******************************************************************************/
long bt_hci_authentication_requested(struct btstack *stack, bt_hci_con_handle_t con_handle)
{
    //jaybee

    // Send the pkt, wait if necessary and return the return value or an error
    // We pass a null wcmdpointer. by this blocking is prevented
    return _bt_hci_outro_cmd(stack, 0, BT_HCI_SYNC, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_AUTHENTICATION_REQUESTED),
                             con_handle);
}

/*******************************************************************************
 * bt_hci_remote_name_request
 ******************************************************************************/
long bt_hci_remote_name_request(struct btstack *stack, bt_addr_t addr, u_short clock_offset, u_char page_scan_repetition_mode,
                                char *name, u_char maxlen)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, BT_HCI_SYNC, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_REMOTE_NAME_REQUEST);
    wcmdpointer->ptr = name;
    wcmdpointer->response = maxlen;

    stack->cmd.payload[2] = 0xA;        // cmd-length
    memcpy(stack->cmd.payload + 3, addr, BD_ADDR_LEN);  // Array.Pos 3-8
    stack->cmd.payload[9] = page_scan_repetition_mode;
    stack->cmd.payload[10] = 0; // reserved
    stack->cmd.payload[11] = BTN_LO(clock_offset);
    stack->cmd.payload[12] = BTN_HI(clock_offset);

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, BT_HCI_SYNC, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_REMOTE_NAME_REQUEST),
                             BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
* bt_hci_read_clock_offset
******************************************************************************/
long bt_hci_read_clock_offset(struct btstack *stack, struct bt_hci_cmd_response *response, bt_hci_con_handle_t app_con_handle)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    _bt_hci_module_con_handle_t module_con_handle;
    
    module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;
    
    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_LINK_CONTROL, HCI_OCF_LC_READ_CLOCK_OFFSET);
    
    stack->cmd.payload[2] = 2;        // cmd-length
    stack->cmd.payload[3] = BTN_LO(module_con_handle);
    stack->cmd.payload[4] = BTN_HI(module_con_handle);
    
    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, BT_HCI_SYNC, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_READ_CLOCK_OFFSET),
                             app_con_handle);
}
