/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */
 
/**
 * @file bt_hci_cmd_host_control.c
 *
 * \author Mathias Payer <payerm@student.ethz.ch>
 *
 * \date 2004/05/04
 *
 * @brief Implements host_control hci commands
 * 
 * $Log: bt_hci_cmd_host_control.c,v $
 * Revision 1.27  2006/10/27 14:55:17  yuecelm
 * Changed signedness of strings in order to compile with avr-gcc >4.0
 *
 * Revision 1.26  2006/10/26 13:23:16  kevmarti
 * - Included syslog debug definitions
 *
 * Revision 1.25  2006/10/16 14:22:31  yuecelm
 * clean and overwrite event filter works now (should fix SF bug #1578162)
 *
 * Revision 1.24  2006/08/30 12:02:57  yuecelm
 * event_filter: reserve enough heap for any case
 *
 * Revision 1.23  2006/08/16 13:12:24  yuecelm
 * fixed bug with param handling in bt_hci_set_event_filter
 *
 * Revision 1.22  2006/08/07 11:27:18  yuecelm
 * remember host properties (baudrate, name, cod...)
 * to recover the same state after a reset
 *
 * Revision 1.21  2006/03/23 07:22:19  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.20.2.3  2006/03/20 12:37:14  kevmarti
 * Set log level to zero
 *
 * Revision 1.20.2.2  2006/03/20 09:25:58  kevmarti
 * Adapted to new logging / terminal printing macros
 *
 * Revision 1.20.2.1  2006/02/01 14:59:17  kevmarti
 * Added bt stack hci debug info to the system-wide logging service (/debug/logging)
 *
 * Revision 1.20  2005/09/27 08:28:37  kevmarti
 * rewrote (fixed) bt_hci_set_event_filter
 * (see doku)
 *
 * Revision 1.19  2005/06/13 15:56:57  hobid
 * Added bt_hci_set_event_mask.
 *
 * Revision 1.18  2005/04/15 12:18:03  beutel
 * minor doxygen cleanup
 *
 * 
 */

#include <stdio.h>
#include <string.h>
#include <sys/event.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <bt/bt_defs.h>
#include <sys/heap.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

#define MIN(a, b) ((a > b)? b : a)

/*******************************************************************************
 * bt_hci_set_event_mask
 ******************************************************************************/
long bt_hci_set_event_mask(struct btstack *stack, struct bt_hci_cmd_response *response, u_long mask_high, u_long mask_low)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd),
                      HCI_OGF_HOST_CONTROL, HCI_OCF_HC_SET_EVENT_MASK);

    if (params->event_mask == NULL)
    {
        params->event_mask = NutHeapAlloc(sizeof(struct event_mask_high_low));
    }
    params->event_mask->mask_high = mask_high;
    params->event_mask->mask_low = mask_low;

    stack->cmd.payload[2] = 0x08; //cmd-length
    
    stack->cmd.payload[3]  = (u_char)(mask_low        & 0xFF);
    stack->cmd.payload[4]  = (u_char)(mask_low  >> 8  & 0xFF);
    stack->cmd.payload[5]  = (u_char)(mask_low  >> 16 & 0xFF);
    stack->cmd.payload[6]  = (u_char)(mask_low  >> 24 & 0xFF);
    stack->cmd.payload[7]  = (u_char)(mask_high       & 0xFF);
    stack->cmd.payload[8]  = (u_char)(mask_high >> 8  & 0xFF);
    stack->cmd.payload[9]  = (u_char)(mask_high >> 16 & 0xFF);
    stack->cmd.payload[10] = (u_char)(mask_high >> 24 & 0xFF);

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
               SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_SET_EVENT_MASK),
               BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_reset
 ******************************************************************************/
long bt_hci_reset(struct btstack *stack, struct bt_hci_cmd_response *response)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	if (stack->reset!=0)
		return BT_ERR_RST_RUN;
	stack->reset=1;

	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_RESET);
	
	stack->cmd.payload[2] = 0x00; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_RESET), BT_HCI_HANDLE_INVALID);
}

long _bt_hci_set_event_filter_bytearray(struct btstack* stack, struct bt_hci_cmd_response* response, u_char * byte_array)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait until the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_SET_EVENT_FILTER);
    
    memcpy(&stack->cmd.payload[2], byte_array, byte_array[0] + 1);
    
    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_SET_EVENT_FILTER), BT_HCI_HANDLE_INVALID);    
}

/*******************************************************************************
 * bt_hci_set_event_filter
 ******************************************************************************/
long bt_hci_set_event_filter(struct btstack* stack, struct bt_hci_cmd_response* response, u_char param, ...)
{
	struct param_list * params = &(stack->params);
    //u_char* params = &stack->cmd.payload[3];
    u_char * array;
	va_list argptr;
	u_long ul_param;
	va_start(argptr, param);
    
    if (params->event_filter == NULL)
    {
        params->event_filter = NutHeapAlloc(12);
    }

    array = &params->event_filter[1];

    // set filter type (event_filter[1] --> cmd.payload[3])
    *array++ = param;
    params->event_filter[0] = 1;

    // if inquiry filter or connection filter
    if ((param == 0x01) || (param == 0x02)) {
        // second param contains condition type
        switch (*array++ = (u_char)va_arg(argptr, unsigned)) {
        // return all events
        case 0x00:
            // set cmd length
            params->event_filter[0] = 2;
            break;
        // filter on class of device
        case 0x01:
            // third param contains class of device (unsigned long format)
            ul_param = va_arg(argptr, u_long);
            // write class of device to packet payload
            *array++ = BTN_LO(ul_param);
            *array++ = BTN_HI(ul_param);
            *array++ = BTN_HI2(ul_param);
            // fourth param contains device-mask (unsigned long format)
            ul_param = va_arg(argptr, u_long);
            // write device-mask to packet payload
            *array++ = BTN_LO(ul_param);
            *array++ = BTN_HI(ul_param);
            *array++ = BTN_HI2(ul_param);
            // set cmd length
            params->event_filter[0] = 8;
            break;
        // show only specific device
        case 0x02:
            // third param contains bt address of desired device
            memcpy(array, va_arg(argptr, u_char*), BD_ADDR_LEN);
            // set cmd length
            params->event_filter[0] = 8;
            break;
        default:
            WARNING("hci_set_event_filter: error: illegal filter condition type.\n");
            return -0x12;
        }
    }
    // if connection filter, set auto accept flag
    if (param == 0x02) {
        *array++ = (u_char)va_arg(argptr, unsigned);
        // increment cmd length
        params->event_filter[0]++;
    }
    va_end(argptr);

    return _bt_hci_set_event_filter_bytearray(stack, response, params->event_filter);
}		

//long bt_hci_set_event_filter(struct btstack *stack, struct bt_hci_cmd_response *response, u_char param, ...)
//{
//	struct bt_hci_cmd_response wcmd, *wcmdpointer;
//	u_char i,count;
//	
//	va_list argptr;
//	va_start(argptr,param);
//	
//	// Init & wait 'till the pkt can be sent
//	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_SET_EVENT_FILTER);
//	
//	stack->cmd.payload[2] = param; //cmd-length
//	if (param!=0x00) {
//		count = param - 1; // #bytes (inquiry) +1 = #bytes (conn set.) (auot_accept_flag)
//
//		param = va_arg(argptr,unsigned);
//		stack->cmd.payload[3] = param;
//		
//		/*
//		switch (param) {
//			case 0x00: break; // no add. properties
//			case 0x01: count += 6; // (class of device & device mask)
//				break;
//			case 0x02: count += 6; // (bt-address)
//		}				
//		*/
//		if (param!=0x00) count+=6; // abbr. of the above stmt (optimization, but does the same)
//
//		for (i=4; i<count+4; i++)
//			stack->cmd.payload[i] = va_arg(argptr,unsigned);
//	}
//	va_end(argptr);
//	
//	// Send the pkt, wait if necessary and return the return value or an error
//	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_SET_EVENT_FILTER), BT_HCI_HANDLE_INVALID);
//}


/*******************************************************************************
 * bt_hci_read_pin_type
 ******************************************************************************/
long bt_hci_read_pin_type(struct btstack *stack, struct bt_hci_cmd_response *response)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_PIN_TYPE);
	
	stack->cmd.payload[2] = 0x0; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_PIN_TYPE), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_pin_type
 ******************************************************************************/
long bt_hci_write_pin_type(struct btstack *stack, struct bt_hci_cmd_response *response, u_char type)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	struct param_list * params = &(stack->params);
    
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_PIN_TYPE);
	
    if (params->pin_type == NULL)
    {
        params->pin_type = NutHeapAlloc(sizeof(u_char));   
    }
    *(params->pin_type) = type;
    
	stack->cmd.payload[2] = 0x01; //cmd-length
	stack->cmd.payload[3] = type;
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_PIN_TYPE), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_local_name
 ******************************************************************************/
long bt_hci_write_local_name(struct btstack *stack, struct bt_hci_cmd_response *response, u_char *name)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
    
	u_char i;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_LOCAL_NAME);
	
    if (params->local_name == NULL)
    {
        params->local_name = NutHeapAlloc(0xF8 + 1);
        params->local_name[0xF8] = '\0'; // termination (should not be overwritten)
    }
    memcpy(params->local_name, name, MIN(0xF8, strlen((char *) name)) + 1);
    
	stack->cmd.payload[2] = 0xF8; //max name = 248!
	
	for (i=0; i<0xF8; i++) {
		stack->cmd.payload[i+3] = name[i];
		if (name[i]=='\0') break;
	}
	if (i==0xF8) i--;
	stack->cmd.payload[i+3]='\0';
	
   	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_LOCAL_NAME), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_local_name
 ******************************************************************************/
long bt_hci_read_local_name(struct btstack *stack, struct bt_hci_cmd_response *response, u_char *name, u_char maxlen)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_LOCAL_NAME);
	
	// Save the address of the name-string
	wcmdpointer->ptr = name;
	wcmdpointer->response = maxlen;
	
	stack->cmd.payload[2] = 0x0; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_LOCAL_NAME), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_read_connection_accept_timeout
 ******************************************************************************/
long bt_hci_read_connection_accept_timeout(struct btstack *stack, struct bt_hci_cmd_response *response)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_CONNECTION_ACCEPT_TIMEOUT);
	
	stack->cmd.payload[2] = 0x0; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_CONNECTION_ACCEPT_TIMEOUT), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_connection_accept_timeout
 ******************************************************************************/
long bt_hci_write_connection_accept_timeout(struct btstack *stack, struct bt_hci_cmd_response *response, u_short time)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_CONNECTION_ACCEPT_TIMEOUT);

    if (params->connection_accept_timeout == NULL)
    {
        params->connection_accept_timeout = NutHeapAlloc(sizeof(u_short));   
    }
    *(params->connection_accept_timeout) = time;
	
    stack->cmd.payload[2] = 0x02; //cmd-length
	
	stack->cmd.payload[3] = BTN_LO(time);
	stack->cmd.payload[4] = BTN_HI(time);
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_CONNECTION_ACCEPT_TIMEOUT), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_read_page_timeout
 ******************************************************************************/
long bt_hci_read_page_timeout(struct btstack *stack, struct bt_hci_cmd_response *response)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_PAGE_TIMEOUT);
	
	stack->cmd.payload[2] = 0x0; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_PAGE_TIMEOUT), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_page_timeout
 ******************************************************************************/
long bt_hci_write_page_timeout(struct btstack *stack, struct bt_hci_cmd_response *response, u_short time)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_PAGE_TIMEOUT);

    if (params->page_timeout == NULL)
    {
        params->page_timeout = NutHeapAlloc(sizeof(u_short));   
    }
    *(params->page_timeout) = time;
	
	stack->cmd.payload[2] = 0x02; //cmd-length
	stack->cmd.payload[3] = BTN_LO(time);
	stack->cmd.payload[4] = BTN_HI(time);

	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_PAGE_TIMEOUT), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_read_scan_enable
 ******************************************************************************/
long bt_hci_read_scan_enable(struct btstack *stack, struct bt_hci_cmd_response *response)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_SCAN_ENABLE);
	
	stack->cmd.payload[2] = 0x0; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_SCAN_ENABLE), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_scan_enable
 ******************************************************************************/
long bt_hci_write_scan_enable(struct btstack *stack, struct bt_hci_cmd_response *response, u_char type)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_SCAN_ENABLE);

    if (params->scan_enable == NULL)
    {
        params->scan_enable = NutHeapAlloc(sizeof(u_char));   
    }
    *(params->scan_enable) = type;
	
	stack->cmd.payload[2] = 0x01; //cmd-length
	stack->cmd.payload[3] = type;
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_SCAN_ENABLE), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_read_local_cod
 ******************************************************************************/
long bt_hci_read_local_cod(struct btstack *stack, struct bt_hci_cmd_response *response)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_COD);
	
	stack->cmd.payload[2] = 0x00; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_COD), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_local_cod
 ******************************************************************************/
long bt_hci_write_local_cod(struct btstack *stack, struct bt_hci_cmd_response *response, u_long cod)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_COD);

    if (params->local_cod == NULL)
    {
        params->local_cod = NutHeapAlloc(sizeof(u_long));   
    }
    *(params->local_cod) = cod;
	
	stack->cmd.payload[2] = 0x03; //cmd-length
	stack->cmd.payload[3] = BTN_LO(cod);
	stack->cmd.payload[4] = BTN_HI(cod);
	stack->cmd.payload[5] = BTN_HI2(cod);
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_COD), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_set_flowcontrol
 ******************************************************************************/
long bt_hci_set_flowcontrol(struct btstack *stack, struct bt_hci_cmd_response *response, u_char type)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_SET_HOST_CTRL_TO_HOST_FLOW_CONTROL);

    if (params->flowcontrol == NULL)
    {
        params->flowcontrol = NutHeapAlloc(sizeof(u_char));   
    }
    *(params->flowcontrol) = type;
	
	stack->cmd.payload[2] = 0x01; //cmd-length
	stack->cmd.payload[3] = type;
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_SET_HOST_CTRL_TO_HOST_FLOW_CONTROL), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_host_buffer_size
 ******************************************************************************/
long bt_hci_host_buffer_size(struct btstack *stack, struct bt_hci_cmd_response *response, u_short acl_max_len, u_char sco_max_len, u_short nr_acl_pkts, u_short nr_sco_pkts)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
	
#if defined(__BTNODE2__)
	//TODO:
	//ERROR definition:
	//spec for BTnode Rev2!!!!
	if (acl_max_len < 339) {
		// The Ericsson Bluetooth module rok 101007 requires a host buffer
		// larger than or equal to 339. 
		return -3;
	}
#endif
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_HOST_BUFFER_SIZE);
	
    if (params->host_buffer_size == NULL)
    {
        params->host_buffer_size = NutHeapAlloc(sizeof(struct host_buffer_len_nr));   
    }
    params->host_buffer_size->acl_max_len = acl_max_len;
    params->host_buffer_size->sco_max_len = sco_max_len;
    params->host_buffer_size->nr_acl_pkts = nr_acl_pkts;
    params->host_buffer_size->nr_sco_pkts = nr_sco_pkts;
    
	stack->cmd.payload[2] = 0x07; //cmd-length
	stack->cmd.payload[3] = BTN_LO(acl_max_len);
	stack->cmd.payload[4] = BTN_HI(acl_max_len);
	stack->cmd.payload[5] = sco_max_len;
	stack->cmd.payload[6] = BTN_LO(nr_acl_pkts);
	stack->cmd.payload[7] = BTN_HI(nr_acl_pkts);
	stack->cmd.payload[8] = BTN_LO(nr_sco_pkts);
	stack->cmd.payload[9] = BTN_HI(nr_sco_pkts);
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_HOST_BUFFER_SIZE), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_acl_free_buffer
 ******************************************************************************/
long bt_hci_acl_free_buffer(struct btstack *stack, bt_hci_con_handle_t app_con_handle, u_short nr)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	_bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
	if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;

	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, BT_HCI_SYNC, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_HOST_NUM_OF_COMPLETED_PACKETS_OCF);
	
	stack->cmd.payload[2] = 0x05; // cmd-length
	stack->cmd.payload[3] = 0x01; // #completed pkts for one handle
	stack->cmd.payload[4] = BTN_LO(module_con_handle);
	stack->cmd.payload[5] = BTN_HI(module_con_handle);
	stack->cmd.payload[6] = BTN_LO(nr);
	stack->cmd.payload[7] = BTN_HI(nr);
	
	// Attention: according to the spec (BT1_2:Volume 2,Part E,Chapter 4.2)
    // "...The Host Number Of Completed Packets command is a special command for which no command
    // flow control is used, and which can be sent anytime there is a connection..."
    
    // => we don't register in the wait queue (there is no answer)

	// Send the pkt, wait if necessary and return the return value or an error
	// We pass a null wcmdpointer. by this blocking is prevented
    return _bt_hci_outro_cmd(stack, 0, BT_HCI_SYNC, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_HOST_NUM_OF_COMPLETED_PACKETS_OCF), app_con_handle);
}


/*******************************************************************************
 * bt_hci_read_link_supervision_timeout
 ******************************************************************************/
long bt_hci_read_link_supervision_timeout (struct btstack *stack, struct bt_hci_cmd_response *response, bt_hci_con_handle_t app_con_handle)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	_bt_hci_module_con_handle_t module_con_handle;
    
    // get module connection handle
    module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
	if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_LINK_SUPERVISION_TIMEOUT);
	
	stack->cmd.payload[2] = 0x02; //cmd-length
	stack->cmd.payload[3] = BTN_LO(module_con_handle);
	stack->cmd.payload[4] = BTN_HI(module_con_handle);
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_LINK_SUPERVISION_TIMEOUT), app_con_handle);
}


/*******************************************************************************
 * bt_hci_write_link_supervision_timeout
 ******************************************************************************/
long bt_hci_write_link_supervision_timeout (struct btstack *stack, struct bt_hci_cmd_response *response,
                                           bt_hci_con_handle_t app_con_handle, u_short timeout)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	_bt_hci_module_con_handle_t module_con_handle;
    
    // get module connection handle
    module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
	if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_ERR_NO_CON;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_LINK_SUPERVISION_TIMEOUT);
	
	stack->cmd.payload[2] = 0x04; //cmd-length
	stack->cmd.payload[3] = BTN_LO(module_con_handle);
	stack->cmd.payload[4] = BTN_HI(module_con_handle);
	stack->cmd.payload[5] = BTN_LO(timeout);
	stack->cmd.payload[6] = BTN_HI(timeout);
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_LINK_SUPERVISION_TIMEOUT), app_con_handle);
}


/*******************************************************************************
 * bt_hci_read_inquiry_mode
 ******************************************************************************/
long bt_hci_read_inquiry_mode(struct btstack *stack, struct bt_hci_cmd_response *response)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_INQUIRY_MODE);
	
	stack->cmd.payload[2] = 0x00; //cmd-length
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_INQUIRY_MODE), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_inquiry_mode
 ******************************************************************************/
long bt_hci_write_inquiry_mode(struct btstack *stack, struct bt_hci_cmd_response *response, u_char mode)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_INQUIRY_MODE);

    if (params->inquiry_mode == NULL)
    {
        params->inquiry_mode = NutHeapAlloc(sizeof(u_char));   
    }
    *(params->inquiry_mode) = mode;
	
	stack->cmd.payload[2] = 0x01; //cmd-length
	stack->cmd.payload[3] = mode;
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_INQUIRY_MODE), BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_read_inquiry_scan_type
 ******************************************************************************/
long bt_hci_read_inquiry_scan_type(struct btstack *stack, struct bt_hci_cmd_response *response)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
 
    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_INQUIRY_SCAN_TYPE);
    
    stack->cmd.payload[2] = 0x00; //cmd-length
 
    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_INQUIRY_SCAN_TYPE), BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_write_inquiry_mode
 ******************************************************************************/
long bt_hci_write_inquiry_scan_type(struct btstack *stack, struct bt_hci_cmd_response *response, u_char mode)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    struct param_list * params = &(stack->params);
 
    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_INQUIRY_SCAN_TYPE);

    if (params->inquiry_scan_type == NULL)
    {
        params->inquiry_scan_type = NutHeapAlloc(sizeof(u_char));   
    }
    *(params->inquiry_scan_type) = mode;
   
    stack->cmd.payload[2] = 0x01; //cmd-length
    stack->cmd.payload[3] = mode;
  
    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_WRITE_INQUIRY_SCAN_TYPE), BT_HCI_HANDLE_INVALID);
}

