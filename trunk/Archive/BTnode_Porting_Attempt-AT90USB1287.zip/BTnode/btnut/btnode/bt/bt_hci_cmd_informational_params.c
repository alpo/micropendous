/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/**
 * @file bt_hci_cmd_informational_parameters.c
 * 
 * \author Mathias Payer <payerm@student.ethz.ch>
 *
 * \date 2004/05/11
 * 
 * @brief Implements the hci-cmds that deal with informational parameters
 * 
 * $Log: bt_hci_cmd_informational_params.c,v $
 * Revision 1.12  2006/10/26 13:23:33  kevmarti
 * - Included syslog debug definitions
 *
 * Revision 1.11  2005/06/03 14:03:35  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.10  2005/04/15 12:18:47  beutel
 * minor doxygen cleanup
 *
 */

#include <stdio.h>
#include <sys/event.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

/*******************************************************************************
 * bt_hci_read_local_version_information
 ******************************************************************************/
long bt_hci_read_local_version_information(struct btstack *stack, struct bt_hci_cmd_response *response,
                                           struct bt_hci_local_version_result *version)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer =
        _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_INFORMATIONAL_PARAMS,
                          HCI_OCF_IP_READ_LOCAL_VERSION_INFORMATION);

    // Save the responses in a version struct
    wcmdpointer->ptr = version;
    wcmdpointer->response = 0;

    stack->cmd.payload[2] = 0x0;        //cmd-length

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_LOCAL_VERSION_INFORMATION),
                             BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_read_local_supported_commands
 ******************************************************************************/
long bt_hci_read_local_supported_commands(struct btstack *stack, struct bt_hci_cmd_response *response)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer =
        _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_INFORMATIONAL_PARAMS,
                          HCI_OCF_IP_READ_LOCAL_SUPPORTED_COMMANDS);

    stack->cmd.payload[2] = 0x0;        //cmd-length

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_LOCAL_SUPPORTED_COMMANDS),
                             BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_read_local_supported_features
 ******************************************************************************/
long bt_hci_read_local_supported_features(struct btstack *stack, struct bt_hci_cmd_response *response, u_char * features)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer =
        _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_INFORMATIONAL_PARAMS,
                          HCI_OCF_IP_READ_LOCAL_SUPPORTED_FEATURES);

    // Save the responses in a version struct
    wcmdpointer->ptr = features;

    stack->cmd.payload[2] = 0x0;        //cmd-length

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_LOCAL_SUPPORTED_FEATURES),
                             BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_read_local_extended_features
 ******************************************************************************/
long bt_hci_read_local_extended_features(struct btstack *stack, struct bt_hci_cmd_response *response)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer =
        _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_INFORMATIONAL_PARAMS,
                          HCI_OCF_IP_READ_LOCAL_EXTENDED_FEATURES);

    stack->cmd.payload[2] = 0x0;        //cmd-length

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response,
                             SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_LOCAL_EXTENDED_FEATURES),
                             BT_HCI_HANDLE_INVALID);
}

/*******************************************************************************
 * bt_hci_read_buffer_size
 ******************************************************************************/
long bt_hci_read_buffer_size(struct btstack *stack, struct bt_hci_cmd_response *response)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer =
        _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_BUFFER_SIZE);

    stack->cmd.payload[2] = 0x0;        //cmd-length

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_BUFFER_SIZE),
                             BT_HCI_HANDLE_INVALID);
}


/*******************************************************************************
 * bt_hci_read_bt_addr
 ******************************************************************************/
long bt_hci_read_bt_addr(struct btstack *stack, struct bt_hci_cmd_response *response, bt_addr_t addr)
{
    struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_BD_ADDR);

    // Save the address of the bt_addr-string
    wcmdpointer->ptr = addr;

    stack->cmd.payload[2] = 0x0;        //cmd-length

    // Send the pkt, wait if necessary and return the return value or an error
    return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_BD_ADDR),
                             BT_HCI_HANDLE_INVALID);
}
