#include <sys/event.h>
#include <sys/heap.h>
#include <bt/bt_psm.h>
#include <bt/bt_hci_api.h>
#include <stdio.h>
#include <sys/timer.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_PSMUX
#define LOG_LEVEL SYSLOG_LEVEL_PSMUX
#include <debug/log_set.h>

/**
 *  \brief Representation of a higher layer service. 
 * 
 * Contains all the information needed to handle a higher layer service.
 *
 * A service is the logical endpoint that will receive and handle
 * messages obtained from a remote device. Multiple services can be registered
 * at the protocol / service multiplexor.
 * 
 * \see typedef #bt_acl_pkt_buf (for more details about received messages)
 * \see struct bt_psm_t (for more information about the protocol / service
 * multiplexor)
 */
typedef struct _bt_psm_service_s {
	u_short psm;					///< Protocol/Service Multiplexor value
	u_short service_nr;				///< Service number uniquely defining a registered service
	BT_PSM_DATA_CB;					///< Data Reception Callback
	void* cb_arg;					///< Data Reception Callback Argument
	bt_acl_pkt_buf** free_bufs;		///< Available free buffers (opt.)
} _bt_psm_service_t;


struct bt_psm_s {
	struct btstack* bt_stack;		///< Pointer to the bt-stack to use
	_bt_psm_service_t* services;	///< Pointer to the registered services
	u_short nr_services;			///< Maximal nr of services
	bt_acl_pkt_buf* free_bufs;		///< Pointer to the default message buffers
	u_short nr_free_bufs;			///< Number of default message buffers
	bt_acl_pkt_fifo* delivery_que;	///< delivery queue
	HANDLE msg_avail;
};

/**
 * \brief Returns the next free service number.
 * 
 * \param stack Pointer to the l2cap connectionless stack
 * 
 * \return
 * - next free service number
 * - #L2CAP_CL_ERR_SERVICE_PORTS_EXHAUSTED if the l2cap stack already reached
 * the maximal number of services it can handle
 */
long _bt_psm_get_next_service_nr(bt_psm_t* mux) {
	u_short i;
	_bt_psm_service_t* services = mux->services;
	for (i=0; i<mux->nr_services; i++) {
		if (services[i].psm == 0) return i;
	}
	return BT_PSM_ERR_SERVICE_PORTS_EXHAUSTED;
}

/**
 * \brief Returns the service number of the higher layer service registerd
 * on the PSM passed.
 * 
 * \param stack Pointer to the L2CAP connection-less stack
 * \param psm The Protocol/Service Multiplexer
 * 
 * \return
 * - Service number of the registered service
 * - #L2CAP_CL_ERR_NO_SERVICE_REGISTERED if the PSM passed is not in use
 */
long _bt_psm_get_service_nr_by_psm(bt_psm_t* mux, u_short psm)
{
	u_short i;
	_bt_psm_service_t* services = mux->services;
	for (i=0; i<mux->nr_services; i++) {
		if (services[i].psm == psm) return i;
	}
	return BT_PSM_ERR_NO_SERVICE_REGISTERED;
}

_bt_psm_service_t* _bt_psm_get_service_by_nr(bt_psm_t* mux, u_short service_nr)
{
	_bt_psm_service_t* service;
	// check if service nr is valid
	if (service_nr > mux->nr_services) return NULL;
	// else, check if a service is registered
	service = &mux->services[service_nr];
	if (!mux->services[service_nr].psm) return NULL;
	return service;
}


///**
// * \brief Checks if the PSM passed is valid or not.
// * 
// * \param psm Protocol/Service Multiplexer
// * 
// * \return
// * - 1 if the PSM passed is valid
// * - 0 else
// * 
// * For further details refer to the BT specification 1.2, Vol 3, Part A, p. 45.
// */
//u_char _bt_psm_psm_valid(u_short psm)
//{
//	// TODO: implement this function
//	return 1;
//}

/**
 * \brief Message Bearer Thread - delivers buffered packets to a higher
 * layer service.
 * 
 * For every packet bearer there exists a packet queue and a higher layer
 * service. The packet bearer delivers the packets buffered in the packet
 * queue to the corresponding higher layer service.
 * 
 * Basically, a packet bearer waits for the event
 * #acl_pkt_bearer_t::pkt_avail (indicating that a packet has been added
 * to its packet queue), gets the next packet buffer to process from the packet
 * queue and delivers the packet to the higher layer service. This step will be
 * repeated as long as there are packets in the packet queue or the flag
 * #acl_pkt_bearer_t::td_kill is set, in which case the packet bearer
 * destroys itself and releases the resources it used back to the OS.
 * 
 * \see #acl_pkt_bearer_t
 * \see #bt_psm_pkt_fifo.c
 * \see #bt_psm_pkt_buf_destroy
 */
THREAD(PSMUX, arg)
{
	bt_psm_t* psmux;
	bt_acl_pkt_buf* pkt_buf;
	bt_acl_pkt_buf* free_buf;
	_bt_psm_service_t* service;
	
	// pointer to the delivery queue
	psmux = (bt_psm_t*)arg;
	
	while(1)
	{
		// get next message from the delivery buffer
		pkt_buf = bt_acl_pkt_fifo_get_first(psmux->delivery_que);
		// if there is a message in the queue, we deliver it
		if (pkt_buf) {
			// get pointer to service & deliver msg
			service = pkt_buf->arg;
			free_buf =
				service->data_cb(pkt_buf, pkt_buf->pload, pkt_buf->plen, service->service_nr, service->cb_arg);
			// add the msg obtained to the queue of free buffers
			free_buf->next = *(service->free_bufs);
			*(service->free_bufs) = free_buf;
			// give other threads a chance!
			NutThreadYield();
		}
		// else, wait 'til a pkt buffer has to be delivered.
		else {
			NutEventWait(&psmux->msg_avail, NUT_WAIT_INFINITE);
		}
	}
}

inline u_short bt_psm_get_nr_default_bufs(bt_psm_t* psmux)
{
	return psmux->nr_free_bufs;
}

short bt_psm_deliver_msg(bt_psm_t* psmux,
						bt_acl_pkt_buf* pkt_buf,
						u_char* data,
						u_short len,
						u_short psm,
						bt_acl_pkt_buf** free_buf)
{
	long service_nr;
	_bt_psm_service_t* service;
	
    // if illegal psm, return error
    //if (!_bt_psm_psm_valid(psm)) return BT_PSM_ERR_INVALID_PSM;
    
    // get service - return if invalid service nr
    service_nr = _bt_psm_get_service_nr_by_psm(psmux, psm);
    if (service_nr < 0) return BT_PSM_ERR_NO_SERVICE_REGISTERED;
    service = &psmux->services[(u_short)service_nr];
    
    // if this is a buffered packet, add packet to the pkt_buf queue
    if (service->free_bufs)
    {
    	// if there is no free packet buffer available, return error
    	if (!(*service->free_bufs))
    	{
    		INFO("ERR: dlvr! psm: 0x%04x, pkt_buf: %p, ctxt: %s (buf ovflw!)\n", psm, pkt_buf, runningThread->td_name);
    		*free_buf = pkt_buf;
    		return BT_PSM_ERR_BUF_OVERFLOW;
    	}
    	// else, get the free buffer
    	*free_buf = *(service->free_bufs);
    	*(service->free_bufs) = (*free_buf)->next;
    	(*free_buf)->next = NULL;
    	
    	/* add packet buffer to the delivery queue */
		// store pkt parameters
		pkt_buf->pload = data;
		pkt_buf->plen = len;
		pkt_buf->arg = service;
		// add buffer to queue & wake up the delivery thread
		bt_acl_pkt_fifo_add_last(psmux->delivery_que, pkt_buf);
		NutEventPostAsync(&psmux->msg_avail);
		INFO("pkt_buf: %p dlvrd to psm: 0x%04x, ctxt: %s\n", pkt_buf, psm, runningThread->td_name);
    }
    // else, deliver pkt_buf directly
    else
    {
    	*free_buf = service->data_cb(pkt_buf, data, len, service->service_nr, service->cb_arg);
    	INFO("pkt_buf: %p delivered to psm: 0x%04x, len: %s\n", pkt_buf, psm, runningThread->td_name);
    }
    return 0;
}


/**
 * \brief Registers an upper layer service.
 */
long bt_psm_service_register(bt_psm_t* mux,
								u_short psm,
								BT_PSM_DATA_CB,
								void* cb_arg)
{
	long service_nr;
	_bt_psm_service_t* service;
	
	// if invalid psm, return
	//if (!_bt_psm_psm_valid(psm)) return BT_PSM_ERR_INVALID_PSM;
	// only continue if psm is not in use
	if (_bt_psm_get_service_nr_by_psm(mux, psm) != BT_PSM_ERR_NO_SERVICE_REGISTERED)
		return BT_PSM_ERR_PSM_IN_USE;
	// else, get next free service control block
	service_nr = _bt_psm_get_next_service_nr(mux);
	if (service_nr < 0) return BT_PSM_ERR_SERVICE_PORTS_EXHAUSTED;
	
	// else, get pointer to service struct
	service = &mux->services[(u_short)service_nr];
	
	// set fields
	service->data_cb = data_cb;
	service->cb_arg = cb_arg;
	service->psm = psm;
	service->service_nr = service_nr;
	
	// set default message buffer & pkt bearer
	service->free_bufs = &mux->free_bufs;
	return service_nr;
}

// clears the previously registered service with service nr \p service_nr
short bt_psm_service_clear(bt_psm_t* mux, u_short service_nr) {
	
	_bt_psm_service_t* service;
	
	// get pointer to the service - return if error
	if (service_nr > mux->nr_services) return BT_PSM_ERR_INVALID_SERVICE_NR;
	service = &mux->services[service_nr];
	
	// reset fields
	service->psm = 0;
	service->data_cb = NULL;
	service->cb_arg = NULL;
	return 0;
}

short bt_psm_service_set_buffers(bt_psm_t* mux,
								u_short service_nr,
								bt_acl_pkt_buf** free_bufs)
{
	_bt_psm_service_t* service;
	
	// get service by nr - return if error
	service = _bt_psm_get_service_by_nr(mux, service_nr);
	if (!service) return BT_PSM_ERR_INVALID_SERVICE_NR;
	
	// set pkt queue & pkt bearer 
	service->free_bufs = free_bufs;
	return 0;
}

bt_psm_t* bt_psm_init(struct btstack* bt_stack,
						u_short nr_services,
						u_short nr_bufs)
{
	bt_psm_t* psmux;
	
	// dyn. allocate psm
	psmux = NutHeapAllocClear(sizeof(bt_psm_t) + nr_services*sizeof(_bt_psm_service_t));
	psmux->nr_services = nr_services;
	psmux->services = (_bt_psm_service_t*)(((u_char*)psmux) + sizeof(bt_psm_t));
	psmux->bt_stack = bt_stack;
	
	// create default ACL packet buffer queue
	psmux->free_bufs = bt_acl_pkt_queue_create(bt_stack, nr_bufs);
	psmux->nr_free_bufs = nr_bufs;
	
	// init delivery queue
	psmux->delivery_que = bt_acl_pkt_fifo_create();
	
	// create delivery thread
	NutThreadCreate("psmux", PSMUX, psmux, 2048);
	return psmux;
}
