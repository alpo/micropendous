/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/**
 * @file bt_hci_dispatch.c
 *
 * \date 2004/04/14 21:37:09 
 * 
 * \author Mathias Payer <payerm@student.ethz.ch>
 *
 * Defines some functions to "alloc" pkts and dispatch them to the
 * hci-controller
 * 
 * $Log: bt_hci_dispatch.c,v $
 * Revision 1.53  2006/10/26 13:25:10  kevmarti
 * - Included syslog debug definitions
 *
 * Revision 1.52  2006/10/23 10:52:23  kevmarti
 * code beautification
 *
 * Revision 1.51  2006/10/06 14:37:14  kevmarti
 * Bugfix: role was set wrong when a passive connection complete event arrived
 *
 * Revision 1.50  2006/09/25 13:44:13  kevmarti
 * - _bt_hci_get_app_con_handle(): added check if connection is in open state
 * - _bt_hci_get_module_con_handle(): added check if connetion is in open state
 *
 * Revision 1.49  2006/09/14 10:28:06  yuecelm
 * avoid superfluously posts to semaphore single_cmds
 * (dirty/temporary fix)
 *
 * Revision 1.48  2006/09/12 12:52:51  kevmarti
 * Bugfix in '_bt_hci_outro_cmd()': fixed handling of errors caused by '_bt_hci_setWaitQueue()'.
 *
 * Revision 1.47  2006/09/10 20:09:16  yuecelm
 * add INFO logs to determine the address of each bt_semaphore,
 * set initial value of semaphore single_cmd to 1 instead of 2
 *
 * Revision 1.46  2006/08/31 15:10:28  yuecelm
 * move the event watchdog before UART send to ensure that
 * the watchdog does not miss the reply from the BT module
 *
 * Revision 1.45  2006/08/30 12:12:56  yuecelm
 * improved bt_hw_reset: performs it thread-safe,
 * all non-connection-related HCI commands from other threads
 * are hold until after the reset procedure
 *
 * Revision 1.44  2006/08/29 15:44:18  freckle
 * moved post on cmd queue and packet statistics where they belong
 *
 * Revision 1.43  2006/08/21 10:33:10  yuecelm
 * add debug logs before and after semaphores,
 * if event watchdog is triggered then release
 * semaphore nr_hci_cmds with value 1
 *
 * Revision 1.42  2006/07/28 16:19:34  yuecelm
 * add a (disabled) event watchdog which handles not-sended/lost
 * HCI events, if enabled, the Bluetooth stack will not block anymore
 *
 * Revision 1.41  2006/03/23 07:22:19  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.39.2.4  2006/03/22 14:07:30  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.39.2.3  2006/03/20 09:42:22  kevmarti
 * Adapted to new logging / terminal printing macros
 *
 * Revision 1.39.2.2  2006/02/21 13:54:34  kevmarti
 * Restored original state to reduce changes compared to HEAD
 *
 * Revision 1.39.2.1  2006/02/01 15:01:33  kevmarti
 * - Some smaller adaptions due to the separation of the ACL layer
 * - Added bt stack hci debug info to the system-wide logging service (/debug/logging)
 *
 * Revision 1.40  2006/02/20 17:23:15  yuecelm
 * add read link policy commands,
 * adapted event and response handling,
 * cosmetic changes
 *
 * Revision 1.39  2005/06/14 18:01:05  freckle
 * disabled printf in _bt_hci_wakeup as passive events do trigger warnings
 *
 * Revision 1.38  2005/06/14 17:44:25  freckle
 * moved single bt command lock into outro_cmd (thanks to Daniel)
 *
 * Revision 1.37  2005/06/10 17:40:24  freckle
 * Assert bt_hci_wakeup really wakes at least on thread (prints error msg)
 *
 * Revision 1.36  2005/06/10 15:15:14  freckle
 * only allow sending of one Command before receiving Command Status event
 * or command is complete to ensure handling of Command Status Event returning
 * an error is correct.
 *
 * Revision 1.35  2005/06/07 11:42:19  hobid
 * Bugfix in authentication
 *
 * Revision 1.34  2005/06/03 14:03:35  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.33  2005/04/15 12:21:59  beutel
 * added link key requests and more pin code stuff
 *
 * Revision 1.32  2004/11/24 08:19:16  dyerm
 * reverted to 1.30 code
 *
 * Revision 1.30  2004/11/16 13:43:39  dyerm
 * fixed more compile bugs
 *
 * Revision 1.29  2004/11/16 13:34:59  dyerm
 * fixed compile problem, re-wrote DISCONNECT_COMPLETE_EVENT to wake waiting threads for the disconnected link
 *
 * Revision 1.28  2004/11/16 12:00:34  dyerm
 * added extra check for module_handle = BT_HCI_HANDLE_INVALID
 *
 * Revision 1.27  2004/11/12 10:36:05  freckle
 * forgot to add #include <sys/timer.h>
 *
 * Revision 1.26  2004/11/12 10:32:34  freckle
 * fixed bug(s) in _bt_hci_outro_cmd and cleaned up there. updated docu, too.
 *
 * Revision 1.25  2004/11/12 10:19:37  dyerm
 * changed dump waitqueue to **hex** ogf ocf output
 *
 * Revision 1.24  2004/10/29 09:15:59  dyerm
 * bd_addr -> bt_addr
 * can not -> cannot
 *
 * Revision 1.23  2004/08/11 12:25:04  martinhinz
 * doku change: www.ethernut.de to www.btnode.ethz.ch
 *
 */
#include <sys/thread.h>
#include <sys/atom.h>
#include <sys/event.h>
#include <sys/timer.h>
#include <sys/heap.h>
#include <stdio.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <debug/syslog.h>

// event watchdog
#define ENABLE_EVENT_WATCHDOG 0

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

/*******************************************************************************
 * _bt_hci_pkts_init
 ******************************************************************************/
void _bt_hci_pkts_init(struct btstack *stack)
{
    u_char i;

    // Set default type for cmd
    stack->cmd.type = HCI_FREE_BUFFER;

    _bt_semaphore_init(&(stack->nr_hci_cmds), 1);
    INFO("nr_hci_cmds: %p\n", &(stack->nr_hci_cmds));

    // set default type for event
    stack->evt.type = HCI_FREE_BUFFER;

    // Initialize possible callback-queues
    for (i = 0; i < BT_HCI_NR_WAIT_QUEUES; i++)
        stack->waitqueue[i] = 0;

    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        stack->connection[i].state = BT_HCI_CONN_INVALID;
        stack->connection[i].app_con_handle = BT_HCI_HANDLE_INVALID;
        stack->connection[i].module_con_handle = BT_HCI_HANDLE_INVALID;
        stack->connection[i].role = 0;
    }
    stack->conn_request = 0;     /**< There are no requests pending */

    // Initialize the cmd-wait queue
    _bt_semaphore_init(&(stack->hci_cmd_queue), 1);
    INFO("hci_cmd_queue: %p\n", &(stack->hci_cmd_queue));

    // Initialize the single command without Command Status Event queue and set
    // latest command index to none
    _bt_semaphore_init(&(stack->single_cmd), 0);
    INFO("single_cmd: %p\n", &(stack->single_cmd));
    _bt_hci_wakeup_unset(stack); // set single_cmd to 1
    
    // Set initial acl-pkt
    stack->acl_pkt = &(stack->acl_init);

    // Set initial sco-pkt
    stack->sco_pkt = &(stack->sco_init);

}

/*******************************************************************************
 * _bt_hci_dumpWaitQueue
 ******************************************************************************/
void _bt_hci_dumpWaitQueue(struct btstack *stack)
{
    u_char i;
    struct bt_hci_cmd_response *resp;

    DEBUG("_bt_hci_dumpWaitQueue:\n\r");

    for (i = 0; i < BT_HCI_NR_WAIT_QUEUES; i++)
        if ((stack->waitqueue[i]) != 0) {
            // print entry
            resp = stack->waitqueue[i];
            DEBUG("%d:  OGF: 0x%x, OCF: 0x%x, App_Con_Handle: %d (@0x%x)\n\r", i,
                     (resp->ogfocf >> 2) & 0x3f, resp->ogfocf >> 8, resp->cmd_handle, (uptr_t) resp);
        }
}

/*******************************************************************************
 * _bt_hci_setWaitQueue
 ******************************************************************************/
int _bt_hci_setWaitQueue(struct btstack *stack, struct bt_hci_cmd_response *resp)
{
    u_char i;

    for (i = 0; i < BT_HCI_NR_WAIT_QUEUES; i++) {
        if ((stack->waitqueue[i]) == 0) {
            stack->waitqueue[i] = resp;
            // set latest command to wake on Command Status Event
            stack->latest_cmd = i;
            DEBUG("Latest command index: %d set \n\r", i);
            return 0;
        } else {
            if ((stack->waitqueue[i]) == resp) {
                // duplicate response error
                return -2;
            }
        }
    }
    return -1;
}

/*******************************************************************************
* _bt_hci_wakeup_unset
******************************************************************************/
inline void _bt_hci_wakeup_unset(struct btstack *stack){

    DEBUG( "Latest command index: %d cleared \n\r", stack->latest_cmd);
    // dirty/temporary fix (MY) -> avoid superfluously posts to single_cmd
    if (stack->latest_cmd != BT_HCI_WAIT_QUEUE_NONE)
    {
        stack->latest_cmd = BT_HCI_WAIT_QUEUE_NONE;
    
        // Command completed or Status Event received, allow next Command to be sent
        _bt_semaphore_post(&(stack->single_cmd));
    }
}

/*******************************************************************************
* bt_hci_wakeup_index
* wakes one thread of waitqueue and set response
******************************************************************************/
void _bt_hci_wakeup_index(struct btstack *stack, u_char index, long response)
{
    stack->waitqueue[index]->response = response;
    NutEventBroadcastAsync(&(stack->waitqueue[index]->block));
    // manually set queue to SIGNALED for checking
    stack->waitqueue[index]->block = SIGNALED;
    stack->waitqueue[index] = 0;
    
    // reset latest command
    if (stack->latest_cmd == index)
        _bt_hci_wakeup_unset(stack);
}

/*******************************************************************************
 * bt_hci_wakeup
 * wake all threads that wait on ogcocf & con_handle combination and set response
 * ogocf == 0xffff marks any ocf/ogf combination
 ******************************************************************************/
int _bt_hci_wakeup(struct btstack *stack, u_short ogfocf, u_short cmd_handle, long response)
{
    u_char i;
    int result = -1;

    for (i = 0; i < BT_HCI_NR_WAIT_QUEUES; i++) {
        if ((stack->waitqueue[i] != 0) && ((stack->waitqueue[i]->cmd_handle) == cmd_handle)) {
            if ((ogfocf == 0xffff) || ((stack->waitqueue[i]->ogfocf) == ogfocf)) {
                _bt_hci_wakeup_index(stack, i, response);
                result = 0;
            }
        }
    }
    /** TODO: ASSERTION: at least one thread woken if not any ogfocf selected (could be used on closing bb connection)
     * Problem here: How to deal with events we did not create (e.g. Role Change Event)?  */
    /*
     if ((result == -1) && (ogfocf != 0xffff)){
        printf_P(PSTR("_bt_hci_wakeup OGF: 0x%x, OCF: 0x%x, App_Con_Handle: %d failed\n\r"),
                 ogfocf >> 2 & 0x3f, ogfocf >> 8, cmd_handle);
        _bt_hci_dumpWaitQueue(stack);
    }
    */
    return result;
}

/*******************************************************************************
* bt_hci_wakeup_latest
* wakes up latest thread on waitqueue and set response
******************************************************************************/
void _bt_hci_wakeup_latest(struct btstack *stack, long response)
{
    if (stack->latest_cmd != BT_HCI_WAIT_QUEUE_NONE){
        _bt_hci_wakeup_index(stack, stack->latest_cmd, response);
    } else {
        DEBUG("_bt_hci_wakeup_latest: no latest command set!\n\r");
    }
}

/*******************************************************************************
 * bt_hci_cmd_get_response
 ******************************************************************************/
struct bt_hci_cmd_response *_bt_hci_cmd_get_response(struct btstack *stack, u_short ogcocf, u_short cmd_handle)
{
    u_char i;

    for (i = 0; i < BT_HCI_NR_WAIT_QUEUES; i++)
        if ((stack->waitqueue[i] != 0) && ((stack->waitqueue[i]->ogfocf) == ogcocf)
            && ((stack->waitqueue[i]->cmd_handle) == cmd_handle)) {
            return stack->waitqueue[i];
        }
    return 0;
}

/*******************************************************************************
 * _bt_hci_get_free_con_entry_index
 ******************************************************************************/
short _bt_hci_get_free_con_entry_index(struct btstack *stack)
{
    u_char i;

    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++)
    {
        if (stack->connection[i].state == BT_HCI_CONN_INVALID)
        {
            stack->connection[i].state = BT_HCI_CONN_UNINITIALIZED;
            stack->connection[i].role = 3;
            stack->connection[i].role_change = 3;
            stack->connection[i].app_con_handle = BT_HCI_HANDLE_INVALID;
            stack->connection[i].module_con_handle = BT_HCI_HANDLE_INVALID;
            stack->connection[i].pkts_h2c = 0;
            stack->connection[i].auth = BT_HCI_AUTH_NONE;
            return i;
        }
    }
    return -1;
}

/*******************************************************************************
 * _bt_hci_get_app_con_handle (module_con_handle -> app_con_handle)
 ******************************************************************************/
bt_hci_con_handle_t _bt_hci_get_app_con_handle(struct btstack * stack, _bt_hci_module_con_handle_t module_con_handle)
{
    u_char con;

    // sanity check
    if (module_con_handle == BT_HCI_HANDLE_INVALID)
        return BT_HCI_HANDLE_INVALID;

    // look for handle
    for (con = 0; con < BT_HCI_MAX_NUM_CON; con++)
    {
    	if (stack->connection[con].state == BT_HCI_CONN_STATE_OPEN)
    	{
        	if (stack->connection[con].module_con_handle == module_con_handle)
        	{
            	return stack->connection[con].app_con_handle;
        	}
        }
    }
    return BT_HCI_HANDLE_INVALID;
}

/*******************************************************************************
 * _bt_hci_get_module_con_handle (app_con_handle -> module_con_handle)
 ******************************************************************************/
_bt_hci_module_con_handle_t _bt_hci_get_module_con_handle(struct btstack * stack, bt_hci_con_handle_t app_con_handle)
{
    u_char con;
    for (con = 0; con < BT_HCI_MAX_NUM_CON; con++)
    {
    	if (stack->connection[con].state == BT_HCI_CONN_STATE_OPEN)
    	{
        	if (stack->connection[con].app_con_handle == app_con_handle)
        	{
            	return stack->connection[con].module_con_handle;
        	}
        }
    }
    return BT_HCI_HANDLE_INVALID;
}

/*******************************************************************************
 * _bt_hci_intro_cmd
 ******************************************************************************/
struct bt_hci_cmd_response *_bt_hci_intro_cmd(struct btstack *stack, struct bt_hci_cmd_response *wcmd,
                                              struct bt_hci_cmd_response *response, struct bt_hci_pkt_cmd *cmd, u_char ogf,
                                              u_short ocf)
{
	INFO("CMD (0x%02.X/0x%02.X), nr hci pkts: %d\n", ogf, ocf, stack->nr_hci_cmds.counter);
	
    if (stack->hw_reset == NULL || stack->hw_reset != runningThread)
    {
        // Wait until a cmd-pkt is at hand!
        DEBUG("before acquire hci_cmd_queue\n");
        _bt_semaphore_wait(&(stack->hci_cmd_queue));
        DEBUG("after acquire hci_cmd_queue\n");
    }

    // Attention: according to the spec (BT1_2:Volume 2,Part E,Chapter 4.2)
    // "...The Host Number Of Completed Packets command is a special command for which no command
    // flow control is used, and which can be sent anytime there is a connection..."

    // => we don't acquire the nr_hci_cmds

    if ((ogf != HCI_OGF_HOST_CONTROL) || (ocf != HCI_OCF_HC_HOST_NUM_OF_COMPLETED_PACKETS_OCF)) {
        // Wait until the controller is ready for some more pkts!
        DEBUG("before acquire nr_hci_cmds\n");
        _bt_semaphore_wait(&(stack->nr_hci_cmds));
        DEBUG("after acquire nr_hci_cmds\n");
    }

    cmd->type = HCI_COMMAND_DATA_PACKET;

    // Strangely the group-field comes after the command field (little<->big endian)
    cmd->payload[1] = ogf << 2;

    cmd->payload[0] = ocf;

    // Synchronous or asynchronous?
    if (response == BT_HCI_SYNC)
        return wcmd;
    else
        return response;
}

#if ENABLE_EVENT_WATCHDOG > 0
struct _event_watchdog_conf {
    struct btstack * stack;
    struct bt_hci_cmd_response * wcmd;
    u_long timeout;
};

THREAD(EV_WATCHDOG, arg)
{        
    struct _event_watchdog_conf * ewc = (struct _event_watchdog_conf *) arg;

#if LOG_LEVEL >= LOG_INFO
    u_long start_time = NutGetMillis();
#endif

    if (NutEventWait(&(ewc->wcmd->block), ewc->timeout) == -1)
    {            
        WARNING("EVENT TIMEOUT (%lu ms)...\n", ewc->timeout);

        DEBUG("release nr_hci_cmds with value 1\n");
        _bt_semaphore_postval(&(ewc->stack->nr_hci_cmds), 1);
        
        // emulate event with error code    
        _bt_hci_wakeup(ewc->stack, ewc->wcmd->ogfocf, ewc->wcmd->cmd_handle, BT_ERR_BT_MODULE);
        
        if (ewc->wcmd->ogfocf == SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY))
        {
            _bt_semaphore_post(&(ewc->stack->inquiry));
        }
    }

    INFO("response time (OGF 0x%02x, OCF 0x%02x): %lu ms\n", 
         ((ewc->wcmd->ogfocf & 0x00ff) >> 2), (ewc->wcmd->ogfocf >> 8), 
         (u_long) (NutGetMillis() - start_time));
       
    NutHeapFree(ewc);
    
    NutThreadExit();
    
    while (1) { NutSleep(-1); }
}
#endif

/*******************************************************************************
 * bt_hci_outro_cmd
 ******************************************************************************/
long _bt_hci_outro_cmd(struct btstack *stack, struct bt_hci_cmd_response *wcmdpointer, struct bt_hci_cmd_response *response,
                       u_short ogfocf, u_short cmd_handle)
{
    int retval;

    // first, register wcmd, if necessary

    // some cmds don't require or want to use the waitqueue, so far these are:
    // - bt_hci_accept_connection_request (don't want, called from hci read thread)
    // - bt_hci_pin_code_request_reply    (don't want, called from hci read thread)
    // - bt_hci_acl_free_buffer           (don't need, no answer from module anyway)
    if (wcmdpointer) {

        // Wait until there are no pending Commmand Status Events of previous sent commands
        DEBUG("before acquire single_cmd\n");
        _bt_semaphore_wait(&(stack->single_cmd));
        DEBUG("after acquire single_cmd\n");

        // store command identifier
        wcmdpointer->ogfocf = ogfocf;
        wcmdpointer->cmd_handle = cmd_handle;
        wcmdpointer->block = 0;

        // reserve waiting slot
        do {
            retval = _bt_hci_setWaitQueue(stack, wcmdpointer);
            if (retval != 0)
            {
            	if (retval == -1)
            	{
            		DEBUG("hci outro: wait que full, waiting...\n\r");
            		NutSleep(1000);
            	}
                else if (retval == -2)
                {
                    // duplicate response error
                    WARNING("hci outro: duplicate-resp err!\n\r");
                    WARNING("New Resp:  OGF: %d, OCF: OCF%d, App_Con_Handle: %d (@0x%x)\n\r",
                             (ogfocf >> 2) & 0x3f, ogfocf >> 8, cmd_handle, (uptr_t) wcmdpointer);
                    _bt_hci_dumpWaitQueue(stack);
                    // release semaphores
                    _bt_semaphore_post(&(stack->single_cmd));
                    _bt_semaphore_post(&(stack->hci_cmd_queue));
                    return BT_ERR_BT_MODULE;
                }
                else
                {
                	WARNING("hci outro: err set wait que.\n");
                }
            }
        } while (retval != 0);
    }

#if ENABLE_EVENT_WATCHDOG > 0
    if (wcmdpointer != NULL)
    {
        struct _event_watchdog_conf * ewc = 
            NutHeapAlloc(sizeof(struct _event_watchdog_conf));
        ewc->stack = stack;
        ewc->wcmd = wcmdpointer;
        switch (ogfocf)
        {
            case (SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY)):
            {
                ewc->timeout = 60000ul;
                break;   
            }
            case (SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_CREATE_CONNECTION)):
            {
                ewc->timeout = 30000ul;
                break;   
            }
            default:
            {
                ewc->timeout = 5000ul;
                break;
            }
        }
        if (NutThreadCreate("ev_wd", EV_WATCHDOG, ewc, 128) == NULL)
        {
            WARNING("Cannot alloc event watchdog thread...\n");
        }
    }
#endif
    
    // Is the sending successful?
    retval = _bt_hci_send_pkt(stack, (u_char *) & stack->cmd);
    
    // If they are sleeping threads that want to send a cmd, wake them up
    if (stack->hw_reset == NULL || stack->hw_reset != runningThread)
    {
        _bt_semaphore_post(&(stack->hci_cmd_queue));
    }
    
    if (retval != 0) {
        DEBUG("bt_hci_outro_cmd, _bt_hci_send_pkt failed error %d \n\r", retval);
        return retval;
    }
    // done, if no wcmd (see above)
    if (wcmdpointer == 0)
        return 0;

    // Sync. call?
    if (response == BT_HCI_SYNC) {
        NutEventWait(&(wcmdpointer->block), NUT_WAIT_INFINITE);
        return wcmdpointer->response;
    }
    return 0;
}
