#include <sys/heap.h>
#include <bt/bt_defs.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_acl_defs.h>
#include <bt/bt_acl_pkt_buf.h>

struct bt_acl_pkt_fifo_s {
	bt_acl_pkt_buf* first;
	bt_acl_pkt_buf* last;
	u_short size;
};

// creates an ACL packet buffer
bt_acl_pkt_buf* bt_acl_pkt_buf_create(struct btstack* stack) {
	
	bt_acl_pkt_buf* buf;
	
	buf = NutHeapAllocClear(sizeof(bt_acl_pkt_buf));
	buf->pkt = NutHeapAllocClear(stack->host_acl_len + BT_ACL_HCI_PKT_HDR_LEN + sizeof(void*));
	return buf;
}

// destroys a single ACL packet buffer
void bt_acl_pkt_buf_destroy(bt_acl_pkt_buf* buf)
{
	NutHeapFree(buf->pkt);
	NutHeapFree(buf);
}

bt_acl_pkt_buf* bt_acl_pkt_queue_create(struct btstack* stack, u_short nr_bufs)
{
	u_short i;
	bt_acl_pkt_buf* first = NULL;
	bt_acl_pkt_buf* buf = NULL;
	// dyn. allocate packet buffers & add them to the queue of free buffers
	for (i=0; i<nr_bufs; i++) {
		// create a new buf
		buf = bt_acl_pkt_buf_create(stack);
		buf->next = first;
		first = buf;
	}
	return first;
}

void bt_acl_pkt_queue_destroy(bt_acl_pkt_buf* que)
{
	bt_acl_pkt_buf* buf;
	
	while ((buf = que)) {
		// remove buffer from queue
		que = buf->next;
		// destroy buffer
		bt_acl_pkt_buf_destroy(buf);
	}
}

// creates a que of acl pkt buffers
bt_acl_pkt_fifo* bt_acl_pkt_fifo_create(void)
{
	bt_acl_pkt_fifo* fifo;
	
	// dyn. allocate buffer
	fifo = NutHeapAllocClear(sizeof(bt_acl_pkt_fifo));
	fifo->size = 0;
	fifo->first = NULL;
	fifo->last = NULL;
	return fifo;
}


void bt_acl_pkt_fifo_destroy(bt_acl_pkt_fifo* fifo)
{
	bt_acl_pkt_buf* buf;
	
	while ((buf = fifo->first)) {
		// remove buffer from queue
		fifo->first = buf->next;
		// destroy the buffer
		bt_acl_pkt_buf_destroy(buf);
	}
	
	// free memory
	NutHeapFree(fifo);
}

bt_acl_pkt_buf* bt_acl_pkt_fifo_get_first(bt_acl_pkt_fifo* fifo)
{
	bt_acl_pkt_buf* buf;
	
	// remove first free buffer from the queue of free bufs
	buf = fifo->first;
	if (buf) {
		fifo->first = buf->next;
		fifo->size--;
		buf->next = NULL;
	}
	return buf;
}

bt_acl_pkt_buf* bt_acl_pkt_fifo_top(bt_acl_pkt_fifo* fifo)
{
	return fifo->first;
}

void bt_acl_pkt_fifo_add_first(bt_acl_pkt_fifo* fifo, bt_acl_pkt_buf* buf)
{
	// add fragment passed to the top of the buffer
	buf->next = fifo->first;
	fifo->first = buf;
	// if the buffer was empty, we have to set the pointer to the last buffered
	// fragment
	if (!fifo->size) fifo->last = buf;
	// increment size of the buffer
	fifo->size++;
}

void bt_acl_pkt_fifo_add_last(bt_acl_pkt_fifo* fifo, bt_acl_pkt_buf* buf)
{
	// if the queue is empty we add the buffer to the head of the queue
	if (!fifo->size)
		return bt_acl_pkt_fifo_add_first(fifo, buf);
	// else, we add the buffer to the end of the queue
	fifo->last->next = buf;
	fifo->last = buf;
	buf->next = NULL;
	// increment size of the queue
	fifo->size++;
}
