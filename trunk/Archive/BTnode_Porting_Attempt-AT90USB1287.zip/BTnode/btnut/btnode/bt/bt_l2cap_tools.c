/*
 * Copyright (C) 2000-2006 by ETH Zurich
 * Copyright (C) 2004 by Ole Reinhardt <ole.reinhardt@embedded-it.de>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */
 
 
/* 
 * bt_l2cap_tools.c
 *
 * Implementation of additional functions for the L2CAP layer of BTnut
 * 
 * $Log: bt_l2cap_tools.c,v $
 * Revision 1.3  2006/03/23 07:22:19  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.1.2.1  2006/02/02 08:10:27  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.2  2006/01/17 14:14:30  yuecelm
 * move bt_l2cap_get_outgoing_mtu out of bt_l2cap_tools.c (used in rfcomm.c), enable cvs log
 *
 * 
 */ 

#include <string.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/atom.h>
#include <bt/bt_defs.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>

#ifndef L2CAP_DEBUG 
#define L2CAP_DEBUG 3
#endif

#if     L2CAP_DEBUG >= 3  
#define INFO(text, ...) printf_P(PSTR("L2CAP:" text),## __VA_ARGS__)
#else
#define INFO(text, ...) 
#endif

#if     L2CAP_DEBUG >= 2  
#define WARNING(text, ...) printf_P(PSTR("L2CAP: WARNING:" text),## __VA_ARGS__)
#else
#define WARNING(text, ...) 
#endif

#if     L2CAP_DEBUG >= 1  
#define ERROR(text, ...) printf_P(PSTR("L2CAP: ERROR:" text),## __VA_ARGS__)
#else
#define ERROR(text, ...) 
#endif

u_char bt_l2cap_get_local_cid(u_short channel_id, u_short *cid)
{
    struct bt_l2cap_channel * channel;
    
    channel = _bt_l2cap_get_channel_from_channel_id(channel_id);

    if (channel == NULL)
        return BT_L2CAP_ERR_INVALID_HANDLE;

    *cid = channel->local_cid;
    return BT_L2CAP_ERR_SUCCESS;
}

u_char bt_l2cap_get_remote_cid(u_short channel_id, u_short *cid)
{
    struct bt_l2cap_channel * channel;
    
    channel = _bt_l2cap_get_channel_from_channel_id(channel_id);

    if (channel == NULL)
        return BT_L2CAP_ERR_INVALID_HANDLE;

    *cid = channel->remote_cid;
    return BT_L2CAP_ERR_SUCCESS;
}

u_char bt_l2cap_get_incomming_mtu(u_short channel_id, u_short *mtu)
{
    struct bt_l2cap_channel * channel;
    
    channel = _bt_l2cap_get_channel_from_channel_id(channel_id);

    if (channel == NULL)
        return BT_L2CAP_ERR_INVALID_HANDLE;

    *mtu = channel->imtu;
    return BT_L2CAP_ERR_SUCCESS;
}

u_char bt_l2cap_get_hci_connection_handle(u_short channel_id, bt_hci_con_handle_t *con_handle)
{
    struct bt_l2cap_service * service;
    
    service = _bt_l2cap_get_service_from_channel_id(channel_id);
    
    if (service == NULL)
        return BT_L2CAP_ERR_INVALID_HANDLE;
 
    *con_handle = service->con_handle;
    return BT_L2CAP_ERR_SUCCESS;
}

u_char bt_l2cap_is_ch_open(u_short channel_id)
{
    return (_bt_l2cap_get_channel_from_channel_id(channel_id) != NULL);
}

u_char bt_l2cap_l2ping(bt_addr_t bt_addr, u_char *payload, u_short len, u_long *time)
{
    bt_hci_con_handle_t con_handle;
    struct bt_l2cap_signal *signal = (struct bt_l2cap_signal *) &l2cap_stack->tmp_pkt->payload;    

    long retval;
        
    if (len + BT_L2CAP_HEADER_LEN + BT_L2CAP_SIG_HEADER_LEN > l2cap_stack->acl_len)
    {
        ERROR("Payload lengths exeeds max acl packet size\n");
        return BT_L2CAP_ERR_PAYLOAD_LEN;
    }

    if (echo_cmd.id) {
        WARNING("Ping pending\n");
        return BT_L2CAP_ERR_PING_PENDING;
    }

    retval = bt_hci_get_con_handle(l2cap_stack->bt_stack, bt_addr);
    if (retval == BT_ERR_NO_CON)
    {
        if (l2cap_stack->bb_connections == BT_HCI_MAX_NUM_CON)
        {
            ERROR("Can not create new bb connection. Maximum number of connections just opend.\n");
            return BT_L2CAP_ERR_BB_CON_FAILED;
        }
            
        retval = bt_hci_create_connection(l2cap_stack->bt_stack, BT_HCI_SYNC, bt_addr, l2cap_stack->pkt_types,
                                         0, 0, BT_HCI_ROLE_SWITCH_MASTER);

        if (retval >= 0) {
            con_handle = retval;
        } else 
        {
            ERROR("Opening baseband connection failed\n");
            return BT_L2CAP_ERR_BB_CON_FAILED;
        }
    } else con_handle = retval;
    
    *time = NutGetMillis();

    echo_cmd.id = _bt_l2cap_get_new_sigid(_bt_l2cap_handle2baseband(con_handle));
    
    l2cap_stack->tmp_pkt->cid[0] = (u_char) (BT_L2CAP_CID_SIG & 0xFF);
    l2cap_stack->tmp_pkt->cid[1] = (u_char) (BT_L2CAP_CID_SIG >> 8);
    
    l2cap_stack->tmp_pkt->len[0] = (u_char)((len + BT_L2CAP_SIG_HEADER_LEN) & 0xFF);
    l2cap_stack->tmp_pkt->len[1] = (u_char)((len + BT_L2CAP_SIG_HEADER_LEN) >> 8);
    signal->id = echo_cmd.id;
    signal->len[0] = (u_char) (len & 0xFF);
    signal->len[1] = (u_char) (len >> 8);
    signal->code = BT_L2CAP_SIG_ECHO_REQ;
    memcpy(signal->payload, payload, len);

    bt_hci_send_acl_pkt(l2cap_stack->bt_stack, con_handle, HCI_PB_FIRST_FRAGMENT, HCI_BC_UNICAST,
                    (l2cap_stack->tmp_pkt->len[0] | (l2cap_stack->tmp_pkt->len[1] << 8)) + BT_L2CAP_HEADER_LEN, (struct bt_hci_pkt_acl *) (l2cap_stack->tmp_pkt));

    if (NutEventWait(&echo_cmd.echo_ev, BT_L2CAP_SIGNAL_TIMEOUT) != 0)
    {  
        ERROR("Timeout on ping request\n");
        time = 0;
        return BT_L2CAP_ERR_TIMEOUT;
    }
    
    *time = NutGetMillis() - *time;
    return BT_L2CAP_ERR_SUCCESS;
}
