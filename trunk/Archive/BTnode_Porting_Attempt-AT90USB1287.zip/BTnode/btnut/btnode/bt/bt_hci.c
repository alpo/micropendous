/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * @file bt_hci.c
 *
 * @brief HCI statemachine.
 * 
 * \author Mathias Payer <payerm@student.ethz.ch>
 * 
 * \date 2004/04/18 13:07:09
 * 
 * $Log: bt_hci.c,v $
 * Revision 1.81  2007/01/05 16:27:10  yuecelm
 * add bt_hw_[shutdown|startup] to clean up BT stack and power down temporary the
 * BT module, update doc
 *
 * Revision 1.80  2006/11/06 11:14:53  yuecelm
 * bt_reset: remove unnecessary Nut*Critical, disable disconnections before reset
 *
 * Revision 1.79  2006/10/26 13:25:10  kevmarti
 * - Included syslog debug definitions
 *
 * Revision 1.78  2006/10/23 10:55:58  kevmarti
 * Modified some debugging statements
 *
 * Revision 1.77  2006/09/25 14:37:40  kevmarti
 * Enabled auto-acception of connection requests by default.
 *
 * Revision 1.76  2006/09/19 13:48:39  kevmarti
 * disabled connection auto-accept (we need to test it first)
 *
 * Revision 1.75  2006/09/19 13:30:41  kevmarti
 * - removed acl link semaphore
 * - removed acl pkt mutex
 * - enabled auto-acception of connection events (for test reasons)
 *
 * Revision 1.74  2006/09/10 20:16:57  yuecelm
 * add INFO logs to determine the address of each bt_semaphore,
 * improve bt_hw_reset (reject incoming connections during reset,
 * try first HCI disconnections)
 *
 * Revision 1.73  2006/08/31 15:14:10  yuecelm
 * bt_hw_reset: also acquire and release the inquiry semaphore
 *
 * Revision 1.72  2006/08/30 12:12:56  yuecelm
 * improved bt_hw_reset: performs it thread-safe,
 * all non-connection-related HCI commands from other threads
 * are hold until after the reset procedure
 *
 * Revision 1.71  2006/08/29 15:44:18  freckle
 * moved post on cmd queue and packet statistics where they belong
 *
 * Revision 1.70  2006/08/21 11:04:12  yuecelm
 * add bt_hw_reset (invokes a hardware reset of the Bluetooth module)
 *
 * Revision 1.69  2006/08/07 11:27:18  yuecelm
 * remember host properties (baudrate, name, cod...)
 * to recover the same state after a reset
 *
 * Revision 1.68  2006/07/07 12:46:23  yuecelm
 * little refactoring: add function bt_setup(), split bt_hci_init()
 *
 * Revision 1.67  2006/04/05 11:00:04  kevmarti
 * chanded DEBUG_STR statements back to DEBUG statements because it is not necessary to use DEBUG_STR: the strings to print are constant during runtime
 *
 * Revision 1.66  2006/04/05 05:32:46  dyerm
 * changed DEBUG statements that use %s to DEBUG_STR
 *
 * Revision 1.65  2006/03/28 23:26:09  olereinhardt
 * Changed some string variables in signedness in order to make it compiling with avr-gcc 4.0.2
 *
 * Revision 1.64  2006/03/27 14:15:35  kevmarti
 * Reverted changes in hci acl data callback & changes 'l2cap.c'
 *
 * Revision 1.63  2006/03/23 07:22:19  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.62.2.5  2006/03/22 09:34:47  kevmarti
 * Added callback argument to con table change callback
 *
 * Revision 1.62.2.4  2006/03/20 09:45:49  kevmarti
 * Adapted to new logging / terminal printing macros
 *
 * Revision 1.62.2.3  2006/02/21 13:58:31  kevmarti
 * - Restored original state to reduce changes compared to HEAD
 * - adapted to new interface of bt_hci_get_pkt
 *
 * Revision 1.62.2.2  2006/02/06 13:35:15  dyerm
 * accept con callback filter now has an optional argument that can be registered
 *
 * Revision 1.62.2.1  2006/02/01 15:08:03  kevmarti
 * - Moved 'bt_hci_send_pkt()' to separated ACL-layer
 * - Smaller adaptions due to the separation of the ACL-layer
 * - Added bt-stack hci debug info to the system-wide logging service
 *
 * Revision 1.62  2005/10/06 09:27:19  lwinterhalter
 * Simple Bluetooth packet statistics added.
 *
 * Revision 1.61  2005/06/13 15:56:56  hobid
 * Added bt_hci_set_event_mask.
 *
 * Revision 1.60  2005/06/10 16:22:23  freckle
 * added comment why the sending of accept connection requests or accept pin
 * code request won't block
 *
 * Revision 1.59  2005/06/10 16:15:15  freckle
 * Removed earlier hack (NutDelay) in HCI thread
 *
 * Revision 1.58  2005/06/10 15:08:22  freckle
 * Explicitly initialized semaphores in bt_hci_init
 * moved code around a bit
 *
 * Revision 1.57  2005/06/06 12:09:27  hobid
 * Fixed PIN Code handling / Pairing.
 *
 * Revision 1.56  2005/06/03 14:15:27  olereinhardt
 * removed debug output
 *
 * Revision 1.55  2005/06/03 14:03:35  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.54  2005/04/19 18:26:33  beutel
 * added debug flags and more rfcommpin code stuff
 *
 * Revision 1.53  2005/04/15 12:24:03  beutel
 * added link key requests and more pin code stuff
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/heap.h>
#include <sys/atom.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_event.h>
#include <bt/bt_hci_dispatch.h>
#include <debug/syslog.h>
#include <debug/toolbox.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

bt_addr_t bt_addr_null = { 0, 0, 0, 0, 0, 0 };
bt_hci_con_handle_t bt_hci_app_con_handle_counter;

/**
 * Discards the acl pkt and returns
 * This is the default callback for acl data (gets overwritten bei l2cap)
*/
struct bt_hci_pkt_acl *_acl_null(void* arg,
									struct bt_hci_pkt_acl *pkt,
									bt_hci_con_handle_t app_con_handle,
									u_char pb_flag,
									u_char bc_flag,
									u_short len,
									u_long t_arrive)
{
    long retval;
    // Free this pkt!
    retval = bt_hci_acl_free_buffer((struct btstack *) arg, app_con_handle, 1);
    DEBUG("Acl pkt. from handle %d with pb=%d, bc=%c of len %d dropped (&pkt. freed: %ld)\n", app_con_handle, pb_flag, bc_flag, len,
          retval);
    return pkt;
}

/**
 * Discards the sco pkt and returns
*/
struct bt_hci_pkt_sco *_sco_null(void *arg, struct bt_hci_pkt_sco *pkt, bt_hci_con_handle_t app_con_handle, u_char len)
{
    DEBUG("Sco pkt. from handle %d of len %d dropped\n", app_con_handle, len);
    return pkt;
}

void _con_table_null(u_char type, u_char detail, bt_hci_con_handle_t app_con_handle, void* cb_arg)
{
    switch (type) {
    case BT_HCI_MY_ROLE_MASTER:
        DEBUG("CB: My role switched to master (%d)\n", app_con_handle);
        break;
    case BT_HCI_MY_ROLE_SLAVE:
        DEBUG("CB: My role switched to slave (%d)\n", app_con_handle);
        break;
    case BT_HCI_CONNECTION:
        DEBUG("CB: Connection opened (%d)\n", app_con_handle);
        break;
    case BT_HCI_DISCONNECTION:
        DEBUG("CB: Disconnected (%d)\n", app_con_handle);
        break;
    default:
        DEBUG("Illegal type entered! (%d)\n", type);
    }
}

/**
 * Default filter that rejects all connections.
 */
void _reject_con_null(bt_addr_t addr, u_long cod, u_char type, void* arg)
{
}

THREAD(bt_hci_thread, arg)
{
    struct btstack *stack = arg;
    u_char *ptr;
    u_char i;
    _bt_hci_module_con_handle_t module_con_handle;      //con handle for module
    bt_hci_con_handle_t app_con_handle; //unique con handle for application
    u_short len;
    u_char pb_flag;
    u_char bc_flag;
    u_long t_arrive;

    // DEBUG("- Entering Loop...\n");
    while (1) {
        DEBUG("bt_hci: before read pkt...\n");
        ptr = _bt_hci_get_pkt(stack, &len, &t_arrive);
        DEBUG("bt_hci: after read pkt...\n");

        // Handle incoming packets
        if (ptr != 0) {
            switch (ptr[0]) {
            case HCI_EVENT_PACKET:
                // Dispatch the event.
                _bt_hci_handle_event(stack, (struct bt_hci_pkt_evt *) ptr);
                break;
            case HCI_ACL_DATA_PACKET:
                //Use callback (with acl-pkt)
                module_con_handle = (ptr[2] & 0xF) << 8 | ptr[1];
                pb_flag = (ptr[2] >> 4) & 3;
                bc_flag = (ptr[2] >> 6) & 3;
				app_con_handle = _bt_hci_get_app_con_handle(stack, module_con_handle);
				// write app con handle to the acl header
				ptr[1] = BTN_LO(app_con_handle);
				ptr[2] = BTN_HI(app_con_handle) | (ptr[2] & 0xF0);
				DEBUG("acl pkt! mhdl: %d, ahdl: %d, pb: %d, bc: %d\n",
					  module_con_handle, app_con_handle, pb_flag, bc_flag);
                stack->acl_pkt =
                    stack->hci_acl_cb(stack->hci_acl_cb_arg,
                    					(struct bt_hci_pkt_acl *) ptr,
                    					app_con_handle,
                    					pb_flag,
                    					bc_flag,
                    					len,
                    					t_arrive);
#ifdef BT_PKT_STATS
                // update pkt stats
                stack->acl_pkt_stat.rx.pkts++;
                stack->acl_pkt_stat.rx.bytes+=len;
#endif
                break;
            case HCI_SCO_DATA_PACKET:
                //Use callback (with sco-pkt)
                module_con_handle = (ptr[2] & 0xF) << 8 | ptr[1];
                app_con_handle = _bt_hci_get_app_con_handle(stack, module_con_handle);
                // DEBUG("-- SCO-DATA RECEIVED mapping: %d -> %d\n\n", module_con_handle, app_con_handle);
                // TODO: figure out, if there are things like packet boundary and broadcast for sco packets
                // TODO: if yes, communicate them to application
                stack->sco_pkt = stack->hci_sco_cb(stack, (struct bt_hci_pkt_sco *) ptr, app_con_handle, len);
                break;
            default:
                ERROR("thread: Something strange received 0x%2x\n", ptr[0]);
                break;
            }
        }

        /** (MR) Mental node to myself: Why this code will not block...
            -- after receiving a connection request, we try to send an accept connection request
            -- if there has been no commands waiting -> OK
            -- if there has been a  command  waiting, we won't send now. whatever this command is/was, there will
                  be an event to indicate that the command is completed. In this case we're pass here again... -> OK
         */
        
        if (stack->conn_request != 0) { // There are requests pending
            for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {  // Find these requests and handle them!

                /** (MR) unclean solution: we should not block during sending this command 
                         implemented workaround: we check first if everything is ready 
                  */

                // cmd-packet ready and nr-hci_cmds also ok?
                if ((stack->hci_cmd_queue.counter > 0) && (stack->nr_hci_cmds.counter > 0)) {

                    if (stack->connection[i].state == BT_HCI_CONN_STATE_ACK) {
                        // accept the connection per default, and stay slave
                        DEBUG("Accept connection request! \n");
                        stack->connection[i].state = BT_HCI_CONN_STATE_WAITPAS;
                        bt_hci_accept_connection_request(stack, stack->connection[i].bdaddr, stack->connection[i].role);
                        stack->conn_request--;
                    }
                }
            }
        }
        
        if (stack->pin_request != 0) {  // There are requests pending

            for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {  // Find these requests and handle them!

                /** (MR) unclean solution: we should not block during sending this command 
                         implemented workaround: we check first if everything is ready 
                  */
                // cmd-packet ready and nr-hci_cmds also ok?
                if ((stack->hci_cmd_queue.counter > 0) && (stack->nr_hci_cmds.counter > 0)) {
                    if (stack->connection[i].auth == BT_HCI_AUTH_NONE) {
                        // accept the pin code request
                        DEBUG("Accepting pin code request! \n");
                        len = strlen(BTN_DEFAULT_PIN);
                        DEBUG("Sending pin code %s with length %x\n", BTN_DEFAULT_PIN, len);

                        /* the bt module will pass back a bt address */
                        bt_addr_t addr;
                        memcpy( addr, stack->connection[i].bdaddr, BD_ADDR_LEN);
                        if( bt_hci_pin_code_request_reply(stack,stack->connection[i].app_con_handle,addr,len,(u_char*)BTN_DEFAULT_PIN) == 0) {
                            stack->connection[i].auth = BT_HCI_AUTH_SENTPINRESP;
                            stack->pin_request--;
                        }
                    }
                }
            }

        }
        // and give other threads a chance!
        NutThreadYield();
    }
}

void bt_setup(struct btstack *stack)
{
    long retval;
    struct param_list * params = &(stack->params);

    // Reset controller
    DEBUG("Calling Reset\n");
    retval = bt_hci_reset(stack, BT_HCI_SYNC);
    DEBUG("Reset: %ld\n", retval);

    if (params->event_mask != NULL) {
        DEBUG("event_mask available\n");
        retval = bt_hci_set_event_mask(stack, BT_HCI_SYNC,
                                       params->event_mask->mask_high,
                                       params->event_mask->mask_low);
    } else {
        // Return all except Link Key Requests
        retval = bt_hci_set_event_mask(stack, BT_HCI_SYNC,
                                       BT_HCI_DEFAULT_EVENT_MASK_HIGH,
                                       BT_HCI_DEFAULT_EVENT_MASK_LOW & 
                                           ~BT_HCI_EVENT_LINK_KEY_REQUEST);
    }
    DEBUG("Set event mask: %ld\n", retval);

    if (params->event_filter != NULL) {
        DEBUG("event_filter available\n");
        retval = _bt_hci_set_event_filter_bytearray(stack, BT_HCI_SYNC, params->event_filter);
    } else {
        retval = bt_hci_set_event_filter(stack, BT_HCI_SYNC, 0x01, 0x00);
        // enable auto acception of incoming connections
        retval += bt_hci_set_event_filter(stack, BT_HCI_SYNC, 0x02, 0x00, 0x02);
        stack->con_rqst_cb = NULL;
    }
    DEBUG("Set event filter: %ld\n", retval);
    
    if (params->connection_accept_timeout != NULL) {
        DEBUG("connection_accept_timeout available\n");
        retval = bt_hci_write_connection_accept_timeout(stack, BT_HCI_SYNC, 
                                        *(params->connection_accept_timeout));        
    } else {
        // Set default conn.accept timeout (default from btspec)
        retval = bt_hci_write_connection_accept_timeout(stack, BT_HCI_SYNC, 
                                                        0x1F40);
    }
    DEBUG("Set conn.accept timeout: %ld\n", retval);

    if (params->page_timeout != NULL) {
        DEBUG("page_timeout available\n");
        retval = bt_hci_write_page_timeout(stack, BT_HCI_SYNC, 
                                           *(params->page_timeout));        
    } else {
        // Set default page timeout (default from btspec)
        retval = bt_hci_write_page_timeout(stack, BT_HCI_SYNC, 0x2000);
    }
    DEBUG("Set page timeout: %ld\n", retval);

    if (params->scan_enable != NULL) {
        DEBUG("scan_enable available\n");
        retval = bt_hci_write_scan_enable(stack, BT_HCI_SYNC, 
                                          *(params->scan_enable));        
    } else {
        // Set default write scan timeout
        retval = bt_hci_write_scan_enable(stack, BT_HCI_SYNC,
                                          BT_HCI_SCAN_MODE_INQUIRY_PAGE);
    }
    DEBUG("Set scan enable: %ld\n", retval);

    if (params->flowcontrol != NULL) {
        DEBUG("flowcontrol_type available\n");
        retval = bt_hci_set_flowcontrol(stack, BT_HCI_SYNC, 
                                        *(params->flowcontrol));
    } else {
        // Set default flowcontrol type
#if (BT_RADIO_TYPE != ZEEVO)
        retval = bt_hci_set_flowcontrol(stack, BT_HCI_SYNC, 
                                        BT_HCI_FLOWCONTROL_ACL);
#else
        retval = bt_hci_set_flowcontrol(stack, BT_HCI_SYNC,
                                        BT_HCI_FLOWCONTROL_OFF);
#endif
    }
    DEBUG("Set flow control: %ld\n", retval);

    if (params->inquiry_mode != NULL) {
        DEBUG("inquiry_mode available\n");
        retval = bt_hci_write_inquiry_mode(stack, BT_HCI_SYNC, 
                                           *(params->inquiry_mode));
        DEBUG("Set inquiry mode: %ld\n", retval);
    } else {
#if (BT_RADIO_TYPE == ZEEVO)
        // Set Inquiry type to include rssi
        retval = bt_hci_write_inquiry_mode(stack, BT_HCI_SYNC, 
                                           BT_HCI_INQUIRY_MODE_RSSI);
        DEBUG("Set inquiry mode: %ld\n", retval);
#endif
    }        
    
    if (params->inquiry_scan_type != NULL) {
        DEBUG("inquiry_scan_type available\n");
        retval = bt_hci_write_inquiry_scan_type(stack, BT_HCI_SYNC,
                                                *(params->inquiry_scan_type));
        DEBUG("Set inquiry scan type: %ld\n", retval);
    } else {
#if (BT_RADIO_TYPE == ZEEVO)
        retval = bt_hci_write_inquiry_scan_type(stack, BT_HCI_SYNC,
                                                BT_HCI_INQUIRY_SCAN_INTERLACED);
#endif  
    }
    
    if (params->default_link_policy_settings != NULL) {
        DEBUG("default_link_policy_settings available\n");
        retval = bt_hci_write_default_link_policy_settings(stack, BT_HCI_SYNC, 
                                    *(params->default_link_policy_settings));
        DEBUG("Set default link policy settings: %ld\n", retval);        
    }
    
    if (params->host_buffer_size != NULL) {
        DEBUG("host_buffer_size available\n");
        retval = bt_hci_host_buffer_size(stack, BT_HCI_SYNC,
                                         params->host_buffer_size->acl_max_len,
                                         params->host_buffer_size->sco_max_len,
                                         params->host_buffer_size->nr_acl_pkts,
                                         params->host_buffer_size->nr_sco_pkts);
        DEBUG("Set host buffer size: %ld\n", retval);
    }
    
    if (params->local_cod != NULL) {
        DEBUG("local_cod available\n");
        retval = bt_hci_write_local_cod(stack, BT_HCI_SYNC, 
                                        *(params->local_cod));
        DEBUG("Set local cod: %ld\n", retval);
    }
    
    if (params->local_name != NULL) {
        DEBUG("local_name available\n");
        retval = bt_hci_write_local_name(stack, BT_HCI_SYNC, params->local_name);
        DEBUG("Set local name: %ld\n", retval);
    }
    
    if (params->pin_type != NULL) {
        DEBUG("pin_type available\n");
        retval = bt_hci_write_pin_type(stack, BT_HCI_SYNC, *(params->pin_type));
        DEBUG("Set pin type: %ld\n", retval);
    }

    if (params->baudrate != NULL) {
        DEBUG("baudrate available\n");
        retval = bt_hci_set_baudrate(stack, *(params->baudrate));
        DEBUG("Set UART: %ld\n", retval);           
    } else {
#if (BT_RADIO_TYPE == ZEEVO)
        // TODO: UART communication with BT currently fails if 115200 or higher is used
        // remove this line, after this is fixed. Its in ZEEVO only, as ERICSSON has 57600 as default
        retval = bt_hci_set_baudrate(stack, BT_HCI_B57600);
        DEBUG("Set UART to 57600: %ld\n", retval);
#endif  
    }    

    // Read buffer sizes
    retval = bt_hci_read_buffer_size(stack, BT_HCI_SYNC);
    DEBUG("Read buffer size: %ld\n", retval);
}

void * bt_hw_shutdown(struct btstack * stack)
{
#if defined(__BTNODE3__)
    HCI_CON_RQST_CB;
    //bt_hci_con_handle_array con_handles;
    //long res, nr_con_handles;
    u_char i;

    //--- check if another bt_hw_reset is running

    if (stack->hw_reset != NULL)
        return (void *) -1;

    stack->hw_reset = runningThread;

    //--- hold on hci command packets

    DEBUG("before acquire hci_cmd_queue, single_cmd and inquiry\n");
    _bt_semaphore_wait(&(stack->hci_cmd_queue));
    // I dont exactly know which semaphores have to be acquired
    // to guarantee the expiration of the last command
    //_bt_semaphore_wait(&(stack->nr_hci_cmds));
    _bt_semaphore_wait(&(stack->single_cmd)); // wait until last cmd is replied
    _bt_semaphore_wait(&(stack->inquiry)); // wait until inquiry is finished
    DEBUG("after acquire hci_cmd_queue, single_cmd and inquiry\n");
    //_bt_semaphore_post(&(stack->nr_hci_cmds));
    _bt_semaphore_post(&(stack->single_cmd));
    _bt_semaphore_post(&(stack->inquiry));

    //--- reject all incoming connections

    con_rqst_cb = stack->con_rqst_cb;
    stack->con_rqst_cb = _reject_con_null;

    /*
    // MY: only enable the disconnection procedure,
    // if some event timeout is implemented and enabled

    //--- disconnects

    INFO("try HCI disconnects...\n");
    nr_con_handles = bt_hci_get_con_handles(stack, con_handles);
    for (i = 0; i < nr_con_handles; i++)
    {
        res = bt_hci_disconnect(stack, BT_HCI_SYNC, con_handles[i],
                                BT_HCI_DISCONNECT_POWER_DOWN);
        INFO("con_handle %d disconnect: %ld\n", con_handles[i], res);
    }
    */

    //--- set baudrate to default

#if (BT_RADIO_TYPE == ZEEVO)
    INFO("set baudrate to 115200 (default after reset)...\n");
    _bt_hci_lowlevel_set_baudrate(_fileno(stack->transport.uart), 115200);

    //--- prepare to reset

    stack->transport.reset_pending = 1;
#endif

    INFO("power off BT module...\n");
    btn_hardware_bt_power_off();

    //--- clean up connection table

    stack->conn_request = 0;
    stack->pin_request = 0;

    INFO("emulate disconnects...\n");
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++)
    {
        if (stack->connection[i].state != BT_HCI_CONN_INVALID)
        {
            DEBUG("con_handle %d:\n", stack->connection[i].app_con_handle);
            stack->connection[i].module_con_handle = BT_HCI_HANDLE_INVALID;
            if (stack->connection[i].app_con_handle != BT_HCI_HANDLE_INVALID)
            {
                while (_bt_hci_wakeup(stack, 0xffff,
                                      stack->connection[i].app_con_handle,
                                      BT_ERR_BT_MODULE) != -1)
                {
                    DEBUG("  wake up\n");
                }
                // trigger connection table callback if connected
                if (stack->connection[i].state == BT_HCI_CONN_STATE_OPEN)
                {
                    DEBUG("  callback\n");
                    stack->con_table_cb(BT_HCI_DISCONNECTION,
                                        BT_HCI_DISCON_LINK_LOST,
                                        stack->connection[i].app_con_handle,
                                        stack->con_change_cb_arg);
                }
                stack->connection[i].app_con_handle = BT_HCI_HANDLE_INVALID;
            }
            stack->connection[i].state = BT_HCI_CONN_INVALID;
            DEBUG("  done!\n");
        }
    }

    return con_rqst_cb;
#else
    return NULL;
#endif
}

void bt_hw_startup(struct btstack * stack, HCI_CON_RQST_CB)
{
#if defined(__BTNODE3__)
    if ((stack->hw_reset == NULL) || (con_rqst_cb == (void *) -1))
        return;

    INFO("power on BT module...\n");
    btn_hardware_bt_power_on();

    //--- setup host parameters

    INFO("setup BT module...\n");
    bt_setup(stack);

    //--- set old accept_con callback

    INFO("register old accept_con callback...\n");
    stack->con_rqst_cb = con_rqst_cb;

    _bt_semaphore_post(&(stack->hci_cmd_queue));

    stack->hw_reset = NULL;
#endif
}

void bt_hw_reset(struct btstack * stack)
{
#if defined(__BTNODE3__)
    HCI_CON_RQST_CB;
    
    con_rqst_cb = bt_hw_shutdown(stack);

    if (con_rqst_cb != (void *) -1)
    {
        NutSleep(1000);

        bt_hw_startup(stack, con_rqst_cb);

        INFO("hw_reset finished.\n");
    }
    else
    {
        WARNING("hw_reset failed.\n");
    }
#endif  
}

/******************************************************************************
 * bt_hci_init
 ******************************************************************************/
struct btstack *bt_hci_init(void *transport)
{
    long retval;
    struct btstack *stack;
    
    //alloc stack
    stack = NutHeapAllocClear(sizeof(struct btstack));
    if (stack == NULL) {
        ERROR("alloc memory\n");
        return NULL;
    }
    // Initialize the stack
    DEBUG("bt_hci_main\n");
    stack->transport.hwdev = transport;
    
    // explicitly initialize semaphores
    _bt_semaphore_init(&(stack->nr_acl_pkts), 0);
    INFO("nr_acl_pkts: %p\n", &(stack->nr_acl_pkts));
    _bt_semaphore_init(&(stack->nr_sco_pkts), 0);
    INFO("nr_sco_pkts: %p\n", &(stack->nr_sco_pkts));

    // Initialize inquiry queue
    _bt_semaphore_init(&(stack->inquiry), 1);
    INFO("inquiry: %p\n", &(stack->inquiry));
    
    retval = _bt_hci_initdev(stack);
    DEBUG("- UART init: %ld\n", retval);

    // Init the connid with 1 (this value gets inc'ed, with every new conn.)
    bt_hci_app_con_handle_counter = 1;

    // Initialize the packets and semaphores: nr_hci_cmds, hci_cmd_queue, inquiry, single_cmd
    DEBUG("- init stack-pkts\n");
    _bt_hci_pkts_init(stack);

    // And register the callbacks
    DEBUG("- Register (null) callbacks\n");
    bt_hci_register_acl_cb(stack, &_acl_null, 0x0, 0);
    bt_hci_register_sco_cb(stack, &_sco_null, 0x0);
    bt_hci_register_con_table_cb(stack, _con_table_null, NULL);

    DEBUG("Creating Thread...\n");
    NutThreadCreate("BTStack", bt_hci_thread, stack, 1024);

    bt_setup(stack);

    // Read BT address
    retval = bt_hci_read_bt_addr(stack, BT_HCI_SYNC, stack->bt_addr);
    DEBUG("Read BT address: "ADDR_FMT"\n", ADDR(stack->bt_addr));

    return stack;
}

/*******************************************************************************
 * bt_hci_register_acl_cb
 ******************************************************************************/
void bt_hci_register_acl_cb(struct btstack *stack, HCI_ACL_CB, struct bt_hci_pkt_acl *pkt, void *arg)
{
	// set callback & cb arg
    stack->hci_acl_cb = hci_acl_cb;
    stack->hci_acl_cb_arg = arg;
    stack->acl_pkt = pkt;
}


/*******************************************************************************
 * bt_hci_send_acl_pkt
 ******************************************************************************/
long bt_hci_send_acl_pkt(struct btstack *stack, bt_hci_con_handle_t app_con_handle, u_char pb_flag, u_char bc_flag, u_short length,
                         struct bt_hci_pkt_acl *pkt)
{
    u_char con;
    // Get the external con_handle & increase the number of uncompleted packages
    for (con = 0; con < BT_HCI_MAX_NUM_CON; con++) {
        if (stack->connection[con].app_con_handle == app_con_handle) {
            break;
        }
    }
    // The connection is invalid
    if (con == BT_HCI_MAX_NUM_CON)
        return BT_ERR_NO_CON;

    // The connection exists in the table, but it is not in an open state!
    if (stack->connection[con].state != BT_HCI_CONN_STATE_OPEN)
        return BT_ERR_NO_CON;

    _bt_semaphore_wait(&(stack->nr_acl_pkts));

    stack->connection[con].pkts_h2c += 1;

    pkt->type = HCI_ACL_DATA_PACKET;
    pkt->header[0] = BTN_LO(stack->connection[con].module_con_handle);
    pkt->header[1] = BTN_HI(stack->connection[con].module_con_handle) | (pb_flag & 3) << 4 | (bc_flag & 3) << 6;
    pkt->header[2] = BTN_LO(length);
    pkt->header[3] = BTN_HI(length);

#ifdef BT_PKT_STATS
    // update pkt stats
    stack->acl_pkt_stat.tx.pkts++;
    stack->acl_pkt_stat.tx.bytes+=length;
#endif
    
    return _bt_hci_send_pkt(stack, (u_char *) pkt);
}


/*******************************************************************************
 * bt_hci_register_sco_cb
 ******************************************************************************/
void bt_hci_register_sco_cb(struct btstack *stack, HCI_SCO_CB, struct bt_hci_pkt_sco *pkt)
{
    stack->hci_sco_cb = hci_sco_cb;
    stack->sco_pkt = pkt;
}


/*******************************************************************************
 * bt_hci_register_con_table_cb
 ******************************************************************************/
void bt_hci_register_con_table_cb(struct btstack *stack, HCI_CON_TABLE_CB, void* cb_arg)
{
    stack->con_table_cb = con_table_cb;
    stack->con_change_cb_arg = cb_arg;
}

/*******************************************************************************
 * bt_hci_register_accept_con_cb
 ******************************************************************************/
void bt_hci_register_accept_con_cb(struct btstack *stack, HCI_CON_RQST_CB, void* arg)
{
    stack->con_rqst_cb = con_rqst_cb;
    stack->con_rqst_cb_arg = arg;
}
