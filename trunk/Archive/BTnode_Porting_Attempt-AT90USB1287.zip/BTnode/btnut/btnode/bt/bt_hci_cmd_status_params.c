/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */
 
 /**
 * @file bt_hci_cmd_status_params.c
 *
 * @brief Deals with status parameter hci-cmds
 * 
 *
 * 2004/05/04 Mathias Payer <payerm@student.ethz.ch>
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/event.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

/*******************************************************************************
 * bt_hci_get_link_quality
 ******************************************************************************/
long bt_hci_get_link_quality(struct btstack *stack,  struct bt_hci_cmd_response *response, bt_hci_con_handle_t app_con_handle, u_char* link_quality)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
  _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
  if (module_con_handle == BT_HCI_HANDLE_INVALID) return BT_ERR_NO_CON;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_STATUS_PARAMS, HCI_OCF_SP_GET_LINK_QUALITY);
	
	wcmdpointer->response = 0;
	wcmdpointer->ptr = link_quality;

	stack->cmd.payload[2] = 0x02; // cmd-length
	stack->cmd.payload[3] = BTN_LO(module_con_handle);
	stack->cmd.payload[4] = BTN_HI(module_con_handle);
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_STATUS_PARAMS, HCI_OCF_SP_GET_LINK_QUALITY),app_con_handle);
}



/*******************************************************************************
 * bt_hci_read_rssi
 ******************************************************************************/
long bt_hci_read_rssi(struct btstack *stack,  struct bt_hci_cmd_response *response, bt_hci_con_handle_t app_con_handle, short* rssi)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
  _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
  if (module_con_handle == BT_HCI_HANDLE_INVALID) return BT_ERR_NO_CON;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_STATUS_PARAMS, HCI_OCF_SP_READ_RSSI);
	
	wcmdpointer->response = 0;
	wcmdpointer->ptr = rssi;

	stack->cmd.payload[2] = 0x02; // cmd-length
	stack->cmd.payload[3] = BTN_LO(module_con_handle);
	stack->cmd.payload[4] = BTN_HI(module_con_handle);
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_STATUS_PARAMS, HCI_OCF_SP_READ_RSSI),app_con_handle);
}

/*******************************************************************************
 * bt_hci_read_abs_rssi
 ******************************************************************************/
long bt_hci_read_abs_rssi(struct btstack *stack,  struct bt_hci_cmd_response *response, bt_hci_con_handle_t app_con_handle, char* abs_rssi)
{
	struct bt_hci_cmd_response wcmd, *wcmdpointer;
  _bt_hci_module_con_handle_t module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
  if (module_con_handle == BT_HCI_HANDLE_INVALID) return BT_ERR_NO_CON;
	
	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_VENDOR_COMMANDS, HCI_OCF_VC_ZEEVO_READ_ABSOLUTE_RSSI);
	
	wcmdpointer->response = 0;
	wcmdpointer->ptr = abs_rssi;

	stack->cmd.payload[2] = 0x02; // cmd-length
	stack->cmd.payload[3] = BTN_LO(module_con_handle);
	stack->cmd.payload[4] = BTN_HI(module_con_handle);
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_VENDOR_COMMANDS, HCI_OCF_VC_ZEEVO_READ_ABSOLUTE_RSSI),app_con_handle);
}

/*******************************************************************************
* bt_hci_read_clock
******************************************************************************/
long bt_hci_read_clock(struct btstack *stack,  struct bt_hci_cmd_response *response, u_char which_clock,
                                       bt_hci_con_handle_t app_con_handle, u_short *accuracy)
{
    _bt_hci_module_con_handle_t module_con_handle = 0;
	struct bt_hci_cmd_response wcmd, *wcmdpointer;

    // get module handle for remote clock 
    if (which_clock == 1) {
         module_con_handle = _bt_hci_get_module_con_handle(stack, app_con_handle);
        if (module_con_handle == BT_HCI_HANDLE_INVALID) return BT_ERR_NO_CON;
    }

    /** register BT_HCI_HANDLE_INVALID in table */
    app_con_handle = BT_HCI_HANDLE_INVALID;

	// Init & wait 'till the pkt can be sent
	wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, response, &(stack->cmd), HCI_OGF_STATUS_PARAMS, HCI_OCF_SP_READ_CLOCK);
	
	wcmdpointer->response = 0;
	wcmdpointer->ptr = accuracy;
    
	stack->cmd.payload[2] = 0x03; // cmd-length
	stack->cmd.payload[3] = BTN_LO(module_con_handle);
	stack->cmd.payload[4] = BTN_HI(module_con_handle);
	stack->cmd.payload[5] = which_clock;
	
	// Send the pkt, wait if necessary and return the return value or an error
	return _bt_hci_outro_cmd(stack, wcmdpointer, response, SET_OGF_OCF(HCI_OGF_STATUS_PARAMS,
	 HCI_OCF_SP_READ_CLOCK),app_con_handle);
}
