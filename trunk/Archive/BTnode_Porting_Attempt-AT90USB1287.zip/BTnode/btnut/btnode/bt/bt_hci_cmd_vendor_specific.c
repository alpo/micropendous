/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

 /**
 * @file bt_hci_link_policy.c
 *
 * @brief Deals with vendor specific commands hci-cmds
 * 
 *
 * 2004/05/04 Mathias Payer <payerm@student.ethz.ch>
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/event.h>
#include <sys/heap.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <bt/bt_hci_transport_uart.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

/*******************************************************************************
 * bt_hci_set_baudrate
 ******************************************************************************/
/**
 * Sets the desired baudrate.
 * This command is specific for the uart layer!
 *
 * BT_HCI_B57600 (Baudrate of 57600 BAUD)
 * BT_HCI_B115200 (Baudrate of 115200 BAUD)
 * BT_HCI_B230400 (Baudrate of 230400 BAUD)
 * BT_HCI_B460800 (Baudrate of 460800 BAUD)
 *
 * @param stack The bt-stack to use
 * @param baudrate The baudrate define from above
 *
 * @return 0 if everything was ok, or BT_ERR_UART_COM
 *
 */
long bt_hci_set_baudrate(struct btstack *stack, u_char baudrate)
{
    u_long baud;
    struct bt_hci_cmd_response wcmd, *wcmdpointer;
    long retval;
    u_char ocf;
    struct param_list * params = &(stack->params);

    if (params->baudrate == NULL)
    {
        params->baudrate = NutHeapAlloc(sizeof(u_char));   
    }
    *(params->baudrate) = baudrate;

#if (BT_RADIO_TYPE == ERICSSON)

    // Ericcson Implementation
    switch (baudrate) {
    case BT_HCI_B57600:
        baud = 57600;
        break;
    case BT_HCI_B115200:
        baud = 115200;
        break;
    case BT_HCI_B230400:
        baud = 230400;
        break;
    case BT_HCI_B460800:
        baud = 460800;
        break;
    default:
        return BT_ERR_UART_COM;
    }

    ocf = HCI_OCF_VC_ERICSSON_SET_UART_BAUD_RATE;
#elif (BT_RADIO_TYPE == ZEEVO)

    // Zeevo Implementation
    switch (baudrate) {
    case BT_HCI_B19200:
        baud = 19200;
        baudrate = 0x03;
        break;
    case BT_HCI_B38400:
        baud = 38400;
        baudrate = 0x04;
        break;
    case BT_HCI_B57600:
        baud = 57600;
        baudrate = 0x06;
        break;
    case BT_HCI_B115200:
        baud = 115200;
        baudrate = 0x08;
        break;
    case BT_HCI_B230400:
        baud = 230400;
        baudrate = 0x0a;
        break;
    case BT_HCI_B460800:
        baud = 460800;
        baudrate = 0x0c;
        break;
    default:
        return BT_ERR_UART_COM;
    }
    ocf = HCI_OCF_VC_ZEEVO_CHANGE_BAUD_RATE;

#else
    return BT_ERR_UART_COM;
#endif

    // Init & wait 'till the pkt can be sent
    wcmdpointer = _bt_hci_intro_cmd(stack, &wcmd, BT_HCI_SYNC, &(stack->cmd), HCI_OGF_VENDOR_COMMANDS, ocf);

#if (BT_RADIO_TYPE == ERICSSON)
    stack->cmd.payload[2] = 0x01;       // cmd-length
    stack->cmd.payload[3] = baudrate;
#elif (BT_RADIO_TYPE == ZEEVO)
    stack->cmd.payload[2] = 0x05;       // cmd-length
    stack->cmd.payload[3] = 0x03;       // data bits 8
    stack->cmd.payload[4] = 0x00;       // stop bits 1
    stack->cmd.payload[5] = 0x00;       // parity none
    stack->cmd.payload[6] = baudrate;   // enumerated baud rate
    stack->cmd.payload[7] = 0x00;       // temporary change
#else
    return BT_ERR_UART_COM;
#endif

    // Send the pkt, wait if necessary and return the return value or an error
    // We pass wcmdpointer two times because this command may not block!
    // This is a small hack to prevent outro_cmd to block, but we don't use wcmd, it just gets allocated on the stack for a short period!
    retval = _bt_hci_outro_cmd(stack, wcmdpointer, wcmdpointer, SET_OGF_OCF(HCI_OGF_VENDOR_COMMANDS, ocf), BT_HCI_HANDLE_INVALID);
    if (retval != 0)
        return BT_ERR_UART_COM;

    // Now we set the uart_speed:
    if (_bt_hci_lowlevel_set_baudrate(_fileno(stack->transport.uart), baud) != 0)
        return BT_ERR_UART_COM;

    // wait for completion
    NutEventWait(&(wcmdpointer->block), NUT_WAIT_INFINITE);


    return 0;
}
