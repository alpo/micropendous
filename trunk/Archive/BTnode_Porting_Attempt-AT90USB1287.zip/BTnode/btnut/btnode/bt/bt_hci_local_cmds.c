/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

 /**
 * @file bt_hci_local_cmds.c
 *
 * The functions in this file may be called by the application
 * developer.
 * In this file one finds the cmds that are executed on the
 * local stack structure.
 * Here informations and parameters can be set and retrieved.
 * 
 * 2004/05/25 Mathias Payer <payerm@student.ethz.ch>
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/event.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

/*******************************************************************************
 * bt_hci_local_role_discovery
 ******************************************************************************/
long bt_hci_local_role_discovery(struct btstack *stack, bt_hci_con_handle_t app_con_handle)
{
    u_char i;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if ((stack->connection[i].state == BT_HCI_CONN_STATE_OPEN) && (stack->connection[i].app_con_handle == app_con_handle)) {
            return stack->connection[i].role;
        }
    }
    return BT_ERR_NO_CON;
}

/*******************************************************************************
 * bt_hci_local_mode_discovery
 ******************************************************************************/
long bt_hci_local_mode_discovery(struct btstack *stack, bt_hci_con_handle_t app_con_handle)
{
    u_char i;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if ((stack->connection[i].state == BT_HCI_CONN_STATE_OPEN) &&
            (stack->connection[i].app_con_handle == app_con_handle)) {
            return (((long) stack->connection[i].interval << 8) | stack->connection[i].mode);
        }
    }
    return BT_ERR_NO_CON;
}

/*******************************************************************************
 * bt_hci_get_remote_cod
 ******************************************************************************/
long bt_hci_get_remote_cod(struct btstack *stack, bt_hci_con_handle_t app_con_handle)
{
    u_char i;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if ((stack->connection[i].state == BT_HCI_CONN_STATE_OPEN) && (stack->connection[i].app_con_handle == app_con_handle)) {
            return stack->connection[i].cod;
        }
    }
    return BT_ERR_NO_CON;
}


/*******************************************************************************
 * bt_hci_get_con_handles
 ******************************************************************************/
long bt_hci_get_con_handles(struct btstack *stack, bt_hci_con_handle_array app_con_handles)
{
    u_char i;
    u_char result;
    result = 0;

    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if (stack->connection[i].state == BT_HCI_CONN_STATE_OPEN) {
            if (app_con_handles != NULL)
                app_con_handles[result] = stack->connection[i].app_con_handle;
            result++;
        }
    }
    return result;
}

/*******************************************************************************
 * bt_hci_get_con_handle
 ******************************************************************************/
long bt_hci_get_con_handle(struct btstack *stack, bt_addr_t addr)
{
    u_char i;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if ((stack->connection[i].state == BT_HCI_CONN_STATE_OPEN) && (BD_ADDR_CMP(stack->connection[i].bdaddr, addr))) {
            return stack->connection[i].app_con_handle;
        }
    }
    return BT_ERR_NO_CON;
}

long bt_hci_get_local_bt_addr(struct btstack *stack, bt_addr_t addr)
{
    memcpy(addr, stack->bt_addr, BD_ADDR_LEN);
    return 0;
}

/*******************************************************************************
 * bt_hci_get_remote_bt_addr
 ******************************************************************************/
long bt_hci_get_remote_bt_addr(struct btstack *stack, bt_hci_con_handle_t app_con_handle, bt_addr_t addr)
{
    u_char i;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if ((stack->connection[i].state == BT_HCI_CONN_STATE_OPEN) && (stack->connection[i].app_con_handle == app_con_handle)) {
            memcpy(addr, &stack->connection[i].bdaddr, BD_ADDR_LEN);
            return 0;
        }
    }
    return BT_ERR_NO_CON;
}


/*******************************************************************************
 * bt_hci_is_con_open
 ******************************************************************************/
long bt_hci_is_con_open(struct btstack *stack, bt_hci_con_handle_t app_con_handle)
{
    u_char i;
    for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
        if ((stack->connection[i].state == BT_HCI_CONN_STATE_OPEN) && (stack->connection[i].app_con_handle == app_con_handle))
            return 0;
    }
    return BT_ERR_NO_CON;
}
