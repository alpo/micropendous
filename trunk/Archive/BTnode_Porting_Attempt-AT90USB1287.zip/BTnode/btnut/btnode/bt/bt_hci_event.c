/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/**
 * @file bt_hci_event.c
 *
 * \author Mathias Payer <payerm@student.ethz.ch>
 *
 * \date 2004/04/18 14:11:09
 *
 * @brief Handles hci events.
 * 
 * $Log: bt_hci_event.c,v $
 * Revision 1.85  2006/11/08 15:22:41  yuecelm
 * handle BT_HCI_HARDWARE_ERROR, add info log about remaining acl semaphores
 * after a BT_HCI_NUMBER_OF_COMPLETED_PACKETS event
 *
 * Revision 1.84  2006/10/26 17:41:40  freckle
 * finished documentation and API of new hci cmds
 * returned bt clock multiplied by four to match bt 1.2 spec
 *
 * Revision 1.83  2006/10/26 16:03:31  freckle
 * added new commands: bt_hci_read_clock and bt_hci_read_clock_offset
 *
 * Revision 1.82  2006/10/26 13:25:10  kevmarti
 * - Included syslog debug definitions
 *
 * Revision 1.81  2006/10/23 10:54:30  kevmarti
 * Modified some debugging statements
 *
 * Revision 1.80  2006/10/05 14:54:48  kevmarti
 * - bugfix: in case of a connection complete event returning an error, the calling thread had not been woken up.
 * - rearranged debug output
 *
 * Revision 1.79  2006/10/05 08:24:14  kevmarti
 * Bugfixes (see bug #1548532, followup 2006-10-05 10:19)
 *
 * Revision 1.78  2006/09/25 14:42:31  kevmarti
 * Rewrote handling of events:
 * - connection request
 * - connection complete
 * - disconnection complete
 * This was necessary due to the new connection request callback
 *
 * Revision 1.77  2006/09/19 13:26:25  kevmarti
 * Changed handling of connection complete event: if there is no prepared connection, the connection will be added to the con table.
 *
 * Revision 1.76  2006/09/14 10:09:27  yuecelm
 * add missing library logging.h
 *
 * Revision 1.75  2006/08/30 12:05:36  yuecelm
 * also handle HCI_OCF_HC_SET_EVENT_MASK
 *
 * Revision 1.74  2006/08/21 10:34:33  yuecelm
 * add debug logs before and after semaphores
 *
 * Revision 1.73  2006/06/30 16:28:12  yuecelm
 * add printouts of 'ebt console' command (Zeevo-specific)
 *
 * Revision 1.72  2006/05/13 00:51:20  yuecelm
 * invalidate app_handle after call disconnect callback,
 * only call (role change) connection callback if connection is established
 *
 * Revision 1.71  2006/05/03 11:47:59  kevmarti
 * Added handling of OCF_LC_CREATE_CONNECTION_CANCEL (command complete event)
 *
 * Revision 1.70  2006/05/02 16:56:15  kevmarti
 * Adjusted handling of command complete event. Additionally, the OCF
 * HCI_OCF_LC_INQUIRY_CANCEL is handled which cancels a running inquiry.
 *
 * Revision 1.69  2006/03/28 23:26:09  olereinhardt
 * Changed some string variables in signedness in order to make it compiling with avr-gcc 4.0.2
 *
 * Revision 1.68  2006/03/23 07:22:19  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.65.2.5  2006/03/22 14:07:30  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.65.2.4  2006/03/22 11:04:47  kevmarti
 * Added callback argument in con table change callback
 *
 * Revision 1.65.2.3  2006/03/20 09:43:58  kevmarti
 * Adapted to new logging / terminal printing macros
 *
 * Revision 1.65.2.2  2006/02/06 13:35:15  dyerm
 * accept con callback filter now has an optional argument that can be registered
 *
 * Revision 1.65.2.1  2006/02/01 15:02:12  kevmarti
 * Added bt stack hci debug info to the system-wide logging service (/debug/logging)
 *
 * Revision 1.67  2006/02/21 14:54:03  yuecelm
 * corrections on event and result handling for link policy commands
 *
 * Revision 1.66  2006/02/20 17:23:16  yuecelm
 * add read link policy commands,
 * adapted event and response handling,
 * cosmetic changes
 *
 * Revision 1.65  2005/08/19 13:08:58  freckle
 * added INFO macro for BT_HCI_MODE_CHANGE_EVENT
 *
 * Revision 1.64  2005/06/13 15:57:16  hobid
 * Added bt_hci_link_key_request_negative_reply.
 *
 * Revision 1.63  2005/06/10 17:40:24  freckle
 * Assert bt_hci_wakeup really wakes at least on thread (prints error msg)
 *
 * Revision 1.62  2005/06/10 16:15:45  freckle
 * print bt mac addresses in usual order
 *
 * Revision 1.61  2005/06/10 15:15:14  freckle
 * only allow sending of one Command before receiving Command Status event
 * or command is complete to ensure handling of Command Status Event returning
 * an error is correct.
 *
 * Revision 1.60  2005/06/06 12:09:27  hobid
 * Fixed PIN Code handling / Pairing.
 *
 * Revision 1.59  2005/06/03 14:03:36  olereinhardt
 * Re-indented files according to NutOS coding style: -kr -nut -l 132
 *
 * Revision 1.58  2005/06/03 08:40:48  hobid
 * Bugfix in _bt_hci_handle_event
 *
 * Revision 1.57  2005/05/10 16:19:35  dyerm
 * HCI event debug set to 0 (off) per default
 *
 * Revision 1.56  2005/04/19 18:26:33  beutel
 * added debug flags and more rfcommpin code stuff
 *
 * Revision 1.55  2005/04/15 12:21:59  beutel
 * added link key requests and more pin code stuff
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/event.h>
#include <sys/atom.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_event.h>
#include <bt/bt_hci_dispatch.h>
#include <bt/bt_hci_defs.h>
#include <debug/toolbox.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_HCI
#define LOG_LEVEL SYSLOG_LEVEL_HCI
#include <debug/log_set.h>

/*******************************************************************************
 * _bt_hci_handle_event
 ******************************************************************************/
void _bt_hci_handle_event(struct btstack *stack, struct bt_hci_pkt_evt *pkt)
{
	long retval;
    struct bt_hci_cmd_response *wcmd;
    struct bt_hci_inquiry_result *inquiry;
    u_char *str;
    bt_hci_con_handle_t app_con_handle = BT_HCI_HANDLE_INVALID;
    _bt_hci_module_con_handle_t module_con_handle;
    bt_addr_t tmp_addr;
    short i = 0, j;
    u_char i2;
    u_long req_cod;
    u_char myrole;
    struct bt_hci_connection* con;
    
    INFO("EVT (0x%02.X) rcvd!\n", pkt->evt_code);

    switch (pkt->evt_code) {
    case BT_HCI_INQUIRY_COMPLETE:      // 0x01
        INFO("Inquiry complete\n");
        // If there was an error, we return -BT_ERROR_CODE (see specs)
        if (pkt->payload[0] != 0)
            _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY), BT_HCI_HANDLE_INVALID, -pkt->payload[0]);
        //if (stack->inquiry==0xFF) stack->inquiry=0x0;
        wcmd = _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY), BT_HCI_HANDLE_INVALID);
        _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY), BT_HCI_HANDLE_INVALID, wcmd->response);
        _bt_semaphore_post(&(stack->inquiry));
        break;
    case BT_HCI_INQUIRY_RESULT:        // 0x02
    case BT_HCI_INQUIRY_RESULT_WITH_RSSI:      // 0x22
        i2 = 14;

        // There is alread an inquiry running, and we get the first results...
        DEBUG("Inq. result (0x%X devices)\n", pkt->payload[0]);

        // if inquiry==0xFF -> no devices were found jet (this is the first inq_res), otherwise this var
        // holds the number of already discovered devices
        wcmd = _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY), BT_HCI_HANDLE_INVALID);
        inquiry = (struct bt_hci_inquiry_result *) wcmd->ptr;
        for (i = 0; i < pkt->payload[0]; i++) {
            memcpy(inquiry[i + wcmd->response].bdaddr, pkt->payload + 1 + i * i2, BD_ADDR_LEN);
            inquiry[i + wcmd->response].page_scan_rep_mode = pkt->payload[7 + i * i2] & 0xF;
            inquiry[i + wcmd->response].page_scan_period_mode = pkt->payload[8 + i * i2] & 0xF;
            if (pkt->evt_code == BT_HCI_INQUIRY_RESULT_WITH_RSSI) {
                inquiry[i + wcmd->response].cod = ((((u_long) pkt->payload[9 + i * i2])) |
                                                   (((u_long) pkt->payload[10 + i * i2]) << 8) |
                                                   (((u_long) pkt->payload[11 + i * i2]) << 16));
                inquiry[i + wcmd->response].clock_offset =
                    pkt->payload[13 + i * i2] << 8 | pkt->payload[12 + i * i2] | BT_HCI_VALID_CLOCK_OFFSET;
                inquiry[i + wcmd->response].rssi = ((signed char *) pkt->payload)[14 + i * i2];
            } else {
                inquiry[i + wcmd->response].cod = ((((u_long) pkt->payload[10 + i * i2])) |
                                                   (((u_long) pkt->payload[11 + i * i2]) << 8) |
                                                   (((u_long) pkt->payload[12 + i * i2]) << 16));
                inquiry[i + wcmd->response].clock_offset =
                    pkt->payload[14 + i * i2] << 8 | pkt->payload[13 + i * i2] | BT_HCI_VALID_CLOCK_OFFSET;
                inquiry[i + wcmd->response].rssi = 0;
            }
        }
        wcmd->response += pkt->payload[0];
        break;
    case BT_HCI_CONNECTION_COMPLETE:   // 0x03
        memcpy(tmp_addr, pkt->payload + 3, BD_ADDR_LEN);
              
        // find connection in con table
        con = NULL;
        for (i = 0; i < BT_HCI_MAX_NUM_CON; i++)
        {
            if (stack->connection[i].state != BT_HCI_CONN_INVALID)
            {
                if (BD_ADDR_CMP(stack->connection[i].bdaddr, tmp_addr))
                {
                	con = &stack->connection[i];
                	app_con_handle = con->app_con_handle;
                    break;
                }
            }
        }
        
        // if no entry can be found in the con table
        if (!con)
        {
	        ERROR("EVT (0x03): no entry for " SADDR_FMT ". mhdl: %d Type: %d err: 0x%2.x\n",
	        	 SADDR(pkt->payload + 3), (pkt->payload[2] << 8 | pkt->payload[1]),
	        	 pkt->payload[9], pkt->payload[0]);
	        
        	/* if auto accept is on, this is normal since this device cannot have
        	 * prepared this connection (the module does not send con rqst events)
        	 */
        	if (!stack->con_rqst_cb)
        	{
	            // get a free con table entry
	            i = _bt_hci_get_free_con_entry_index(stack);
	            // con table full - this should not happen
	            if (i < 0)
	            {
	            	// TODO: send reject connection request
	            	ERROR("EVT (0x03): No free table entry for " SADDR_FMT "\n", SADDR(tmp_addr));
	            	break;
	            }
	            // else init connection & set state to WAIT_PASSIVE
	            con = &stack->connection[i];
	            memcpy(con->bdaddr, pkt->payload + 3, BD_ADDR_LEN);
	            con->state = BT_HCI_CONN_STATE_WAITPAS;
	            con->app_con_handle = bt_hci_app_con_handle_counter++;
	            con->role = BT_HCI_MY_ROLE_SLAVE;
	            app_con_handle = con->app_con_handle;
        	}
        	else
        	{
        		/* if auto accept is off, an error must have occured since this
        		 * device should have prepared this connection (with the
        		 * con rqst event received earlier).
        		 */
        		ERROR("EVT (0x03): con for " SADDR_FMT "not prepared!\n", SADDR(tmp_addr));
        		break;
        	}
        }
        
        INFO("EVT (0x03): " SADDR_FMT ". state: %d, ahdl: %d, mhdl: %d Type: %d err: 0x%2.x\n",
        	 SADDR(pkt->payload + 3), con->state, con->app_con_handle,
        	 pkt->payload[1] | pkt->payload[2] << 8, pkt->payload[9], pkt->payload[0]);
	    
        // switch con state
        switch (con->state)
        {
	    	// if in acitve or passive wait, everything's ok
	    	case BT_HCI_CONN_STATE_WAITPAS:
	    	case BT_HCI_CONN_STATE_WAITACK:
	    		// if error (con complete did not succeed) clean up con table
	    		if (pkt->payload[0])
	    		{
	        		con->state = BT_HCI_CONN_INVALID;
	        		con->app_con_handle = BT_HCI_HANDLE_INVALID;
	        		con->module_con_handle = BT_HCI_HANDLE_INVALID;
	        		retval = -pkt->payload[0];
	        	    INFO("EVT (0x03): con table entry %i, hdl: %d cleared.\n", i, app_con_handle);
	    		}
	    		// else, adjust connection table entry & signal higher layer
	    		else
	    		{
		    		if (con->state == BT_HCI_CONN_STATE_WAITACK)
			        {
			        	i2 = BT_HCI_CONNECTION_ACTIVE;
			        }
			        else
			        {
			        	i2 = BT_HCI_CONNECTION_PASSIVE;
			        }
		        	con->state = BT_HCI_CONN_STATE_OPEN;
			        con->module_con_handle = pkt->payload[1] | pkt->payload[2] << 8;
			        con->type = pkt->payload[9];
			        con->mode = BT_HCI_CONN_MODE_ACTIVE;
			        
			        INFO("EVT (0x03): con entry %d updated. ahdl: %d, mhdl: %d, role: %d\n",
			        	 i, app_con_handle, con->module_con_handle, con->role);
			        
		            // signal higher layer
		            stack->con_table_cb(BT_HCI_CONNECTION,
		            					i2,
		                                con->app_con_handle,
		                                stack->con_change_cb_arg); // Call the callback!
		            retval = app_con_handle;
	    		}
	        break;
	    case BT_HCI_CONN_STATE_OPEN:
	    case BT_HCI_CONN_STATE_ACK:
	    case BT_HCI_CONN_INVALID:
	    case BT_HCI_CONN_UNINITIALIZED:
	    default:
	    	ERROR("EVT (0x03): con %d has wrong state: %d\n", i, stack->connection[i].state);
	    	retval = -pkt->payload[0];
        }
        // wake up calling thread
        _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_CREATE_CONNECTION),
                       app_con_handle, retval);
        break;
    case BT_HCI_CONNECTION_REQUEST:    // 0x04
    	// if no accept con cb is registered, we should not receive con rqsts!
    	if (!stack->con_rqst_cb)
    	{
    		ERROR("no con rqst cb registered!\n");
    		break;
    	}
    	
    	// get remote addr, remote cod & role
        memcpy(tmp_addr, pkt->payload, BD_ADDR_LEN);
        req_cod = (((u_long) pkt->payload[6]) | (((u_long) pkt->payload[7]) << 8) | (((u_long) pkt->payload[8]) << 16));
        myrole = BT_HCI_MY_ROLE_SLAVE;
        
        // get a free con table entry & initialize it
        i = _bt_hci_get_free_con_entry_index(stack);
        if (i == -1) {
            INFO("con table full. Ignoring rqst...\n");
            break;
            // TODO: What can we do here if there are no more connections available => Check this!
        }
        memcpy(stack->connection[i].bdaddr, pkt->payload, BD_ADDR_LEN);
        stack->connection[i].cod = req_cod;
        stack->connection[i].type = pkt->payload[9];
        stack->connection[i].app_con_handle = bt_hci_app_con_handle_counter++;
        stack->connection[i].state = BT_HCI_CONN_STATE_ACK;
        stack->connection[i].role = myrole;
        stack->connection[i].mode = BT_HCI_CONN_MODE_ACTIVE;
        stack->conn_request++;
        DEBUG("Connection request from %.2x:%.2x:%.2x:%.2x:%.2x:%.2x Conn.Nr.: %d\n", pkt->payload[5], pkt->payload[4],
              pkt->payload[3], pkt->payload[2], pkt->payload[1], pkt->payload[0], stack->connection[i].app_con_handle);
        break;
    case BT_HCI_DISCONNECTION_COMPLETE:        // 0x05
        module_con_handle = pkt->payload[2] << 8 | pkt->payload[1];
        
        // find connection in con table
        con = 0;
        for (i = 0; i < BT_HCI_MAX_NUM_CON; i++)
        {
        	if (stack->connection[i].state != BT_HCI_CONN_INVALID)
        	{
	            if (stack->connection[i].module_con_handle == module_con_handle)
	            {
	            	con = &stack->connection[i];
	            	app_con_handle = con->app_con_handle;
	                break;
	            }
        	}
        }
        
        // if con was found and no error occurred, invalidate the connection
        if (i < BT_HCI_MAX_NUM_CON)
        {
            INFO_STR("EVT (0x05): " SADDR_FMT " #%d, ahdl: %d, mhdl: %d, err: %d, reason: 0x%02X\n",
        	 	 	 SADDR(con->bdaddr), i, con->app_con_handle, module_con_handle,
        	 	 	 pkt->payload[0], pkt->payload[3]);
        	// if no error occured, invalidate connection
            if (!pkt->payload[0])
            {
            	INFO("con closed. hdl: %d, " SADDR_FMT "\n", app_con_handle, SADDR(con->bdaddr));
            	// invalidate con table entry
            	con->state = BT_HCI_CONN_INVALID;
                con->module_con_handle = BT_HCI_HANDLE_INVALID;
                con->app_con_handle = BT_HCI_HANDLE_INVALID;
                con->role = 0;
                // callback
                stack->con_table_cb(BT_HCI_DISCONNECTION, pkt->payload[3], app_con_handle, stack->con_change_cb_arg);
                // wake up caller
                _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_DISCONNECT), app_con_handle, -pkt->payload[0]);
                // wake up other commands for this link
                _bt_hci_wakeup(stack, 0xffff, app_con_handle, BT_ERR_CON_BROKEN);
            }
            // else, just wake up caller
            else
            {
            	_bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_DISCONNECT), app_con_handle, -pkt->payload[0]);
            }
        }
        else
        {
        	INFO("EVT (0x05): no con table entry for mhdl %d!\n", module_con_handle);
        }
        break;
    case BT_HCI_REMOTE_NAME_REQUEST_COMPLETE:  // 0x07
        // Handle a remote_name_request complete event
        wcmd =
            _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_REMOTE_NAME_REQUEST),
                                     BT_HCI_HANDLE_INVALID);
        str = (u_char *) wcmd->ptr;
        if (wcmd->response > 248)
            wcmd->response = 248;
        for (i = 0; i < wcmd->response; i++) {
            str[i] = pkt->payload[i + 7];
            if (str[i] == '\0')
                break;          // Act. length reached.
        }
        // assert string is terminated
        if (i == wcmd->response)
            i--;
        str[i] = '\0';
        if (pkt->payload[0] != 0)
            _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_REMOTE_NAME_REQUEST), BT_HCI_HANDLE_INVALID,
                           -pkt->payload[0]);
        else
            _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_REMOTE_NAME_REQUEST), BT_HCI_HANDLE_INVALID, i);
        break;
    case BT_HCI_COMMAND_COMPLETE:      // 0x0E
        _bt_hci_handle_event_cmd_complete(stack, pkt);
        break;
    case BT_HCI_COMMAND_STATUS:        // 0x0F
        _bt_hci_handle_event_cmd_status(stack, pkt);
        break;
    case BT_HCI_HARDWARE_ERROR:        // 0x10
        ERROR("Hardware error event: 0x%02x (%d)\n", pkt->payload[0], pkt->evt_length);
        break;
    case BT_HCI_ROLE_CHANGE:   // 0x12
        // find module con handle in table
        for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
            if (BD_ADDR_CMP(stack->connection[i].bdaddr, &pkt->payload[1])) {
                break;
            }
        }
        if (i == BT_HCI_MAX_NUM_CON)
        {
            DEBUG("BT_HCI_ROLE_CHANGE: This should not happen (connection not found in table)!\n");
            break;
        }
        // set app_con_handle
        app_con_handle = stack->connection[i].app_con_handle;

        if (pkt->payload[0] != 0) {
            _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_ROLE_CHANGE), app_con_handle, -pkt->payload[0]);
            break;
        }

        // update table
        stack->connection[i].role = pkt->payload[7];
        INFO("BT_HCI_ROLE_CHANGE handle: %d, new role: %d\n", app_con_handle, pkt->payload[7]);
        _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_ROLE_CHANGE), app_con_handle, pkt->payload[7]);
        if (stack->connection[i].state == BT_HCI_CONN_STATE_OPEN)
        {
        	stack->con_table_cb(pkt->payload[7], 0, app_con_handle, stack->con_change_cb_arg);    // Call the callback (MASTER or SLAVE)!
        }
        break;
    case BT_HCI_NUMBER_OF_COMPLETED_PACKETS:   // 0x13
        // if (pkt->payload[0] != 1)
        //    printf("BT_HCI_NUMBER_OF_COMPLETED_PACKETS: handles %d != 1\n\r",pkt->payload[0]);

        for (i = 0; i < pkt->payload[0]; i++) {
            // DEBUG("Free pkts + %d\n\r", pkt->payload[3+i*4]);

            // printf("F: %d + %d ", stack->nr_acl_pkts.counter, pkt->payload[3+i*4]);
            // if ( (pkt->payload[4+i*4] << 8 | pkt->payload[3+i*4]) != 1)
            //    printf("BT_HCI_NUMBER_OF_COMPLETED_PACKETS: free pkts != 1\n\r");

            _bt_semaphore_postinc(&(stack->nr_acl_pkts), pkt->payload[4 + i * 4] << 8 | pkt->payload[3 + i * 4]);
            // printf("= %d \n\r", stack->nr_acl_pkts.counter);
            for (j = 0; j < BT_HCI_MAX_NUM_CON; j++) {
                if (stack->connection[j].module_con_handle == ((pkt->payload[2 + i * 4] << 8) | pkt->payload[1 + i * 4])) {
                    stack->connection[j].pkts_h2c -= pkt->payload[4 + i * 4] << 8 | pkt->payload[3 + i * 4];
                    break;
                }
            }
            INFO("hdl %d: %d pkts completed.\n", stack->connection[j].app_con_handle,
                  pkt->payload[4 + i * 4] << 8 | pkt->payload[3 + i * 4]);
        }
        INFO("NOCP event: %d\n", stack->nr_acl_pkts.counter);
        break;
    case BT_HCI_MODE_CHANGE_EVENT:     // 0x14
        for (i = 0; i < BT_HCI_MAX_NUM_CON; i++) {
            if (stack->connection[i].module_con_handle ==
                ((((u_short) pkt->payload[2] << 8) | pkt->payload[1]) & 0x0fff) ) {
                    break;
            }
        }
        if (i == BT_HCI_MAX_NUM_CON)
        {
            DEBUG("BT_HCI_MODE_CHANGE: This should not happen (connection not found in table)!\n");
            break;
        }

        // set app_con_handle
        app_con_handle = stack->connection[i].app_con_handle;
        
        if (pkt->payload[0] != 0) {
            _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_ROLE_CHANGE), app_con_handle, -pkt->payload[0]);
            break;
        }

        // update table
        stack->connection[i].mode = pkt->payload[3];
        if (pkt->payload[3] != BT_HCI_CONN_MODE_ACTIVE)
            stack->connection[i].interval = (((u_short) pkt->payload[5]) << 8) | pkt->payload[4];
        else
            stack->connection[i].interval = 0;
        INFO("BT_HCI_MODE_CHANGE handle: %d, new mode: %d (interval: %d)\n",
              app_con_handle, pkt->payload[3], stack->connection[i].interval);
        // several hci commands causing this event, so use 0xffff
        _bt_hci_wakeup(stack, 0xffff, app_con_handle,
                       (((long) stack->connection[i].interval << 8) | pkt->payload[3]));
        break;
    case BT_HCI_PIN_CODE_REQUEST:      // 0x16
        //todo jaybee
        memcpy(tmp_addr, pkt->payload, BD_ADDR_LEN);

        stack->pin_request++;
        //bt_hci_pin_code_request_reply(stack, struct bt_hci_cmd_response *response, bt_hci_con_handle_t con_handle, bt_addr_t addr, u_char pin_length, u_char pin_code);
        INFO("Received pin code request from %.2x:%.2x:%.2x:%.2x:%.2x:%.2x ConnNr: %d\n", pkt->payload[5], pkt->payload[4],
             pkt->payload[3], pkt->payload[2], pkt->payload[1], pkt->payload[0], stack->connection[i].app_con_handle);
        break;
    case BT_HCI_LINK_KEY_REQUEST:      // 0x17  
        INFO("Received link key request.\n");
        memcpy(tmp_addr, pkt->payload, BD_ADDR_LEN);
        /* TODO this should be send from the HCI thread */
        bt_hci_link_key_request_negative_reply(stack, tmp_addr);
        break;
    case BT_HCI_LINK_KEY_NOTIFICATION: // 0x18
        INFO("Received link key notification.\n");
        break;
    case BT_HCI_MAX_SLOTS_CHANGED:     // 0x1B
        DEBUG("Event ignored (intentionally): 0x%X\n", pkt->evt_code);
        break;
    case BT_HCI_READ_CLOCK_OFFSET_COMPLETE:   // 0x1c
        module_con_handle = pkt->payload[2] << 8 | pkt->payload[1];
        app_con_handle = _bt_hci_get_app_con_handle(stack, module_con_handle);
        if (pkt->payload[0] != 0) {
            _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_READ_CLOCK_OFFSET), app_con_handle, -pkt->payload[0]);
            break;
        }
        _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_READ_CLOCK_OFFSET), app_con_handle,
                       pkt->payload[4] << 8 | pkt->payload[3]);
        break;
    case CONNECTION_PACKET_TYPE_CHANGED:       // 0x1D
        module_con_handle = pkt->payload[2] << 8 | pkt->payload[1];
        app_con_handle = _bt_hci_get_app_con_handle(stack, module_con_handle);
        if (pkt->payload[0] != 0) {
            _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, CHANGE_CONNECTION_PACKET_TYPE), app_con_handle, -pkt->payload[0]);
            break;
        }
        DEBUG("CONNECTION_PACKET_TYPE_CHANGED handle: %d\n", app_con_handle);
        _bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, CHANGE_CONNECTION_PACKET_TYPE), app_con_handle,
                       pkt->payload[4] << 8 | pkt->payload[3]);
        break;
    case BT_HCI_VENDOR_SPECIFIC:       // 0xff
        DEBUG("Vendor specific event: Code: 0x%X\n", pkt->evt_code);
        for (i = 0; i < pkt->evt_length; i++) {
            printf("0x%X\n", pkt->payload[i]);
        }
        break;
#if (BT_RADIO_TYPE == ZEEVO)
    case 0xEF:   // print console commands
        for (i = 1; i < pkt->evt_length; i++) {
            printf("%c", pkt->payload[i]);
        }
        break;
#endif
    default:
        INFO("Event received: Code: 0x%X Length: %d\n", pkt->evt_code, pkt->evt_length);
        for (i = 0; i < pkt->evt_length; i++) {
            printf("%c", pkt->payload[i]);
        }
    }
    
    stack->evt.type = HCI_FREE_BUFFER;
}


/*******************************************************************************
 * _bt_hci_handle_event_cmd_complete
 ******************************************************************************/
void _bt_hci_handle_event_cmd_complete(struct btstack *stack, struct bt_hci_pkt_evt *pkt)
{
    u_short ocf;
    u_char ogf;
    u_char i;
    struct bt_hci_cmd_response *wcmd;
    struct bt_hci_local_version_result *version;
    u_char *str;
    long response = 0;
    _bt_hci_module_con_handle_t module_con_handle = BT_HCI_HANDLE_INVALID;      // Set default value
    bt_hci_con_handle_t app_con_handle = BT_HCI_HANDLE_INVALID;
    u_char wakeup = 1; // should we try to wake a waitng thread
    
    ogf = BT_HCI_GET_OGF(pkt->payload + 1);     // The desired value starts at payload+1 (payload[1])
    ocf = BT_HCI_GET_OCF(pkt->payload + 1);
    
    INFO("cmd complete (0x%02X/0x%02X). nr hci cmds: %d, val: %d\n", ogf, ocf, pkt->payload[0], stack->nr_hci_cmds.counter);

    switch (ogf) {
    case HCI_OCF_NOP:
        DEBUG("NOP from the controller\n");
        wakeup = 0; // no one to wake around
        break;
    case HCI_OGF_LINK_CONTROL:
        switch (ocf) {
        case HCI_OCF_LC_INQUIRY_CANCEL:
	        INFO("Inq cancel\n");	        
	        // if there was an inquiry running, we wake up the corresponding thread
	        _bt_semaphore_trywait(&stack->inquiry);
	        wcmd = _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY), BT_HCI_HANDLE_INVALID);
	        if (wcmd)
	        	_bt_hci_wakeup(stack, SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_INQUIRY), BT_HCI_HANDLE_INVALID, wcmd->response);
	        _bt_semaphore_post(&(stack->inquiry));
        	break;
        case HCI_OCF_LC_CREATE_CONNECTION_CANCEL:
        	INFO("create con cancel!\n");
        	break;
        case HCI_OCF_LC_LINK_KEY_REQUEST_NEGATIVE_REPLY:
            _bt_hci_wakeup_unset(stack);
            break;
        case HCI_OCF_LC_PIN_CODE_REQUEST_REPLY:
            INFO("Pin code request complete.\n");
            wcmd = _bt_hci_cmd_get_response(stack,
                                            SET_OGF_OCF(HCI_OGF_LINK_CONTROL, HCI_OCF_LC_PIN_CODE_REQUEST_REPLY),
                                            BT_HCI_HANDLE_INVALID);
            /* FIXME bt_hci_pin_code_request_reply() cannot pass an address
             *       pointer as it would block the whole stack.
             */
            //str = (u_char *) wcmd->ptr;
            u_char temp_buf[6];
            str = temp_buf;
            for (i = 0; i < 6; i++) {
                str[i] = pkt->payload[i + 4];
            }
            INFO("Pin code for: %.2x:%.2x:%.2x:%.2x:%.2x:%.2x\n", str[5], str[4], str[3], str[2], str[1], str[0]);
            _bt_hci_wakeup_unset(stack);
            break;
        default:
            INFO("(unhandled lc): ocf: 0x%X\n", ocf);
        }
        break;
    case HCI_OGF_LINK_POLICY:
        switch (ocf) {
        case HCI_OCF_LP_ROLE_DISCOVERY:
            module_con_handle = pkt->payload[5] << 8 | pkt->payload[4];
            //wcmd = bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_LINK_POLICY, HCI_OCF_LP_ROLE_DISCOVERY), bt_hci_con_handle_c2s(stack, app_con_handle));
            response = pkt->payload[6];
            break;
        case HCI_OCF_LP_READ_LINK_POLICY_SETTINGS:
            module_con_handle = ((u_short) pkt->payload[5] << 8) | pkt->payload[4];
            if (pkt->payload[3] == 0)
                // no errors
                response = ((u_short) pkt->payload[7] << 8) | pkt->payload[6];
            else
                response = -pkt->payload[3];
            break;
        case HCI_OCF_LP_WRITE_LINK_POLICY_SETTINGS:
            module_con_handle = (((u_short) pkt->payload[5]) << 8) | pkt->payload[4];
            response = -pkt->payload[3];
            break;
        case HCI_OCF_LP_READ_DEFAULT_LINK_POLICY_SETTINGS:
            if (pkt->payload[3] == 0)
                // no errors
                response = ((u_short) pkt->payload[5] << 8) | pkt->payload[4];
            else
                response = -pkt->payload[3];
            break;
        case HCI_OCF_LP_WRITE_DEFAULT_LINK_POLICY_SETTINGS:
            response = -pkt->payload[3];
            break;
        default:
            INFO("(unhandled lp): ocf: 0x%X\n", ocf);
        }
        break;
    case HCI_OGF_HOST_CONTROL:
//                      DEBUG("OGF_HOST_CONTROL complete Event...\n");
        switch (ocf) {
        case HCI_OCF_HC_RESET:
            // DEBUG("Reset complete.\n");
            // If there are threads waiting for this cmd to complete, wake them up!
            stack->reset = 0;
            break;
        case HCI_OCF_HC_SET_EVENT_MASK:
        case HCI_OCF_HC_SET_EVENT_FILTER:
        case HCI_OCF_HC_WRITE_PIN_TYPE:
        case HCI_OCF_HC_WRITE_LOCAL_NAME:
        case HCI_OCF_HC_WRITE_CONNECTION_ACCEPT_TIMEOUT:
        case HCI_OCF_HC_WRITE_PAGE_TIMEOUT:
        case HCI_OCF_HC_WRITE_SCAN_ENABLE:
        case HCI_OCF_HC_WRITE_COD:
        case HCI_OCF_HC_SET_HOST_CTRL_TO_HOST_FLOW_CONTROL:
        case HCI_OCF_HC_HOST_BUFFER_SIZE:
        case HCI_OCF_HC_WRITE_INQUIRY_MODE:
        case HCI_OCF_HC_WRITE_INQUIRY_SCAN_TYPE:
            INFO("Host Control Command completed (no return value) (OCF: 0x%X).\n",ocf);
            // Here we only get a status result. OK or ERROR
            // waiting threads will be woken up later (in case you worry..): MR
            break;
        case HCI_OCF_HC_READ_COD:
            response = ((u_long) pkt->payload[6]) << 16 | ((u_long) pkt->payload[5]) << 8 | pkt->payload[4];
            break;
        case HCI_OCF_HC_READ_CONNECTION_ACCEPT_TIMEOUT:
        case HCI_OCF_HC_READ_PAGE_TIMEOUT:
        case HCI_OCF_HC_READ_INQUIRY_MODE:
            response = pkt->payload[5] << 8 | pkt->payload[4];
            break;
        case HCI_OCF_HC_WRITE_LINK_SUPERVISION_TIMEOUT:
            module_con_handle = pkt->payload[5] << 8 | pkt->payload[4];
            break;
        case HCI_OCF_HC_READ_LINK_SUPERVISION_TIMEOUT:
            module_con_handle = pkt->payload[5] << 8 | pkt->payload[4];
            response = pkt->payload[7] << 8 | pkt->payload[6];
            break;
        case HCI_OCF_HC_READ_PIN_TYPE:
        case HCI_OCF_HC_READ_SCAN_ENABLE:
            response = pkt->payload[4];
            break;
        case HCI_OCF_HC_READ_LOCAL_NAME:
            INFO("Read Local Name complete.\n");
            wcmd = _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_HOST_CONTROL, HCI_OCF_HC_READ_LOCAL_NAME),
                                            BT_HCI_HANDLE_INVALID);
            str = (u_char *) wcmd->ptr;
            if (wcmd->response > 248)
                wcmd->response = 248;
            for (i = 0; i < wcmd->response; i++) {
                str[i] = pkt->payload[i + 4];
                if (str[i] == '\0')
                    break;      // Act. length reached.
            }
            // assert string is terminated
            if (i == wcmd->response)
                i--;
            str[i] = '\0';
            break;
        default:
            INFO("(unhandled hc): ocf: 0x%X\n", ocf);
        }
        break;
    case HCI_OGF_INFORMATIONAL_PARAMS:
        switch (ocf) {
        case HCI_OCF_IP_READ_LOCAL_VERSION_INFORMATION:
            INFO("Read local version information.\n");
            wcmd =
                _bt_hci_cmd_get_response(stack,
                                         SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_LOCAL_VERSION_INFORMATION),
                                         BT_HCI_HANDLE_INVALID);
            version = (struct bt_hci_local_version_result *) wcmd->ptr;
            // get the payload
            version->hciversion = pkt->payload[4];
            version->hcirevision = pkt->payload[5] | pkt->payload[6] << 8;
            version->lmpversion = pkt->payload[7];
            version->manufacturername = pkt->payload[8] | pkt->payload[9] << 8;
            version->lmpsubversion = pkt->payload[10] | pkt->payload[11] << 8;
            INFO("Read local version information complete: %X %.4X %X %.4X %.4X\n", version->hciversion, version->hcirevision,
                 version->lmpversion, version->manufacturername, version->lmpsubversion);
            break;
        case HCI_OCF_IP_READ_LOCAL_SUPPORTED_FEATURES:
            INFO("Read local supported features.\n");
            wcmd =
                _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_LOCAL_SUPPORTED_FEATURES),
                                         BT_HCI_HANDLE_INVALID);
            str = (u_char *) wcmd->ptr;
            // get the payload
            for (i = 0; i < 8; i++) {
                str[i] = pkt->payload[i + 1];
            }
            INFO("Read local LMP supported features complete: %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X\n", str[0], str[1], str[2],
                 str[3], str[4], str[5], str[6], str[7]);
            break;
        case HCI_OCF_IP_READ_LOCAL_SUPPORTED_COMMANDS:
            break;
        case HCI_OCF_IP_READ_LOCAL_EXTENDED_FEATURES:
            break;
        case HCI_OCF_IP_READ_BUFFER_SIZE:
            INFO("Read buffer size complete.\n");
            stack->acl_max_len = pkt->payload[5] << 8 | pkt->payload[4];
            stack->sco_max_len = pkt->payload[6];
            _bt_semaphore_postval(&(stack->nr_acl_pkts), pkt->payload[8] << 8 | pkt->payload[7]);
            _bt_semaphore_postval(&(stack->nr_sco_pkts), pkt->payload[10] << 8 | pkt->payload[9]);
            INFO("Max Buffers #acl-pkt: %d, #sco-pkt: %d, max-len acl: %d, sco: %d\n", pkt->payload[8] << 8 | pkt->payload[7],
                 pkt->payload[10] << 8 | pkt->payload[9], stack->acl_max_len, stack->sco_max_len);
            break;
        case HCI_OCF_IP_READ_BD_ADDR:
            // INFO("Read BT Name complete.\n");
            wcmd =
                _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_INFORMATIONAL_PARAMS, HCI_OCF_IP_READ_BD_ADDR),
                                         BT_HCI_HANDLE_INVALID);
            str = (u_char *) wcmd->ptr;
            for (i = 0; i < 6; i++) {
                str[i] = pkt->payload[i + 4];
            }
            break;
        default:
            WARNING("(unhandled ip): ocf: 0x%X\n", ocf);
        }
        break;
    case HCI_OGF_STATUS_PARAMS:
        switch (ocf) {
        case HCI_OCF_SP_GET_LINK_QUALITY:
            module_con_handle = pkt->payload[5] << 8 | pkt->payload[4];
            wcmd = _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_STATUS_PARAMS, HCI_OCF_SP_GET_LINK_QUALITY),
                                         _bt_hci_get_app_con_handle(stack, module_con_handle));
            *(u_char *) wcmd->ptr = (u_char) pkt->payload[6];
            break;
        case HCI_OCF_SP_READ_RSSI:
            module_con_handle = pkt->payload[5] << 8 | pkt->payload[4];
            wcmd = _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_STATUS_PARAMS, HCI_OCF_SP_READ_RSSI),
                                         _bt_hci_get_app_con_handle(stack, module_con_handle));
            *(short *) wcmd->ptr =  pkt->payload[7] << 8 | pkt->payload[6];
            break;
        case HCI_OCF_SP_READ_CLOCK:
            app_con_handle =    BT_HCI_HANDLE_INVALID;
            module_con_handle = BT_HCI_HANDLE_INVALID;
            wcmd = _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_STATUS_PARAMS, HCI_OCF_SP_READ_CLOCK), app_con_handle);
#if (BT_RADIO_TYPE == ZEEVO)
            /** Zeevo does only return a single byte - but as remote retrieval does not work it 
                it does not matter anyway. */
            if ( wcmd->ptr ) {
                *(u_short *) wcmd->ptr = pkt->payload[10];
            }
#else
            if ( wcmd->ptr ) {
                *(u_short *) wcmd->ptr = pkt->payload[11] << 8 | pkt->payload[10];
            }
#endif      
            response = ((u_long) pkt->payload[9]) << 24 | ((u_long) pkt->payload[8]) << 16 |
                       ((u_long) pkt->payload[7]) << 8  | pkt->payload[6];
#if (BT_RADIO_TYPE == ZEEVO)
            /** Zeevo returns the value in 1.25 ms instead of 0.3125 ms as described in 1.2 spec */
            response = response << 2;
#endif
            break;
        default:
            WARNING("(unhandled ip): ocf: 0x%X\n", ocf);
            wakeup = 0; // don't know
        }
        break;
    case HCI_OGF_VENDOR_COMMANDS:
        switch (ocf) {
#if (BT_RADIO_TYPE == ERICSSON)
        case HCI_OCF_VC_ERICSSON_SET_UART_BAUD_RATE:
            break;
#endif
#if (BT_RADIO_TYPE == ZEEVO)
        case HCI_OCF_VC_ZEEVO_CHANGE_BAUD_RATE:
            break;
#endif
        case HCI_OCF_VC_ZEEVO_READ_ABSOLUTE_RSSI:
#if (BT_RADIO_TYPE == ZEEVO)
            // using _bt_hci_cmd_get_response does not work here, because in contrast to the normal HCI_Read_RSSI, no connection handle is returened here
            // therefore, things have to be done manually. 
            // wcmd = _bt_hci_cmd_get_response(stack, SET_OGF_OCF(HCI_OGF_VENDOR_COMMANDS, HCI_OCF_VC_ZEEVO_READ_ABSOLUTE_RSSI), _bt_hci_get_app_con_handle(stack, module_con_handle));
            for (i = 0; i < BT_HCI_NR_WAIT_QUEUES; i++) {
                if ((stack->waitqueue[i] != 0)
                    && ((stack->waitqueue[i]->ogfocf) ==
                        SET_OGF_OCF(HCI_OGF_VENDOR_COMMANDS, HCI_OCF_VC_ZEEVO_READ_ABSOLUTE_RSSI))) {
                    wcmd = stack->waitqueue[i];
                    // get the connection handle from the wait queue instead
                    module_con_handle = _bt_hci_get_module_con_handle(stack, stack->waitqueue[i]->cmd_handle);
                    // copy the abs rssi value to the requested location
                    *((char *) wcmd->ptr) = ((signed char *) pkt->payload)[4];
                    break;
                }
            }
            if (i == BT_HCI_NR_WAIT_QUEUES) {
                // wait queue was not found
                wcmd = 0;
                WARNING("READ_ABSOLUTE_RSSI Event: no entry in wait queue found!");
            }
#endif
            break;
        default:
            WARNING("(unhandled vc): ocf: 0x%X\n", ocf);
        }
        break;
    default:
        WARNING("(unhandled) Cmd complete event: OGF: 0x%X OCF: 0x%X\n", ogf, ocf);
    }                          // end switch ogf

    // If there was an error, set the error-value!
    if (pkt->payload[3] != 0) {
        response = -pkt->payload[3];
    }
    // use app_con_handle if available 
    if (module_con_handle != BT_HCI_HANDLE_INVALID) {
        app_con_handle = _bt_hci_get_app_con_handle(stack, module_con_handle);
    }
    
    // if not told otherwise, wakeup waiting thread
    if (wakeup)
        _bt_hci_wakeup(stack, SET_OGF_OCF(ogf, ocf), app_con_handle, response);

    // Nr of packets the controller can handle until he runs out of buffer (post them to the bt_semaphore)
    DEBUG("release nr_hci_cmds with value %d\n", pkt->payload[0]);
    _bt_semaphore_postval(&(stack->nr_hci_cmds), pkt->payload[0]);
}


/*******************************************************************************
 * _bt_hci_handle_event_cmd_status
 ******************************************************************************/
void _bt_hci_handle_event_cmd_status(struct btstack *stack, struct bt_hci_pkt_evt *pkt)
{
    u_short ocf;
    u_char ogf;

    ogf = BT_HCI_GET_OGF(pkt->payload + 2);     // The desired value starts at payload[2] 
    ocf = BT_HCI_GET_OCF(pkt->payload + 2);
    
    INFO("cmd status (0x%2.X/0x%2.X). err: 0x%2.X nr hci cmds: %d, val: %d\n", ogf, ocf, pkt->payload[0], pkt->payload[1], stack->nr_hci_cmds.counter);
    
    // if everything's ok
    if (!pkt->payload[0])
    {
        if (ocf != HCI_OCF_NOP)
            DEBUG("Command (OGF/OCF: 0x%X/0x%X) still running.\n", ogf, ocf);
        else
            DEBUG("Nop from the controller\n");
        // unset latest Command 
        _bt_hci_wakeup_unset(stack);
    }
    else
    {
    	// TODO: handle errors in cmd status events more carefully    		
        ERROR("(CMD-Status: OGF/OCF: 0x%X/0x%X): 0x%X.\n", ogf, ocf, pkt->payload[0]);
        // wakeup thread which send latest Command 
        _bt_hci_wakeup_latest(stack, -pkt->payload[0]);
    }

    // Nr of packets the controller can handle until he runs out of buffer (post them to the bt_semaphore)
    DEBUG("release nr_hci_cmds with value %d\n", pkt->payload[1]);
    _bt_semaphore_postval(&(stack->nr_hci_cmds), pkt->payload[1]);
}
