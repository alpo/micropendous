/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file bt_acl.c
 * 
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch> 
 * 
 * \date 2006/03/23
 * 
 * \brief Implementation of the ACL layer.
 */
#include <bt/bt_defs.h>
#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_hci_dispatch.h>
#include <bt/bt_hci_api.h>
#include <bt/bt_acl_defs.h>
#include <sys/mutex.h>
#include <sys/heap.h>
#include <sys/timer.h>
#include <debug/toolbox.h>
#include <string.h>
#include <debug/syslog.h>

// debug settings
#define LOG_CLASS SYSLOG_CLASS_ACL
#define LOG_LEVEL SYSLOG_LEVEL_ACL
#include <debug/log_set.h>

#if LOG_LEVEL >= 4
char acl_dbg_buf[121*3];
#endif

/**
 * Returns the con handle a packet was received on.
 */
inline bt_hci_con_handle_t bt_acl_get_con_handle(struct bt_hci_pkt_acl* pkt)
{
	return (((u_char*)pkt)[2] & 0xF) << 8 | ((u_char*)pkt)[1];
}

/**
 * Returns the pb flag of a received packet
 */
inline u_char bt_acl_get_pb_flag(struct bt_hci_pkt_acl* pkt)
{
	return (((u_char*)pkt)[1] >> 4) & 3;
}

/**
 * Returns the bc flag of a received acl packet
 */
inline u_char bt_acl_get_bc_flag(struct bt_hci_pkt_acl* pkt)
{
	return (((u_char*)pkt)[1] >> 6) & 3;
}

/**
 * Returns a pointer to the payload of an ACL packet
 */
inline u_char* bt_acl_get_data_pointer(struct bt_hci_pkt_acl* pkt)
{
	return (pkt->payload);
}

inline u_short bt_acl_get_pkt_types(struct btstack* stack)
{
	return stack->acl_pkt_types;
}

inline u_short bt_acl_get_max_pkt_len(struct btstack* stack)
{
	return stack->host_acl_len;
}


/**
 * Opens an acl communication link.
 * 
 * returns 0 or error. a handle to the packet is stored in \param acl_pkt.
 */
long bt_acl_acquire_write_lock(struct btstack* stack,
							   bt_hci_con_handle_t hdl,
							   u_char pb_flag,
							   u_char bc_flag,
							   u_short len)
{
	u_char hci_acl_hdr[HCI_ACL_DATA_PKT_HDR + 1];	// +1 for hci pkt type
	_bt_hci_module_con_handle_t module_hdl;
	long result;
	u_char con = 0;
	
	// aquire ACL write lock
	_bt_semaphore_wait(&stack->acl_write);
	// ACL write parameters
	stack->acl_write_hdl = BT_HCI_HANDLE_INVALID;
	stack->acl_written = 0;
	stack->acl_write_len = 0;
	    
    // if not self delivery
    if (hdl != BT_HCI_CON_HANDLE_OWN) 
    {
	    // Get the external con_handle & increase the number of uncompleted packets
	    for (con = 0; con < BT_HCI_MAX_NUM_CON; con++)
	    {
	    	if (stack->connection[con].state == BT_HCI_CONN_STATE_OPEN)
	    	{
	        	if (stack->connection[con].app_con_handle == hdl)
	        	{
	            	break;
	        	}
	        }
	    }
	    
	    // If con not found in con table, return error
	    if (con == BT_HCI_MAX_NUM_CON)
	    {
	    	// release acl write lock
	    	_bt_semaphore_post(&stack->acl_write);
	        return BT_ERR_NO_CON;
	    }
	        
	    // else, get module con handle
	    module_hdl = stack->connection[con].module_con_handle;
    }
    // if self delivery, set module con handle to BT_HCI_CON_HANDLE_OWN
    else
    {
    	module_hdl = BT_HCI_CON_HANDLE_OWN;
    }
    
    // check payload size
    if (len > stack->host_acl_len)
    {
    	// release ACL write lock
    	_bt_semaphore_post(&stack->acl_write);
    	return BT_ERR_ACL_PLOAD_OVFLW;
    }

	// build hci packet header
	// Note: if self delivery (hdl == BT_HCI_CON_HANDLE_OWN) we don't do the
	// module_hdl <-> app_con_hdl conversion: in that case, module_hdl
	// is set to BT_HCI_CON_HANDLE_OWN (see bt_acl_write_lock_release)
	hci_acl_hdr[0] = HCI_ACL_DATA_PACKET;
	hci_acl_hdr[1] = BTN_LO(module_hdl);
	hci_acl_hdr[2] = BTN_HI(module_hdl) | (pb_flag & 3) << 4 | (bc_flag & 3) << 6;
	hci_acl_hdr[3] = BTN_LO(len);
	hci_acl_hdr[4] = BTN_HI(len);

	// if the packet has not to be sent to this device
	if (hdl != BT_HCI_CON_HANDLE_OWN)
	{	
		// wait until the bt module has completed enough packets
        _bt_semaphore_wait(&(stack->nr_acl_pkts));
		// increment number of completed packets for the given connection
		stack->connection[con].pkts_h2c += 1;
	    // acquire uart
	    _bt_hci_aquire_write_lock(stack);
	    // send header
	    result = _bt_hci_lowlevel_write(stack, (u_char*)&hci_acl_hdr, sizeof(hci_acl_hdr));
	    // if error, release uart and return
	    if (result < 0)
	    {
	    	// release lock on uart
		    _bt_hci_relase_write_lock(stack);
		    // since we did not send a packet, increment nr acl packets
		    _bt_semaphore_post(&(stack->nr_acl_pkts));
		    // release acl connection
		    _bt_semaphore_post(&stack->acl_write);
		    return BT_ERR_UART_COM;
	    }
	}
	// if self delivery, just copy data
	else
	{
		memcpy(stack->acl_self, hci_acl_hdr, sizeof(hci_acl_hdr));
	}
    // give ACL write access and return
    stack->acl_write_hdl = hdl;
    stack->acl_write_len = len;
    stack->acl_written = 0;
    return 0;
}

/**
 * Closes a previously opened acl link.
 * 
 * Call this function after you've written your data to an acl link.
 * 
 * Note: does not close the baseband connection!
 */
void bt_acl_write_lock_release(struct btstack* stack)
{
	u_long t_stamp;
    
	// if this was not a self delivery
	if (stack->acl_write_hdl != BT_HCI_CON_HANDLE_OWN)
	{
		// release uart
    	_bt_hci_relase_write_lock(stack);
    	// increment nr_acl_pkts semaphore if there was an error
    	if (stack->acl_write_hdl == BT_HCI_HANDLE_INVALID)
    	{
    		_bt_semaphore_post(&(stack->nr_acl_pkts));
    	}
	}
    // else, we have to deliver the packet to this device
    else
    {
    	DEBUG_STR("self delivery (%d bytes)\n%s\n", acl_hdl->written + sizeof(struct bt_hci_pkt_acl) - 1,
    				dbg_str_to_hex_str(acl_dbg_buf, (u_char*)stack->acl_self, acl_hdl->written + sizeof(struct bt_hci_pkt_acl) - 1));
		// get local time
    	t_stamp = NutGetMillis();
    	// call callback
    	stack->acl_self = stack->hci_acl_cb(stack->hci_acl_cb_arg,
    										stack->acl_self,
    										bt_acl_get_con_handle(stack->acl_self),
    										bt_acl_get_pb_flag(stack->acl_self),
    										bt_acl_get_bc_flag(stack->acl_self),
    										stack->acl_written,
    										t_stamp);
    }
    // release ACL write lock
    _bt_semaphore_post(&stack->acl_write);
}

/**
 * Writes data to a previously opened acl link.
 * 
 * Call #bt_acl_acquire_write_lock() to open an acl communication link.
 * Write your data to the link using #bt_acl_lowlevel_write().
 * After sending your data, release the link using #bt_acl_write_lock_release().
 */
long bt_acl_lowlevel_write(struct btstack* stack, u_char* data, u_short len)
{
	// return error if handle is invalid
	if (stack->acl_write_hdl == BT_HCI_HANDLE_INVALID)
	{
		return BT_ERR_ACL_WRITE;
	}
	
	// prevent payload overflow
	if (stack->acl_written + len > stack->acl_write_len)
	{
		stack->acl_write_hdl = BT_HCI_HANDLE_INVALID;
		return BT_ERR_ACL_PLOAD_OVFLW;
	}
	
	// if not self-delivery
	if (stack->acl_write_hdl != BT_HCI_CON_HANDLE_OWN)
	{
		// if error, return
		if (_bt_hci_lowlevel_write(stack, data, len))
		{
			stack->acl_write_hdl = BT_HCI_HANDLE_INVALID;
			return BT_ERR_UART_COM;
		}
	}
	// if self delivery, just copy the data
	else {
		memcpy(stack->acl_self->payload + stack->acl_written, data, len);
	}
	// remember nr of bytes written
	stack->acl_written += len;
	return 0;
}

/**
 * Application interface for sending an acl packet
 */
long bt_acl_send_packet(struct btstack* stack,
						bt_hci_con_handle_t con_hdl,
						u_char pb_flag,
						u_char bc_flag,
						u_char* data,
						u_short len)
{
	long result;
	
	result =
		bt_acl_acquire_write_lock(stack, con_hdl, pb_flag, bc_flag, len);
	if (result) return result;
	
    // send data
    result = bt_acl_lowlevel_write(stack, data, len);
    
    // complete the packet
    bt_acl_write_lock_release(stack);
    return result;
}

u_short bt_acl_init(struct btstack* stack, u_short pkt_types)
{
	u_short acl_size;
	
	// set max acl size
    acl_size = BT_ACL_PAYLOAD_SIZE_DM1;
    if (pkt_types & BT_HCI_PACKET_TYPE_DH1) acl_size = BT_ACL_PAYLOAD_SIZE_DH1;
    if (pkt_types & BT_HCI_PACKET_TYPE_DM3) acl_size = BT_ACL_PAYLOAD_SIZE_DM3;
    if (pkt_types & BT_HCI_PACKET_TYPE_DH3) acl_size = BT_ACL_PAYLOAD_SIZE_DH3;
    if (pkt_types & BT_HCI_PACKET_TYPE_DM5) acl_size = BT_ACL_PAYLOAD_SIZE_DM5;
    if (pkt_types & BT_HCI_PACKET_TYPE_DH5) acl_size = BT_ACL_PAYLOAD_SIZE_DH5;
    
    // store pkt types & max acl size the host can handle
    stack->acl_pkt_types = pkt_types;
    stack->host_acl_len = acl_size;
    
    // init acl send stuff
    _bt_semaphore_init(&stack->acl_write, 1);
    stack->acl_write_hdl = BT_HCI_HANDLE_INVALID;
    stack->acl_write_len = 0;
    stack->acl_written = 0;
    
    // init acl packet for self delivery
    stack->acl_self = NutHeapAllocClear(stack->host_acl_len + BT_ACL_HCI_PKT_HDR_LEN + sizeof(void*));
    
    DEBUG("ACL: set pkt types to %d!\n", stack->acl_pkt_types);
    return acl_size;
}
