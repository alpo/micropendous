/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 * $Id: uart-echo.c,v 1.10 2006/03/23 07:22:22 dyerm Exp $
 * 
 */

/*!
 * $Log: uart-echo.c,v $
 * Revision 1.10  2006/03/23 07:22:22  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.7.2.1  2006/02/02 08:10:26  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.9  2005/12/07 15:46:47  beutel
 * fixed up some minor cosmetics and indexer problems
 *
 * Revision 1.8  2005/12/06 18:53:28  beutel
 * fixed links on api doc's for new webpage, cleaned examples docu
 *
 * Revision 1.7  2005/10/05 14:42:20  beutel
 * added sesnor-app to demo apps, added all demo apps to default makefile, changed default baud rate to 57600 baud on all apps.
 *
 */ 

/**
 * \example uart-echo/uart-echo.c
 *
 * \date 18.06.2004 
 * 
 * \author Martin Hinz <btnode@hinz.ch>
 * 
 * This application echos the application uart and signals a
 * received byte with an led pattern
 */
 
#include <string.h>
#include <stdio.h>
#include <io.h>
#include <hardware/btn-hardware.h>
#include <dev/usartavr.h>
#include <led/btn-led.h>
#include <sys/thread.h>
FILE *uart;


/*
 * listen on uart and write to uart
 */
void listen_to_uart(void)
{
    int got;
    char inbuf[20]; 
    for(;;){
        got = _read(_fileno(uart), inbuf, 20);
        btn_led_clear_pattern_queue();
        btn_led_add_pattern(BTN_LED_PATTERN_UP, 0,1, 1);
        btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 4, BTN_LED_INFINITE);
        _write(_fileno(uart), inbuf, got);        
    }
} 

int main(void){   
    u_long baud = 57600;
    btn_hardware_init();
    //initialize application UART
    //speed of uart set default to 576200
    NutRegisterDevice(&APP_UART, 0, 0);
    uart = fopen(APP_UART.dev_name, "r+");
    _ioctl(_fileno(uart), UART_SETSPEED, &baud);

    fputs("UART-echo application!\n",uart); 
    btn_led_init(1);
    btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 4, BTN_LED_INFINITE);
    
    listen_to_uart();
    return 1;
}
