/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/*!
 * $Log: rfcomm-proxy.c,v $
 * Revision 1.5  2006/11/06 11:32:50  yuecelm
 * move my email address to a permanent one
 *
 * Revision 1.4  2006/06/27 21:27:55  yuecelm
 * introduce defines
 *
 * Revision 1.3  2006/06/26 10:36:09  yuecelm
 * minor changes
 *
 * Revision 1.2  2006/06/23 13:13:05  yuecelm
 * add connection callback, re-add application example, disable debug
 *
 */ 
 
/**
 * \example rfcomm-proxy/rfcomm-proxy.c
 *
 * \date 2006/01/15 
 *
 * \author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 *
 * Example application to show the use of the RFCOMM-proxy (channel 1)
 *
 */

#include <dev/usartavr.h>
#include <hardware/btn-hardware.h>
#include <led/btn-led.h>
#include <sys/timer.h>

#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>
#include <bt/bt_rfcomm.h>

#include <dev/rfcomm_proxy.h>

// RFCOMM channel
#define RFCOMM_DEV_CHANNEL 1

// baudrate on serial port
#define RFCOMM_DEV_SERIAL_BAUDRATE 9600

// LED signalling
#define RFCOMM_DEV_LED 1
#if RFCOMM_DEV_LED > 0
#define RFCOMM_DEV_LED_HB(color)    btn_led_heartbeat(50,1<<color,1)
#define RFCOMM_DEV_LED_SET(color)   btn_led_set(color)
#define RFCOMM_DEV_LED_CLEAR(color) btn_led_clear(color)
#else
#define RFCOMM_DEV_LED_HB(color)
#define RFCOMM_DEV_LED_SET(color)
#define RFCOMM_DEV_LED_CLEAR(color)
#endif

#define BLUE      0
#define RED       1
#define YELLOW    2
#define GREEN     3

#define BT_L2CAP_HCI_PACKET_TYPE (BT_HCI_PACKET_TYPE_DM1 | \
                                  BT_HCI_PACKET_TYPE_DH1 | \
                                  BT_HCI_PACKET_TYPE_DM3 | \
                                  BT_HCI_PACKET_TYPE_DH3)

// stack size for threads
#define STACKSIZE 512

struct btstack * stack;
struct bt_l2cap_stack * l2cap_stack;
struct bt_rfcomm_stack * rfcomm_stack;

void con_cb(u_char channel, u_char connected)
{
    if (connected)
    {
        btn_hardware_io_power(1);
        RFCOMM_DEV_LED_HB(BLUE);
    }
    else
    {
        btn_hardware_io_power(0);
        RFCOMM_DEV_LED_HB(GREEN);      
    }
}

int main(void)
{
    // hardware init
    btn_hardware_init();

#if RFCOMM_DEV_LED > 0
    btn_led_init(1);
#else
    btn_led_init(0);
#endif

    RFCOMM_DEV_LED_SET(BLUE);
    
    // bluetooth module on (takes a while)
    btn_hardware_bt_on();
       
    // Start the stack and let the initialization begin
    stack = bt_hci_init(&BT_UART);
    l2cap_stack = bt_l2cap_init(stack, 8, 8, BT_L2CAP_HCI_PACKET_TYPE);
    rfcomm_stack = bt_rfcomm_init(l2cap_stack, BT_RFCOMM_DEF_MFS, 4, 5);

    RFCOMM_DEV_LED_CLEAR(BLUE);

    RFCOMM_DEV_LED_HB(GREEN);

    rfcomm_proxy_init(rfcomm_stack, RFCOMM_DEV_CHANNEL,
                      RFCOMM_DEV_SERIAL_BAUDRATE, con_cb);

    // something to do -> main cannot finish
    for (;;) {
        NutSleep(-1);
    }

    return -1;
}
