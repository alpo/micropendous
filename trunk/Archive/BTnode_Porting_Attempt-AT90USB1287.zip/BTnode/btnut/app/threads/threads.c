/*!
 * Copyright (C) 2001-2004 by egnite Software GmbH. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY EGNITE SOFTWARE GMBH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL EGNITE
 * SOFTWARE GMBH OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 */

/*!
 * $Log: threads.c,v $
 * Revision 1.5  2006/03/29 01:15:01  olereinhardt
 *
 * Changed signedness of strings in order to compile with avr-gcc 4.0.2
 *
 * Revision 1.4  2006/03/23 07:22:24  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.2.4.1  2006/02/02 08:10:26  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.3  2005/12/06 18:53:28  beutel
 * fixed links on api doc's for new webpage, cleaned examples docu
 *
 * Revision 1.2  2004/10/26 10:15:26  dyerm
 * with heartbeat und cpu freq.
 *
 * Revision 1.1  2004/10/25 13:27:06  freckle
 * added threads example from ehternut
 *
 */

/*!
 * \example threads/threads.c
 * 
 * \date 2004/10/25
 * \author Matthias Ringwald
 *
 * This sample demonstrates Nut/OS multithreading.
 *
 * Each thread is started with 192 bytes of stack. This is very
 * low and doesn't provide much space for local variables.
 */

#include <stdio.h>
#include <io.h>

#include <sys/thread.h>
#include <sys/timer.h>

#include <dev/usartavr.h>
#include <hardware/btn-hardware.h>
#include <led/btn-led.h>


/*
 * High priority thread.
 */
THREAD(Thread1, arg)
{
    /*
     * Endless loop in high priority thread.
     */
    NutThreadSetPriority(16);
    for (;;) {
        putchar('H');
        NutSleep(125);
    }
}

/*
 * Low priority thread.
 */
THREAD(Thread2, arg)
{
    /*
     * Endless loop in low priority thread.
     */
    NutThreadSetPriority(128);
    for (;;) {
        putchar('L');
        NutSleep(125);
    }
}

/*
 * Main application thread. 
 */
int main(void)
{
    u_long baud = 115200;

    /*
     * Register the UART device, open it, assign stdout to it and set 
     * the baudrate.
     */
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "w", stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);

    puts("\nThread Test running on BTnut");
    u_long cpu_crystal = NutGetCpuClock();
    printf("CPU = %u.%04u MHz\n",(int) (cpu_crystal / 1000000UL), (int) ((cpu_crystal - (cpu_crystal / 1000000UL) * 1000000UL) / 100));


    // start heartbeet
    btn_led_init(1);
    

    /*
     * Start two additional threads. All threads are started with 
     * priority 64.
     */
    NutThreadCreate("t1", Thread1, 0, 192);
    NutThreadCreate("t2", Thread2, 0, 192);

    /*
     * Endless loop in main thread.
     */
    for (;;) {
        putchar('M');
        NutSleep(125);
    }
    return 0;
}
