/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 */

/**
 * \example l2cap_cl_test/l2cap_cl_test.c
 * 
 * \date 2005/10/20
 *
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch>
 *
 * \brief Test application used to verify the connectionless l2cap layer.
 * 
 * This test application was mainly used to verify buffer management and
 * data delivery of the connectionless l2cap layer.
 * 
 * Using the terminal command "register <psm>" (see below) registers a dummy
 * data callback which simply blocks when it is called. This data callback
 * is called whenever a packet for the psm specified arrives (see below).
 * Calling the terminal command "unblock <service_nr>" wakes up the blocked
 * service with service number 'service_nr'.
 * Clear a registered service using "l2capc clear <service_nr>".
 * 
 * Use the command "l2capc send <handle> <psm> <data_size> to send
 * a connectionless l2cap packet to the connected device on handle <handle>:
 * after invocation, a connectionless l2cap packet of the size <data_size>
 * will be created and sent to the psm <psm> of the connected remote device
 * 
 * After invoking the "register" command the dummy callback will be called
 * in context of a common 'delivery-thread'. Call
 * "chctxt <service_nr> <td_size>" to change the context of packet delivery:
 * a new thread with stacksize <td_size> is created which is then responsible
 * for delivering packets arriving for service with nr <service_nr>.
 * Pass zero if delivery shall be done in context of the bt-stack.
 * 
 * Note: With the new event logger, debug output is no longer printed
 * directely to the terminal.
 * Use the terminal command "log show" to see the events logged during your
 * session.
 */
#include <stdio.h>
#include <dev/usartavr.h>
#include <sys/heap.h>
#include <sys/event.h>
#include <sys/thread.h>
#include <hardware/btn-hardware.h>

#include <bt/bt_hci_cmds.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <bt/bt_acl_defs.h>

#include <terminal/btn-terminal.h>
#include <terminal/log-cmds.h>
#include <terminal/btn-cmds.h>
#include <terminal/bt-cmds.h>
#include <terminal/nut-cmds.h>
#include <terminal/bt_psm-cmds.h>
#include <terminal/l2cap_cl-cmds.h>
#include <led/btn-led.h>

// debug settings
#define LOG_LEVEL	4
#define LOG_CLASS	16
#include <debug/log_set.h>

//#include <sys/tracer.h>

#define MAX_NR_SERVICES 	8

struct _l2cap_cl_test_stack {
	struct btstack* bt_stack;
	bt_psm_t* psmux;
	u_short acl_size;
	u_char data_buf[3*121];
	HANDLE unblock[MAX_NR_SERVICES];
};

struct _l2cap_cl_test_stack* stack;

bt_acl_pkt_buf* l2cap_cl_test_data_cb(bt_acl_pkt_buf* msg, u_char* data,
                                      u_short len, u_short service_nr,
                                      void* cb_arg)
{
	u_char i;
	
	// print data
	printf("rcvd %d bytes on handle %d, service_nr: %d!\n",
							len, bt_acl_get_con_handle(msg->pkt), service_nr);
	for (i=0; i<len; i++) {
		printf("%.2x ", data[i]);
	}
	printf("\n");
	
	// print context
	printf("context: %s\n", runningThread->td_name);
	
	NutEventWait(&stack->unblock[service_nr], NUT_WAIT_INFINITE);
	printf("service: %d, callback returned!\n", service_nr);
	return msg;
}

// register service
void l2cap_cl_test_cmd_register_service(char* arg) {
	long service_nr = 0;
	int psm;
	// parse user input
	if (sscanf(arg, "%u", &psm) == 1) {
		psm = (u_short)psm;
		service_nr = bt_psm_service_register(stack->psmux, psm,
									l2cap_cl_test_data_cb, NULL);
		if (service_nr == BT_PSM_ERR_INVALID_PSM)
			printf("error: invalid psm (%d)!\n", psm);
		else if (service_nr == BT_PSM_ERR_PSM_IN_USE)
			printf("error: psm %d in use by service %li!\n", psm, service_nr);
		else if (service_nr == BT_PSM_ERR_SERVICE_PORTS_EXHAUSTED)
			printf("error: too many services!\n");
		else
			printf("service registered. nr: %d, psm: %d\n", (u_short)service_nr, psm);
	}
	else printf("error usage: register <psm>\n");
}

void l2cap_cl_test_cmd_unblock_cb(char* arg) {
	int service_nr;
	// parse user input
	if (sscanf(arg, "%u", &service_nr) == 1) {
		// unblock the corresponding thread
		NutEventPost(&stack->unblock[service_nr]);
	}
	else printf("error usage: unblock <service_nr>\n");
}

/**
 * main function that initializes the hardware, led, terminal, bluetooth
 * and acl communication stack and registers some predefined commands.
 * Use tab-tab to see the registered commands once the program is running.
 */
int main(void)
{	
    // serial baud rate
    u_long baud = 57600;

    // hardware init
    btn_hardware_init();
    btn_led_init(1);
    
    // dyn. allocate test stack
    stack = NutHeapAllocClear(sizeof(struct _l2cap_cl_test_stack));
    
    // init app uart
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "r+", stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);
    
    // logging
    log_init();
    
    // hello world!
    printf("\n# --------------------------------------------");
    printf("\n# Welcome to BTnut (c) 2005 ETH Zurich\n");
    printf("# --------------------------------------------");
    printf("\nbooting bluetooth module... ");

    // bluetooth module on (takes a while)
    btn_hardware_bt_on();
    printf("ok.\n\r");
    
    // verbose debug of all hci information
    // _bt_hci_debug_uart = 1;
    
    // Start bt-stack and let the initialization begin
    printf("init bt-stack... ");
    stack->bt_stack = bt_hci_init(&BT_UART);
    printf("done.\n");
    
    // Init acl layer
    printf("init acl layer... ");
    bt_acl_init(stack->bt_stack, BT_HCI_PACKET_TYPE_DM3);
    printf("done.\n");
    
    // Init the protocol service multiplexor
    printf("protocol / service mux... ");
    stack->psmux = bt_psm_init(stack->bt_stack, MAX_NR_SERVICES, 4);
    printf("done.\n");
    
    // Init connectionless l2cap stack
    printf("connectionless l2cap... ");
    l2cap_cl_init(stack->bt_stack, stack->psmux);
    printf("done.\n");

    // give hint
    printf("hit tab twice for a list of commands\n\r");
    
    // terminal init
    btn_terminal_init(stdout, "[bt-cmd@btnode]$");
    
    // init bluetooth cmds
    bt_cmds_init(stack->bt_stack);
    bt_cmds_register_cmds();
    
    // init btnode cmds
    btn_cmds_register_cmds();
    
    // init nut/os cmds
    nut_cmds_register_cmds();
    
    // init commands for protocol / service multiplexor
    bt_psm_cmds_init(stack->psmux);
    bt_psm_cmds_register_cmds();
    
    // init l2cap connection-less cmds
    l2cap_cl_cmds_init(stack->bt_stack);
    l2cap_cl_cmds_register_cmds();

	// init log cmds
	log_cmds_init(stdout);
    
    // register cmds for testing the point-to-point protocol
    btn_terminal_register_cmd("register", l2cap_cl_test_cmd_register_service);
    btn_terminal_register_cmd("unblock", l2cap_cl_test_cmd_unblock_cb);

    // terminal mode
    btn_terminal_run(BTN_TERMINAL_NOFORK, 0);

    return 0;
}
