/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 */

/**
 * \example mhop_blink/mhop_blink.c
 * 
 * \date 2005/10/27
 *
 * \author Kevin Martin <kevmarti@tik.ee.ethz.ch>
 *
 * \brief Simple example application using the connectionless multi-hop
 * transport layer and a connection manager.
 * 
 * With this application it is possible to send "blink" commands to an
 * arbitrary node in a connected network. Network establishment is done
 * automatically by the connection manger.
 * 
 * After sending a "blink" cmd pkt to a destination node, receiving
 * intermediate nodes flash their blue and red LED's, while the destination
 * node flashes all LED's.
 * 
 * When receiving a "blink" cmd, the receiving node stores the source of the
 * packet in its forwarding table (i.e. the packets sent have set the
 * "source recording" flag). Thus, being lucky (depending on the network
 * topology the connection manager formed) it is possible to gain some inside
 * into the underlying routing protocol.
 */
#include <stdio.h>
#include <dev/usartavr.h>
#include <sys/heap.h>
#include <sys/event.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <hardware/btn-hardware.h>
#include <led/btn-led.h>

#include <bt/bt_hci_defs.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_acl_defs.h>
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>

#include <mhop/mhop_cl.h>
#include <mhop/mhop_init.h>

#include <terminal/btn-terminal.h>
#include <terminal/bt_psm-cmds.h>
#include <terminal/bt-cmds.h>
#include <terminal/log-cmds.h>
#include <terminal/mhop_cl-cmds.h>

#include <debug/logging.h>

// choose your connection manger here!
#include <cm/cm_tree.h>

#include "program_version.h"


#define MAX_NR_SERVICES 	16

#define FWD_BUF_SIZE		5

#define CM_PSM				0x1003
#define MHOP_PSM			0x1005
#define BLINK_PSM			0x1007

#define CM_COD              933


/**
 * \brief Data callback of the "blink" service.
 * 
 * This callback is called each time a "blink" request arrives.
 * 
 * Depending on the target address of the received packet, different LED's
 * start to blink.
 * 
 * \param msg Pointer to the received packet
 * \param data Pointer to the payload of the received packet
 * \param data_len Size of the payload
 * \param service_nr The service number this callback corresponds to
 * \param cb_arg Callback argument: could be defined when registering at
 * the protocol/service multiplexor (see #mhop_blink_service_register).
 * Unused in this example.
 */
bt_acl_pkt_buf* _mhop_blink_data_cb(bt_acl_pkt_buf* pkt_buf,
									u_char* data,
									u_short data_len,
									u_short service_nr,
									void* cb_arg)
{
	u_char* target;
	target = mhop_cl_get_target_addr(pkt_buf->pkt);
	
	// let all LED's blink
	btn_led_add_pattern(BTN_LED_PATTERN_ON_OFF, 15, 3, 5);
	
	// free the received message
	return pkt_buf;
}

/**
 * \brief Query function of the "blink" service.
 * 
 * This function sends a "blink" request packet to the target device passed.
 * 
 * Note: in the initialization routine, this function is registered at the
 * btnode terminal to enable user interaction. Functions registered at the
 * terminal do always take a string as their argument.
 */
void _mhop_blink_cmd_send_blink_rqst(char* arg) {
    u_char i;
    unsigned int addr[BD_ADDR_LEN];
    bt_addr_t dest_addr;
    
    // parse user input
    if (sscanf(arg, "%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
    	// store bt addr
        for (i = 0; i < BD_ADDR_LEN; i++) {
            dest_addr[i] = (u_char) addr[i];
        }
        // send the packet
        mhop_cl_send_pkt(NULL, 0, dest_addr, BLINK_PSM, MHOP_CL_BROADCAST, MHOP_CL_TTL_INFINITE);
        tprintf("blink rqst sent.\n");
    }
    else tprintf("error usage: blink <addr>\n");
}


void _mhop_blink_cmd_send_blink_reply(char* arg) {
    u_char i;
    unsigned int addr[BD_ADDR_LEN];
    bt_addr_t dest_addr;
    long retval;
    
    // parse user input
    if (sscanf(arg, "%2x:%2x:%2x:%2x:%2x:%2x", &addr[5], &addr[4], &addr[3], &addr[2], &addr[1], &addr[0]) == 6) {
    	// store bt addr
        for (i = 0; i < BD_ADDR_LEN; i++) {
            dest_addr[i] = (u_char) addr[i];
        }
        // send the packet
        retval = mhop_cl_send_pkt(NULL, 0, dest_addr, BLINK_PSM, MHOP_CL_UNICAST, MHOP_CL_TTL_INFINITE);
        tprintf("blink reply sent: %d\n", retval);
    }
    else tprintf("error usage: blink <addr>\n");
}

/**
 * \brief Registers the "blink" service at the protocol/service multiplexor
 * 
 * For that the "blink" service is accessible by remote devices, it has
 * to be registered at the protocol/service multiplexor: On a receiving device,
 * the protocol/service multiplexor uses the unique identifier \param psm
 * found in a received packet to deliver it to the service registered at
 * psm \param psm.
 * 
 * \param psmux Pointer to the protocol/service multiplexor
 * \param psm PSM to use for the "blink" service
 */
long mhop_blink_service_register(bt_psm_t* psmux, u_short psm)
{
	long blink_service_nr;
	
	// register "blink" service at psmux
	blink_service_nr =
		bt_psm_service_register(psmux, BLINK_PSM, _mhop_blink_data_cb, NULL);
	
	// return if the "blink" service could has not been registered properly
	if (blink_service_nr < 0) {
		printf("error registering blink service!\n");
		return blink_service_nr;
	}
	// else, set packet buffers for the "blink" service
	else {
		// we don't need any buffers for the "blink" service!
		bt_psm_service_set_buffers(psmux, blink_service_nr, NULL);
	}
	return blink_service_nr;
}

/**
 * \brief Initialization routine
 * 
 * Initialization routinge that initializes the hardware, the led's the
 * terminal, as well as the bluetooth and the multi-hop communication
 * stacks.
 * 
 * At the end of the routine, the "blink" service is registered at
 * the protocol/service multiplexor, and the command for sending a
 * "blink" request is registered at the terminal.
 */
int main(void)
{
//	FILE* terminal;
	// pointer to the bt_stack
	struct btstack* bt_stack;
	
	// pointer to the protocol/service multiplexor
	bt_psm_t* psmux;
	
    // serial baud rate
    u_long baud = 57600;

    // hardware init
    btn_hardware_init();
    btn_led_init(1);
    
    // init terminal app uart
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "r+", stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);
        
    // init event logger
    log_init();
    
    // hello world!
    printf("\n# --------------------------------------------");
    printf("\n# Welcome to BTnut (c) 2006 ETH Zurich\n");
    printf("# program version: %s\n", PROGRAM_VERSION);
    printf("# --------------------------------------------");
    printf("\nbooting bluetooth module... ");

    // bluetooth module on (takes a while)
    btn_hardware_bt_on();
    printf("ok.\n\r");
    
    // Start bt-stack and let the initialization begin
    printf("init bt-stack... ");
    bt_stack = bt_hci_init(&BT_UART);
    printf("done.\n");

	// Initialize connection-less multi-hop layer
    // Set ACL packet types
    printf("setting acl pkt types... ");
    bt_acl_init(bt_stack, BT_HCI_PACKET_TYPE_DM3);
    printf("done.\n");
    
    // Init protocol/service multiplexor
    printf("init protcol/service mux... ");
    psmux = bt_psm_init(bt_stack, MAX_NR_SERVICES, 4);
    printf("done.\n");
    
    // Init connectionless l2cap stack
    printf("init connectionless l2cap... ");
    l2cap_cl_init(bt_stack, psmux);
    printf("done.\n");
    
    // Init connection manager
    printf("init connection manager... ");
    con_mgr_init(bt_stack, psmux, CM_PSM, bt_hci_register_con_table_cb, CM_COD);
    printf("done.\n");
    
    // Init connectionless multihop protocol
    printf("init connectionless multi-hop protocol... ");
    mhop_cl_init(bt_stack,
    				psmux,
    				MHOP_PSM,
    				6,
    				con_mgr_register_con_table_cb);
    printf("done.\n");
	   
	// register the "blink" service at the service / protocol multiplexor
	mhop_blink_service_register(psmux, BLINK_PSM);

	// init terminal & give hint
	btn_terminal_init(stdout, "[mblink@btnode]$");
    printf("hit tab twice for a list of commands\n\r");
    
	// register "blink" command at terminal
	btn_terminal_register_cmd("blink", _mhop_blink_cmd_send_blink_rqst);
	
	// register "reply" command at terminal
	btn_terminal_register_cmd("reply", _mhop_blink_cmd_send_blink_reply);
		
    // terminal mode
    btn_terminal_run(BTN_TERMINAL_NOFORK, 0);

    return 0;
}
