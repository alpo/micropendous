/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: l2cap-cmd.c,v 1.8 2006/03/27 14:14:04 kevmarti Exp $
 * 
 */

/*!
 * $Log: l2cap-cmd.c,v $
 * Revision 1.8  2006/03/27 14:14:04  kevmarti
 * Reverted changes in hci acl data callback & changes 'l2cap.c'
 *
 * Revision 1.7  2006/03/24 15:06:29  dyerm
 * removed obsolete bt_acl_com
 *
 * Revision 1.6  2006/03/23 07:22:25  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.4.2.3  2006/03/22 10:11:11  kevmarti
 * Adapted call to 'bt_l2cap_init()'
 *
 * Revision 1.4.2.2  2006/03/21 10:30:55  kevmarti
 * - Added ACL initialization (moved from 'l2cap_init()' to 'bt_acl_init()')
 * - Adapted to new interface of 'l2cap_init()'
 *
 * Revision 1.4.2.1  2006/02/02 08:09:37  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.5  2005/12/06 18:53:28  beutel
 * fixed links on api doc's for new webpage, cleaned examples docu
 *
 * Revision 1.4  2005/10/05 14:42:21  beutel
 * added sesnor-app to demo apps, added all demo apps to default makefile, changed default baud rate to 57600 baud on all apps.
 *
 */ 

/**
 * \example l2cap-cmd/l2cap-cmd.c
 *
 * \date  2005/04/11
 *
 * \author Ole Reinhard
 * \author Jan Beutel <j.beutel@ieee.org>
 *
 * Example application to show the use of the Bluetooth L2CAP layer.
 */

#include <stdio.h>
#include <string.h>
#include <io.h>
#include <stdlib.h>
#include <dev/usart.h>
#include <dev/usartavr.h>
#include <sys/thread.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>
#include <terminal/btn-terminal.h>
#include <terminal/btn-cmds.h>
#include <terminal/bt-cmds.h>
#include <terminal/nut-cmds.h>
#include <terminal/l2cap-cmds.h>
#include <led/btn-led.h>
#include <hardware/btn-hardware.h>

#define BT_L2CAP_HCI_PACKET_TYPE         (BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DH1 | \
                                          BT_HCI_PACKET_TYPE_DM3 | BT_HCI_PACKET_TYPE_DH3)

/*
#define BT_L2CAP_HCI_PACKET_TYPE        (BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DH1 |\
                                         BT_HCI_PACKET_TYPE_DM3 | BT_HCI_PACKET_TYPE_DH3 |\
                                         BT_HCI_PACKET_TYPE_DM5 | BT_HCI_PACKET_TYPE_DH5)

*/

FILE *uart_terminal;
struct btstack* stack;
struct bt_l2cap_stack* l2cap_stack;

/**
 * to initialize the terminal
 */
void init_term(void) {
    u_long baud = 57600;
    
    // initialize UART 1
    NutRegisterDevice(&APP_UART, 0, 0);
    uart_terminal = fopen(APP_UART.dev_name, "r+");
    _ioctl(_fileno(uart_terminal), UART_SETSPEED, &baud);
    btn_terminal_init(uart_terminal, "[bt-cmd@btnode]$");
}

/**
 * main function that initializes the hardware, led, terminal, bluetooth
 * and acl communication stack and registers some predefined commands.
 * Use tab-tab to see the registered commands once the program is running.
 */
int main(void)
{
    //long retval;
    btn_hardware_init();
    // btnode init
    btn_led_init(1);
    init_term();
    btn_hardware_bt_on();
    
    // Register DebugDevice (there comes the output if DEBUG was enabled
    // during the compilation of the stack)
    //NutRegisterDevice( &devDebug1, 0, 0);
    freopen(APP_UART.dev_name, "w", stdout);
    DEBUGT("bt-cmd started...\n");
    
    // Start the stack and let the initialization begin
    stack = bt_hci_init(&BT_UART);
    
    bt_hci_write_local_cod(stack, BT_HCI_SYNC, 200);
    
    // init l2cap
    l2cap_stack =
    	bt_l2cap_init(stack, 8, 8, BT_L2CAP_HCI_PACKET_TYPE);

    // terminal init
    bt_cmds_init(stack);
    l2cap_cmds_init(l2cap_stack, 1, BT_L2CAP_MIN_MTU, BT_L2CAP_MTU_DEFAULT);
    
    bt_cmds_register_cmds();
    btn_cmds_register_cmds();
    nut_cmds_register_cmds();
    l2cap_cmds_register_cmds();
    
    //register_cmds();
    DEBUGT("cmds registered\n");
    btn_terminal_run(BTN_TERMINAL_NOFORK, 0);
    return 0;
}
