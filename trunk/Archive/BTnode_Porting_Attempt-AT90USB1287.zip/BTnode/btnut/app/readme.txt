readme.txt for application examples of BTnut

2004.10.26 Matthias Ringwald <mringwal@inf.ethz.ch>


Example Applications to get started using BTnut
-----------------------------------------------

This folder contains several applications that allow to
get started on the BTnut System running on BTnode hardware
and emulated on unix machines. All applications are sending
to the serial port at 57600, 8N1, no flowcontrol.


List of sample applications
---------------------------
threads - show the usage of priorities and several cooperative
threads.

uart-echo - an application that echos received data on the serial
port and flashes the LEDs.

uart-suart - similar to the uart-echo, this application echoes
data received on the hardware serial port to a software uart
at 9600 baud.

bt-cmd - a terminal application that allows to explore the
bluetooth functionality. Press the TAB key twice to get a
list of commands.

l2cap-cmd - an extended version of the bt-cmd that allow to
play and test the l2cap layer implementation.

btstreamer - a bit outdated test applications that is used
for bluetooth performance and stability testing 


List of other applications
--------------------------

bttest - is used for low-level production test of BTnode Rev3.
All BTnode Rev3 nodes that are distributed pass the tests.
The usage of this application requires in-detail knowledge
of the hardware and can potentially harm your device.
Don't use it.

bootloader - the bootloader application allows to program
a BTnode via a serial cable and/or over the air by storing
a new flash image in the extended SRAM of the node. 
You should get a BTnode with a working bootloadern and 
should not need to write the bootloader to the ATmega flash
yourself.


