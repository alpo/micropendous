readme.txt for boot loader on btnode (ATmega128L)

2004.06.04 Martin Hinz <btnode@hinz.ch>
2004.10.04 Matthias Ringwald <mringwal@inf.ethz.ch>


Boot Loader Support for the ATmega128 targets
----------------------------------------------

This folder contains the boot loader application that allows to update the
flash image of the microcontroller in two ways: via a serial connection at
startup or by a running application itself. 

For this to work, this boot loader application has to be stored in the
boot loader section of the ATmega128 and the BOOTSZ fuse bits have to be
configured properly.


Receiving the Program Data
--------------------------

Our boot loader can receive the program data by two ways, either it is
already stored in the extended SRAM of the BTnode (256 KB) or it is
received over a uart connection from a AVR programming tool that supports
the protocol of the SDK 500. The SDK 500 is at supported by Atmel's AVR Studio,
the uisp tool and others. The boot loaders uses the defined APP_UART interfaces
which is uart1 on rev2.2 and uart0 on rev3 BTnodes.


Setup and upload the Boot Loader onto the BTnode (INSTALL)
----------------------------------------------------------

The boot loader is using the maximum boot section of 4096 words.
To enable boot loader support you have to set the  boot section size and
set the boot reset fuse.  With this settings the CPU will start at 
the boot section after reset.

If you're using BTnode Rev3 nodes, you skip this section as the 
bootloader is already installed.


If your using uisp with an STK500 board or ATMEL's AVR ISP connected to /dev/ttyS0,
you can use the following commands:

> uisp -v=3 -dprog=stk500 -dserial=/dev/ttyS0 -dpart=ATmega128 --rd_fuses
to read the fuse bytes

For a BTnode Rev3, you'll get low, high, extended = 0x8e, 0x00, 0xff

For our bootloader you want to set: 
High Fuse Bit 0: BOOTRST = 0
High Fuse Bit 1: BOOTSZ0 = 0
High Fues Bit 2: BOOTSZ1 = 0

so the three lower bits of the high fuse are 0.

After figuring out the correct high fuse value, you can set the new value by:

> uisp -v=3 -dprog=stk500 -dserial=/dev/ttyS0 -dpart=ATmega128 --wr_fuse_h=NEW_VALUE

Use NEW_VALUE = 0 to enable boot loader, JTAG debugging, SPI program download
and no preservation of EEPROM content during re-programming with --erase command.
To get further information see ATmega128L datasheet.


To install the boot loader, enter in the boot loader folder

> make upload TARGET
with TARGET = BTnode2 or BTnode3

Note: The boot loader has to be uploaded by an ISP programmer first. :)



Usage
-----
 
With this boot loader you can upload a program via:

1) uart cable and uisp tool

2) bluetooth dongle and upload-bt program running on a unix system
   (not implemented yet)

3) running BTnut Application

Remark: using the boot loader, a Flash erase is not possible as the boot
loader resides in the the Flash, too.

All LEDs will be on while the Boot Loader program is running!



1) UART upload
--------------

At startup the boot loader sends the characters 0x14 and 0x10 to the APP_UART
which are the O.K. answer of the uisp protocol. If there is a waiting uisp 
program it answers immediately with the next programming command and the Boot
Loader recognizes the uisp programming approach. If no uisp program answers
the application starts. 

The easiest way to use the uart upload is: hold the reset button down on the
BTnode, start uisp and then release the reset button!



2) Running BTnut Application
-----------------------------------

A running app can store a new flash image that it gets from somewhere somehow
into the extended SRAM, sets some flags and trigger a RESET. After startup,
the boot loader first checks for a waiting uisp tool, then checks if there
is a valid flash image in the SRAM. If it is found and th REPROG_BOOT_ACTIVE
flag is set, the flash image is transfered into the flash programm memory.



2) OVER-THE-AIR-PROGRAMMING service
-----------------------------------

this extnension of the previouis method will allow to reprogram the BTnode
over the air.

-> not implemented for the BTnut System Software yet



Advantages:
-----------

Only once a programmer is needed to program the boot loader and set the fuse
bits. With the boot loader it is possible to load any program over the uart
interface using the uisp tool.

Uart programming is faster than STK500 programming. To speed up the programming
over-the-air parallel programming could be implemented:

Timings:
programming the boot loader with a STK500 (CVS Version): ~ 4 sec
programming an application with a STK500: ~31sec (85KByte)
programming application with boot loader, uisp over uart1: ~18sec (85KByte)
programming application with boot loader, upload-bt over bluetooth: (85KByte)
  inquiry(6sec), sending data (17sec), programming (10sec) = ~33sec 
(values for over-the-air used from BTnode System Software)



Deactivating the boot loader (UNINSTALL)
----------------------------------------
The Boot Loader can be turned off by setting the bit0 of the high fuse to 1.
This also turns off the sending ot the two chars 0x14 and 0x10 at booting time.

