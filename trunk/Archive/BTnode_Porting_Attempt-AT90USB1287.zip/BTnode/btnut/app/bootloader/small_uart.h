/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/*
 * small_uart.h - Small Uart driver for uisp protocol
 *
 * 2004.02.13 Martin Hinz <hinz@tik.ee.ethz.ch>
 *
 */

#ifndef SMALL_UART_H_INCLUDED
#define SMALL_UART_H_INCLUDED

#include <sys/types.h>

#define UART_PARITY_NONE 0
#define UART_PARITY_EVEN 1
#define UART_PARITY_ODD 2

/*
 * init the uart default: baud 115200, none_parity
 */
void small_uart_init(void);

/*
 * to change the baudrate
 */
void small_uart_set_baud_rate(u_long baudrate);

/*
 * to change the parity bit
 */
void small_uart_set_parity(u_char parity);

/*
 * reads n bytes and stores it into the buffer buf
 * this function is blocking
 */
void small_uart_read(u_char * buf, u_short n);

/*
 * reads maximum n bytes and stores it into the buffer buf
 * the function returns with amount of read bytes after time ms
 * or n bytes have been read.
 */
u_char small_uart_read_t(u_char * buf, u_short n, u_short time);

/*
 * function that adds char 0x14 at the beginning of data
 * and 0x10 at the end (uisp protocol) and calls 
 * small_uart1_write
 */
void small_uart_write_ans(u_char * data, u_short count);

/*
 * writes data to uart1
 * this function is blocking!
 */
void small_uart_write(u_char * data, u_short count);

#endif                          // UART_H_INCLUDED
