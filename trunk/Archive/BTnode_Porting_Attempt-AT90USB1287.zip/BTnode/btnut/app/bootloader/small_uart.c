/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/*
 * small_uart.c - device driver for hardware UART on AVR atmega128 platform
 *
 * 2004.02.13 Martin Hinz <hinz@tik.ee.ethz.ch>
 * 2004.10.05 Matthias Ringwald <mringwal@inf.ethz.ch>
 */

/* only small uart that receives program code for the bootloader from
 * uart. max 231byte (page = 256 + 5 byte header and end)
 * use internal buffer only for header and parameter code, as soon as
 * program data arrives switch to ImagePage buffer on bootloader.c
 * send can be blocking and only one buffer needed
 */

/* -------------------------------------------------------------------------
 * includes
 * ------------------------------------------------------------------------- */

#include "small_uart.h"
#include <hardware/btn-hardware.h>

// pos of ram image
u_char ramimage_pos;

//
u_char code_arriving;

//
u_char write_blocking;

// -------------------------------------------------------------------------
//
// -------------------------------------------------------------------------
// read n bytes and give pointer to first byte back
// block until n bytes in memory or time is up! gives back how many read

u_char small_uart_read_t(u_char * buf, u_short n, u_short ms)
{
    u_short i, j;
    u_char uart_pos = 0;
    for (i = 0; i < ms; i++) {
        for (j = 0; j < 919; j++) {
#if (APP_UART_NR == 0)
            if (UCSR0A & (1 << RXC)) {
                buf[uart_pos] = inp(UDR0);
#else
            if (UCSR1A & (1 << RXC)) {
                buf[uart_pos] = inp(UDR1);
#endif
                uart_pos++;
                if (uart_pos == n)
                    return n;
            }
        }
    }
    return uart_pos;
}

void small_uart_read(u_char * buf, u_short n)
{
    u_short uart_pos = 0;
    //wait until n bytes available
    while (uart_pos < n) {
        //wait for next data
#if (APP_UART_NR == 0)
        while (!(UCSR0A & (1 << RXC))) {
        }
        buf[uart_pos] = inp(UDR0);
#else
        while (!(UCSR1A & (1 << RXC))) {
        }
        buf[uart_pos] = inp(UDR1);
#endif
        uart_pos++;
    }
}

// -------------------------------------------------------------------------
// 
// -------------------------------------------------------------------------
// special write that is blocking and will add char 0x14 at the front of the
// buffer and char 0x10 at the end (uisp protocol!)

void small_uart_write_ans(u_char * data, u_short count)
{
    u_char buf[1];
    buf[0] = 0x14;              //uisp char for ans
    small_uart_write(buf, 1);
    small_uart_write(data, count);
    buf[0] = 0x10;              //uisp char for o.k.
    small_uart_write(buf, 1);
}

void small_uart_write(u_char * data, u_short count)
{
    u_short i;
    for (i = 0; i < count; i++) {
#if (APP_UART_NR == 0)
        while (!(UCSR0A & (1 << UDRE)));
        // clear TXC flag
        cbi(UCSR0A, TXC);
        outp(data[i], UDR0);
#else
        while (!(UCSR1A & (1 << UDRE)));
        // clear TXC flag
        cbi(UCSR1A, TXC);
        outp(data[i], UDR1);
#endif
    }                           // end for
}

/*-------------------------------------------------------------------------
 * small_uart1_set_baud_rate
 * PRE: CPU_FREQ is set correctly
 * ------------------------------------------------------------------------- */
void small_uart_set_baud_rate(u_long baudrate)
{
    // prescaler of UART1 for selected Baudrate
    //
    // UBRR1H=0 (always)
    // UBRR1L=
    //              system clock
    //              3.6864 MHz    7.3728 MHz
    // bautrate
    //  14.4K       15            31
    //  28.8K        7            15
    //  57.6K        3             7
    //  76.6K        2             5
    // 115.2K        1             3
    // 230.4K        0             1

    // BAUD = CPU_FREQ / (16 * (UBBR + 1)) 
    // UBBR = CPU_FREQ / ( 16 * BAUD) - 1 = ((CPU_FREQ / 16 ) / BAUD) - 1

    // use 32 bit arithmetics
    u_long ubrr = CPU_FREQ / 16;
    ubrr = ubrr / baudrate - 1;
    // set UBRR
#if (APP_UART_NR == 0)
    outp(ubrr & 255, UBRR0L);
    outp(ubrr >> 8, UBRR0H);
#else
    outp(ubrr & 255, UBRR1L);
    outp(ubrr >> 8, UBRR1H);
#endif
}

/*-------------------------------------------------------------------------
 * small_uart1_set_parity
 * ------------------------------------------------------------------------- */
void small_uart_set_parity(u_char parity)
{
    u_char newParity = inp(UCSR1C) & (255 - (1 << UPM1) - (1 << UPM0));
    switch (parity) {
    case UART_PARITY_NONE:
        // set odd parity
        break;
    case UART_PARITY_EVEN:
        // set odd parity
        newParity |= (1 << UPM1);
        break;
    case UART_PARITY_ODD:
        // set odd parity
        newParity |= (1 << UPM1) | (1 << UPM0);
        break;
    }
#if (APP_UART_NR == 0)
    outp(newParity, UCSR0C);
#else
    outp(newParity, UCSR1C);
#endif
}

// -------------------------------------------------------------------------
//
// -------------------------------------------------------------------------
void small_uart_init()
{
    //set enable interrupts
    cli();
    code_arriving = 0;
    // set default baud rate
    small_uart_set_baud_rate(115200);
    // set parity
    small_uart_set_parity(UART_PARITY_NONE);

#if (APP_UART_NR == 0)
    // enable receiver
    sbi(UCSR0B, RXEN);
    // enable transmitter
    sbi(UCSR0B, TXEN);
    // set up CTS port as input
    cbi(UART0_CTS_DDR, UART0_CTS_BIT);
    // set up RTS port as output
    sbi(UART0_RTS_DDR, UART0_RTS_BIT);
    // unset RTS, allow other side to transmit
    cbi(UART0_RTS_PORT, UART0_RTS_BIT);
    // set internal pull-up for uart rx
    sbi(PORTE, 0);


#else                           //btnode rev2, app uart nr == 1
    // enable receiver
    sbi(UCSR1B, RXEN);
    // enable transmitter
    sbi(UCSR1B, TXEN);
#ifdef UART1_CTS_BIT
    // set up CTS port as input
    cbi(UART1_CTS_DDR, UART1_CTS_BIT);
#endif
    // set up RTS port as output
    sbi(UART1_RTS_DDR, UART1_RTS_BIT);
    // unset RTS, allow other side to transmit
    cbi(UART1_RTS_PORT, UART1_RTS_BIT);
    // set internal pull-up for uart rx
    sbi(PORTD, 2);
#endif
}

