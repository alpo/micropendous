/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */


/*
 * BT bootloader, bootloader.c
 * 
 * 22nd Jan 2003 Urs Frey <ufrey@smartballs.ch>
 * 2004.02.19 Martin Hinz <hinz@tik.ee.ethz.ch>
 * 2004.10.07 Matthias Ringwald <mringwal@inf.ethz.ch>
 * 2005.05.18 Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 *
 *
 * First the bootloader checks if uisp tool (20030618 and 20040311 tested)
 * wants to send program code (1.)
 * if not, the SRAM will be checked. if the active flag is set to
 * REPROG_BOOT_ACTIVE the bootloader stores the program code from SRAM
 * into flash (2.) and boots. (the SRAM can be filled with program code over
 * bluetooth, planned system feature).
 * 
 * 1. APP_UART (UISP):
 * first the bootloader sends the answer o.k. char 0x14 and 0x10 to uart1
 * with baud 115200. if the uisp program answers within 50ms 
 * with the 0x42 cmd (device code request) the bootloader will load the program
 * data over uart1 using the uisp protokoll and stores it into atmega128 flash. 
 * 
 * 
 * 2. SRAM:
 * program reads intel hex data from sram (xbanks) and stores it into atmega128
 * flash. HEX data in ram is of the format:
 *
 * ------------------------------------------------------------------------------
 * | prog_type | prog_ver | active_flag | prog_len | CRC |   ...data...    | CRC |
 * ------------------------------------------------------------------------------
 *       1          4            1           4        2    ..[prog_len]..     2
 *
 * program data records are of the format LLLAAADDDDDDD....
 *
 * where LLL  is the record lenght in bytes
 *       AAA  the starting address
 *       D    program data (L times)
 *
 *
 * program data is expected to start at address XRAM_PRSTART+MEM_LEN_HEADER+MEM_CRC
 * see boot_defs.h for defines!
 *
 */

// -------------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------------

#include <stdlib.h>
#include <limits.h>

// avr specific
#include <avr/io.h>
#include <avr/boot.h>

#if __AVR_LIBC_VERSION__ >= 10400UL
#include <avr/interrupt.h>
#else
#include <avr/signal.h>
#endif

// btnut
#include <hardware/btn-hardware.h>
#include <hardware/btn-ledhw.h>
#include <hardware/ram_banks.h>
#include <led/btn-led.h>

// bootloader support
#include <support/bootloader.h>
#include "stk500_private.h"

// our uart
#include "small_uart.h"

#include "program_version.h"

// -------------------------------------------------------------------------
// Prototypes
// -------------------------------------------------------------------------

void uart_program_ans(u_char * data, u_short count);

// -------------------------------------------------------------------------
// Globals
// -------------------------------------------------------------------------

const char bootloader_version[16] __attribute__ ((section (".bootloader-version"))) = PROGRAM_VERSION;

u_char RamImage[PAGE_SIZE];
u_long prog_len;
u_char prog_source;

u_char use_config_latch = 0;
u_char external_memory_available = 0;

// -------------------------------------------------------------------------
// enable bank switched external memory explicitly
// @TODO: this code shoud be somewhere in the btnut libs
// -------------------------------------------------------------------------
void my_init(void) __attribute__ ((naked))
    __attribute__ ((section(".init0")));

void my_init(void)
{
    // enable xsram at the very beginning to be able to place .bss and
    // .data there
    sbi(MCUCR, SRE);
    // bus-keeper
    sbi(XMCRB, XMBK);

    // set address lines for external memory (if they are defined)
#if defined(RAM_CTR_A_DDR) && defined(RAM_CTR_B_DDR)
    // => address lines are output, select bank 0
    sbi(RAM_CTR_B_DDR, RAM_CTR_B_PIN);
    sbi(RAM_CTR_A_DDR, RAM_CTR_A_PIN);
    cbi(RAM_CTR_B_PORT, RAM_CTR_B_PIN);
    cbi(RAM_CTR_A_PORT, RAM_CTR_A_PIN);
#endif
}


//wait in ms (more or less)
void wait(u_short ms)
{
    u_short i, j;
    for (i = 0; i < ms; i++) {
        for (j = 0; j < 919; j++) {
            asm volatile ("nop");
        }
    }
}


//get page from flash into ram buffer
void read_page(u_long page)
{
    u_short i;
    for (i = 0; i < PAGE_SIZE; i++)
        RamImage[i] = pgm_read_byte_far(page + i);  //read flash data into ram image storage
}

//write buffer into flash
void write_page(u_long page)
{
    u_short i;

    // Erase page.
    boot_page_erase(page);
    while (boot_rww_busy())
        boot_rww_enable();

    // Write data to buffer a word at a time. Note incrementing address by 2.
    for (i = 0; i < PAGE_SIZE; i += 2)
        boot_page_fill(page + i, RamImage[i] + (RamImage[i + 1] << 8));

    // Write page.
    boot_page_write(page);
    while (boot_rww_busy())
        boot_rww_enable();
}


void init_leds(u_char a){
    if (use_config_latch){
        _btn_led_init();
    }
    else {
        // set ddr to output
        sbi(LED_PORT_DDR, LED0);
        sbi(LED_PORT_DDR, LED1);
        sbi(LED_PORT_DDR, LED2);
        sbi(LED_PORT_DDR, LED3);
    }        
}
    
void set_leds(u_short code)
{
    if (use_config_latch){
        if (code & 1)
            _btn_led_set(LED0);
        else
            _btn_led_clear(LED0);
        if (code & 2)
            _btn_led_set(LED1);
        else
            _btn_led_clear(LED1);
        if (code & 4)
            _btn_led_set(LED2);
        else
            _btn_led_clear(LED2);
        if (code & 8)
            _btn_led_set(LED3);
        else
            _btn_led_clear(LED3);
    }
    else{
        if (code & 1)
            sbi(LED_PORT, LED0);
        else
            cbi(LED_PORT, LED0);
        if (code & 2)
            sbi(LED_PORT, LED1);
        else
            cbi(LED_PORT, LED1);
        if (code & 4)
            sbi(LED_PORT, LED2);
        else
            cbi(LED_PORT, LED2);
        if (code & 8)
            sbi(LED_PORT, LED3);
        else
            cbi(LED_PORT, LED3);
    }
}

void start_main_program(void)
{
    asm("jmp 0x0000"::);        //jump to application
}

void ind_error(u_short err)
{
    set_leds(err);
    wait(5000);  // wait for user to see/read error nr
    start_main_program();
}

/*
 * set active flag to normal program code active
 */
void sram_set_to_normal_active(void)
{
    u_char buffer[1];
    buffer[0] = REPROG_DATA_ACTIVE;
    cpy_to_xbank(buffer, XBANK_PRSTART + MEM_OFFSET_AKTIV_FLAG, MEM_LEN_AKTIV_FLAG);
    //update crc
    update_xbank_crc(XBANK_PRSTART, XBANK_PRSTART + MEM_LEN_HEADER);
}

/*
 * check if active flag is set to boot active and return 1
 */
u_char sram_contains_boot_code(void)
{
    u_char buffer[1];
    if (check_xbank_crc(XBANK_PRSTART, XBANK_PRSTART + MEM_LEN_HEADER))
        return 0;
    cpy_from_xbank(buffer, XBANK_PRSTART + MEM_OFFSET_AKTIV_FLAG, MEM_LEN_AKTIV_FLAG);
    if (buffer[0] == REPROG_BOOT_ACTIVE)
        return 1;
    else
        return 0;
}

/*
 * check all crc in sram and set prog_len
 */
u_char check_sram(void)
{
    u_char buffer[MEM_LEN_HEADER];

    cpy_from_xbank(buffer, XBANK_PRSTART, MEM_LEN_HEADER);

    //check if code is btnode program code!
    if (buffer[MEM_OFFSET_PROG_TYPE] != REPROG_BTNODE_PROGRAM_DATA)
        return ERR_DATA;

    //check if code is active
    if (buffer[MEM_OFFSET_AKTIV_FLAG] != REPROG_DATA_ACTIVE)
        return ERR_INACTIVE;

    //get program length
    prog_len = FROM_ARRAY32(buffer, MEM_OFFSET_PROG_LEN);

    //important, next step hangs if length==0  
    if (prog_len == 0)
        return ERR_PROG_LEN;    //prog_len is zero
    
    //check program code for crc
    if (check_xbank_crc(XBANK_PRSTART + MEM_LEN_HEADER + MEM_CRC, XBANK_PRSTART + MEM_LEN_HEADER + MEM_CRC + prog_len))
        return ERR_CRC_DATA;    //data crc wrong
        
    //check memory bounds
    u_long flash_addr = 0;
    u_long flash_addr_old = 0;
    u_long rec_len = 0;
    u_long ram_addr = XBANK_PRSTART + MEM_LEN_HEADER + MEM_CRC;
    while (ram_addr < XBANK_PRSTART + MEM_LEN_HEADER + MEM_CRC + prog_len) {
        cpy_from_xbank(buffer, ram_addr, 6);    //read record header
        
        flash_addr_old = flash_addr + rec_len;
        rec_len = (((u_long) buffer[0] << 16) | ((u_long) buffer[1] << 8) | ((u_long) buffer[2]));
        flash_addr = ((u_long) buffer[3] << 16) | ((u_long) buffer[4] << 8) | ((u_long) buffer[5]);
        ram_addr += 6 + rec_len;
        
        if ((flash_addr_old > flash_addr) || (flash_addr+rec_len > FLASH_PREND))
            return ERR_MEMADDR;
    }

    return 0;
}

/*
 * program flash using sram data
 */
void sram_programming(void)
{
    u_long ram_addr = 0;        //address in ram (bytes)
    u_long flash_addr = 0;      //address in flash (bytes)
    u_long current_page;        //current page that gets filled
    u_long rec_end;             //end position of current record in ram
    u_short cpy_len;
    u_char buffer[6];
    
    //start flashing
    ram_addr = XBANK_PRSTART + MEM_LEN_HEADER + MEM_CRC;        //start of first record
    while (ram_addr < XBANK_PRSTART + MEM_LEN_HEADER + MEM_CRC + prog_len) {

        //here read first few lines!!
        cpy_from_xbank(buffer, ram_addr, 6);    //read record header

        ram_addr += 6;          //first data byte position
        rec_end = ram_addr + (((u_long) buffer[0] << 16) | ((u_long) buffer[1] << 8) | ((u_long) buffer[2]));       //record en position
        flash_addr = ((u_long) buffer[3] << 16) | ((u_long) buffer[4] << 8) | ((u_long) buffer[5]);     //address
        current_page = NOPAGE;  //on every new record read current page in memory
        while (ram_addr < rec_end) {
            if ((flash_addr & 0xFFFF00) != current_page) {
                if (current_page != NOPAGE) {   //new page
                    write_page(current_page);   //write last page
                }
                current_page = flash_addr & 0xFFFF00;
                //only read page if not whole page will be filled, rec_end - ram_add < PAGE_SIZE
                if (rec_end - ram_addr < PAGE_SIZE) {
                    read_page(current_page);   //read new page
                }
            }
            cpy_len = MIN(PAGE_SIZE - (flash_addr % PAGE_SIZE), rec_end - ram_addr);
            cpy_from_xbank(RamImage + (flash_addr % PAGE_SIZE), ram_addr, cpy_len);
            ram_addr += cpy_len;
            flash_addr += cpy_len;
        }
        write_page(current_page);
    }
}

/* 
 * uisp has to be started first. it sends 0x30 and 0x20 to uart and waits
 * for an answer. this uisp init cmd cannot be read, for that reason this
 * function sends out answer 0x14 0x10 and listen if uisp replies
 * returns the expected reply cmd or 0 if no reply
 * 
 * 2nd possibility: wait 1/2 sec an listen if 0x30, 0x20 arrives (not implemented)
 */
u_char uart_start_sequence(void)
{
    u_char buf[1];
    u_char count;
    //write o.k. ans
    uart_program_ans(buf, 0);
    //read next byte but don't wait more than 300ms
    count = small_uart_read_t(buf, 1, 300);
    if (count == 1) {
        return buf[0];          //cmd needed in next function
    }
    return 0;
}

/*
 * send back uisp error code
 */
void uart_programming_error(u_char value)
{
    u_char buf[2];
    buf[0] = Resp_STK_INSYNC;             //ans
    buf[1] = value; // 0x11;              //error
    small_uart_write(buf, 2);
    ind_error(ERR_UART);
}

// -------------------------------------------------------------------------
// 
// -------------------------------------------------------------------------
// special write that is blocking and will add Resp_STK_INSYNC at the front of the
// buffer and Resp_STK_OK at the end (uisp protocol!)

void uart_program_ans(u_char * data, u_short count)
{
    u_char buf[1];
    buf[0] = Resp_STK_INSYNC;          // stk500 char for ans
    small_uart_write(buf, 1);
    small_uart_write(data, count);
    buf[0] = Resp_STK_OK;              // stk500 char for o.k.
    small_uart_write(buf, 1);
}


/*
 * uisp protocol with first cmd as argument
 */
void uart_programming(u_char cmd)
{
    u_char buf[24];
    u_char programming = 0;     //will be set if programming started (code arrives)
    u_char leave_loop = 0;      //if set the programming will be done
    u_long flash_addr = 0;      //address in flash (bytes)
    u_char cont_flag;           // used to see, if after leaving programming mode more commands arrive 
    buf[0] = cmd;               // store first command received earlier
    u_short page_size;
    
    //loop until leave prog mode after datas arrived (leave_loop will be set to 1)
    do {
        switch (buf[0]) {
            case Cmnd_STK_GET_SYNC:           // STK500 Presence Check
                small_uart_read(buf, 1);
                uart_program_ans(buf, 0);       //write back o.k.
                break;
            case Cmnd_STK_GET_PARAMETER:
                small_uart_read(buf, 2);
                switch (buf[0]) {
                    case Parm_STK_SW_MINOR:
                        buf[0] = 0x0f;  //15
                        uart_program_ans(buf, 1);      
                        break;
                    case Parm_STK_SW_MAJOR:
                        buf[0] = 0x01;  //1
                        uart_program_ans(buf, 1);      
                        break;
                    case Parm_STK_HW_VER:
                        buf[0] = 0x01;		// 1
                        uart_program_ans(buf, 1);      
                        break;
                    case Param_STK500_TOPCARD_DETECT:
                        buf[0] = 0x02;		// STK501
                        uart_program_ans(buf, 1);      
                        break;
                    case Parm_STK_VTARGET:
                        buf[0] = 0x01;		// 0x32 = 5.0 V
                        uart_program_ans(buf, 1);      
                        break;
                    case Parm_STK_VADJUST:
                        buf[0] = 0x01;		// 0x32 = 5.0 V
                        uart_program_ans(buf, 1);      
                        break;
                    case Parm_STK_OSC_PSCALE:
                        buf[0] = 0x01;		// 
                        uart_program_ans(buf, 1);      
                        break;
                    case Parm_STK_OSC_CMATCH:
                        buf[0] = 0x00;		// 
                        uart_program_ans(buf, 1);      
                        break;
                    case Parm_STK_SCK_DURATION:
                        buf[0] = 0x01;		// 1.1 us
                        uart_program_ans(buf, 1);      
                        break;
                    default:
                        //not implemented: send error
                        buf[0] = 0x14;
                        buf[1] = 0x11;
                        small_uart_write(buf, 2);
                        break;
                }
                break;
            case Cmnd_STK_SET_DEVICE:             //device code
                small_uart_read(buf, 21);
                uart_program_ans(buf, 0);       //write back o.k.
                break;
            case Cmnd_STK_SET_DEVICE_EXT:             //set extended device
                small_uart_read(buf, 6);
                uart_program_ans(buf, 0);       //write back o.k.
                break;
            case Cmnd_STK_ENTER_PROGMODE:             //enter prog code
                small_uart_read(buf, 1);
                uart_program_ans(buf, 0);       //write back o.k.
                break;
            case Cmnd_STK_LEAVE_PROGMODE:             //leaf prog mode
                small_uart_read(buf, 1);
                uart_program_ans(buf, 0);       //write back o.k.
                                                    //now second time or after data arrived, leave loop!!!
                if (programming)
                    leave_loop = 1;
                break;
            case Cmnd_STK_CHIP_ERASE:             //chip erase
                small_uart_read(buf, 1);
                uart_program_ans(buf, 0);       //write back o.k.
                break;
            case Cmnd_STK_LOAD_ADDRESS:             //address arriving
                small_uart_read(buf, 3);
                flash_addr = (((u_long) buf[0]) | ((u_short) buf[1] << 8)) << 1;
                // check memory bounds
                if (flash_addr > FLASH_PREND) {
                    uart_programming_error(0x14); // error nr 3
                } else {
                    if ( (buf[1] & 8) == 0) {
                       set_leds( buf[1]>>4 ); // show high address (for half the time)
                    } else {
                        set_leds( 0 );        // blank
                    }
                    uart_program_ans(buf, 0);       //write back o.k.
                    //as soon address arrives set programming started
                    programming = 1;
                }
                break;
            case Cmnd_STK_UNIVERSAL:             // write fuses // read device code
                small_uart_read(buf, 5);
                switch (buf[0]){
                    case 0x30:  // get device signature: 0x1e9720
                        switch (buf[2]) {
                            case 0:
                                buf[0] = 0x1e;
                                break;
                            case 1:
                                buf[0] = 0x97;
                                break;
                            case 2:
                                buf[0] = 0x02;
                                break;
                            default:
                                break;
                        }
                        break;
                    case 0x50:  // get fuses
                        switch (buf[1]){
                            case 0x00:
                                buf[0] = 0xBF; // lfuse = 0xBF
                                break;
                            case 0x08:
                                buf[0] = 0xff; // efuse = 0xff
                                break;
                            default:
                                break;
                        }
                        break;
                    case 0x58:  // get hfuses
                        buf[0] = 0x00; // 0x00
                        break;
                    case 0xa0:  // get something else
                        buf[0] = 0xff; // 0xff
                        break;
                    default:
                        break;
                }
                uart_program_ans(buf, 1);       //write back o.k.
                break;
            case Cmnd_STK_PROG_PAGE:             //write data
                small_uart_read(buf, 3);
                //reading length and memtype
                if (buf[2] != 0x46) { //flash type
                    uart_programming_error(0x12); // error nr 1
                    break;
                }
                page_size = ((u_short) buf[0]) << 8 | buf[1];
                small_uart_read( RamImage, page_size);
                small_uart_read(buf, 1);
                //check if last byte is end char
                if (buf[0] != 0x20) {
                    uart_programming_error(0x13); // error nr 2
                    break;
                }                                 
                write_page(flash_addr);         //write page
                uart_program_ans(buf, 0);       //write back o.k.
                break;
            case Cmnd_STK_READ_PAGE:             //read data
                small_uart_read(buf, 4);
                page_size = ((u_short) buf[0]) << 8 | buf[1];
                read_page(flash_addr);
                uart_program_ans(RamImage, page_size);
                break;
            case Cmnd_STK_READ_SIGN:             //read sig byte
                small_uart_read(buf, 1);
                buf[0] = 0x1e;
                buf[1] = 0x97;
                buf[2] = 0x02;
                uart_program_ans(buf, 3);
                break;
            default:
                uart_programming_error( buf[0]);
                break;
        }
        //read next cmd
        if (!leave_loop) {
            small_uart_read(buf, 1);
        } else {
            // last chance for uisp to continue
            cont_flag = small_uart_read_t(buf, 1, 500);
            if (cont_flag) {
                leave_loop = 0;
            }
        }
    } while (!leave_loop);
    
    wait( 10 ); // Wait for last byte to be transmitted
    
}

// -------------------------------------------------------------------------
// -- TEST, IF SRAM IS AVAILABLE => CONFIG_LATCH HAS TO BE USED           --
// -------------------------------------------------------------------------
u_char sram_available(void){

    u_char mem_avail = 0;
    
    volatile u_char *xbuffer1 = (u_char*) 0x1111;
    volatile u_char *xbuffer2 = (u_char*) 0x1234;
    volatile u_char *xbuffer3 = (u_char*) 0x4321;
    volatile u_char *xbuffer4 = (u_char*) 0x4444;
    u_char buffer1, buffer2, buffer3, buffer4;
    
    // store old values
    buffer1 = *xbuffer1;
    buffer2 = *xbuffer2;
    buffer3 = *xbuffer3;
    buffer4 = *xbuffer4;
    
    // test values
    *xbuffer1 = 0x11;
    *xbuffer2 = 0x22;
    *xbuffer3 = 0x33;
    *xbuffer4 = 0x44;
    
    if (*xbuffer1 == 0x11)
        if (*xbuffer2 == 0x22)
            if (*xbuffer3 == 0x33)
                if (*xbuffer4 == 0x44)
                    mem_avail = 1;
    
    if (mem_avail) {
        // restore test bytes
        *xbuffer1 = buffer1;
        *xbuffer2 = buffer2;
        *xbuffer3 = buffer3;
        *xbuffer4 = buffer4;
    }
    return mem_avail;
}

// -------------------------------------------------------------------------
// -- MAIN                                                                --
// -------------------------------------------------------------------------
// avoid nut/os substitution of main into NutAppMain
#undef main
int main(void)
{
    u_char error;
    u_char cmd = 0;
    u_char mem_avail;

    //disable interrupts
    cli();

    // enable write-protection of bootloader section (for SPM instructions only)
    // note: this protection will be always cleared after a chip erase
    boot_lock_bits_set(_BV(BLB11));
    
    // @TODO: here, function from btnut lib has to be called to link with .init0
    // see comments for my_init
    // btn_hardware_init();
    
    // figure out, if external mem is available
    mem_avail = sram_available();
    if (mem_avail == 0){
        // extra mem missing => disable SRAM
        cbi(MCUCR, SRE);
        cbi(XMCRB, XMBK);
    }
    external_memory_available = mem_avail;

#ifdef HAVE_CONFIG_LATCH
    // on btnode3, the config latch has to be used, if ram is available
    use_config_latch = mem_avail;
    btn_hardware_config_latch_init();    
#else
    use_config_latch = 0;
#endif
    
    // ok, let's go
    small_uart_init();

    // LEDs on
    init_leds(0);
    set_leds(15);

    //read cmd on uart
    cmd = uart_start_sequence();
  
    //if expected cmd arrived, start uart programming
    if (cmd) {

        uart_programming(cmd);

        set_leds( 0 );
        wait( 350 );
        set_leds( 1 );
        wait( 250 );
        set_leds( 2 );
        wait( 250 );
        set_leds( 4 );
        wait( 250 );
        set_leds( 8 );
        wait( 250 );
    }
    else
    {
        if (sram_contains_boot_code()) {
            
            sram_set_to_normal_active();
            error = check_sram();
            if (error) {
                ind_error(error);
            } else {
                sram_programming();
            }
        }
    }
    
    set_leds(0);
    
    start_main_program();
    
    return 0;
}
