/*
 * Copyright (C) 2005 Mario Strasser <mast@gmx.net>,
 *                    Swiss Federal Institute of Technology (ETH) Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Id: ccc-cmd.c,v 1.5 2006/03/29 01:15:01 olereinhardt Exp $
 * 
 */

/*!
 * $Log: ccc-cmd.c,v $
 * Revision 1.5  2006/03/29 01:15:01  olereinhardt
 *
 * Changed signedness of strings in order to compile with avr-gcc 4.0.2
 *
 * Revision 1.4  2006/03/23 07:22:23  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.2.2.1  2006/02/02 08:09:37  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.3  2005/12/06 18:53:28  beutel
 * fixed links on api doc's for new webpage, cleaned examples docu
 *
 * Revision 1.2  2005/10/05 14:42:20  beutel
 * added sesnor-app to demo apps, added all demo apps to default makefile, changed default baud rate to 57600 baud on all apps.
 *
 */ 

/**
 * \example ccc-cmd/ccc-cmd.c
 * 
 *
 * \date 2005/08/15 
 *
 * \author Mario Strasser <mast@gmx.net>
 *
 * Example application to show the use of the chipcon radio on the 
 * BTnode rev3.
 */

#include <stdio.h>
#include <string.h>
#include <io.h>
#include <stdlib.h>
#include <dev/usart.h>
#include <dev/usartavr.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/heap.h>
#include <sys/tracer.h>
#include <led/btn-led.h>
#include <hardware/btn-hardware.h>
#include <terminal/btn-terminal.h>
#include <terminal/btn-cmds.h>
#include <terminal/nut-cmds.h>
#include <cc/bmac.h>
#include <cc/ccc.h>

/**
 * Initialises the first UART and the terminal.
 */
static void term_init(void) 
{
    FILE *uart_terminal;
    u_long baud = 57600;
            
    /* initialize UART 1 */
    NutRegisterDevice(&APP_UART, 0, 0);
    uart_terminal = fopen(APP_UART.dev_name, "r+");
    _ioctl(_fileno(uart_terminal), UART_SETSPEED, &baud);
    btn_terminal_init(uart_terminal, "[bt-cmd@btnode]$");
    freopen(APP_UART.dev_name, "w", stdout);    
}

/**
 * Initializes the BTnode.
 */
static void btnode_init(void) 
{    
    int res;
    /* initialize the btnode hardware */
    btn_hardware_init();
    btn_led_init(0);
    term_init(); 
    res = bmac_init(0);
    if (res != 0) DEBUGT("bmac_init() failed\n");
    bmac_enable_led(1);
    res = ccc_init(&bmac_interface);
    if (res != 0) DEBUGT("ccc_init() failed\n");        
}

/**
 * Packet handler
 */
void test_pkt_handler(ccc_packet_t *pkt)
{
    DEBUGT("\033[32mPacket of type %d from %04x to %04x"
           "(%d bytes):\033[39m %.80s\n", pkt->type, pkt->src, pkt->dst,
           pkt->length, pkt->data);
}

#define TEST_PACKET_TYPE 0x01
#define TEST_PACKET_SIZE (8*250)

/**
 * CCC send terminal command
 */
void ccc_send_echo(char *arg)
{
    int i, res;
    u_short num, addr = BROADCAST_ADDR;
    ccc_packet_t *pkt = new_ccc_packet(TEST_PACKET_SIZE);
    if (pkt == NULL || sscanf(arg, "%hu", &num) != 1) {
        printf("usage: ccc-echo <#packets>\n");
        return;
    }
    pkt->length = TEST_PACKET_SIZE;
    for (i = 0; i < pkt->length; i += 2) {
        pkt->data[i] = '-';
        pkt->data[i+1] = ':';
    }
    memcpy(pkt->data, "Echo-Packet: 0123456789", 23);
    pkt->data[pkt->length - 1] = 0;
    for (i = 0; i < num; i++) {
        DEBUGT("ccc_send(%04x) = ", addr);
        res = ccc_send(addr, TEST_PACKET_TYPE, pkt);
        DEBUGT("%d\n", res);
        NutSleep(2000);
    }
    free(pkt);
}

/**
 * Registers all supported commands.
 */
static void register_cmds(void)
{
    btn_cmds_register_cmds();
    nut_cmds_register_cmds();
    btn_terminal_register_cmd("ccc-echo", ccc_send_echo);
}

/**
 * Main function that initializes the hardware, led, terminal, and 
 * the CC1000 low-power radio and registers some predefined commands.
 * Use tab-tab to see the registered commands once the program is running.
 */
int main(void) 
{
    /* initialize the BTnode hardware and the CC1000 radio */    
    btnode_init();    
    DEBUGT("btnode initialized.\n");    
    /* regiser all commands */
    register_cmds();
    DEBUGT("commands registered.\n");
    /* register packet handler */
    ccc_register_packet_handler(TEST_PACKET_TYPE, test_pkt_handler);
    /* start terminal */ 
    DEBUGT("starting terminal...\n\n");      
    btn_terminal_run(BTN_TERMINAL_NOFORK, 256);
    DEBUGT("exit\n");
    return 0;
}

