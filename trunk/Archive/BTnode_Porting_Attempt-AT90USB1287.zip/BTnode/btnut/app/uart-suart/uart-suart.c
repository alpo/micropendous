/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 * $Id: uart-suart.c,v 1.11 2006/03/23 07:22:25 dyerm Exp $
 * 
 */

/*!
 * $Log: uart-suart.c,v $
 * Revision 1.11  2006/03/23 07:22:25  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.8.2.1  2006/02/02 08:10:26  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.10  2005/12/07 15:46:44  beutel
 * fixed up some minor cosmetics and indexer problems
 *
 * Revision 1.9  2005/12/06 18:53:28  beutel
 * fixed links on api doc's for new webpage, cleaned examples docu
 *
 * Revision 1.8  2005/10/05 14:42:20  beutel
 * added sesnor-app to demo apps, added all demo apps to default makefile, changed default baud rate to 57600 baud on all apps.
 *
 */ 

/**
 * \example uart-suart/uart-suart.c
 *
 * \date 18.06.2004 
 * 
 * \author Martin Hinz <btnode@hinz.ch>
 * 
 * This application connects the software uart with the hardware uart
 * to chat between both uarts! :)
 */
 
#include <stdio.h>
#include <io.h>

#include <suart/btn-suart.h>
#include <dev/usartavr.h>
#include <led/btn-led.h>
#include <sys/thread.h>
#include <hardware/btn-hardware.h>
FILE *uarts, *uart;


/*
 * thread to listen on application uart and write on software uart
 */
THREAD(ListenUart, arg)
{
    int got;
    char inbuf[20]; 
    for(;;){
        got = _read(_fileno(uart), inbuf, 20);
        btn_led_clear_pattern_queue();
        btn_led_add_pattern(BTN_LED_PATTERN_UP, 0,1, 1);
        btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 4, BTN_LED_INFINITE);
        _write(_fileno(uarts), inbuf, got);        
    }
} 

/*
 * function to listen on software uart and write to application uart
 */
void listen_to_suart(void)
{
    int got;
    char inbuf[20]; 
    for(;;){
        got = _read(_fileno(uarts), inbuf, 20);
        btn_led_clear_pattern_queue();
        btn_led_add_pattern(BTN_LED_PATTERN_DOWN, 0,1, 1);
        btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 4, BTN_LED_INFINITE);
        _write(_fileno(uart), inbuf, got);        
    }
} 

int main(void){   
    u_long sbaud = 9600;
    btn_hardware_init();    
    // initialize software UART
    NutRegisterDevice(&S_UART, 0, 0);
    uarts = fopen(S_UART.dev_name, "r+");
    _ioctl(_fileno(uarts), UART_SETSPEED, &sbaud);
    
    u_long baud = 57600;
    // initialize application UART
    //speed of uart set default to 57600
    NutRegisterDevice(&APP_UART, 0, 0);
    uart = fopen(APP_UART.dev_name, "r+");
    _ioctl(_fileno(uart), UART_SETSPEED, &baud);
    
    
    fputs("Software uart. type to chat with hardware uart!\n",uarts); 
    fputs("Hardware uart. type to chat with software uart!\n",uart); 
    btn_led_init(1);
    btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 4, BTN_LED_INFINITE);
    // start thread for Uart to Software-Uart chat
    NutThreadCreate("T_uart", ListenUart, 0, 192);
    
    listen_to_suart();
    return 1;
}
