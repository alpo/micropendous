/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: tracer.c,v 1.3 2006/05/16 18:24:18 beutel Exp $
 *  
 */
 
 /*!
 * $Log: tracer.c,v $
 * Revision 1.3  2006/05/16 18:24:18  beutel
 * dummy checkin for cruisecontrol test
 *
 * Revision 1.2  2006/03/23 07:22:22  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.1.2.2  2006/03/22 14:07:31  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.1  2006/02/21 19:37:05  beutel
 * added senso and tracer example
 *
 */ 

/**
 * \example tracer/tracer.c
 *
 * \date 2006/02/21 
 *
 * \author Jan Beutel <j.beutel@ieee.org>
 *
 * Example application to show the use of the tracer library for tracing all 
 * kinds of os related low-level events. Enable -DNUTTRACER to use this example.
 * 
 */
 
#include <io.h>
#include <stdio.h>
#include <dev/usartavr.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/tracer.h>
#include <hardware/btn-hardware.h>
#include <led/btn-led.h>
#include <terminal/btn-terminal.h>

int init_stdout(void)
{
    u_long baud = 57600;
    sbi( PORTD, 2);
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "r+", stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);
    return 1;
}


THREAD(ledthread, arg)
{
    for (;;) {
        btn_led_clear(LED1);
        btn_led_set(LED0);
    	NutSleep(500);
    	btn_led_clear(LED0);
        btn_led_set(LED1);
        NutSleep(500);
    }
}


int main(void)
{
    // hardware init
    btn_hardware_init();
    btn_led_init(0);
    init_stdout();
    NutThreadCreate("LedThr",ledthread,0,192);
    btn_terminal_init(stdout, "[bt-cmd@btnode]$");
    btn_terminal_register_cmd("trace",NutTraceTerminal);
    btn_terminal_run(BTN_TERMINAL_NOFORK, 0);
   
    return 0;
}

