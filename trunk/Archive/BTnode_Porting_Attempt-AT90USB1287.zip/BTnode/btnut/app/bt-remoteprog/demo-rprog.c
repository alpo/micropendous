/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \example bt-remoteprog/demo-rprog.c
 *
 * \date 28.04.2005
 *
 * \author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 * \author Matthias Ringald <mringwal@inf.ethz.ch>
 *
 * Demo application: BTnode with remote programming capability (over L2CAP)
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/timer.h>

#include <hardware/btn-hardware.h>
#include <led/btn-led.h>
#include <hardware/btn-bat.h>
#include <support/bt_remoteprog.h>

#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>

#include <dev/usartavr.h>

#include "program_version.h"


//#define MAX_MTU BT_L2CAP_MTU_DEFAULT
#define MAX_MTU 1024

#define BAUD 57600

#define THRESHOLD_MV 2000

#define BT_L2CAP_HCI_PACKET_TYPE ( BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DM3 | BT_HCI_PACKET_TYPE_DM5 )

#define BLUE 0
#define RED 1
#define YELLOW 2
#define GREEN 3


// the bluetooth stack (for HCI and L2CAP)
struct btstack* stack;
struct bt_l2cap_stack* l2cap_stack;

char intstr[10];

u_char rp_reset_cb(u_char arg)
{
    return 1;
}

void check_battery(void){

    u_int volt_mV;
    
    // check supply, else dont boot up bluetooth
    if ( !btn_external_power() )
    {
        volt_mV = btn_bat_measure(10);
        printf_P(PSTR("battery: %d.%02d V\n\n"), volt_mV / 1000,
                 (volt_mV % 1000)/10 );
        
        if ( volt_mV < THRESHOLD_MV )
        {
            puts_P(PSTR("ERROR: not enough power...\nHALT.\n"));
            btn_led_set(RED);
            while (1);
        }
    }
}

/*
 * Main
 *
 */
int main(void)
{

    // set bps for serial port (8N1N)
    u_long baud = BAUD;

    long ret;

    btn_hardware_init();

    btn_led_init(1);
    btn_led_set(BLUE);

    // Initialize UART
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "r+",stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);

    puts_P(PSTR("\n"));

    ret = 0;

    check_battery();
    
    puts_P(PSTR("bootup bluetooth..."));

    //_bt_hci_debug_uart = 1;
    btn_hardware_bt_on();

    puts_P(PSTR("done.\n"));

    // TODO Remove Sleep
    // sleep a little to prevent crashes
    NutSleep(70);

    puts_P(PSTR("build up HCI and L2CAP stack."));
    stack = bt_hci_init(&BT_UART);

    //ret = bt_hci_set_baudrate(stack,BT_HCI_B115200);
    //if (ret)
    //        puts_P(PSTR("WARNING: Cannot set baudrate.\n"));

    // TODO Remove Sleep
    // sleep a little to prevent crashes
    NutSleep(70);

    // set fancy bt name
    if (bt_hci_write_local_name(stack,BT_HCI_SYNC,(u_char*) "Remote-Programmable-BTnode"))
        puts_P(PSTR("WARNING: Cannot set local name.\n"));

    // set bt class of device
    if (bt_hci_write_local_cod(stack,BT_HCI_SYNC,100))
        puts_P(PSTR("WARNING: Cannot set local class of device.\n"));

    // init l2cap stack
    l2cap_stack = bt_l2cap_init(stack,8,1,BT_L2CAP_HCI_PACKET_TYPE);
    puts_P(PSTR("done.\n"));

    // enabl remote programming on default PSM (see in support/bt_remoteprog.h>
    bt_remoteprog_init(l2cap_stack, rp_reset_cb);

    // main application, show compile time
    puts_P(PSTR(PROGRAM_VERSION "\n"));

    btn_led_clear(BLUE);

    // something to do -> main cannot finish
    for (;;) {
        NutSleep(-1);
    }
    return 1;

}
