/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 * 
 */

/*!
 * $Log: bt-cmd-over-rfcomm.c,v $
 * Revision 1.10  2006/11/06 11:32:50  yuecelm
 * move my email address to a permanent one
 *
 * Revision 1.9  2006/06/18 19:41:58  yuecelm
 * add extra commands (CPM, low-power, inquiry/page scan)
 *
 * Revision 1.8  2006/04/06 14:55:43  kevmarti
 * - Removed inclusion of obsolete 'terminal/tprintf.h'
 * - Adjusted call to 'log_init'
 * - Adjusted call to 'log_cmds_init()'
 *
 * Revision 1.7  2006/03/23 07:22:25  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.4.2.6  2006/03/22 16:56:42  dyerm
 * fixed acl initialisation
 *
 * Revision 1.4.2.5  2006/03/22 14:07:39  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.4.2.4  2006/03/22 09:26:13  dyerm
 * added acl_init
 *
 * Revision 1.4.2.3  2006/03/20 06:50:57  dyerm
 * removed printf_P
 * added logging commands
 *
 * Revision 1.4.2.2  2006/02/02 08:11:08  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.6  2006/02/20 17:11:33  yuecelm
 * "\n\r" -> "\n", cosmetic changes
 *
 * Revision 1.5  2006/02/14 17:56:00  yuecelm
 * fixed bug (BTnode hangs when reconnect RFCOMM), cosmetic changes
 *
 * Revision 1.4  2006/01/27 15:56:48  yuecelm
 * disable hold mode defaultly
 *
 * Revision 1.3  2006/01/25 00:43:53  yuecelm
 * add bluetooth terminal (bt-cmds)
 *
 * Revision 1.2  2006/01/16 16:33:11  yuecelm
 * merge of branch rfcomm_dev: add example application using rfcomm device driver
 *
 *
 */ 

// Martin Hinz <btnode@hinz.ch> is author of original program (bt-cmd)

/**
 * \example bt-cmd-over-rfcomm/bt-cmd-over-rfcomm.c
 *
 * \date 2006/01/12 
 *
 * \author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 * 
 * Example application to show the use of the bt stack and the simple but 
 * powerful terminal interface over RFCOMM channel 1.
 */

#include <stdio.h>
#include <sys/event.h>
#include <sys/timer.h>

#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>
#include <bt/bt_rfcomm.h>

#include <dev/rfcomm.h>
#include <dev/usartavr.h>

#include <hardware/btn-hardware.h>

#include <terminal/btn-terminal.h>
#include <terminal/btn-cmds.h>
#include <terminal/nut-cmds.h>
#include <terminal/bt-cmds.h>
#include <terminal/log-cmds.h>


#include <led/btn-led.h>
#include <debug/logging.h>

#include "program_version.h"

#define TERM_PREFIX "[bt-cmd@btnode]$ "

#define BT_L2CAP_HCI_PACKET_TYPE (BT_HCI_PACKET_TYPE_DM1 | \
                                  BT_HCI_PACKET_TYPE_DH1 | \
                                  BT_HCI_PACKET_TYPE_DM3 | \
                                  BT_HCI_PACKET_TYPE_DH3)

#define DEFAULT_LINK_POLICY (BT_HCI_LINK_POLICY_ALL_DISABLED | \
                             BT_HCI_LINK_POLICY_ROLE_SWITCH  | \
                             BT_HCI_LINK_POLICY_SNIFF_MODE   | \
                             BT_HCI_LINK_POLICY_PARK_STATE)

struct btstack* stack;
struct bt_l2cap_stack * l2cap_stack;
struct bt_rfcomm_stack * rfcomm_stack;

NUTDEVICE * devRFComm01;
FILE * rfcomm_terminal;

static void con_cb_terminal(u_char channel, u_char connected)
{
    if (connected)
    {
        printf("RFCOMM terminal connected.\n\r");
    	fprintf(rfcomm_terminal, "\nhit tab twice for a list of commands\n" TERM_PREFIX);
    }
    else
    {
        printf("RFCOMM terminal disconnected.\n\r");
    }
}

/**
 * main function that initializes the hardware, led, terminal and registers
 * some predefined commands.
 * Use tab-tab to see the registered commands once the program is running.
 */
int main(void)
{
    // serial baud rate
    u_long baud = 57600;

    // hardware init
    btn_hardware_init();
    btn_led_init(1);
    
    // init app uart
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "r+", stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);
    
    // init event logging
    log_init();
    
    // hello world!
    printf("\n# --------------------------------------------");
    printf("\n# Welcome to BTnut (c) 2005 ETH Zurich\n");
    printf("# bt-cmd-over-rfcomm: %s\n", PROGRAM_VERSION);
    printf("# --------------------------------------------");
    printf("\nbooting bluetooth module... ");

    // bluetooth module on (takes a while)
    btn_hardware_bt_on();
    
    // verbose debug of all hci information
    //_bt_hci_debug_uart = 1;
       
    // Start the stack and let the initialization begin
    stack = bt_hci_init(&BT_UART);

    // disable hold mode (inquiry can cause a hardware error event on Zeevo)
    bt_hci_write_default_link_policy_settings(stack, BT_HCI_SYNC, DEFAULT_LINK_POLICY);
	l2cap_stack = bt_l2cap_init(stack, 8, 8, BT_L2CAP_HCI_PACKET_TYPE);

	rfcomm_stack = bt_rfcomm_init(l2cap_stack, BT_RFCOMM_DEF_MFS, 4, 4);
	printf("ok.\n");

    // create RFCOMM NUTDEVICE (channel 1)
	devRFComm01 = RFCommCreate(rfcomm_stack, 1, con_cb_terminal);
    if (devRFComm01 == NULL)
    {
        printf("ERROR: devRFComm01 is NULL!\n\r");
		NutSleep(5000);
        return -1;
    }
    // register RFCOMM NUTDEVICE
	NutRegisterDevice(devRFComm01, 0, 0);
    // open means here listen at channel 1
    // connection callback con_cb_terminal will be thrown on connect/disconnect
	rfcomm_terminal = fopen(devRFComm01->dev_name, "r+");
    if (rfcomm_terminal == NULL)
    {
        printf("Open rfcomm_terminal failed\n\r");
        NutSleep(5000);
        return -2;
    }

    // terminal init
    btn_terminal_init(rfcomm_terminal, TERM_PREFIX);

	log_cmds_init(rfcomm_terminal);
    btn_cmds_register_cmds();
    nut_cmds_register_cmds();
    bt_cmds_init(stack);
    bt_cmds_register_cmds();
    bt_extra_cmds_register_cmds();
    
    printf("READY!\n");
    
    // terminal mode
    btn_terminal_run(BTN_TERMINAL_NOFORK, 0);

    return 0;
}
