/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 */

/*!
 * $Log: rfcomm-device.c,v $
 * Revision 1.4  2006/11/06 11:32:50  yuecelm
 * move my email address to a permanent one
 *
 * Revision 1.3  2006/03/23 07:22:25  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.2.2.2  2006/02/02 08:11:08  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.2  2006/01/16 16:48:10  yuecelm
 * merge of branch rfcomm_dev: add example application using rfcomm device driver
 *
 *
 */ 
 
/**
 * \example rfcomm-device/rfcomm-device.c
 *
 * \date 2006/01/13 
 *
 * \author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 *
 * Example application to show the use of the RFCOMM device driver.
 * RFCOMM channel 1 print outs messages, channel 2 is running a echo service.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>
#include <dev/usartavr.h>
#include <sys/device.h>
#include <sys/event.h>
#include <sys/file.h>
#include <sys/heap.h>
#include <sys/timer.h>
#include <sys/thread.h>
#include <hardware/btn-hardware.h>
#include <led/btn-led.h>
#include <bt/bt_hci_cmds.h>
#include <bt/bt_l2cap.h>
#include <bt/bt_rfcomm.h>
#include <dev/rfcomm.h>

#define MAX_BUFFER 50

#define BLUE 0
#define RED 1
#define YELLOW 2
#define GREEN 3

#define BT_L2CAP_HCI_PACKET_TYPE         (BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DH1 | \
                                          BT_HCI_PACKET_TYPE_DM3 | BT_HCI_PACKET_TYPE_DH3)

// stack size for threads
#define STACKSIZE 512

#define INFO(text) puts_P(PSTR(text));
#define INFOF(text, ...) printf_P(PSTR(text "\n"),## __VA_ARGS__);
#define WARNING(text) puts_P(PSTR("WARNING: " text));
#define WARNINGF(text, ...) printf_P(PSTR("WARNING: " text "\n"),## __VA_ARGS__);
#define ERROR(text) puts_P(PSTR("ERROR: " text));
#define ERRORF(text, ...) printf_P(PSTR("ERROR: " text "\n"),## __VA_ARGS__);

NUTDEVICE * devRFComm01;
NUTDEVICE * devRFComm02;
FILE * rfcomm_debug;
FILE * rfcomm_terminal_echo;
struct btstack * stack;
struct bt_l2cap_stack * l2cap_stack;
struct bt_rfcomm_stack * rfcomm_stack;

HANDLE conn_event = NULL;

static u_char rfcomm_terminal_connected = 0;
static void con_cb_terminal(u_char channel, u_char connected)
{
    rfcomm_terminal_connected = connected;
    
    if (connected)
    {
        INFO("RFCOMM terminal connected.");
        NutEventPostAsync(&conn_event);
    }
    else
    {
        INFO("RFCOMM terminal disconnected.");        
    }
}

THREAD(debug_prints, arg)
{
    int res;
    
    for (;;)
    {
        res = fprintf(rfcomm_debug, "%lu s\n", NutGetSeconds());
        if (res < 1)
        {
            ERRORF("fprintf returns %d", res);
        }
        res = fprintf_P(rfcomm_debug, PSTR("%lu min\n"), NutGetSeconds()/60);
        if (res < 1)
        {
            ERRORF("fprintf_P returns %d", res);
        }
        NutSleep(5000);
    }
}

THREAD(terminal_echo, arg)
{
    int readed;
    int res;
    u_char * buffer = NutHeapAlloc(MAX_BUFFER);
    int fd_rfcomm = _fileno(rfcomm_terminal_echo);
   
    for (;;)
    {
        if (rfcomm_terminal_connected || 
                NutEventWait(&conn_event, NUT_WAIT_INFINITE))
        {
            readed = _read(fd_rfcomm, buffer, MAX_BUFFER);
            res = _write(fd_rfcomm, buffer, readed);
            if (res < 1)
            {
                ERRORF("_write returns %d", res);
            }
        }
    }
}

int main(void)
{
    int res;

    // serial baud rate
    u_long baud = 57600;

    // hardware init
    btn_hardware_init();
    btn_led_init(1);

    btn_led_set(BLUE);
    
    // init app uart
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "r+", stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);
        
    INFO("Enable bluetooth module...");

    // bluetooth module on (takes a while)
    btn_hardware_bt_on();
    
    // verbose debug of all hci information
    //_bt_hci_debug_uart = 1;
       
    // Start the stack and let the initialization begin
    
    INFO("Initialize HCI stack...");
    stack = bt_hci_init(&BT_UART);

    //bt_hci_write_local_cod(stack, BT_HCI_SYNC, 200);
    
    INFO("Initialize L2CAP stack...");
    l2cap_stack = bt_l2cap_init(stack, 8, 8, BT_L2CAP_HCI_PACKET_TYPE);
    
    INFO("Initialize RFCOMM stack...");
    rfcomm_stack = bt_rfcomm_init(l2cap_stack, BT_RFCOMM_DEF_MFS, 4, 5);

    /**
     * order of use:
     *   create -> register -> open -> (print/get)* -> close -> destroy
     *     (unregister is not available in Nut/OS)
     */

    INFO("Create RFCOMM devices:");
    devRFComm01 = RFCommCreate(rfcomm_stack, 1, NULL);        
    if (devRFComm01 == NULL)
    {
        ERROR("devRFComm01 is NULL!");
        goto loop;
    }
    devRFComm02 = RFCommCreate(rfcomm_stack, 2, con_cb_terminal);
    if (devRFComm02 == NULL)
    {
        ERROR("devRFComm02 is NULL!");
        goto loop;
    }
        
    INFO("Register RFCOMM devices...");
    res = NutRegisterDevice(devRFComm01, 0, 0);
    if (res != 0)
    {
        ERRORF("Registering is failed (%d)", res);
        goto loop;
    }
    res = NutRegisterDevice(devRFComm02, 0, 0);
    if (res != 0)
    {
        ERRORF("Registering is failed (%d)", res);
        goto loop;
    }
        
    INFO("Open RFCOMM devices:");    
    rfcomm_debug = fopen(devRFComm01->dev_name, "w");
    if (rfcomm_debug == NULL)
    {
        ERROR("Open rfcomm_debug failed");
        goto loop;
    }    
    rfcomm_terminal_echo = fopen(devRFComm02->dev_name, "w+");
    if (rfcomm_terminal_echo == NULL)
    {
        ERROR("Open rfcomm_terminal_echo failed");
        goto loop;
    }    

    btn_led_clear(BLUE);

    INFO("Ready!");

    NutSleep(1000);

    INFO("Starting threads...");
    NutThreadCreate("prints", debug_prints, 0, STACKSIZE);
    NutThreadCreate("echo", terminal_echo, 0, STACKSIZE);

loop:

    // something to do -> main cannot finish
    for (;;) {
        NutSleep(10000);
    }

    return 0;
}
