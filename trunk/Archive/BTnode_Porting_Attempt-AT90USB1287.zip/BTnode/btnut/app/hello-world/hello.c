#include <stdio.h>
#include <io.h>

#include <dev/usartavr.h>

#include <hardware/btn-hardware.h>


void init_term(void) {
    FILE *uart_terminal;
    u_long baud = 57600;

    NutRegisterDevice(&APP_UART, 0, 0);
    uart_terminal = fopen(APP_UART.dev_name, "r+");
    _ioctl(_fileno(uart_terminal), UART_SETSPEED, &baud);
    freopen(APP_UART.dev_name, "w", stdout);    
}

int main(void)
{
    init_term();
    printf("Hello World!\n");
    return 0;
}
