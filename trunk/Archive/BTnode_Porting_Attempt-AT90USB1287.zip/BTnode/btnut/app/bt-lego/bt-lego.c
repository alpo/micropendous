/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */
 /**
 * \example bt-lego/bt-lego.c
 *
 * \date 06.12.2004
 * 
 * \author Philipp Blum <blum@tik.ee.ethz.ch>
 * 
 *This application opens a bluetooth point-to-point connection. 
 * Depending on the bluetooth address, the app either
 * - parses input from the sw-uart and forwards lego messages to the other
 *   node or
 * - listens to the bluetooth connection and forwards lego messages to the
 *   sw-uart
 */


/********************************************************/
/* INCLUDES */
/********************************************************/

#include <stdio.h>			 // FILE, fopen(), freopen, stdout, _fileno()
#include <io.h>              // _ioctl()

#include <sys/device.h>      // NutRegisterDevice()
#include <sys/thread.h>
#include <sys/timer.h>
#include <sys/event.h>

#include <hardware/btn-hardware.h> // btn_hardware_bt_on()
#include <bt/bt_hci_defs.h>  // bt_addr_t
#include <bt/bt_hci_api.h>   // bt_hci_init()
#include <bt/bt_hci_cmds.h>  // bt_hci_read_bd_addr()
#include <bt/bt_defs.h>      // struct btstack
#include <bt/bt_psm.h>
#include <bt/l2cap_cl.h>
#include <dev/usartavr.h>    // BT_UART, APP_UART
#include <suart/btn-suart.h> // S_UART
#include <led/btn-led.h>

#include <terminal/btn-terminal.h>
#include <terminal/bt-cmds.h>
#include <terminal/btn-cmds.h>
#include <terminal/nut-cmds.h>



/********************************************************/
/* GLOBAL VARIABLES */
/********************************************************/
#define NPAIRS 3
u_char masters[NPAIRS] = {0x31,0x29,0x6a};
u_char slaves[NPAIRS]  = {0x8a,0x20,0x7e};

bt_addr_t master_addr = {0x00,0x00,0x00,0x3f,0x04,0x00};
bt_addr_t slave_addr  = {0x00,0x00,0x00,0x3f,0x04,0x00};

struct btstack* bt_stack = NULL;
bt_psm_t* psmux = NULL;

FILE *uart, *uarts;

int con_handle = -1;

/********************************************************/
/* INTERNAL FUNCTION DECLARATIONS */
/********************************************************/
void _init_btn(void);
void _init_bt(void);
int  _am_i_master(void);
void _init_suart(void);
void _init_duart(void);
void _run_terminal(void);
int  _open_con_to_slave(void);
int  _parse_lego(u_char *, int);
int _send_to_slave(u_char *, int);
void _test_send(u_char*);



/********************************************************/
/* INTERNAL FUNCTION DEFINITIONS */
/********************************************************/

void _init_btn(void) {
	btn_hardware_init();
	btn_led_init(1);	
}

void _init_bt(void) {
    u_short acl_size;
	btn_hardware_bt_on();
	bt_stack = bt_hci_init(&BT_UART);
	if (bt_stack != NULL){
        acl_size = bt_acl_init(bt_stack, BT_HCI_PACKET_TYPE_DM3);
        psmux = bt_psm_init(bt_stack, 2, 4, acl_size);
        l2cap_cl_init(bt_stack, psmux, bt_hci_register_acl_cb);
    }
}

int _am_i_master(void) {
	int i;
	bt_addr_t my_addr;
	
	if (bt_stack == 0) 
		return 0; // stack not initialized
    bt_hci_get_local_bt_addr(bt_stack, my_addr);
    printf("my addr is %u\n",my_addr[0]);    
	for (i=0;i<NPAIRS;i++) {
		if (my_addr[0] == masters[i]) {
			master_addr[0] = masters[i];
			slave_addr[0]  = slaves[i];
			return 1;
		}
	}
	return 0;
}

void _init_suart(void) {
    u_long sbaud = 2400;
    u_long sparity = 1; // ODD

    NutRegisterDevice(&S_UART, 0, 0);
    uarts = fopen(S_UART.dev_name, "r+");
    _ioctl(_fileno(uarts), UART_SETSPEED, &sbaud);
    _ioctl(_fileno(uarts), UART_SETPARITY, &sparity);
}

void _init_duart(void) {
//    u_long baud = 115200;
    u_long baud = 19200;

    NutRegisterDevice(&APP_UART, 0, 0);
    uart = freopen(APP_UART.dev_name, "r+",stdout);
    _ioctl(_fileno(uart), UART_SETSPEED, &baud);
}


void _run_terminal(void) {

    btn_terminal_init(stdout, "[bt-lego]$");
    btn_cmds_register_cmds();
    nut_cmds_register_cmds();
	if (bt_stack != 0) {
	    bt_cmds_init(bt_stack);
    	bt_cmds_register_cmds();
	}
	btn_terminal_register_cmd("legosend", _test_send);
    btn_terminal_run(BTN_TERMINAL_NOFORK, 0);	
}

int  _open_con_to_slave(void){
	long retval;
	if (psmux != NULL) {
		retval = bt_hci_create_connection(bt_stack, BT_HCI_SYNC, slave_addr, BT_HCI_PACKET_TYPE_DM1 | BT_HCI_PACKET_TYPE_DH1 | BT_HCI_PACKET_TYPE_DM3, 0, 0, BT_HCI_ROLE_SWITCH_CHANGE);
		return (int) retval;
	}
	return -1;
}

int  _parse_lego(u_char * buf, int len){
	static int state = 1;
	static u_char data = 0;
	int i;
//	printf("parsing %d chars\n",len);
	for(i=0;i<len;i++) {
//		printf("parsing %x in state %d\n",buf[i],state);
		switch (state) {
			case 1:
				if (buf[i]==0x55 || buf[i]==0xd5) state = 2;
				else state = 1;
				data = 0;
				break;
			case 2:
				if (buf[i]==0xff) state = 3;
				else 
					if (buf[i]==0x00) state = 4;
					else state = 1;
				break;
			case 3:
				if (buf[i]==0x00) state = 4;
				else state = 1;
				break;
			case 4:
				if (buf[i]==0xf7) state = 5;
				else state = 1;
				break;
			case 5:
				if (buf[i]==0x08) state = 6;
				else state = 1;
				break;
			case 6:
				data = buf[i];
				state = 7;
//				printf("data is %u",data);
//				printf(", ~data is %u",~data);
				break;
			case 7:
//				printf(", inv-data is %u",buf[i]);
//				printf(", ~inv-data is %u",~buf[i]);
				if (data+buf[i] == 255) {
					state = 8;
//					printf("-> match!\n");
				}
				else {
					state = 1;
//					printf("-> miss!\n");
				}
				break;
			case 8:
				state = 9;
				break;
			case 9:
				state = 1;
				return (int)data;
		}
	}
	return -state;
}

void _test_send(u_char* arg) {
	u_char data = 0xdd;
	printf_P(PSTR("test send.."));
	_send_to_slave(&data,1);
	printf_P(PSTR("ok\n"));
}

int _send_to_slave(u_char * outbuf, int len) {
	long retval;
	int i;
    bt_acl_com_pkt_t pkt;
    u_char *data = bt_acl_com_get_data_pointer(&pkt);
    //cast payload to acl_com
//	printf("_send: con_handle=%d\n",con_handle);
	if (con_handle<0) {
		return -1;
	}
    for (i=0;i<len;i++) {
	    data[i] = outbuf[i];
    }
//   	printf_P(PSTR("_send ..."));
    
    retval = bt_acl_com_send_packet(acl_stack, &pkt, (bt_hci_con_handle_t)con_handle, 3, 1);
    if (retval == BT_ERR_NO_CON) {
    	printf_P(PSTR(" BT_ERR_NO_CON\n"));
    	con_handle = -1;
    	return -1;
    }
   if (retval == BT_ERR_BT_MODULE) {
    	printf_P(PSTR(" BT_ERR_BT_MODULE\n"));
    	return -1;
    }
//   	printf_P(PSTR(" ok\n"));
	return 0;
}

int _get_lego_msg(void)
{
    int msg = -1;
    long res;
    u_short len;
    //acl-pkt
    bt_acl_com_pkt_t *p_pkt = 0;
    bt_hci_con_handle_t get_handle;
    u_char *data;
    u_char errors;
    errors = bt_acl_com_get_status(acl_stack);
    if (errors & BT_ERR_INVALID_SERV_NR) {
        DEBUGT("get: error: pkt with invalid service number arrived from module\n");
    } else if (errors & BT_ERR_INVALID_HANDLE) {
        DEBUGT("get: error: pkt with invalid con handle arrived from module\n");
    } else if (errors & BT_ERR_FRAGMENTED_ACL_PKT) {
        DEBUGT("get: error: fragmented acl pkt arrived from module\nplease change pkt type!\n");
    } else if (errors & BT_ERR_BUFFER_OVERFLOW) {
        DEBUGT("get: error: internal acl buffer overflowed\n");
    }
    res = bt_acl_com_get_packet(acl_stack, 3, &p_pkt, &get_handle, &len, 0);
    data = bt_acl_com_get_data_pointer(p_pkt);
//    DEBUGT("pkt arrived from handle %d of len %d. Data:\n", get_handle, len);
//    bt_acl_com_dump_data(data, len);
    msg = (int)data[0];
    bt_acl_com_free_packet(acl_stack, p_pkt);
    return msg;
}

void _send_to_lego(int msg) {
	u_char buffer[]={0x55,0xff,0x00,0xf7,0x08,0x00,0x00,0x00,0x00};
	buffer[5]=(u_char)msg;
	buffer[6]=~buffer[5];
	buffer[7]=(u_char)(0xf7+buffer[5]);
	buffer[8]=~buffer[7];
    _write(_fileno(uarts), buffer, 9);        
}

THREAD(lego_slave, arg)
//void lego_slave(void)
{
	int msg;
	
	for(;;){	
		msg = _get_lego_msg();
		if (msg>=0) {
//			printf("received msg %d, forwarding...",msg);
			btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 1, 1);							
			_send_to_lego(msg);
//			printf_P(PSTR("ok\n"));
		}
			printf("received msg %d\n",msg);
//		NutSleep(1000);
	}
} 

THREAD(lego_master, arg)
//void lego_master(void)
{
	int got, msg;
    u_char inbuf[20];
    u_char c_msg;

	for (;;) {
		printf_P(PSTR("Connection to slave ..."));
		while (con_handle<0){
			con_handle = (int)	_open_con_to_slave();
			if (con_handle<0)
				printf(" err code -%x ",-con_handle);
		}	
		btn_led_set(3);
		printf_P(PSTR("ok\n"));	
		for(;;){
			got = _read(_fileno(uarts), inbuf, 20);
			if (con_handle<0) {
				printf_P(PSTR("Connection dropped\n"));
				btn_led_clear(3);
				break; //get new connection
			}
			msg = _parse_lego(inbuf, got);
			if (msg>=0) {	
//				printf("parsed message %d\n",msg);
				c_msg = (u_char)msg;
				btn_led_add_pattern(BTN_LED_PATTERN_KNIGHT, 0, 1, 1);				
				_send_to_slave(&c_msg,1);
				printf("parsed message %d\n",msg);
			}
		}
	}
} 

 
int main(void){   
	_init_btn();
	_init_duart();
	_init_suart();
	printf_P(PSTR("\n\nHello, this is bt-lego\n"));
	printf_P(PSTR("Initializing BT stacks ..."));
	_init_bt();
	printf_P(PSTR("ok\n"));
	if (_am_i_master()) {
		printf_P(PSTR("I am the master\n"));
	    NutThreadCreate("T_Master", lego_master, 0, 512);    		
	}
	else {
		printf_P(PSTR("I am the slave\n"));
	    NutThreadCreate("T_Slave", lego_slave, 0, 192);    
	}

	_run_terminal();
    return 1;
}
