/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

#ifndef _MONITOR_H_
#define _MONITOR_H_

/**
 * \file monitor.h
 * \brief Monitor functions to retrieve status information of a running program.
 */

#include <bt/bt_defs.h>

/**
 * \brief Registers the 'mon' cmd in btn-terminal.
 * 
 * After this call the following cmds are available:
 *   mon bat
 *   mon cmd <cmd>
 *   mon heap
 *   mon irq [<nr>]
 *   mon net
 *   mon reg <reg/port/mem-addr>
 *   mon timers
 *   mon ver
 */
void mon_register_cmds(void);

/**
 * \brief Initializes monitor functionality.
 * \param bt_stack Pointer to current bt_stack or NULL if no network monitoring necessary.
 * \param progver Pointer to a string that shall be shown as program version.
 */
void mon_init(struct btstack* bt_stack, u_char* progver);

#endif //_MONITOR_H_
