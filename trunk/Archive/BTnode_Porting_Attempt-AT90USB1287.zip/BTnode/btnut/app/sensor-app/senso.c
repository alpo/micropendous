/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 * $Id: senso.c,v 1.6 2006/11/09 14:13:40 yuecelm Exp $
 * 
 */

/*!
 * $Log: senso.c,v $
 * Revision 1.6  2006/11/09 14:13:40  yuecelm
 * changed signedness of strings in order to compile with avr-gcc >=4.0
 *
 * Revision 1.5  2006/03/27 19:22:20  freckle
 * commented jtag disable
 *
 * Revision 1.4  2006/03/23 07:22:24  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.1.2.2  2006/03/22 14:07:33  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.1.2.1  2006/02/02 08:10:26  dyerm
 * meged changes from MAIN branch from [Root_multihop_merge] to [multihop_merged_1] into multihop_merge branch
 *
 * Revision 1.3  2006/02/21 19:37:05  beutel
 * added senso and tracer example
 *
 * Revision 1.2  2005/12/06 18:53:28  beutel
 * fixed links on api doc's for new webpage, cleaned examples docu
 *
 * Revision 1.1  2005/10/05 14:42:20  beutel
 * added sesnor-app to demo apps, added all demo apps to default makefile, changed default baud rate to 57600 baud on all apps.
 *
 */ 

/**
 * \example sensor-app/senso.c
 *
 * \date 2005/10/05 
 *
 * \author Jan Beutel <j.beutel@ieee.org>
 *
 * Example application to show the use of generic sensors. Here we use a 
 * teco particles ssmall sensor attached via an usbprog board.
 *  
 * For the moment, the monitoring function to be used as a deployment-support 
 * network target is removed. To use it include all monitor lines and set the 
 * baud rate to 19200. It requires tp compile nut/OS with -DNUT_PERFMON.
 
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <hardware/btn-hardware.h>
#include <terminal/btn-terminal.h>
#include <terminal/btn-cmds.h>
#include <dev/adc.h>
#include <dev/usartavr.h>
#include <led/btn-led.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <dev/twif.h>
#include "monitor.h"
#include "../../extras/teco_ssmall/micsampler.h"
#include "../../extras/teco_ssmall/tsl2550.h"
#include "program_version.h"

#include <avr/wdt.h>

#define UART_SPEED 19200  //was 19200 for use of monitoring function

extern void _jtag_off(u_char *arg);

void sensorLoop(void)
{
    NutThreadSetPriority(180);
    
    // init twi
    TwInit(20); // set our slave addr = 20
    
    // start light sensor
    if(tsl_init())
        DEBUGT("ERROR: no light sensor found\n");
    
    // start microphone sampling thread
    ADCInit();
    mic_init();
    
    for(;;){
        u_char i, channel0, channel1;

        for(i = 0; i < 10; i++){
            u_short val = mic_read();
            mic_set_leds(val);
            if( val >= 1015 )
				DEBUGT("ALARM: Microphone = %d\n", val);
				
            NutSleep(100);
        }
  
        // NOTE: TLS2550 needs 800ms integration time for both channels
        if(tsl_read(&channel0, &channel1)){
            DEBUGT("ERROR: could not read light sensor\n");
            btn_led_add_pattern(BTN_LED_PATTERN_OFF_ON_OFF,9,1,BTN_LED_INFINITE);
            DEBUGT("ERROR: system error\n");
            DEBUGT("ERROR: standby for reboot\n");
            NutSleep(1015);
            wdt_enable(WDTO_500MS);
        }else{
         	u_short val = tsl_calculate_lux(channel0, channel1);
            if( val >= 220 )
				DEBUGT("ALARM: Illuminance = %d lx\n", val);
        }
    }
}

int main(void)
{
    // hardware init
    btn_hardware_init();
    btn_led_init(1);
    // sensor board power
    btn_hardware_io_power(1);
    // if additional light sensor (connected to PF7) is used jtag hes to be disabled by
    // _jtag_off(NULL);
    
    // init uart and terminal
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "r+", stdout);
    u_long baud = UART_SPEED;
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);
    btn_terminal_init(stdout, "[senso]$");
    
    DEBUGB("\n# ----------------------------------------");
    DEBUGB("\n# Senso: a Sensor-Demo (c) 2005 ETH Zurich\n");
    DEBUGT("# program version: %s\n", PROGRAM_VERSION);
    DEBUGB("# ----------------------------------------\n");
    NutSleep(200);
 
    // register cmds
    btn_cmds_register_cmds();
    mon_init(NULL, (u_char *) PROGRAM_VERSION);
    mon_register_cmds();
    
    // start terminal
    btn_terminal_run(BTN_TERMINAL_FORK, 1024);
    
    // main loop
    sensorLoop();
    
    return 1;
}
