#include <dev/irqreg.h>
#include <dev/irqreg_avr.h>
#include <sys/osdebug.h>
#include <sys/heap.h>
#include <terminal/btn-terminal.h>
#include <hardware/btn-bat.h>
#include <string.h>

#include "monitor.h"

u_char moncmd_start_mark[] = ":MC_START";
u_char moncmd_end_mark[] = ":MC_END";

static IRQ_HANDLER sig_DUMMY;

IRQ_HANDLER* irqs[34] = {   &sig_INTERRUPT0,
                            &sig_INTERRUPT1,
                            &sig_INTERRUPT2,
                            &sig_INTERRUPT3,
                            &sig_INTERRUPT4,
                            &sig_INTERRUPT5,
                            &sig_INTERRUPT6,
                            &sig_INTERRUPT7,
                            &sig_OUTPUT_COMPARE2,
                            &sig_OVERFLOW2,
                            &sig_INPUT_CAPTURE1,
                            &sig_OUTPUT_COMPARE1A,
                            &sig_OUTPUT_COMPARE1B,
                            &sig_OVERFLOW1,
                            &sig_OUTPUT_COMPARE0,
                            &sig_OVERFLOW0,
                            &sig_SPI,
#ifdef USE_USART0
                            &sig_DUMMY,
                            &sig_DUMMY,
                            &sig_DUMMY,
#else
                            &sig_UART0_TRANS,
                            &sig_UART0_DATA,
                            &sig_UART0_RECV,
#endif
                            &sig_ADC,
                            &sig_EEPROM_READY,
                            &sig_COMPARATOR,
                            &sig_OUTPUT_COMPARE1C,
                            &sig_INPUT_CAPTURE3,
                            &sig_OUTPUT_COMPARE3A,
                            &sig_OUTPUT_COMPARE3B,
                            &sig_OUTPUT_COMPARE3C,
                            &sig_OVERFLOW3,
#ifdef USE_USART1
                            &sig_DUMMY,
                            &sig_DUMMY,
                            &sig_DUMMY,
#else
                            &sig_UART1_TRANS,
                            &sig_UART1_DATA,
                            &sig_UART1_RECV,
#endif
                            &sig_2WIRE_SERIAL,
                            &sig_SPM_READY 
};

typedef struct _mon_stack_s {
    struct btstack* bt_stack;
    u_char* progver;
} _mon_stack_t;
static _mon_stack_t _mon_stack;

void _mon_cmds_irq(char * arg)
{
    u_char irq;
    char *argpos;

    irq = (u_char) (strtoul(arg, &argpos, 0) & 0xff);
    btn_terminal_get_writing_lock();
    if (irq != 0 ) { // irq specified
        DEBUGT("irq %u: %lu\n", irq, irqs[irq]->ir_count);
    } else { // else print all irqs
        for(irq = 0; irq < 34; irq++) {
            DEBUGT("irq %u: %lu\n", irq, irqs[irq]->ir_count);
        }
    }
    btn_terminal_free_writing_lock();
}

void _mon_cmds_bat(void)
{
    if( btn_external_power()) {
        DEBUGT("Battery Voltage: external\n");
    } else {
        int voltage = btn_bat_measure(0);
        DEBUGT("Battery Voltage: %d.%d V\n", voltage / 1000, voltage % 1000);
    }
}

void _mon_cmds_print_usage(void)
{
    DEBUGT("mon: usage: mon bat\n");
    DEBUGT("            mon cmd <cmd>\n");
    DEBUGT("            mon heap\n");
    DEBUGT("            mon irq [<nr>]\n");
    DEBUGT("            mon net\n");
    DEBUGT("            mon reg <reg/port/mem-addr>\n");
    DEBUGT("            mon timers\n");
    DEBUGT("            mon ver\n");
}

void _mon_cmds_reg(char * arg)
{
    char *argpos = arg;
    union {
        u_short addr;
        u_char* ptr;
    } reg;
    
    reg.addr = (u_short) strtoul(arg, &argpos, 0);
    
    if(reg.addr != 0){
        DEBUGT("reg addr 0x%02x: 0x%02x\n", reg.addr, *reg.ptr);
    } else {
        _mon_cmds_print_usage();
    }
}

void mon_cmd(char *arg)
{
    // get 
    if (!strncmp(arg, "heap", 4)) {
        // mem stats (heap)
        btn_terminal_get_writing_lock();
        NutDumpHeap(debug_uart);
        btn_terminal_free_writing_lock();
    } else if (!strncmp(arg, "threads", 7)) {
        // thread list
        btn_terminal_get_writing_lock();
        NutDumpThreadList(debug_uart);
        btn_terminal_free_writing_lock();
    } else if (!strncmp(arg, "timers", 6)) {
        // timer list
        btn_terminal_get_writing_lock();
        NutDumpTimerList(debug_uart);
        btn_terminal_free_writing_lock();
    } else if (!strncmp(arg, "bat", 3)) {
        // battery
        _mon_cmds_bat();
    } else if (!strncmp(arg, "irq", 3)) {
        // irq counters
        _mon_cmds_irq(arg+3);
    } else if (!strncmp(arg, "reg", 3)) {
        // control register contents
        _mon_cmds_reg(arg+3);
    } else if (!strncmp(arg, "net", 3)) {
        // pkt stats
        if(_mon_stack.bt_stack != NULL){
        	/*
            struct bt_pkt_stat* pkt_stat = &_mon_stack.bt_stack->acl_pkt_stat;
            DEBUGT("pkts:  rx=%u (%u lost), tx=%u\n", pkt_stat->rx.pkts,
                                                     pkt_stat->rx_lost.pkts,
                                                     pkt_stat->tx.pkts);
            DEBUGT("bytes: rx=%lu (%lu lost), tx=%lu\n", pkt_stat->rx.bytes,
                                                        pkt_stat->rx_lost.bytes,
                                                        pkt_stat->tx.bytes);
            */                               
        }else{
            DEBUGT("ERROR: no bt_stack specified.\n");
        }
    } else if (!strncmp(arg, "cmd ", 4)) {
        // exec cmd
        btn_terminal_get_writing_lock();
        DEBUGT("\n%s\n", moncmd_start_mark);
        btn_terminal_process_cmd(arg+4);
        DEBUGT("\n%s\n", moncmd_end_mark);
        btn_terminal_free_writing_lock();
    } else if (!strncmp(arg, "ver", 3)) {
        DEBUGT(":MV %s\n", _mon_stack.progver);
    } else {
        _mon_cmds_print_usage();
    }
}

void mon_register_cmds(void)
{
    btn_terminal_register_cmd("mon", mon_cmd);     
}

void mon_init(struct btstack* bt_stack, u_char* progver)
{
    _mon_stack.bt_stack = bt_stack;
    _mon_stack.progver = progver;
}

