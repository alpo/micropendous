#include <bt/bt_hci_cmds.h>

extern struct btstack* stack;
