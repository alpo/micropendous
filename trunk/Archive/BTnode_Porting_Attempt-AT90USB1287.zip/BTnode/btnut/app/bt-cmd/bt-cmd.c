/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch/
 *
 * $Id: bt-cmd.c,v 1.48 2006/12/15 12:24:13 yuecelm Exp $
 * 
 */

/*!
 * $Log: bt-cmd.c,v $
 * Revision 1.48  2006/12/15 12:24:13  yuecelm
 * fix accidentally committed enable debug uart
 *
 * Revision 1.47  2006/10/27 14:51:12  yuecelm
 * Changed signedness of strings in order to compile with avr-gcc >4.0
 *
 * Revision 1.46  2006/08/07 11:52:31  yuecelm
 * replace bt_hci_read_bt_addr with bt_hci_get_local_bt_addr
 *
 * Revision 1.45  2006/06/18 19:41:58  yuecelm
 * add extra commands (CPM, low-power, inquiry/page scan)
 *
 * Revision 1.44  2006/04/12 10:41:00  beutel
 * dummy hcange for cruisecontrol test
 *
 * Revision 1.43  2006/04/06 08:52:10  kevmarti
 * removed 'log_cmds_register_cmds()' function (registering is now done in 'log_cmds_init()')
 *
 * Revision 1.42  2006/04/05 12:56:21  kevmarti
 * adjusted call to 'log_init()'
 *
 * Revision 1.41  2006/04/05 12:47:37  kevmarti
 * Added call to log_cmds_init()
 *
 * Revision 1.40  2006/04/05 10:44:22  kevmarti
 * terminal cmds for logging moved from 'debug/logging.c' to 'terminal/log-cmds.c'
 *
 * Revision 1.39  2006/04/05 10:05:48  beutel
 * *** empty log message ***
 *
 * Revision 1.38  2006/04/05 05:29:36  dyerm
 * fixed reading of bt version and features for the fancy header
 *
 * Revision 1.37  2006/03/29 01:15:00  olereinhardt
 *
 * Changed signedness of strings in order to compile with avr-gcc 4.0.2
 *
 * Revision 1.36  2006/03/24 14:44:50  dyerm
 * removed obsolete bt_acl_com
 *
 * Revision 1.35  2006/03/23 17:13:57  beutel
 * added version, features and name to bt-cmd
 *
 * Revision 1.34  2006/03/23 17:12:39  beutel
 * added version, features and name to bt-cmd
 *
 * Revision 1.33  2006/03/23 07:22:24  dyerm
 * Merged changes from multihop_merge branch. See individual changes on 
 * multihop_merge branch. See Changelog for summary of changes.
 * 
 */ 

/*
 * \example bt-cmd/bt-cmd.c
 *
 * \date 2004/06/18 
 *
 * \author Martin Hinz <btnode@hinz.ch>
 * \author Jan Beutel <j.beutel@ieee.org>
 * 
 * Example application to show the use of the bt stack and the simple but 
 * powerful terminal interface.
 */

#include <stdio.h>
#include <dev/usartavr.h>
#include <sys/heap.h>
#include <sys/timer.h>

#include <hardware/btn-hardware.h>

#include <bt/bt_hci_cmds.h>

#include <terminal/btn-terminal.h>
#include <terminal/btn-cmds.h>
#include <terminal/bt-cmds.h>
#include <terminal/nut-cmds.h>
#include <terminal/log-cmds.h>

#include <led/btn-led.h>
#include <debug/logging.h>
#include <debug/toolbox.h>

#include "program_version.h"
#define CVS_VERSION "$Id: bt-cmd.c,v 1.48 2006/12/15 12:24:13 yuecelm Exp $"

struct btstack* stack;
extern u_char _bt_hci_debug_uart;

/**
 * main function that initializes the hardware, led, terminal, bluetooth
 * and acl communication stack and registers some predefined commands.
 * Use tab-tab to see the registered commands once the program is running.
 */
int main(void)
{
    // serial baud rate
    u_long baud = 57600;
    u_long cpu_crystal;
    u_long nut_tick_freq;

    // hardware init
    btn_hardware_init();
    btn_led_init(1);
    
    // init app uart
    NutRegisterDevice(&APP_UART, 0, 0);
    freopen(APP_UART.dev_name, "r+", stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);
    
    // logging
    log_init();
       
    // hello world!
    printf("\n# ------------------------------------------------------");
    printf("\n# Welcome to BTnut (c) 2006 ETH Zurich\n");
    printf("# bt-cmd program version: %s\n", PROGRAM_VERSION);
    printf("# %s\n", CVS_VERSION);
    cpu_crystal = NutGetCpuClock();
    nut_tick_freq = NutGetTickClock();
    printf("# running @ %u.%04u MHz, NutFreq=%ul Hz\n",
           (int) (cpu_crystal / 1000000UL), (int) ((cpu_crystal - (cpu_crystal / 1000000UL) * 1000000UL) / 100),
        (int) nut_tick_freq);
    printf("# -----------------------------------------------------");
    printf("\nbooting Bluetooth module...\n");

    // bluetooth module on (takes a while)
    btn_hardware_bt_on();
    
    // verbose debug of all hci information
    //_bt_hci_debug_uart = 1;
       
    // Start the stack and let the initialization begin
    stack = bt_hci_init(&BT_UART);
    
    bt_hci_write_default_link_policy_settings(stack, BT_HCI_SYNC,
                                              BT_HCI_LINK_POLICY_ROLE_SWITCH | 
                                              BT_HCI_LINK_POLICY_SNIFF_MODE  |
                                              BT_HCI_LINK_POLICY_PARK_STATE);

    bt_addr_t addr;
    struct bt_hci_local_version_result version;
    u_char features[8];
    u_char _bt_cmds_name[30];
    
    bt_hci_get_local_bt_addr(stack, addr);
    printf("Bluetooth MAC address: "ADDR_FMT"\n", ADDR(addr));
    bt_hci_read_local_version_information(stack, BT_HCI_SYNC, &version);
    printf("HCI version: %X %.4X %X %.4X %.4X\n", version.hciversion,
           version.hcirevision, version.lmpversion, version.manufacturername, version.lmpsubversion);
    bt_hci_read_local_supported_features(stack, BT_HCI_SYNC, features);
    printf("LMP features: %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X\n",
           features[0], features[1], features[2], features[3], features[4], features[5], features[6], features[7]);
    bt_hci_read_local_name(stack, BT_HCI_SYNC, _bt_cmds_name, sizeof(_bt_cmds_name));
    printf("Local name: '%s'\n", _bt_cmds_name);
    
    bt_hci_write_local_name(stack, BT_HCI_SYNC, (u_char*) "bt-cmd demo");
            
    // give hint
    printf("hit tab twice for a list of commands\n");
    
    // terminal init
    char prompt[20];
    sprintf(prompt, "[bt-cmd@"SADDR_FMT"]$ ", SADDR(addr));
    btn_terminal_init(stdout, prompt);
    bt_cmds_init(stack);
    bt_cmds_register_cmds();
    bt_extra_cmds_register_cmds();
    btn_cmds_register_cmds();
    nut_cmds_register_cmds();
    log_cmds_init(stdout);

    // terminal mode
    btn_terminal_run(BTN_TERMINAL_NOFORK, 0);

    return 0;
}
