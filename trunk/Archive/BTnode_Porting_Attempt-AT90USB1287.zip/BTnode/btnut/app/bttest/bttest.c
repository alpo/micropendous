/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.ethernut.de/
 *
 * $Id: bttest.c,v 1.20 2006/07/06 08:42:24 dyerm Exp $
 * 
 */

/*!
 * $Log: bttest.c,v $
 * Revision 1.20  2006/07/06 08:42:24  dyerm
 * updated documentation how to compile for internal sram
 *
 * Revision 1.19  2006/03/29 01:15:01  olereinhardt
 *
 * Changed signedness of strings in order to compile with avr-gcc 4.0.2
 *
 * Revision 1.18  2006/03/24 15:04:28  dyerm
 * removed obsolete bt_acl_com
 *
 * Revision 1.17  2006/03/23 07:22:22  dyerm
 * Merged changes from multihop_merge branch. See individual changes on multihop_merge branch. See Changelog for summary of changes.
 *
 * Revision 1.16.2.2  2006/03/22 14:07:29  dyerm
 * merged changes from main branch from [multihop_merged_1] to [multihop_merged_2] into multihop_merge branch
 *
 * Revision 1.16  2006/02/28 18:03:54  dyerm
 * added uC low power mode tests
 *
 * Revision 1.15  2006/02/28 14:29:47  beutel
 * changed led stuff
 *
 * Revision 1.14  2006/02/28 14:25:56  beutel
 * added bttest programm
 *
 *
 */ 

/**
 * \example bttest/bttest.c
 *
 * \date 27.02.2006
 * \author Jan Beutel <j.beutel@ieee.org>
 *
 * Testing application for new BTnode rev3
 * 
 * To use this testing application it is important to lower all buffersizes
 * to a minimum. otherwise the internal 4KB RAM will not be enough.
 * Lower the uart-buffer in NUT-OS (nut/include/dev/usart.h) to:
 * 32 bytes, high-watermark 30 bytes, low-watermark 20 bytes
 * Lower the buffersize in btn-terminal.h file to something like:
 *
 \verbatim
 #define MAX_CMDS 15
 #define READLN_BUF 15
 #define HISTORY_DEPTH 3
 #define LEN_CMD_NAME 10
 #define TERMINAL_THREADBUFFER_SIZE           0
 #define TERMINAL_MAX_LOGGED_THREADS          0
 \endverbatim
 * 
 * further comment out the definition of NUTXMEM_START and NUTXMEM_SIZE in 
 * arch/btnode3/btn-hardware.h
 * 
 * Don't forget to call 'make clean' and 'make install' after changing
 * the h files!
 */

// nut
#include <stdio.h>
#include <io.h>
#include <dev/usartavr.h>
#include <sys/timer.h>
#include <sys/thread.h>
#include <avr/sleep.h>

// btnode hardware
#include <arch/btn-hardware.h>

// btnode lib
#include <bt/bt_hci_cmds.h>
#include <terminal/btn-terminal.h>
//#include <terminal/nut-cmds.h>
#include <hardware/btn-bat.h>

// chipcon test
#define USED_FROM_BTCMD
#include "cc1000-test.c"

//misc
#include "program_version.h"

// prototypes
void _cmd_inq(char* arg);

FILE *uart_terminal;
FILE *bt_uart;
u_char pkt[10];
u_char got;
u_char inbuf[6];

//terminal init-------------------------------------------------
void init_term(void) {
    u_long parameter;

    // initialize UART 1
    NutRegisterDevice(&APP_UART, 0, 0);
    uart_terminal = fopen(APP_UART.dev_name, "r+");
    parameter = 57600;
    _ioctl(_fileno(uart_terminal), UART_SETSPEED, &parameter);
    parameter = 1;
    _ioctl(_fileno(uart_terminal), UART_SETCOOKEDMODE, &parameter);
    btn_terminal_init(uart_terminal, "[bttest@rev3]$");
}

//checking memory--------------------------------------------
#define MAX_NR_ERRORS 5
#define MEM_TEST_BUF_ADDR 0x1100
#define MEM_TEST_BUF_SIZE 0xFFFF - MEM_TEST_BUF_ADDR

void _print_bits(u_char res) {
        u_char i;
        for (i=0;i<8;i++) {
           if (res&(1<<(7-i))) DEBUGT("1");
           else DEBUGT("0");
        }
}

void _print_error(u_short addr, u_char is, u_char exp) {
  DEBUGT("error at 0x%.4x (",addr);
          _print_bits(addr);
          DEBUGT("): is: 0x%.2x (", is);
          _print_bits(is);
          DEBUGT(") exp: 0x%.2x (", exp);
          _print_bits(exp);
          DEBUGT(")\n");
}

void _print_data(u_short addr, u_char value) {
  DEBUGT("writing at 0x%.4x (",addr);
          _print_bits(addr);
          DEBUGT("): 0x%.2x (", value);
          _print_bits(value);
          DEBUGT(")\n");
}

void _cmd_mem_on(char* arg) {
    //set up bank switching
    sbi(RAM_CTR_A_DDR, RAM_CTR_A_PIN);
    sbi(RAM_CTR_B_DDR, RAM_CTR_B_PIN);
    // enable xsram at the very beginning to be able to place .bss and
    // .data there
    sbi(MCUCR, SRE);
    //no buskeeper and no sectoring
    outb (XMCRB, 0x00);
    // bus-keeper
    sbi(XMCRB, XMBK);
    //waitstates for upper and lower sector
    sbi(MCUCR, SRW10); // 1 cycle befor read-write
    cbi(XMCRA, SRW11);
}

void mem_test_selectBank(u_char i) {
    //DEBUGT("bank %d selected\n",i);
    if (i&1) sbi(RAM_CTR_A_PORT, RAM_CTR_A_PIN);
    else cbi(RAM_CTR_A_PORT, RAM_CTR_A_PIN);
    if (i&2) sbi(RAM_CTR_B_PORT, RAM_CTR_B_PIN);
    else cbi(RAM_CTR_B_PORT, RAM_CTR_B_PIN);
}

u_char mem_test_checkMem(void) {
    volatile u_char *xbuffer;
    xbuffer = (u_char *) MEM_TEST_BUF_ADDR;
    u_short i=0; u_char j=0; u_char data;
    u_char errors=0;
    u_char return_val=0;
    data = 0;
    for (i = 0; i < MEM_TEST_BUF_SIZE; i++) {
        xbuffer[i] = data;
        if (xbuffer[i] != data) {
          _print_error(i, xbuffer[i], data);
          return_val = 1;
          if (errors++ > MAX_NR_ERRORS-2) break;
        }
    }
    data = 1;
    for (j=0; j<8; j++) {
      errors = 0;
      for (i = 0; i < MEM_TEST_BUF_SIZE; i++) {
        xbuffer[i] = data;
        if (xbuffer[i] != data) {
           _print_error(i, xbuffer[i], data);
           return_val = 1;
           if (errors++ > MAX_NR_ERRORS-2) break;
        }
      }
      data = data*2;
    }
    return return_val;
}

u_char mem_test_one(void) {
    volatile u_char *xbuffer;
    u_short res;
    xbuffer = (u_char *) MEM_TEST_BUF_ADDR;
    // test one: check every bank alone
    mem_test_selectBank(0);
    res = mem_test_checkMem();
    mem_test_selectBank(1);
    res += mem_test_checkMem();
    mem_test_selectBank(2);
    res += mem_test_checkMem();
    mem_test_selectBank(3);
    res += mem_test_checkMem();
    // ok
    return res;
}

u_char mem_test_two(void) {
    u_short i;
    u_char bank;
    volatile u_char *xbuffer;
    xbuffer = (u_char *) MEM_TEST_BUF_ADDR;
    u_char errors=0;
    u_char return_val=0;
    // test two: a) fill every bank with special nr to see if banks are disjunct
    //DEBUGT("writing data ");
    for (bank=0; bank<4; bank++) {
        mem_test_selectBank(bank);
        for (i = 0; i < MEM_TEST_BUF_SIZE; i++)
            xbuffer[i] = 0xf0+bank;
    }
    //DEBUGT("verifying data\n");
    // test two: b) now check to see, if data is still there and valid 
    for (bank=0; bank<4; bank++) {     
        mem_test_selectBank(bank);
        for (i = 0; i < MEM_TEST_BUF_SIZE; i++)    
            if (xbuffer[i] != 0xf0+bank) {
               _print_error(i, xbuffer[i], 0xf0+bank);
               return_val = 1;
               if (errors++ > MAX_NR_ERRORS-2) break;
            }
    }
    return return_val;
}

u_char mem_test_three_four(u_short count_step) {
    u_short i;
    u_char bank;
    u_char data;
    volatile u_char *xbuffer;
    xbuffer = (u_char *) MEM_TEST_BUF_ADDR;
    u_char errors=0;
    u_char return_val=0;
    //DEBUGT("writing data ");
    for (bank=0; bank<4; bank++) {
        mem_test_selectBank(bank);
        data = bank*5; //start with different data on each bank
        errors = 0;
        for (i = 0; i < MEM_TEST_BUF_SIZE; i+=count_step) {
            xbuffer[i] = data;
            if (xbuffer[i] != data) {
               _print_error(i, xbuffer[i], bank);
               return_val = 1;
               if (errors++ > MAX_NR_ERRORS-2) break;
            }
            data++;
        }
    }
    if (return_val != 0) return 1;
    //DEBUGT("verifying data\n");
    // test two: b) now check to see, if data is still there and valid   
    for (bank=0; bank<4; bank++) {   
        mem_test_selectBank(bank);
        data = bank*5;
        errors = 0;
        for (i = 0; i < MEM_TEST_BUF_SIZE; i+=count_step) {
              if (xbuffer[i] != data) {
                 _print_error(i, xbuffer[i], data);
                 return_val = 1;
                 if (errors++ > MAX_NR_ERRORS-2) break;
              }
              data++;
            
        }
    }
    return return_val;
}

u_char mem_test_five(void) {
    u_short i;
    u_char bank;
    volatile u_char *xbuffer;
    xbuffer = (u_char *) MEM_TEST_BUF_ADDR;
    u_char errors=0;
    u_char return_val=0;
    //DEBUGT("round 1 0x00,0xff,...\n");
    for (bank=0; bank<4; bank++) {
        //DEBUGT("writing data ");
        mem_test_selectBank(bank);
        for (i = 0; i < MEM_TEST_BUF_SIZE; i++)
            xbuffer[i] = i%2 ? 0x00: 0xFF;
        //DEBUGT("verifying data\n");
        for (i = 0; i < MEM_TEST_BUF_SIZE; i++)    
            if (xbuffer[i] != (i%2 ? 0x00: 0xFF)) {
                 _print_error(i, xbuffer[i], i%2 ? 0x00: 0xFF);
                 return_val = 1;
                 if (errors++ > MAX_NR_ERRORS-2) break;
            }
    }
    //DEBUGT("round 2 0xff,0x00,...\n");
    for (bank=0; bank<4; bank++) {
        //DEBUGT("writing data ");
        mem_test_selectBank(bank);
        for (i = 0; i < MEM_TEST_BUF_SIZE; i++)
            xbuffer[i] = i%2 ? 0xFF: 0x00;
        //DEBUGT("verifying data\n");
        for (i = 0; i < MEM_TEST_BUF_SIZE; i++)    
            if (xbuffer[i] != (i%2 ? 0xFF: 0x00)) {
                 _print_error(i, xbuffer[i], i%2 ? 0xFF: 0x00);
                 return_val = 1;
                 if (errors++ > MAX_NR_ERRORS-2) break;
            }
    }
    return return_val;
}

void _cmd_memtest(char* arg) {
    u_char test = arg[0]-'0';
    u_char res=0;
    if (test<7) {
      if (test == 1) {
         DEBUGT("test one (data bus check)\n");
         res = mem_test_one();
      } else if (test == 2) {
         DEBUGT("test two (bank selecting check)\n");
         res = mem_test_two();
      } else if (test == 3) {
         DEBUGT("test three (address bus high-8-bit check)\n");
         res = mem_test_three_four(256);
      } else if (test == 4) {
         DEBUGT("test four (address bus 16-bit check)\n");
         res = mem_test_three_four(1);
      } else if (test == 5) {
         DEBUGT("test five (memory bit-check on high-8-bit addr)\n");
         res = mem_test_five();
      }
      if (res == 0) {
         DEBUGT("test o.k.\n");
      } else {
         DEBUGT("test error\n");
      }
    } else
      DEBUGT("usage:memtest [1|2|3|4|5]\n");
}

void _cmd_mem(char *arg)
{
	u_char res=0;
    DEBUGT("\nMEMORY TESTING\n");
    DEBUGT("test one (data bus check)\n");
    res = mem_test_one();
    DEBUGT("test two (bank selecting check)\n");
    res += mem_test_two();
    DEBUGT("test three (address bus high-8-bit check)\n");
    res += mem_test_three_four(256);
    DEBUGT("test four (address bus 16-bit check)\n");
    res += mem_test_three_four(1);
    DEBUGT("test five (memory bit-check on high-8-bit addr)\n");
    res += mem_test_five();
    if (res == 0) {
         DEBUGT("MEMORY TEST O.K.\n");
      } else {
         DEBUGT("MEMORY TEST ERROR\n");
      }
}

void _cmd_led(char *arg){
		DEBUGT("\nLED TESTING\n");
		DEBUGT("turning ON  -- ");
		btn_hardware_config_latch_set(LED0);
		DEBUGT("LED0 ");
	    NutSleep( 300 );
    	btn_hardware_config_latch_set(LED1);
	    DEBUGT("LED1 ");
    	NutSleep( 300 );
	    btn_hardware_config_latch_set(LED2);
	    DEBUGT("LED2 ");
    	NutSleep( 300 );
	    btn_hardware_config_latch_set(LED3);
	    DEBUGT("LED3\n");
	    NutSleep( 300 );
	    
	    DEBUGT("turning OFF -- ");
	    btn_hardware_config_latch_clear(LED0);
	    DEBUGT("LED0 ");
	    NutSleep( 300 );
    	btn_hardware_config_latch_clear(LED1);
	    DEBUGT("LED1 ");
	    NutSleep( 300 );
    	btn_hardware_config_latch_clear(LED2);
	    DEBUGT("LED2 ");
	    NutSleep( 300 );
    	btn_hardware_config_latch_clear(LED3);
	    DEBUGT("LED3\n");
	    NutSleep( 300 );
}

// jtag enable/disable--------------------------------------------
void jtag_off(char *arg){
	u_char value = MCUCSR | BV(7);	// JTD - JTAG Disable Bit
	// ... the application software must write the desired value 
	// two times within four cycles
	MCUCSR = value;
	MCUCSR = value;
	DEBUGT("JTAG Disabled\n");
}

void jtag_on(char *arg){
	u_char value = MCUCSR & ~BV(7);	// JTD - JTAG Disable Bit
	// ... the application software must write the desired value 
	// two times within four cycles
	MCUCSR = value;
	MCUCSR = value;
	DEBUGT("JTAG Enabled\n");
}

//bluetooth functions--------------------------------------------
void tristate_bt(char *arg){

	DEBUGT("tri-stating Bluetooth lines\n");	
	// disabling TXEN for BT uart nr 1 in UCSR1B
	cbi ( UCSR1B, TXEN);
	// set TX  as input
	cbi ( DDRD, 3);
	cbi ( PORTD, 3);
	// set RX  as input
	cbi ( DDRD, 2);
	cbi ( PORTD, 2);
	// set RTS as input
	cbi ( DDRD, 4);	//
	cbi ( PORTD, 4);
	// set CTS as input
	cbi ( DDRE, 5);	//
	cbi ( PORTE, 5);
	// set AVR_TDO as input
	cbi ( DDRF, 6);
	cbi ( PORTF, 6);
	// set TMS as input
	cbi ( DDRF, 5);
	cbi ( PORTF, 5);
	// set TCK as input
	cbi ( DDRF, 4);
	cbi ( PORTF, 4);
}

void tristate_off_bt(char *arg){

	DEBUGT("activating Bluetooth lines\n");	
     // enabling TXEN for BT uart nr 1 in UCSR1B
    sbi ( UCSR1B, TXEN);
    // set TX  as output
    sbi ( DDRD, 3);
    // set RX  as input. set up pull ups/downs?
    cbi ( DDRD, 2);
    // set RTS as output
    sbi ( DDRD, 4);	//
    // set CTS as input. set up pull ups/downs?
    cbi ( DDRE, 5);	//
}

void init_bt_uart(void){

    u_long parameter;
	    
    // initialize UART BT
    NutRegisterDevice(&BT_UART, 0, 0);
    bt_uart = fopen(BT_UART.dev_name, "r+");
    
    parameter = BT_UART_INITIAL_SPEED;
    _ioctl(_fileno(bt_uart), UART_SETSPEED, &parameter);
    
    	// Set parity for uart.
	parameter = BT_UART_INITIAL_PARITY;
	_ioctl(_fileno(bt_uart), UART_SETPARITY, &parameter);
	// Set # databits for uart.
	parameter = BT_UART_INITIAL_DATABITS;
	_ioctl(_fileno(bt_uart), UART_SETDATABITS, &parameter);
    
	// Set # stopbits for uart.
	parameter = BT_UART_INITIAL_STOPBITS;
	_ioctl(_fileno(bt_uart), UART_SETSTOPBITS, &parameter);
    
	// Set cooked mode to raw for uart.
	parameter = 0;
	_ioctl(_fileno(bt_uart), UART_SETCOOKEDMODE, &parameter);

	// Set handshake-type for uart.
	parameter = BT_UART_INITIAL_FLOWCONTROL;
	_ioctl(_fileno(bt_uart), UART_SETFLOWCONTROL, &parameter);
}

void _cmd_btreboot(char *arg){

	DEBUGT("\nSTANDBY FOR BLUETOOTH REBOOT\n");
	// tri-state AVR lines
	tristate_bt("");
	jtag_off("");

	// VCC OFF and RESET to GND
	btn_hardware_bt_power( 0 );
	DEBUGT("turning power OFF, ");

	btn_hardware_bt_reset( 1 );
	DEBUGT("reset, waiting... "); 
	NutSleep( 3000 );

	btn_hardware_bt_power( 1 );
	DEBUGT("turning power ON\n"); 
	NutSleep ( 1000 );
	btn_hardware_bt_reset( 0 );
	NutSleep ( 1000 );
	
	// have to leave tristate off for programming
	//tristate_off_bt("");
	//jtag_on("");
	//DEBUGT("Done.\n"); 
	}

void get_from_module(char len) {
    got=0;
    while (got<len){
        got += _read(_fileno(bt_uart), inbuf, 1);
		DEBUGT(".") ;
		//DEBUGT("0x%.2x ",inbuf[0]) ;
    }
    //DEBUGT("\n");
}

void get_from_module_addr(void) {
    got=0;
    while (got<6){
        got += _read(_fileno(bt_uart), inbuf+got, 1);
    }
    while (got!=0) {
        got--;
        DEBUGT(":%.2x",inbuf[got]);
    }   
    DEBUGT("\n");
}

void get_from_module_version(void) {
    got=0;
    while (got<8){
        got += _read(_fileno(bt_uart), inbuf+got, 1);
    }
    while (got!=0) {
        got--;
        DEBUGT(":%.2x",inbuf[got]);
    }   
    DEBUGT("\n");
}

void _cmd_btinit(char* arg) {

	DEBUGT("\nBLUETOOTH TEST\n");
	// tri-state AVR lines
	tristate_bt("");
	jtag_off("");

	// VCC OFF and RESET to GND
	btn_hardware_bt_power( 0 );
	DEBUGT("turning power OFF, ");

	btn_hardware_bt_reset( 1 );
	DEBUGT("reset, waiting... "); 
	NutSleep( 3000 );

	btn_hardware_bt_power( 1 );
	DEBUGT("turning power ON, "); 
	NutSleep ( 1000 );
	btn_hardware_bt_reset( 0 );
	NutSleep ( 1000 );
	
	tristate_off_bt("");
	jtag_on("");

	// flush uart input buffer
	_read(_fileno(bt_uart), 0, 0);

    DEBUGT("\nBLUETOOTH INIT\n");

    //reset pkt
    pkt[0] = 0x01;
    pkt[1] = 0x03; //ocf
    pkt[2] = 0x0C; //ogf shifted by 2
    pkt[3] = 0x00; // payload length
    _write(_fileno(bt_uart), pkt, 4);
    get_from_module(11);
    //DEBUGT("-- got 11 --\n");

	// after reset
	//DEBUGT("-- reset packet --\n");

    //set event filter
    pkt[1] = 0x05;
    pkt[3] = 0x01;

    pkt[4] = 0x00;
    _write(_fileno(bt_uart), pkt, 5);
    get_from_module(7);
    //DEBUGT("-- got 7 --\n");

    //conn accept timeout
    pkt[1] = 0x16;
    pkt[3] = 0x02;

    pkt[4] = 0x40;
    pkt[5] = 0x1F;
    _write(_fileno(bt_uart), pkt, 6);
    get_from_module(7);
    //DEBUGT("-- got 7 --\n");

    //page timeout
    pkt[1] = 0x18;
    pkt[3] = 0x02;
    pkt[4] = 0x00;
    pkt[5] = 0x20;
    _write(_fileno(bt_uart), pkt, 6);
    get_from_module(7);
    //DEBUGT("-- got 7 --\n");

    //scan timeout
    pkt[1] = 0x1A;
    pkt[3] = 0x01;
    pkt[4] = 0x03;
    _write(_fileno(bt_uart), pkt, 5);
    get_from_module(7);
    //DEBUGT("-- got 7 --\n");

    //read buffersize
    pkt[1] = 0x05;
    pkt[2] = 0x10;
    pkt[3] = 0x00;
    _write(_fileno(bt_uart), pkt, 4);
    get_from_module(14);
    //DEBUGT("-- got 14 --\n");

    //set acl flowcontrol
    pkt[1] = 0x31;
    pkt[2] = 0x0C;
    pkt[3] = 0x01;
    pkt[4] = 0x01;
    _write(_fileno(bt_uart), pkt, 5);
    get_from_module(7);
    //DEBUGT("-- got 7 --\n");

    //inquiry type
    pkt[1] = 0x45;
    _write(_fileno(bt_uart), pkt, 5);
    get_from_module(7);
    //DEBUGT("-- got 7 --\n");

    DEBUGT("init done\nmy addr: ");
        
    //read bd addr
    pkt[1] = 0x09;
    pkt[2] = 0x10;
    pkt[3] = 0x00;
    _write(_fileno(bt_uart), pkt, 4);
    get_from_module(7);
    //DEBUGT("-- got 7 --\n");
    get_from_module_addr();

    //read local version info
    pkt[0] = 0x01; //OGF
    pkt[1] = 0x01; //OCF
    pkt[2] = 0x10;
    pkt[3] = 0x00;
    _write(_fileno(bt_uart), pkt, 4);
    DEBUGT("hci version found");
    get_from_module(7);
    //get_from_module(12);
    get_from_module_version();
    //get_from_module(4);

    //DEBUGT("\n");
    //inquiry
    pkt[0] = 0x01;
    pkt[1] = 0x01;
    pkt[2] = 0x04;
    pkt[3] = 0x05;
    pkt[4] = 0x33;
    pkt[5] = 0x8B;
    pkt[6] = 0x9E;
    pkt[7] = 0x30; //length
    pkt[8] = 0x01; //num responses
    _write(_fileno(bt_uart), pkt, 9);
    DEBUGT("inquiry found: ");
    get_from_module(8);
    get_from_module(3);
    get_from_module_addr(); // inquiry result
    get_from_module(8); // inquiry result parameters
    get_from_module(10); // command complete

    DEBUGT("\nBLUETOOTH O.K.\n");
}

void _cmd_inq(char* arg) {

       DEBUGT("BLUETOOTH INQUIRY \n");
       tristate_off_bt("");
	   jtag_on("");
	   //inquiry
       pkt[0] = 0x01;
       pkt[1] = 0x01;
       pkt[2] = 0x04;
       pkt[3] = 0x05;
       pkt[4] = 0x33;
       pkt[5] = 0x8B;
       pkt[6] = 0x9E;
       pkt[7] = 0x30; //length
       pkt[8] = 0x01; //num responses
       _write(_fileno(bt_uart), pkt, 9);
       DEBUGT("inquiry found: ");
       get_from_module(8);
       get_from_module(3);
       get_from_module_addr(); // inquiry result
       get_from_module(8); // inquiry result parameters
       get_from_module(10); // command complete
       DEBUGT("\nBLUETOOTH INQUIRY O.K. \n");
       }

void _cmd_version(char* arg) {

       DEBUGT("BLUETOOTH LOCAL HCI VERSION \n");
       tristate_off_bt("");
	   jtag_on("");
	   //read local version info
       pkt[0] = 0x01; //OGF
       pkt[1] = 0x01; //OCF
       pkt[2] = 0x10;
       pkt[3] = 0x00;
       _write(_fileno(bt_uart), pkt, 4);
       DEBUGT("hci version found");
       get_from_module(7);
       //get_from_module(12);
       get_from_module_version();
       //get_from_module(4);
       }

void _cmd_bat(char* arg){
	u_int volt = 0;
	
	DEBUGT("BATTERY TEST\n");
	volt = btn_external_power();
	if (volt > 0){
		DEBUGT("we have external power\n");
	}
	volt = btn_bat_measure(10);
	DEBUGT("voltage is: %d\n", volt);
	DEBUGT("BATTERY TEST O.K.\n");
	
}

void _cmd_lpm(char* arg){
	
	DEBUGT("LOW POWER MODES TEST\n");
	tristate_bt("");
	jtag_off("");

	// BT_VCC OFF and RESET to GND
	btn_hardware_bt_power( 0 );
	DEBUGT("turned bt power OFF, ");
    NutSleep( 3000 );

	// CC1000_VCC OFF and RESET to GND
	btn_hardware_cc1000_power( 0 );
	DEBUGT("turned cc1000 power OFF, ");
    NutSleep( 3000 );

	// IO_VCC OFF and RESET to GND
	btn_hardware_io_power( 0 );
	DEBUGT("turned io power OFF, ");
    NutSleep( 3000 );

//	btn_hardware_bt_reset( 1 );
//	DEBUGT("BT reset, waiting... "); 
//	NutSleep( 3000 );
//
//	btn_hardware_bt_power( 1 );
//	DEBUGT("turned bt power ON\n"); 
//	NutSleep ( 1000 );
//	btn_hardware_bt_reset( 0 );
//	DEBUGT("BT reset released "); 
//	NutSleep ( 1000 );

    DEBUGT("\nentering IDLE mode for 10s\n");
    NutSleep(500);
    NutThreadSetSleepMode(SLEEP_MODE_IDLE);    
    NutSleep(10000);

    NutThreadSetSleepMode(SLEEP_MODE_NONE);    
    DEBUGT("entering ADC mode for 10s\n");
    NutSleep(500);
    NutThreadSetSleepMode(SLEEP_MODE_ADC);    
    NutSleep(10000);

    NutThreadSetSleepMode(SLEEP_MODE_NONE);    
    DEBUGT("entering PWR_SAVE mode for 10s\n");
    NutSleep(500);
    NutThreadSetSleepMode(SLEEP_MODE_PWR_SAVE);    
    NutSleep(10000);

    NutThreadSetSleepMode(SLEEP_MODE_NONE);    
    DEBUGT("entering EXT_STANDBY mode for 10s\n");
    NutSleep(500);
    NutThreadSetSleepMode(SLEEP_MODE_EXT_STANDBY);    
    NutSleep(10000);

    NutThreadSetSleepMode(SLEEP_MODE_NONE);    

	DEBUGT("LOW POWER MODES TEST FINISHED\n");
}

int main(void)
{
    u_long cpu_crystal;
    u_long nut_tick_freq;
    
    //blink/set blue LED to start
    
    btn_hardware_config_latch_init();
    btn_hardware_config_latch_clear(LED0);
    btn_hardware_config_latch_clear(LED1);
    btn_hardware_config_latch_clear(LED2);
    btn_hardware_config_latch_clear(LED3);
    NutDelay(255);
    btn_hardware_config_latch_set(LED3);
    NutDelay(255);
    btn_hardware_config_latch_clear(LED3);
    NutDelay(255);
    btn_hardware_config_latch_set(LED3);

    // terminal initialization
    init_term();
    DEBUGB("\n# ---------------------------------------------");
    DEBUGB("\n# BTnode rev3 System Test (c) 2005 ETH Zurich\n");
    DEBUGT("# program version: %s\n", PROGRAM_VERSION);
    cpu_crystal = NutGetCpuClock();
    nut_tick_freq = NutGetTickClock();
    DEBUGT("# running @ %u.%04u MHz, NutFreq=%ul Hz\n",
           (int) (cpu_crystal / 1000000UL), (int) ((cpu_crystal - (cpu_crystal / 1000000UL) * 1000000UL) / 100),
        nut_tick_freq);
    DEBUGB("# ---------------------------------------------\n");
            
    // bt uart
    init_bt_uart();
    
    //cc1000 power on
    btn_hardware_cc1000_power( 1 );   


    // ext mem on + setup bank switching
    _cmd_mem_on("");
    
    // register cmds
    btn_terminal_register_cmd("memtest", _cmd_memtest);
    btn_terminal_register_cmd("mem", _cmd_mem);
    btn_terminal_register_cmd("btinit", _cmd_btinit);
	btn_terminal_register_cmd("btreboot", _cmd_btreboot);
    btn_terminal_register_cmd("inq", _cmd_inq);
    btn_terminal_register_cmd("led", _cmd_led);
    btn_terminal_register_cmd("ver", _cmd_version);
    btn_terminal_register_cmd("bat", _cmd_bat);
    btn_terminal_register_cmd("lpm", _cmd_lpm);
    cc_test_register_cmds();
    
    // automatic tests
	_cmd_mem("");
	_cmd_btreboot("");

    // leds off (visible for 100 ms)
    btn_hardware_config_latch_clear(LED3);
    NutSleep(600);
	_cmd_led("");
	_cmd_bat("");

    // main options now: btreset/btpower (for programming) and inq (function)
    btn_terminal_run(BTN_TERMINAL_NOFORK, 0);
	
	
    return 0;
}




