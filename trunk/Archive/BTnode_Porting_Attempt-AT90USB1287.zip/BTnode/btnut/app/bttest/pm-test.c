/*
 * Copyright (C) 2000-2006 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \example bttest/pm-test.c
 *
 * \date 07.03.2006
 * \author Mustafa Yuecel <mustafa.yuecel@alumni.ethz.ch>
 *
 * Production test application using the low power modes on ATmega128L
 *
 */

// 0: NONE, 1: IDLE, 2: ADC, 3: EXT_STANDBY,
//  4: PWR_SAVE, 5: STANDBY, 6: PWR_DOWN

#include <avr/sleep.h>
#include <sys/thread.h>
#include <sys/timer.h>
#include <hardware/btn-hardware.h>
#include <hardware/btn-ledhw.h>
#include <eepromdb/btn-eepromdb.h>

#define EEPROM_ID FOURCC('P', 'M', 'S', 'P')

#define BLUE   0
#define RED    1
#define YELLOW 2
#define GREEN  3

#define MODE_NONE        0
#define MODE_IDLE        1
#define MODE_ADC         2
#define MODE_EXT_STANDBY 3
#define MODE_PWR_SAVE    4
#define MODE_STANDBY     5
#define MODE_PWR_DOWN    6

#define COUNT_PW_MODES 7

u_char getMode(u_char value)
{
    if (value == MODE_IDLE)
    {
        return SLEEP_MODE_IDLE;
    }
    if (value == MODE_ADC)
    {
        return SLEEP_MODE_ADC;
    }
    if (value == MODE_EXT_STANDBY)
    {
        return SLEEP_MODE_EXT_STANDBY;
    }
    if (value == MODE_PWR_SAVE)
    {
        return SLEEP_MODE_PWR_SAVE;
    }
    if (value == MODE_STANDBY)
    {
        return SLEEP_MODE_STANDBY;
    }
    if (value == MODE_PWR_DOWN)
    {
        return SLEEP_MODE_PWR_DOWN;
    }

    return SLEEP_MODE_NONE;
}

void setleds(u_char value)
{
    if (value == MODE_NONE)
    {
        _btn_led_set(BLUE);
        _btn_led_set(RED);
        _btn_led_set(YELLOW);
        _btn_led_set(GREEN);
    }
    else if (value == MODE_IDLE)
    {
        _btn_led_set(BLUE);
        _btn_led_set(RED);
        _btn_led_set(YELLOW);
    }
    else if (value == MODE_ADC)
    {
        _btn_led_set(RED);
        _btn_led_set(YELLOW);
    }
    else if (value == MODE_EXT_STANDBY)
    {
        _btn_led_set(BLUE);
        _btn_led_set(YELLOW);
    }
    else if (value == MODE_PWR_SAVE)
    {
        _btn_led_set(YELLOW);
    }
    else if (value == MODE_STANDBY)
    {
        _btn_led_set(BLUE);
        _btn_led_set(RED);
    }
    else if (value == MODE_PWR_DOWN)
    {
        _btn_led_set(BLUE);
    }
}

void clearleds(void)
{
    _btn_led_clear(BLUE);
    _btn_led_clear(RED);
    _btn_led_clear(YELLOW);
    _btn_led_clear(GREEN);
}

int main(void)
{
    u_long value = COUNT_PW_MODES - 1;

    _btn_led_init();

    btn_hardware_init();

    btn_hardware_bt_power(0);
    btn_hardware_cc1000_power(0);

    btn_eepromdb_get(EEPROM_ID, sizeof(u_long), &value);

    value++;

    value %= COUNT_PW_MODES;

    if (btn_eepromdb_store(EEPROM_ID, sizeof(u_long), &value) == 0)
    {
        _btn_led_set(RED);
        NutSleep(3000);
        return -1;
    }

    setleds((u_char) value);

    NutSleep(2000);

    clearleds();

    NutThreadSetSleepMode(getMode((u_char) value));

    for (;;)
    {
        NutSleep(-1);
    }

    return -1;
}
