/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \example bttest/cc1000-test.c
 *
 * \date 08.07.2004
 * \author Jan Beutel <j.beutel@ieee.org>
 *
 * Production test application using the Chipcon CC1000 module on BTnode Rev3
 *
 * Test setup:  One working golden master device is in viccinity to the test node running
 *              this software as it is
 * 
 * Test:        Initialize and power Chipcon
 *              Read/Write Chipcon Registers: Error if values differ
 *              Send Packet to golden master (which blinks all LEDs on packet reception)
 *              Receive Packet: Error if no packet received or data not correct
 */


// nut
#include <stdio.h>
#include <dev/usartavr.h>
#include <io.h>
#include <sys/atom.h>
#include <sys/timer.h>
#include <sys/event.h>
#include <dev/irqreg.h>

// btnode3
#include <hardware/btn-hardware.h>
#include <led/btn-led.h>

// chipcon
#include <cc/crc.h>
#include <cc/cc1000.h>
#include <cc/cc1000_defs.h>
//#include <cc/sniffer.h>

// stand alone app uses printf_P, bt-cmd used DEBUGT from Terminal
#ifndef USED_FROM_BTCMD
#define DEBUGT(text, ...) printf_P(PSTR(text),## __VA_ARGS__)
#endif 


// #define OLDNODE
// #define ONEWAY

/** global variables and defines for simple packet send and receive */


#define PREAMBLE_THRESH 6   //number of preamble bytes receiver needs to listen
#define PREAMBLE_LEN 16     //number of preamble bytes sender needs to send
#define PREAMBLE_BYTE 0xAA  // 10101010
#define SYNC_BYTE 0x33      // 00110011 used as start of packet
#define FLUSH_BYTE 0xFF     // 11111111

#define STATE_INIT 0 

#define STATE_RECV_IDLE 1 
#define STATE_RECV_PRE 2 
#define STATE_RECV_SYNC 3 
#define STATE_RECV_SIZE 4 
#define STATE_RECV_DATA 5 
#define STATE_RECV_CRC_H 6 
#define STATE_RECV_CRC_L 7 

#define STATE_SEND_PRE 8
#define STATE_SEND_SYNC 9
#define STATE_SEND_SIZE 10
#define STATE_SEND_DATA 11 
#define STATE_SEND_FLUSH 12 
#define STATE_SEND_CRC_H 13 
#define STATE_SEND_CRC_L 14 
#define STATE_SEND_DONE 15 

#define STATE_FINISHED 16

#define MAX_DATA_SIZE 32 // maximum data size sender can send

struct Buff{
    u_char size;
    u_char data[MAX_DATA_SIZE];
};

u_char state = STATE_INIT;
//u_char count=0; 
HANDLE bttestRecvHandle=0,bttestSendHandle=0;
u_char bttestprevData=0, spData, bttestpreambleCount=0, bttestoffset=0, bttestdataCount=0, crcHigh,crcLow;
struct Buff RecvBuff,SendBuff;


/*
 * Protocol for sending and receiving packet
 */

// spi handler which will be called when a byte is sent or received
void Protocol(void* arg){
    switch(state){
    
        case STATE_RECV_IDLE:
            spData=SPDR;
            if(spData == 0xAA || spData == 0x55) //we are in preamble
            {
                bttestpreambleCount = 0;
                state = STATE_RECV_PRE;
            }
            break;
            
        case STATE_RECV_PRE:
            spData=SPDR;
            if(spData != 0xAA && spData != 0x55) //not in preamble anymore
            {
                if(bttestpreambleCount > PREAMBLE_THRESH) //reached end of preamble
                {
                    state = STATE_RECV_SYNC;
                    bttestoffset = 0;
                }
                else //just looking at noise
                {
                    state = STATE_RECV_IDLE;
                }
            }
            else //just seeing more of the preamble
            {
                bttestpreambleCount++;
            }
            bttestprevData = spData;
            break;
            
        case STATE_RECV_SYNC:
            spData=SPDR;
            /* Figure out the bit offset by shifting until the sync byte. */
            while(bttestprevData != SYNC_BYTE && bttestoffset < 8)
            {
                bttestprevData = (bttestprevData << 1) | (spData >> (7-bttestoffset));
                bttestoffset++;
            }
                
            if(bttestoffset >= 8) //didn't get the sync byte... Something is wrong
            {
                state = STATE_RECV_IDLE;
            }
            else
            {
                /* We are synced and ready to start getting the packet. */
                state = STATE_RECV_SIZE;
                bttestprevData = spData;
            }
            break;
            
        case STATE_RECV_SIZE:
            spData = SPDR;
            /* Grab the packet size and verify that it isn't larger than
            the maximum data size. */
            RecvBuff.size = (bttestprevData << bttestoffset) | (spData >> (8-bttestoffset));
            if(RecvBuff.size > MAX_DATA_SIZE || RecvBuff.size == 0)
            {
                //something is wrong--packet is zero size, or too large to recv
                state = STATE_RECV_IDLE;
            }
            else
            {
                //ready to recv data
                bttestdataCount = 0;
                //RecvBuff.data=(u_char*) malloc(RecvBuff.size*sizeof(u_char));
                state = STATE_RECV_DATA;
            }
            bttestprevData = spData;
            break;
            
            
        case STATE_RECV_DATA:
            spData=SPDR;
            RecvBuff.data[bttestdataCount]=(bttestprevData << bttestoffset) | (spData >> (8-bttestoffset));
            bttestdataCount++;
            /* Once we have the whole packet, get the crc*/
            if(bttestdataCount == RecvBuff.size)
                state = STATE_RECV_CRC_H;
            bttestprevData = spData;
            break;
            
        case STATE_RECV_CRC_H:
            //store high byte of crc
            spData = SPDR;
            crcHigh = (bttestprevData << bttestoffset) | (spData >> (8-bttestoffset));
            //ready to recv low byte
            state = STATE_RECV_CRC_L;
            bttestprevData = spData;
            break;
            
        case STATE_RECV_CRC_L:
            //read low byte and assemble full crc
            spData = SPDR;
            crcLow = (bttestprevData << bttestoffset) | (spData >> (8-bttestoffset));
            //if crc checks out, swap buffer up to com layer
            // if(crc_ccitt_compute(RecvBuff.data, RecvBuff.size) == ((((u_long)crcHigh) << 8) | crcLow))
            if (1)
            {
                state = STATE_RECV_IDLE;
                
                //disable the spi interrupt
                SPCR &= ~(1 << SPIE);
                
                //resume the thread
                NutEventPostAsync(&bttestRecvHandle);
            }
            else
            {
                state = STATE_RECV_IDLE;
            }
            break;
            
            
            
        case STATE_SEND_PRE:
            SPDR = PREAMBLE_BYTE; 
            bttestpreambleCount++;
            if(bttestpreambleCount == PREAMBLE_LEN)
                state = STATE_SEND_SYNC;
            break;
            
        case STATE_SEND_SYNC:
            SPDR = SYNC_BYTE; 
            state = STATE_SEND_SIZE;
            break;
            
        case STATE_SEND_SIZE:
            SPDR = SendBuff.size; 
            bttestdataCount = 0;
            state = STATE_SEND_DATA;
            break;      
            
        case STATE_SEND_DATA:
            SPDR = SendBuff.data[bttestdataCount];
            bttestdataCount++;
            if(bttestdataCount == SendBuff.size)
                state = STATE_SEND_CRC_H;
            break;
            
        case STATE_SEND_CRC_H:
            SPDR = crcHigh; 
            state = STATE_SEND_CRC_L;
            break;
            
        case STATE_SEND_CRC_L:
            SPDR = crcLow;
            state = STATE_SEND_FLUSH;
            break;
            
        case STATE_SEND_FLUSH:
            SPDR = FLUSH_BYTE; 
            state = STATE_FINISHED;
            
            //disable the spi interrupt
            SPCR &= ~(1 << SPIE);
            
            // resume the thread
            NutEventPostAsync(&bttestSendHandle);
            break;
            
        case STATE_INIT:
        default:
            break;
    }
}


/*
\brief use Protocol SPI handler without interrupts for sending 
 */

void ProtocolSend(void){
    while ( state != STATE_FINISHED) {
        while ( (SPSR & BV(SPIF)) == 0);
        Protocol( (void *) 0);
    }
}

/**
 \brief receive data into RecvBuf
 \returns 1 if packet was received (at least partially)
 */
u_char cc1000_recv(u_short timeout){

    cc1000_rxmode();

    bttestprevData=0;
    bttestpreambleCount=0;
    bttestoffset=0;
    state=STATE_RECV_IDLE;

    //enable the spi interrupt
    SPCR |= (1 << SPIE);
    
    if (NutEventWaitNext(&bttestRecvHandle, timeout) == 0)
        return 1;
    
    return 0;
}

/**
 \brief send SendBuff
 \returns 1 if packet was received (at least partially)
 */
 
void cc1000_send(void){
    u_long crc;

    NutEnterCritical();

    bttestpreambleCount=0;
    if(SendBuff.size==0 || SendBuff.size>MAX_DATA_SIZE)
        return;

    state=STATE_SEND_PRE;
    
    //compute crc now, so we don't have to do it in interrupt handler
    crc = crc_ccitt_compute(SendBuff.data, SendBuff.size);
    crcLow = crc & 0x00FF;
    crcHigh = (crc & 0xFF00) >> 8;
    
    cc1000_txmode();

    //enable the spi interrupt
    // SPCR |= (1 << SPIE);
    
    //suspend and wait while the packet is sent
    // NutEventWaitNext(&bttestSendHandle,NUT_WAIT_INFINITE);
    
    ProtocolSend();

    // cc1000_rxmode();

    NutExitCritical();
    
}


/* adc initialization*/
void bttest_cc_rssi_adc_init(void){
    uint8_t temp;
    ADCSRA = (1 << ADEN);
    ADMUX = 2; //CC1000_RSSI_ADC; //2 for btnode, 0 for mica2
    // ADMUX |= BV(ADLAR); //left adjusted, only read ADCH

    // first conversion takes 25 adc cycles
    ADCSRA |= (1 << ADSC);
    while(ADCSRA & (1<<ADSC));
    temp=ADCL;
    temp=ADCH;
}


void cc_on(void){

#ifndef OLDNODE
    // turn on chipcon
    btn_hardware_config_latch_set(CC1000_POWER_ON_PIN);
#endif
    
    //adc initialization
    bttest_cc_rssi_adc_init();

    // wait 10 ms (2 ms crystal startup time)
    NutSleep( 10 );

    cc1000_init(0);

    //register handler 
    state = STATE_INIT;
    NutRegisterIrqHandler(&sig_SPI,Protocol,0);
}


void cc_tune_868300(void){

    // setup rx and tx channel for 868.3 MHz
    cc1000_init(0x1d);

    // FRX - CDF02B: 868150000
    cc1000_write(1, 0xCD );
    cc1000_write(2, 0xF0 );
    cc1000_write(3, 0x2B );

    // FTX - CDF757: 868268000
    cc1000_write(4, 0xCD );
    cc1000_write(5, 0xF7 );
    cc1000_write(6, 0x57 );

    cc1000_calibrate();
    // rx and tx channels are initialized and calibrated
}


/**
 \returns 1 if ok
 */

u_char cc_test_registers(void)
{
    u_char i;
    u_char ok = 1;
    
    // DEBUGT( "Testing read/write registers\n\r");
    
    for (i = 0; i < 255 ; i++) {
        cc1000_write(1, i );
        if (cc1000_read( 1 ) != i )
            ok = 0;
    }
    
    if (ok == 0)
        DEBUGT( "Chipcon Error: Read/Write Registers Failed !!!\n\r");
    return ok;
}


/**
 \returns 1 if ok
 */
u_char cc_test_packet(void){

    u_char i;
    u_short sent = 0, received;
    u_short crc_ok = 0;
    u_char ok = 1;
    u_char errors;

    btn_hardware_config_latch_clear(LED0);
    btn_hardware_config_latch_clear(LED1);
    btn_hardware_config_latch_clear(LED2);
    btn_hardware_config_latch_clear(LED3);

    received = 0;
  
    // fill buffer
    for (i=0; i < MAX_DATA_SIZE; i++)
        SendBuff.data[i] = i+i;
    SendBuff.size = MAX_DATA_SIZE;
    
#ifndef ONEWAY
    for (sent=0; sent < 100 ; sent++) {

		// DEBUGT("sending %d\n", sent);
        // send packet
        cc1000_send();
#else

	while (1) {

#endif

		// clear receive buffer
	    for (i=0; i < MAX_DATA_SIZE; i++)
    	    RecvBuff.data[i] = 0;
		
        // receive packet in 1000 ms (if packet is returned, CRC is ok!)
        if (cc1000_recv(500) != 0)
        {
            received++;
            
            // check packet
            ok = 1; errors = 0;
            for (i=0; i < MAX_DATA_SIZE; i++){
                if (RecvBuff.data[i] != SendBuff.data[i]){
                    ok = 0;
                    errors++;
                }
            }
            if (ok) {
		        DEBUGT("+");
                crc_ok++;
            }
            else {
		        DEBUGT("\n\r:");
                for (i=0; i < MAX_DATA_SIZE; i++){
                    if (RecvBuff.data[i] == SendBuff.data[i])
                        DEBUGT("---- ");
                    else
                        DEBUGT("%02x%02x ", SendBuff.data[i], RecvBuff.data[i] );
                }
                DEBUGT("\n\r");
            }
        }
        else
	        DEBUGT(".");

        btn_hardware_config_latch_clear(LED2);        
        btn_hardware_config_latch_clear(LED3);        

		NutSleep( 100 );

        btn_hardware_config_latch_set(LED2);        
        btn_hardware_config_latch_set(LED3);        
        
    }
    
    ok = 1;
    DEBUGT("Chipcon Test: packets send %d, received %d, crc_ok %d\n\r", sent, received, crc_ok);
    if (crc_ok > 95)
        DEBUGT("Chipcon Test: O.K. ");
    else {
        DEBUGT("Chipcon Test: Failed, too many bit errors ");
        ok = 0;
    }
	DEBUGT("\n");    

    return ok;
}


/**
 *
 * echo packets
 *   if at least a packet header was received, send a test packet
 */
void cc_test_echo(char * arg){

    u_char i;

    DEBUGT("Chipcon Production Test - Echo Test Mode\n\r");
    btn_hardware_config_latch_clear(LED0);
    btn_hardware_config_latch_clear(LED1);
    btn_hardware_config_latch_clear(LED2);
    btn_hardware_config_latch_clear(LED3);

    NutEnterCritical();

    cc_on();
    cc_tune_868300();    

    for (i=0; i < MAX_DATA_SIZE; i++)
        SendBuff.data[i] = i+i;
    SendBuff.size = MAX_DATA_SIZE;

    while (1){

#ifndef ONEWAY
        // get packet
		 cc1000_recv(NUT_WAIT_INFINITE);
#endif

        // blink on
#ifdef OLDNODE
		PORTC |= BV ( 0 ) | BV ( 1 );
#else
	    btn_hardware_config_latch_set(LED0);
    	btn_hardware_config_latch_set(LED1);
#endif

        // send packet
        cc1000_send();

#ifdef ONEWAY
		NutSleep ( 300 );
#endif

#ifndef ONEWAY

        // get packet
        cc1000_recv(NUT_WAIT_INFINITE);
#endif
        
        // blink off
#ifdef OLDNODE
		PORTC &= ~ ( BV ( 0 ) | BV ( 1 ) );
#else
    	btn_hardware_config_latch_clear(LED0);
    	btn_hardware_config_latch_clear(LED1);
#endif
        // send packet
        cc1000_send();

#ifdef ONEWAY
		NutSleep ( 300 );
#endif
    }
    NutExitCritical();
}

/**
 * chipcon test
 *  test registers
 *  send and receive 100 packets
  
 \returns 1 if test was ok

 */
 
void cc_test(char * arg) {
    // on
    cc_on();

    // test registers
    if (cc_test_registers()){

        /// 868.3 Mhz
        cc_tune_868300();    

        // test packet sending
        // return cc_test_packet();
        cc_test_packet();
    }
    // return 0;
}


#ifndef USED_FROM_BTCMD
int main(void){
    u_long baud = 115200;

    /*
     * Register the UART device, open it, assign stdout to it and set 
     * the baudrate.
     */
    NutRegisterDevice(&devUsartAvr0, 0, 0);
    freopen("uart0", "w", stdout);
    _ioctl(_fileno(stdout), UART_SETSPEED, &baud);
    
    DEBUGT("\n\rChipcon Production Test Standalone Version\n\r");

#ifdef OLDNODE
	// power on

	// if patched, then PORTC is the latch
    DDRC  = 0xff;
	PORTC = BV (CC1000_POWER_ON_PIN) | BV ( 1 ); // CC on, BT off, LEDSs off but 2.

#else
    // init config latch
    btn_hardware_config_latch_init();    
#endif 

    // try as node
	DEBUGT("TEST APP\n\r");
    cc_test("");
	
    // act as echo partner
    cc_test_echo("");
	DEBUGT("ECHO APP\n\r");

    while (1);
}
#else

#ifdef OLDNODE
#error "OLDNODE not supported for Test App"
#endif

void cc_test_register_cmds(void){
    btn_terminal_register_cmd("cctest", cc_test);
    btn_terminal_register_cmd("ccecho", cc_test_echo);
}

#endif
