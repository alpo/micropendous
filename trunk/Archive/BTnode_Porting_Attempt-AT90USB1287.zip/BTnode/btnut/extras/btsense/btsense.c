/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/*
 * \file btsense.c
 *
 * \date 01.06.2006
 *
 * \author bosterm
 *
 * \brief Library for the BTSense board
 *
 */

 
#include <stdio.h>
#include <string.h>
#include <sys/mutex.h>
#include <sys/timer.h>
#include <led/btn-led.h>
#include <sys/atom.h>
#include <dev/irqreg.h>
#include <dev/twif.h>
#include <hardware/btn-hardware.h>
#include <btsense/btsense.h>
#include <dev/adc2.h> 

#if !defined(__BTN_UNIX__)

// ----------------------------------------------------------------------------
// #define constants
// ----------------------------------------------------------------------------

#define BTSENSE_I2C_TC74 0x48

// ----------------------------------------------------------------------------
// forward declarations
// ----------------------------------------------------------------------------

static void btsense_sound_init(btsense_revision_t rev);
static void btsense_sound_old(u_short freq);
static void btsense_sound_new(u_short freq);
static void btsense_timer3_handler(void *arg);
static void btsense_interrupt6_handler(void* arg);

// ----------------------------------------------------------------------------
// global variables
// ----------------------------------------------------------------------------

void (*btsense_sound) (u_short) = NULL;

// ----------------------------------------------------------------------------
// local variables
// ----------------------------------------------------------------------------

static u_short btsense_adc_handle;
static int btsense_init_complete = 0;

// ----------------------------------------------------------------------------
// global functions
// ----------------------------------------------------------------------------

void btsense_init( btsense_revision_t rev )
{
	if (btsense_init_complete == 1) 
	{
		return;
	}
	
	btsense_init_complete = 1;
	
    // power on sensor board
    btn_hardware_io_power(1); 

    // init I2C bus for the temperature sensor
    // - set pull-up for PD0 && PD1
    sbi(PORTD, PD0);
    sbi(PORTD, PD1);
    // - set i2c slave address
    TwInit(20);	
    
    // init the PIR
	// - disable INT6 as long as we are changing the settings
	cbi(EIMSK, INT6);
	
    // - register motion interrupt handler
    NutRegisterIrqHandler(&sig_INTERRUPT6, btsense_interrupt6_handler, NULL);	
	
	// - set PE6 as input 
	cbi( DDRE, PE6 ); 

    // - set external interrupt 6 to rising *and* falling edge 
    // - (see page 88 of Atmel manual)
    cbi(EICRB, ISC61);
	sbi(EICRB, ISC60);
	
    // - enable interrupt 6
	sbi(EIMSK, INT6);
    //NutIrqEnable(&sig_INTERRUPT6);
    
    // init the beeper
	btsense_sound_init( rev );
	
	// init the adc handle for the light sensor
	btsense_adc_handle = adc2_init( ADC2_MODE_SINGLE_CONVERSION,
							   ADC2_INTERRUPT_DISABLE,
							   ADC2_PRESCALE_DIV2,
							   ADC2_CHANNEL_0,
							   ADC2_REF_AREF ); //ADC2_REF_INTERNAL_256 );
}

u_short btsense_sample_light(void)
{
	if ( btsense_init_complete == 0 )
	{
		return 0xFFFF;
	}
	
	return adc2_read( btsense_adc_handle );
}

/*
 * read out motion pin
 */
u_char btsense_sample_motion(void)
{
	if ( btsense_init_complete == 0 )
	{
		return 0xFF;
	}
	
	return ((PINE & _BV(6)) != 0);
}

/*
 * samples the temperature sensor
 */
int btsense_sample_temp(char* temp)
{
	if ( btsense_init_complete == 0 )
	{
		return 0xFFFF;
	}
	
    u_char tw_cmd = 0x00; // read temperature
    u_char t;
    if (TwMasterTransact(BTSENSE_I2C_TC74, &tw_cmd, 1, &t, 1, 1000) == -1)
    {
        return TwMasterError();
    }
    // actual temperature is value -3.4 degrees
    // c.f. AllSensors/ssimpall/2004_06_28/sensors/tc74.c
    // http://particle.teco.edu/software/index.html
    *temp = t; // - 3;
    return 0;
}


// ----------------------------------------------------------------------------
// local functions
// ----------------------------------------------------------------------------
/*
 * interrupt-driven sound generation
 * @deprecated was used for rev. 1.1 without A
 */
static void btsense_timer3_handler(void *arg) 
{
	static u_char active = 0;	
	
	if ( active != 0 )
    {
    	active = 0;
    	cbi( PORTB, PB4 );		
   	}
   	else
   	{
    	active = 1;   		
    	sbi( PORTB, PB4 );
    }	
}

/*
 * default IRQ handler for motion sensor
 */
static void btsense_interrupt6_handler(void* arg)
{
    static u_char active = 0;

    if ( active == 0 )
	{
		active = 1;
		btn_led_set(3);
	}
	else 
	{
		active = 0;
	    btn_led_clear(3);
	}
}

/*
 * sound init
 * manages both timer and interrupt-driven sound generation 1.1 and 1.1A 
 */
static void btsense_sound_init( btsense_revision_t rev )
{
	// init counter 3
	
	// interrupt settings for counter 3	
	cbi( ETIMSK, OCIE3A );  // no output compare match interrupt for A    
	cbi( ETIMSK, TICIE3 );  // no input capture interrupt
	cbi( ETIMSK, TOIE3 );   // no overflow interrupt
	
    // CTC mode
    cbi( TCCR3B, WGM33 );
    sbi( TCCR3B, WGM32 );        
    cbi( TCCR3A, WGM31 );
    cbi( TCCR3A, WGM30 );   
    
    // set prescaler to DIV 8
    cbi( TCCR3B, CS32 );
    sbi( TCCR3B, CS31 );
    cbi( TCCR3B, CS30 );

   	// this is for originally wired BTSense rev 1.1 boards    
    if ( rev == BTSENSE_REVISION_1_1 )
    {
	    // OC3A disconnected
	    cbi( TCCR3A, COM3A1 );
	    cbi( TCCR3A, COM3A0 );     	
    	
  	    sbi(DDRB, PB4); // set PB4 as output
	    NutRegisterIrqHandler(&sig_OUTPUT_COMPARE3A, btsense_timer3_handler, 0);    
	    btsense_sound = btsense_sound_old;
    }
    else
    {
	    // toggle OC3A on compare match
	    cbi( TCCR3A, COM3A1 );
	    sbi( TCCR3A, COM3A0 );
    	
	    btsense_sound = btsense_sound_new;    	
    }
}


static void btsense_sound_old(u_short freq)
{
	// Beeper is connected to PB4 = OC0
	// so wee need an interrupt routine to control it
	
	if ( btsense_init_complete == 0 )
	{
		return;
	}
	
	u_long ocr;	
	//printf( "btsense_sound_old: Freq = %u\n", freq );
	
	if ( freq == 0 )
	{
		// disable output compare match interrupt for A 
	    cbi( ETIMSK, OCIE3A );    
		return;
	}	
	
	//calculate OCR
	ocr = (7372800 / (2 * 8 * (u_long) freq )) - 1;

	// 16 bit register access needs to be atomic
	NutEnterCritical();    

    // set TOP value
	OCR3A = (u_short) ocr;
	
	// set counter to zero
	TCNT3 = 0x0000;

	// 16 bit register access needs to be atomic
	NutExitCritical();
	
	// enable output compare match interrupt for A  
    sbi( ETIMSK, OCIE3A );  
}

static void btsense_sound_new(u_short freq)
{
	// Beeper is connected to PE3 = OC3A
	
	if ( btsense_init_complete == 0 )
	{
		return;
	}	
	
	u_long ocr;	
	//printf( "btsense_sound_new: Freq = %u\n", freq );
	
	if ( freq == 0 )
	{
		// disable counter
	    // Disable output pin for the CTC mode timer fuction	     
		cbi( DDRE, PE3 );	
		return;
	}	
	
	//calculate OCR
	ocr = (7372800 / (2 * 8 * (u_long) freq )) - 1;
	//printf( "ocr = %lu\n", ocr );
	
	// update counter 3

	// 16 bit register access needs to be atomic
	NutEnterCritical();    

    // set TOP value
	OCR3A = (u_short) ocr;
	
	// set counter to zero
	TCNT3 = 0x0000;

	// 16 bit register access needs to be atomic
	NutExitCritical();
	
	// enable output
    sbi( DDRE, PE3 );	// Output pin for the PWM mode timer fuction		
}

#else

// ----------------------------------------------------------------------------
// unix version
// ----------------------------------------------------------------------------

void btsense_init( btsense_revision_t rev ){
};

u_short btsense_sample_light(void){
	return 0; // its very dark below a desk
}

u_char btsense_sample_motion(void)
{
	return 0; // no motion on unix
}	

int btsense_sample_temp(char* temp){
	*temp = 27; // it's cosy on a unix machine
    return 0;
}

#endif
