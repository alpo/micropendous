/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file btsense.h
 *
 * \date 01.06.2006
 *
 * \author bosterm
 *
 * \brief Library for the BTSense board
 *
 */
 
#ifndef _BTSENSE_H_
#define _BTSENSE_H_

// ----------------------------------------------------------------------------
// structs, enums & typedefs
// ----------------------------------------------------------------------------

/**
 * The revision number of the attached BTsense board.
 * 
 * \param BTSENSE_REVISION_1_0  did never work
 * \param BTSENSE_REVISION_1_1  beeper at PB4 = OC0
 * \param BTSENSE_REVISION_1_1A beeper at PB6 = OC3A
 */
enum btsense_revision_type
{
	BTSENSE_REVISION_1_0,  // did never work
	BTSENSE_REVISION_1_1,  // beeper at PB4=OC0
	BTSENSE_REVISION_1_1A  // beeper at PB6=OC3A
};
typedef enum btsense_revision_type btsense_revision_t;

// ----------------------------------------------------------------------------
// Functions
// ----------------------------------------------------------------------------

/**
 * Initialises the BTense library. This function has to be called before any 
 * other function of this library. Note that this function also enables the
 * interrupt 6 (for the PIR) and installs an appropriate interrupt handler.
 * 
 * \param rev The revision of the BTsense board.
 */
void btsense_init( btsense_revision_t rev );

/**
 * Samples a value from the light sensor. 
 * 
 * \note This functions makes use of the ADC.
 * 
 * \return The current (digitized) light value (0-1023), 
 *         0xFFFF if called without calling btsense_init() before
 */
u_short btsense_sample_light(void);

/**
 * Samples a value from the light sensor. 
 * 
 * \return 1 if a motion is currently detected, 
 *         0 if no motion is currently detected,
 *         0xFF if called without calling btsense_init() before
 */
u_char btsense_sample_motion(void);

/**
 * Samples a value from the temperature sensor. 
 * 
 * \param temp [out] The current temperature.
 * 
 * \return 0 if no error occured,
 *         the result of TwMasterError() if an I�C error occured,
 *         0xFFFF if called without calling btsense_init() before
 */
int btsense_sample_temp(char* temp);

/**
 * Outputs a sound on the beeper.
 * 
 * \note This is a pointer to a function. Its declaration is
 *       void btsense_sound(u_short freq)
 * 
 * \param freq The frequency in Hz to output. Use 0 to turn off the beeper.
 */
extern void (*btsense_sound) (u_short);

#endif
