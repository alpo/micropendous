/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * \file btsense-cmds.c
 *
 * \date 01.06.2006
 *
 * \author bosterm
 *
 * \brief Commands for the BTSense board
 *
 */

#include <string.h>
#include <stdio.h>
#include <btsense/btsense.h>
#include <terminal/btn-terminal.h>

static void sound_cmd(char* arg)
{
	u_long num;
		
	if (( sscanf(arg, "%lu", &num) != 1 ) || num > 20000 )
	{
		printf( "usage: sound <0..20000>\n" );
		return;
	}
	
	btsense_sound( num );
}

void btsense_cmd(char* arg)
{
    if (!strncmp(arg, "motion", 6))
    {
        u_short val = btsense_sample_motion();
        printf("%d\n",val);
    }
    else
    if (!strncmp(arg, "light", 5))
    {
        u_short val = btsense_sample_light();
        printf("%d\n",val);
    }
    else
    if (!strncmp(arg, "temp", 4))
    {
        char c;
        int err = btsense_sample_temp(&c);
        if (err != 0)
        {
            printf("Error = %d\n",err);
        }
        else
        {
            printf("%d\n",c);
        }
    }
    else
    {
        printf("sensor: error: usage:\n"
               "                   btsense motion\n"
               "                   btsense light\n"
               "                   btsense temp\n"
               );
    }
}

void btsense_cmds_register_cmds(void)
{
    btn_terminal_register_cmd("sound", sound_cmd);
    btn_terminal_register_cmd("btsense", btsense_cmd);
}

