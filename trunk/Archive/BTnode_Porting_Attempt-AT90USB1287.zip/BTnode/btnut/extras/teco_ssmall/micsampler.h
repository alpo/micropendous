/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 * $Id: micsampler.h,v 1.3 2006/10/12 16:42:47 freckle Exp $
 */

 /**
 * @file micsampler.h
 * @author Lukas Winterhalter
 * @brief Sensor interface for Teco Particles SSMALL boards.
 */
 
#ifndef MICSAMPLER_H_
#define MICSAMPLER_H_

#include <sys/types.h>

/**
 * Initialize microphone sampling.
 * 
 * This will start a seperate low priority thread that continuously 
 * reads microphone values. The ADC is set to free running mode and 
 * samples values at 62.5kHz (@8MHz clock).
 * 
 * @warning Do not use the ADC after this function has been called!
 */
void mic_init(void);

/**
 * @brief Reads loudest microphone value.
 * 
 * This function returns the loudest sampled microphone value since 
 * the last time it has been called. 
 * The values range from 0 to 1023 (loudest).
 * 
 * @return mic value
 */
u_short mic_read(void);

/**
 * @brief Sets the LEDs according to mic val.
 * 
 * silence: all LEDs off
 *    .     one LEDs on
 *    .     two LEDs on
 *    .     three LEDs on
 * very loud: all LEDs on
 * 
 * @param mic_val microphone value
 */
void mic_set_leds(u_short mic_val);

#endif /*MICSAMPLER_H_*/
