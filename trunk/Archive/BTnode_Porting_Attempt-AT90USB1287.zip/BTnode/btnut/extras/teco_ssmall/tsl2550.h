/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 * $Id: tsl2550.h,v 1.3 2006/10/12 16:42:47 freckle Exp $
 */

/**
 * @file tsl2550.h
 * @author Lukas Winterhalter
 * @brief Sensor interface for Teco Particles SSMALL boards.
 */

#ifndef TSL2550_
#define TSL2550_

#include <sys/types.h>

/**
 * Initialise the light sensor.
 * 
 * TwInit() has to be called before.
 * 
 * @return 0 on success, 1 otherwise
 */
u_char tsl_init(void);

/**
 * Read sampled sensor data.
 * 
 * After this call, the sensor needs 800ms integration time, before
 * the next values can be read.
 * 
 * @param channel0 (all light)
 * @param channel1 (IR-light only)
 * @return 0 on success, 1 otherwise
 */
u_char tsl_read(u_char *channel0, u_char *channel1);

/**
 * Converts channel values from both sensors to an approximated 
 * value in lux.
 * 
 * This is a simplified lux equation approximation using lookup tables.
 * see http://www.taosinc.com/downloads/pdf/dn9b_tsl2550_Lux_Calculation.pdf
 * 
 * @param channel0
 * @param channel1
 * @return Brightness in lux or -1 on error
 */
short tsl_calculate_lux(u_char channel0, u_char channel1);

#endif /*TSL2550_*/
