/*
 * Copyright (C) 2000-2004 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */

/**
 * @author: matthias ringwald 
 * 
 * @brief pin definition for the TecO SSmall Sensor Board connected
 *  over the BTnode USB prog board
 */

// TecO Sensor Board
#define TECO_POWER_ON_PIN   IO_POWER_ON_PIN
#define TECO_MICROPHONE_ADC 0 // PF0
#define TECO_PRESSURE_ADC   1 // PF1
#define TECO_LIGHT_ADC      7 // PF7, if extra light  sensor connected 
#define TECO_EXTRA_ADC      4 // PF4, if extra analog sensor connected 
#define TECO_ADXL_X_PORT    PORTE   // PE6
#define TECO_ADXL_X_PIN     PINE
#define TECO_ADXL_X_BIT     6
#define TECO_ADXL_Y_PORT    PORTB   // PB4
#define TECO_ADXL_Y_PIN     PINB
#define TECO_ADXL_Y_BIT     4
#define TECO_ADXL_Z_PORT    PORTF   // PF4, if extra ADXL added
#define TECO_ADXL_Z_PIN     PINF
#define TECO_ADXL_Z_BIT     4
#define TECO_SCL_PORT       PORTD   // PD0
#define TECO_SCL_PIN        PIND
#define TECO_SCL_BIT        0
#define TECO_SDA_PORT       PORTD   // PD1
#define TECO_SDA_PIN        PIND   
#define TECO_SDA_BIT        1


