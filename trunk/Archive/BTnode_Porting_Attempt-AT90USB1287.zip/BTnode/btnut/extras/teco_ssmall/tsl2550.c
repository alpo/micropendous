/*
 * Copyright (C) 2000-2005 by ETH Zurich
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holders nor the names of
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ETH ZURICH AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ETH ZURICH
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * For additional information see http://www.btnode.ethz.ch
 *
 */
 
#include <io.h>
#include <stdio.h>
#include <dev/twif.h>

#include <teco_ssmall/tsl2550.h>

#define MAX_LUX_STD 1846 // standard mode max lux
#define TSL2550_TW_ADDR 0x39 // slave address

// Lookup table for channel ratio (i.e. channel1 / channel0)
static u_char ratioLut[129] = {
    100, 100, 100, 100, 100, 100, 100, 100,
    100, 100, 100, 100, 100, 100,  99,  99,
     99,  99,  99,  99,  99,  99,  99,  99,
     99,  99,  99,  98,  98,  98,  98,  98,
     98,  98,  97,  97,  97,  97,  97,  96,
     96,  96,  96,  95,  95,  95,  94,  94,
     93,  93,  93,  92,  92,  91,  91,  90,
     89,  89,  88,  87,  87,  86,  85,  84,
     83,  82,  81,  80,  79,  78,  77,  75,
     74,  73,  71,  69,  68,  66,  64,  62,
     60,  58,  56,  54,  52,  49,  47,  44,
     42,  41,  40,  40,  39,  39,  38,  38,
     37,  37,  37,  36,  36,  36,  35,  35,
     35,  35,  34,  34,  34,  34,  33,  33,
     33,  33,  32,  32,  32,  32,  32,  31,
     31,  31,  31,  31,  30,  30,  30,  30,
     30
};

// Lookup table to convert channel values to counts
static u_short countLut[128] = {
       0,    1,    2,    3,    4,    5,    6,    7,
       8,    9,   10,   11,   12,   13,   14,   15,
      16,   18,   20,   22,   24,   26,   28,   30,
      32,   34,   36,   38,   40,   42,   44,   46,
      49,   53,   57,   61,   65,   69,   73,   77,
      81,   85,   89,   93,   97,  101,  105,  109,
     115,  123,  131,  139,  147,  155,  163,  171,
     179,  187,  195,  203,  211,  219,  227,  235,
     247,  263,  279,  295,  311,  327,  343,  359,
     375,  391,  407,  423,  439,  455,  471,  487,
     511,  543,  575,  607,  639,  671,  703,  735,
     767,  799,  831,  863,  895,  927,  959,  991,
    1039, 1103, 1167, 1231, 1295, 1359, 1423, 1487,
    1551, 1615, 1679, 1743, 1807, 1871, 1935, 1999,
    2095, 2223, 2351, 2479, 2607, 2735, 2863, 2991,
    3119, 3247, 3375, 3503, 3631, 3759, 3887, 4015
};

// simplified lux equation approximation using lookup tables.
//  see http://www.taosinc.com/downloads/pdf/dn9b_tsl2550_Lux_Calculation.pdf
short tsl_calculate_lux(u_char channel0, u_char channel1)
{
    // check for valid bit
    if(!(channel0 & 0x80) || !(channel1 & 0x80)){
        return -1;
    }
    // get actual 7-bit values
    channel0 &= 0x7F;
    channel1 &= 0x7F;
    // lookup count from channel value
    u_short count0 = countLut[channel0]; // all light
    u_short count1 = countLut[channel1]; // infrared only
    // calculate ratio
    // Note: the "128" is a scaling factor
    u_char ratio = 128; // default
    // avoid division by zero
    // and count1 must not be greater than count0
    if ((count0) && (count1 <= count0)){
        ratio = (count1 * 128 / count0);
    }else{
        return -1;
    }
    // calculate lux
    // Note: the "256" is a scaling factor
    u_long lux = ((count0-count1) * ratioLut[ratio]) / 256;
    // range check lux
    if (lux > MAX_LUX_STD) 
        lux = MAX_LUX_STD;
    return (short) lux;
}

u_char tsl_read(u_char *channel0, u_char *channel1){
    u_char tw_cmd;
    
    if(channel0){
        tw_cmd = 0x43; // read channel 0 cmd
        if(TwMasterTransact(TSL2550_TW_ADDR, &tw_cmd, 1, channel0, 1, 1000) == -1)
            return 1;
    }
    if(channel1){
        tw_cmd = 0x83; // read channel 1 cmd
        if(TwMasterTransact(TSL2550_TW_ADDR, &tw_cmd, 1, channel1, 1, 1000) == -1)
            return 1;
    }
    return 0;
}

u_char tsl_init(void){
    u_char tw_cmd[1];
    u_char tw_recv[1];
    
    tw_cmd[0] = 0x03; // power up cmd
    TwMasterTransact(TSL2550_TW_ADDR, tw_cmd, 1, tw_recv, 1, 1000);
    if(tw_recv[0] != 0x03)
        return 1; // error
    return 0;
}
