#ifndef _DENCODE_H_
#define _DENCODE_H_

#include <sys/types.h>

extern char *NutDecodeBase64(char *str);
extern int NutDecodeHex(char c);
extern char *NutDecodePath(char *path);

#endif
