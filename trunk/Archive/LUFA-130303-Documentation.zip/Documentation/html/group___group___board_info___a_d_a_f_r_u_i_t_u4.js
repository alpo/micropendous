var group___group___board_info___a_d_a_f_r_u_i_t_u4 =
[
    [ "BOARD_HAS_LEDS", "group___group___board_info___a_d_a_f_r_u_i_t_u4.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];