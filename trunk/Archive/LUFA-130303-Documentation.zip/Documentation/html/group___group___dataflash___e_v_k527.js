var group___group___dataflash___e_v_k527 =
[
    [ "DATAFLASH_CHIP1", "group___group___dataflash___e_v_k527.html#gabe7ecf93a0c0b6a5d6512126e14408db", null ],
    [ "DATAFLASH_NO_CHIP", "group___group___dataflash___e_v_k527.html#gae0f4037c9e631c91114cd78ef51ab2d4", null ],
    [ "DATAFLASH_PAGE_SIZE", "group___group___dataflash___e_v_k527.html#gad97930b6f26a7d1f5a97e479c0320aef", null ],
    [ "DATAFLASH_PAGES", "group___group___dataflash___e_v_k527.html#ga5a83f6d2e43ada7761beba410b329439", null ],
    [ "DATAFLASH_TOTALCHIPS", "group___group___dataflash___e_v_k527.html#gae8e6a4269d8e94891ed4ce41ddd317e8", null ],
    [ "Dataflash_DeselectChip", "group___group___dataflash___e_v_k527.html#ga2656906ce55c6bc2bacba1524652d03a", null ],
    [ "Dataflash_GetSelectedChip", "group___group___dataflash___e_v_k527.html#gae91daea0ab5e622b7565f23146a3dfe7", null ],
    [ "Dataflash_Init", "group___group___dataflash___e_v_k527.html#ga6f2cc43fe8db1e9c17508af642e0c9e0", null ],
    [ "Dataflash_ReceiveByte", "group___group___dataflash___e_v_k527.html#ga598903e58825d31d1e68707e5e6a9b57", null ],
    [ "Dataflash_SelectChip", "group___group___dataflash___e_v_k527.html#ga595aa83e5eeb6f7231abeac53423017b", null ],
    [ "Dataflash_SelectChipFromPage", "group___group___dataflash___e_v_k527.html#gad1b7d12f3253593627d85b06636748a2", null ],
    [ "Dataflash_SendAddressBytes", "group___group___dataflash___e_v_k527.html#gab5e3b85c0d2204b4644b19472d681b49", null ],
    [ "Dataflash_SendByte", "group___group___dataflash___e_v_k527.html#gab68390e967d558f58fffd845dcfd36a4", null ],
    [ "Dataflash_ToggleSelectedChipCS", "group___group___dataflash___e_v_k527.html#gabda610d1e72b182b238a3c871fecd9b9", null ],
    [ "Dataflash_TransferByte", "group___group___dataflash___e_v_k527.html#ga226225bae5393adc94184f5d93850188", null ],
    [ "Dataflash_WaitWhileBusy", "group___group___dataflash___e_v_k527.html#gaa1e6400832a3496234852e77643ba9d3", null ]
];