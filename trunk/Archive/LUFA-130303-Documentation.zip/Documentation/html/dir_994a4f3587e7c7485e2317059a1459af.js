var dir_994a4f3587e7c7485e2317059a1459af =
[
    [ "DeviceTemplate", "dir_036c25fff362d08365fcd9ee781a6974.html", "dir_036c25fff362d08365fcd9ee781a6974" ],
    [ "DriverStubs", "dir_ddbb067844295b56867a1afad4e66574.html", "dir_ddbb067844295b56867a1afad4e66574" ],
    [ "HostTemplate", "dir_a12bf981830c0dd9306260509c4ec8be.html", "dir_a12bf981830c0dd9306260509c4ec8be" ],
    [ "LUFAConfig.h", "_l_u_f_a_config_8h.html", null ]
];