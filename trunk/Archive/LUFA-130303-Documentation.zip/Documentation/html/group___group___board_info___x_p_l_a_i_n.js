var group___group___board_info___x_p_l_a_i_n =
[
    [ "BOARD_HAS_DATAFLASH", "group___group___board_info___x_p_l_a_i_n.html#gad38a7b3c4c9da36015f176544dea8b42", null ],
    [ "BOARD_HAS_LEDS", "group___group___board_info___x_p_l_a_i_n.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];