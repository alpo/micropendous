var group___group___architectures =
[
    [ "ARCH_AVR8", "group___group___architectures.html#ga416485cdc0e303f32a04f7f38e9b46c2", null ],
    [ "ARCH_UC3", "group___group___architectures.html#ga8515ffb8044b8f67a035a3122f67e6c4", null ],
    [ "ARCH_XMEGA", "group___group___architectures.html#ga819ed63e04c913efccee94680140a222", null ]
];