var group___group___endianness =
[
    [ "Byte Reordering", "group___group___byte_swapping.html", "group___group___byte_swapping" ],
    [ "Endianness Conversion", "group___group___endian_conversion.html", "group___group___endian_conversion" ]
];