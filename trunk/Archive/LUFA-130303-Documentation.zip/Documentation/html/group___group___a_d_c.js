var group___group___a_d_c =
[
    [ "ADC Peripheral Driver (AVR8)", "group___group___a_d_c___a_v_r8.html", "group___group___a_d_c___a_v_r8" ]
];