var dir_64780c9f9b5cd2c8394133d1f9e098d4 =
[
    [ "AndroidAccessoryClassCommon.h", "_android_accessory_class_common_8h.html", "_android_accessory_class_common_8h" ],
    [ "AudioClassCommon.h", "_audio_class_common_8h.html", "_audio_class_common_8h" ],
    [ "CDCClassCommon.h", "_c_d_c_class_common_8h.html", "_c_d_c_class_common_8h" ],
    [ "HIDClassCommon.h", "_h_i_d_class_common_8h.html", "_h_i_d_class_common_8h" ],
    [ "HIDParser.h", "_h_i_d_parser_8h.html", "_h_i_d_parser_8h" ],
    [ "HIDReportData.h", "_h_i_d_report_data_8h.html", "_h_i_d_report_data_8h" ],
    [ "MassStorageClassCommon.h", "_mass_storage_class_common_8h.html", "_mass_storage_class_common_8h" ],
    [ "MIDIClassCommon.h", "_m_i_d_i_class_common_8h.html", "_m_i_d_i_class_common_8h" ],
    [ "PrinterClassCommon.h", "_printer_class_common_8h.html", "_printer_class_common_8h" ],
    [ "RNDISClassCommon.h", "_r_n_d_i_s_class_common_8h.html", "_r_n_d_i_s_class_common_8h" ],
    [ "StillImageClassCommon.h", "_still_image_class_common_8h.html", "_still_image_class_common_8h" ]
];