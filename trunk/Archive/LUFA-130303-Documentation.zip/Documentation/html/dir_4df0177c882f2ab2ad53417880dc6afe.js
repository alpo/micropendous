var dir_4df0177c882f2ab2ad53417880dc6afe =
[
    [ "AVR8", "dir_b5e5b2a0e9f826c24bffaa92b4734cc3.html", "dir_b5e5b2a0e9f826c24bffaa92b4734cc3" ],
    [ "XMEGA", "dir_b3ddf78d1f104de329aad8108e7cfff0.html", "dir_b3ddf78d1f104de329aad8108e7cfff0" ],
    [ "ADC.h", "_a_d_c_8h.html", null ],
    [ "Serial.h", "_serial_8h.html", null ],
    [ "SerialSPI.h", "_serial_s_p_i_8h.html", null ],
    [ "SPI.h", "_s_p_i_8h.html", null ],
    [ "TWI.h", "_t_w_i_8h.html", null ]
];