var dir_46f0a310448968fe371c870cd868aa1f =
[
    [ "UC3", "dir_4f301d55d68805298adcc9c5b58dbbe7.html", "dir_4f301d55d68805298adcc9c5b58dbbe7" ],
    [ "XMEGA", "dir_7d64b2eb7704564c22b62dc99b49a048.html", "dir_7d64b2eb7704564c22b62dc99b49a048" ],
    [ "Platform.h", "_platform_8h.html", null ]
];