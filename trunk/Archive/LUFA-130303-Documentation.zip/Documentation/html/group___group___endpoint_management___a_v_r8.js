var group___group___endpoint_management___a_v_r8 =
[
    [ "ENDPOINT_CONTROLEP_DEFAULT_SIZE", "group___group___endpoint_management___a_v_r8.html#gaebe9cfe97e9292e5e8cfba9885bbd901", null ],
    [ "ENDPOINT_TOTAL_ENDPOINTS", "group___group___endpoint_management___a_v_r8.html#ga0aaeafaa974fb7095750a771e2adfc73", null ],
    [ "Endpoint_ClearStatusStage", "group___group___endpoint_management___a_v_r8.html#ga9e00020d1fca630c351e3b8139ba67df", null ],
    [ "Endpoint_ConfigureEndpoint", "group___group___endpoint_management___a_v_r8.html#gaa8e85d230776e44276e8f318d0baed24", null ],
    [ "Endpoint_ConfigureEndpointTable", "group___group___endpoint_management___a_v_r8.html#ga6b39a9542d970d8c7aff7347783137ae", null ],
    [ "Endpoint_DisableEndpoint", "group___group___endpoint_management___a_v_r8.html#ga001d4ebf384129efc77d239011ca8fdb", null ],
    [ "Endpoint_EnableEndpoint", "group___group___endpoint_management___a_v_r8.html#gafdce33d2159f2b1a6e98216ef29e9654", null ],
    [ "Endpoint_GetCurrentEndpoint", "group___group___endpoint_management___a_v_r8.html#ga3eb31e520c947003839bfb5e1e4bf95c", null ],
    [ "Endpoint_GetEndpointDirection", "group___group___endpoint_management___a_v_r8.html#gaedaf95aead8b39dcea3ed2fa52e86950", null ],
    [ "Endpoint_GetEndpointInterrupts", "group___group___endpoint_management___a_v_r8.html#ga4744236ce0d28f80c69a3225fdeabe81", null ],
    [ "Endpoint_HasEndpointInterrupted", "group___group___endpoint_management___a_v_r8.html#gada0981e7d254151e122631401961acb0", null ],
    [ "Endpoint_IsConfigured", "group___group___endpoint_management___a_v_r8.html#ga22dedc9265477d753e932fc805ebb91d", null ],
    [ "Endpoint_IsEnabled", "group___group___endpoint_management___a_v_r8.html#ga0258dd64dd4215c59ce9713868f5a387", null ],
    [ "Endpoint_ResetDataToggle", "group___group___endpoint_management___a_v_r8.html#gac2051cf461db29c5c73651edbe77638a", null ],
    [ "Endpoint_ResetEndpoint", "group___group___endpoint_management___a_v_r8.html#gab38cc206d86c2850741bd4f0b0ef69bf", null ],
    [ "Endpoint_SelectEndpoint", "group___group___endpoint_management___a_v_r8.html#ga49fb57f8c3c17e6729c6ba980df264a4", null ],
    [ "Endpoint_SetEndpointDirection", "group___group___endpoint_management___a_v_r8.html#gae6b0236ec27226add2815d47e7939056", null ],
    [ "USB_Device_ControlEndpointSize", "group___group___endpoint_management___a_v_r8.html#gac1805540ce24cf3cbd621c2e0cbc1c31", null ]
];