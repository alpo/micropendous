var group___group___board_info___r_z_u_s_b_s_t_i_c_k =
[
    [ "BOARD_HAS_LEDS", "group___group___board_info___r_z_u_s_b_s_t_i_c_k.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];