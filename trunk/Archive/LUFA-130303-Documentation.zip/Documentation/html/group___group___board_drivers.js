var group___group___board_drivers =
[
    [ "Board Information Driver - LUFA/Drivers/Board/Board.h", "group___group___board_info.html", "group___group___board_info" ],
    [ "Buttons Driver - LUFA/Drivers/Board/Buttons.h", "group___group___buttons.html", "group___group___buttons" ],
    [ "Dataflash Driver - LUFA/Drivers/Board/Dataflash.h", "group___group___dataflash.html", "group___group___dataflash" ],
    [ "Joystick Driver - LUFA/Drivers/Board/Joystick.h", "group___group___joystick.html", "group___group___joystick" ],
    [ "LEDs Driver - LUFA/Drivers/Board/LEDs.h", "group___group___l_e_ds.html", "group___group___l_e_ds" ],
    [ "Temperature Sensor Driver - LUFA/Drivers/Board/Temperature.h", "group___group___temperature.html", null ]
];