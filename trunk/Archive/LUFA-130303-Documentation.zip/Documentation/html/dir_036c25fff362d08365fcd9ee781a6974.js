var dir_036c25fff362d08365fcd9ee781a6974 =
[
    [ "Descriptors.h", "_descriptors_8h.html", [
      [ "USB_Descriptor_Configuration_t", "struct_u_s_b___descriptor___configuration__t.html", "struct_u_s_b___descriptor___configuration__t" ]
    ] ],
    [ "DeviceApplication.h", "_device_application_8h.html", "_device_application_8h" ]
];