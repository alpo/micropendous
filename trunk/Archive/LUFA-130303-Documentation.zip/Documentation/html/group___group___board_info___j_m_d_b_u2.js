var group___group___board_info___j_m_d_b_u2 =
[
    [ "BOARD_HAS_BUTTONS", "group___group___board_info___j_m_d_b_u2.html#ga533c886382f90af8e9be1f3b95ae52fb", null ],
    [ "BOARD_HAS_LEDS", "group___group___board_info___j_m_d_b_u2.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];