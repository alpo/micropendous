var globals_defs =
[
    [ "a", "globals_defs.html", null ],
    [ "b", "globals_defs_0x62.html", null ],
    [ "c", "globals_defs_0x63.html", null ],
    [ "d", "globals_defs_0x64.html", null ],
    [ "e", "globals_defs_0x65.html", null ],
    [ "g", "globals_defs_0x67.html", null ],
    [ "h", "globals_defs_0x68.html", null ],
    [ "i", "globals_defs_0x69.html", null ],
    [ "j", "globals_defs_0x6a.html", null ],
    [ "l", "globals_defs_0x6c.html", null ],
    [ "m", "globals_defs_0x6d.html", null ],
    [ "n", "globals_defs_0x6e.html", null ],
    [ "o", "globals_defs_0x6f.html", null ],
    [ "p", "globals_defs_0x70.html", null ],
    [ "r", "globals_defs_0x72.html", null ],
    [ "s", "globals_defs_0x73.html", null ],
    [ "t", "globals_defs_0x74.html", null ],
    [ "u", "globals_defs_0x75.html", null ],
    [ "v", "globals_defs_0x76.html", null ]
];