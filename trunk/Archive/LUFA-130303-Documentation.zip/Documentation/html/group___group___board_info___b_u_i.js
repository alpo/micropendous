var group___group___board_info___b_u_i =
[
    [ "BOARD_HAS_LEDS", "group___group___board_info___b_u_i.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];