var group___group___board_info___m_a_x_i_m_u_s =
[
    [ "BOARD_HAS_LEDS", "group___group___board_info___m_a_x_i_m_u_s.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];