var group___group___endpoint_management___x_m_e_g_a =
[
    [ "ENDPOINT_CONTROLEP_DEFAULT_SIZE", "group___group___endpoint_management___x_m_e_g_a.html#gaebe9cfe97e9292e5e8cfba9885bbd901", null ],
    [ "ENDPOINT_TOTAL_ENDPOINTS", "group___group___endpoint_management___x_m_e_g_a.html#ga0aaeafaa974fb7095750a771e2adfc73", null ],
    [ "Endpoint_ClearStatusStage", "group___group___endpoint_management___x_m_e_g_a.html#ga9e00020d1fca630c351e3b8139ba67df", null ],
    [ "Endpoint_ConfigureEndpoint", "group___group___endpoint_management___x_m_e_g_a.html#gaa8e85d230776e44276e8f318d0baed24", null ],
    [ "Endpoint_ConfigureEndpointTable", "group___group___endpoint_management___x_m_e_g_a.html#ga6b39a9542d970d8c7aff7347783137ae", null ],
    [ "Endpoint_GetCurrentEndpoint", "group___group___endpoint_management___x_m_e_g_a.html#ga3eb31e520c947003839bfb5e1e4bf95c", null ],
    [ "Endpoint_GetEndpointDirection", "group___group___endpoint_management___x_m_e_g_a.html#gaedaf95aead8b39dcea3ed2fa52e86950", null ],
    [ "Endpoint_IsConfigured", "group___group___endpoint_management___x_m_e_g_a.html#ga22dedc9265477d753e932fc805ebb91d", null ],
    [ "Endpoint_IsEnabled", "group___group___endpoint_management___x_m_e_g_a.html#ga0258dd64dd4215c59ce9713868f5a387", null ],
    [ "Endpoint_ResetDataToggle", "group___group___endpoint_management___x_m_e_g_a.html#gac2051cf461db29c5c73651edbe77638a", null ],
    [ "Endpoint_ResetEndpoint", "group___group___endpoint_management___x_m_e_g_a.html#gab38cc206d86c2850741bd4f0b0ef69bf", null ],
    [ "Endpoint_SelectEndpoint", "group___group___endpoint_management___x_m_e_g_a.html#ga03ea96bc02c9945a62cb1f0c524bd0f6", null ],
    [ "USB_Device_ControlEndpointSize", "group___group___endpoint_management___x_m_e_g_a.html#gac1805540ce24cf3cbd621c2e0cbc1c31", null ]
];