var group___group___board_info___u_c3___a3___x_p_l_a_i_n_e_d =
[
    [ "BOARD_HAS_BUTTONS", "group___group___board_info___u_c3___a3___x_p_l_a_i_n_e_d.html#ga533c886382f90af8e9be1f3b95ae52fb", null ],
    [ "BOARD_HAS_LEDS", "group___group___board_info___u_c3___a3___x_p_l_a_i_n_e_d.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];