var group___group___endpoint_packet_management =
[
    [ "Endpoint Packet Management (AVR8)", "group___group___endpoint_packet_management___a_v_r8.html", "group___group___endpoint_packet_management___a_v_r8" ],
    [ "Endpoint Packet Management (UC3)", "group___group___endpoint_packet_management___u_c3.html", "group___group___endpoint_packet_management___u_c3" ],
    [ "Endpoint Packet Management (XMEGA)", "group___group___endpoint_packet_management___x_m_e_g_a.html", "group___group___endpoint_packet_management___x_m_e_g_a" ]
];