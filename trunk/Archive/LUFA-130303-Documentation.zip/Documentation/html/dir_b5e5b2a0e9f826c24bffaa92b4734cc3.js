var dir_b5e5b2a0e9f826c24bffaa92b4734cc3 =
[
    [ "ADC_AVR8.h", "_a_d_c___a_v_r8_8h.html", "_a_d_c___a_v_r8_8h" ],
    [ "Serial_AVR8.h", "_serial___a_v_r8_8h.html", "_serial___a_v_r8_8h" ],
    [ "SerialSPI_AVR8.h", "_serial_s_p_i___a_v_r8_8h.html", "_serial_s_p_i___a_v_r8_8h" ],
    [ "SPI_AVR8.h", "_s_p_i___a_v_r8_8h.html", "_s_p_i___a_v_r8_8h" ],
    [ "TWI_AVR8.h", "_t_w_i___a_v_r8_8h.html", "_t_w_i___a_v_r8_8h" ]
];