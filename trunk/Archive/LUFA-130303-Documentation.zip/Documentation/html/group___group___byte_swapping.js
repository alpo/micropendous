var group___group___byte_swapping =
[
    [ "SWAPENDIAN_16", "group___group___byte_swapping.html#gaba93d35feacd49adc70134e65a22fb72", null ],
    [ "SWAPENDIAN_32", "group___group___byte_swapping.html#ga73f8e4615c24163c05bbe5720a31f7d0", null ],
    [ "SwapEndian_16", "group___group___byte_swapping.html#ga0ade1c82bee6691c7de066bdc46e0b1f", null ],
    [ "SwapEndian_32", "group___group___byte_swapping.html#ga23f6e3ed6f714a08274e17dcaf6cc5d2", null ],
    [ "SwapEndian_n", "group___group___byte_swapping.html#ga5544d7aa0da5fa9001b468ce7e6ccc84", null ]
];