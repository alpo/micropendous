var dir_16b1964dc51317bc8f044a1edbbad6e9 =
[
    [ "AndroidAccessoryClassHost.h", "_android_accessory_class_host_8h.html", "_android_accessory_class_host_8h" ],
    [ "AudioClassHost.h", "_audio_class_host_8h.html", "_audio_class_host_8h" ],
    [ "CDCClassHost.h", "_c_d_c_class_host_8h.html", "_c_d_c_class_host_8h" ],
    [ "HIDClassHost.h", "_h_i_d_class_host_8h.html", "_h_i_d_class_host_8h" ],
    [ "MassStorageClassHost.h", "_mass_storage_class_host_8h.html", "_mass_storage_class_host_8h" ],
    [ "MIDIClassHost.h", "_m_i_d_i_class_host_8h.html", "_m_i_d_i_class_host_8h" ],
    [ "PrinterClassHost.h", "_printer_class_host_8h.html", "_printer_class_host_8h" ],
    [ "RNDISClassHost.h", "_r_n_d_i_s_class_host_8h.html", "_r_n_d_i_s_class_host_8h" ],
    [ "StillImageClassHost.h", "_still_image_class_host_8h.html", "_still_image_class_host_8h" ]
];