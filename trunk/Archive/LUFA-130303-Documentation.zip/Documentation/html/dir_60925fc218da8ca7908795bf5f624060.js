var dir_60925fc218da8ca7908795bf5f624060 =
[
    [ "Board", "dir_1ad147b45c81532355ec7c0823e09208.html", "dir_1ad147b45c81532355ec7c0823e09208" ],
    [ "Misc", "dir_b25b8390048ff4b4042af5ceece298cc.html", "dir_b25b8390048ff4b4042af5ceece298cc" ],
    [ "Peripheral", "dir_4df0177c882f2ab2ad53417880dc6afe.html", "dir_4df0177c882f2ab2ad53417880dc6afe" ],
    [ "USB", "dir_e75f4b3e420b592e193641d7e490cb7e.html", "dir_e75f4b3e420b592e193641d7e490cb7e" ]
];