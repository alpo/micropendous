var group___group___board_info___o_l_i_m_e_x_i_s_p_m_k2 =
[
    [ "BOARD_HAS_BUTTONS", "group___group___board_info___o_l_i_m_e_x_i_s_p_m_k2.html#ga533c886382f90af8e9be1f3b95ae52fb", null ],
    [ "BOARD_HAS_LEDS", "group___group___board_info___o_l_i_m_e_x_i_s_p_m_k2.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];