var dir_dab58fb294dbe246c1b3374ca8a134fa =
[
    [ "Common", "dir_64780c9f9b5cd2c8394133d1f9e098d4.html", "dir_64780c9f9b5cd2c8394133d1f9e098d4" ],
    [ "Device", "dir_e5bebb7590f2cdba6af3ebfaee741c48.html", "dir_e5bebb7590f2cdba6af3ebfaee741c48" ],
    [ "Host", "dir_16b1964dc51317bc8f044a1edbbad6e9.html", "dir_16b1964dc51317bc8f044a1edbbad6e9" ],
    [ "AndroidAccessoryClass.h", "_android_accessory_class_8h.html", null ],
    [ "AudioClass.h", "_audio_class_8h.html", null ],
    [ "CDCClass.h", "_c_d_c_class_8h.html", null ],
    [ "HIDClass.h", "_h_i_d_class_8h.html", null ],
    [ "MassStorageClass.h", "_mass_storage_class_8h.html", null ],
    [ "MIDIClass.h", "_m_i_d_i_class_8h.html", null ],
    [ "PrinterClass.h", "_printer_class_8h.html", null ],
    [ "RNDISClass.h", "_r_n_d_i_s_class_8h.html", null ],
    [ "StillImageClass.h", "_still_image_class_8h.html", null ]
];