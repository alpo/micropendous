var dir_b3ddf78d1f104de329aad8108e7cfff0 =
[
    [ "Serial_XMEGA.h", "_serial___x_m_e_g_a_8h.html", "_serial___x_m_e_g_a_8h" ],
    [ "SerialSPI_XMEGA.h", "_serial_s_p_i___x_m_e_g_a_8h.html", "_serial_s_p_i___x_m_e_g_a_8h" ],
    [ "SPI_XMEGA.h", "_s_p_i___x_m_e_g_a_8h.html", "_s_p_i___x_m_e_g_a_8h" ]
];