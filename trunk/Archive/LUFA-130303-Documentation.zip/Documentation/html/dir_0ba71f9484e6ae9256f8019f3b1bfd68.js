var dir_0ba71f9484e6ae9256f8019f3b1bfd68 =
[
    [ "Board.h", "_drivers_2_board_2_a_v_r8_2_u_s_b_t_i_n_y_m_k_i_i_2_board_8h.html", "_drivers_2_board_2_a_v_r8_2_u_s_b_t_i_n_y_m_k_i_i_2_board_8h" ],
    [ "Buttons.h", "_drivers_2_board_2_a_v_r8_2_u_s_b_t_i_n_y_m_k_i_i_2_buttons_8h.html", "_drivers_2_board_2_a_v_r8_2_u_s_b_t_i_n_y_m_k_i_i_2_buttons_8h" ],
    [ "LEDs.h", "_drivers_2_board_2_a_v_r8_2_u_s_b_t_i_n_y_m_k_i_i_2_l_e_ds_8h.html", "_drivers_2_board_2_a_v_r8_2_u_s_b_t_i_n_y_m_k_i_i_2_l_e_ds_8h" ]
];