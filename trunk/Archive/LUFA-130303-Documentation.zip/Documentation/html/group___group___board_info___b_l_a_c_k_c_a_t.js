var group___group___board_info___b_l_a_c_k_c_a_t =
[
    [ "BOARD_HAS_LEDS", "group___group___board_info___b_l_a_c_k_c_a_t.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];