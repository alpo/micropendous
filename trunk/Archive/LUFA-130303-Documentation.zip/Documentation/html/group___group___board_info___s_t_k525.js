var group___group___board_info___s_t_k525 =
[
    [ "BOARD_HAS_BUTTONS", "group___group___board_info___s_t_k525.html#ga533c886382f90af8e9be1f3b95ae52fb", null ],
    [ "BOARD_HAS_DATAFLASH", "group___group___board_info___s_t_k525.html#gad38a7b3c4c9da36015f176544dea8b42", null ],
    [ "BOARD_HAS_JOYSTICK", "group___group___board_info___s_t_k525.html#ga40c56e738823b6244b20ada393836a9e", null ],
    [ "BOARD_HAS_LEDS", "group___group___board_info___s_t_k525.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];