var group___group___dataflash =
[
    [ "A3BU_XPLAINED", "group___group___dataflash___a3_b_u___x_p_l_a_i_n_e_d.html", "group___group___dataflash___a3_b_u___x_p_l_a_i_n_e_d" ],
    [ "B1_XPLAINED", "group___group___dataflash___b1___x_p_l_a_i_n_e_d.html", "group___group___dataflash___b1___x_p_l_a_i_n_e_d" ],
    [ "EVK527", "group___group___dataflash___e_v_k527.html", "group___group___dataflash___e_v_k527" ],
    [ "STK525", "group___group___dataflash___s_t_k525.html", "group___group___dataflash___s_t_k525" ],
    [ "STK526", "group___group___dataflash___s_t_k526.html", "group___group___dataflash___s_t_k526" ],
    [ "USBKEY", "group___group___dataflash___u_s_b_k_e_y.html", "group___group___dataflash___u_s_b_k_e_y" ],
    [ "XPLAIN", "group___group___dataflash___x_p_l_a_i_n.html", "group___group___dataflash___x_p_l_a_i_n" ],
    [ "XPLAIN_REV1", "group___group___dataflash___x_p_l_a_i_n___r_e_v1.html", null ],
    [ "DATAFLASH_CHIP_MASK", "group___group___dataflash.html#ga139827baac789e7383e37756c78a4074", null ],
    [ "Dataflash_DeselectChip", "group___group___dataflash.html#ga2656906ce55c6bc2bacba1524652d03a", null ],
    [ "Dataflash_GetSelectedChip", "group___group___dataflash.html#gae91daea0ab5e622b7565f23146a3dfe7", null ],
    [ "Dataflash_Init", "group___group___dataflash.html#ga6f2cc43fe8db1e9c17508af642e0c9e0", null ],
    [ "Dataflash_ReceiveByte", "group___group___dataflash.html#ga598903e58825d31d1e68707e5e6a9b57", null ],
    [ "Dataflash_SelectChip", "group___group___dataflash.html#ga595aa83e5eeb6f7231abeac53423017b", null ],
    [ "Dataflash_SelectChipFromPage", "group___group___dataflash.html#gad1b7d12f3253593627d85b06636748a2", null ],
    [ "Dataflash_SendAddressBytes", "group___group___dataflash.html#gab5e3b85c0d2204b4644b19472d681b49", null ],
    [ "Dataflash_SendByte", "group___group___dataflash.html#gab68390e967d558f58fffd845dcfd36a4", null ],
    [ "Dataflash_ToggleSelectedChipCS", "group___group___dataflash.html#gabda610d1e72b182b238a3c871fecd9b9", null ],
    [ "Dataflash_TransferByte", "group___group___dataflash.html#ga226225bae5393adc94184f5d93850188", null ],
    [ "Dataflash_WaitWhileBusy", "group___group___dataflash.html#gaa1e6400832a3496234852e77643ba9d3", null ]
];