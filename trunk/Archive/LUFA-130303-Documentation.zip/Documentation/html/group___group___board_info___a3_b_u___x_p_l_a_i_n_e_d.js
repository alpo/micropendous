var group___group___board_info___a3_b_u___x_p_l_a_i_n_e_d =
[
    [ "BOARD_HAS_BUTTONS", "group___group___board_info___a3_b_u___x_p_l_a_i_n_e_d.html#ga533c886382f90af8e9be1f3b95ae52fb", null ],
    [ "BOARD_HAS_DATAFLASH", "group___group___board_info___a3_b_u___x_p_l_a_i_n_e_d.html#gad38a7b3c4c9da36015f176544dea8b42", null ],
    [ "BOARD_HAS_LEDS", "group___group___board_info___a3_b_u___x_p_l_a_i_n_e_d.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];