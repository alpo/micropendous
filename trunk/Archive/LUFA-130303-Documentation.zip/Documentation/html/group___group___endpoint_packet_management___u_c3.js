var group___group___endpoint_packet_management___u_c3 =
[
    [ "Endpoint_AbortPendingIN", "group___group___endpoint_packet_management___u_c3.html#gabdd638740e9c67bc62d2eef8aadbf650", null ],
    [ "Endpoint_ClearIN", "group___group___endpoint_packet_management___u_c3.html#gaa03a298562e0a76d3095c9edf7eeecd5", null ],
    [ "Endpoint_ClearOUT", "group___group___endpoint_packet_management___u_c3.html#gaaa540fdeeab01f675617d210c1ac4eb3", null ],
    [ "Endpoint_ClearSETUP", "group___group___endpoint_packet_management___u_c3.html#ga4fe130e3ce8121c25bba1dd0668bca32", null ],
    [ "Endpoint_ClearStall", "group___group___endpoint_packet_management___u_c3.html#ga870419d9eefaaa8cdd160a99439923ce", null ],
    [ "Endpoint_GetBusyBanks", "group___group___endpoint_packet_management___u_c3.html#gaacb6b1173b17ab1626a21cf94d2d0af5", null ],
    [ "Endpoint_IsINReady", "group___group___endpoint_packet_management___u_c3.html#ga70bad960aa32b4bdb1e95dd71af401ff", null ],
    [ "Endpoint_IsOUTReceived", "group___group___endpoint_packet_management___u_c3.html#ga8256d54bd494ba1c6725982ccbd3027b", null ],
    [ "Endpoint_IsReadWriteAllowed", "group___group___endpoint_packet_management___u_c3.html#gafb6939f9e97812f1f0d7652e382adf68", null ],
    [ "Endpoint_IsSETUPReceived", "group___group___endpoint_packet_management___u_c3.html#gaee0cd99437a570e26a04bdc0fabba97f", null ],
    [ "Endpoint_IsStalled", "group___group___endpoint_packet_management___u_c3.html#ga689548970ff03b2443b09ac2b5696810", null ],
    [ "Endpoint_StallTransaction", "group___group___endpoint_packet_management___u_c3.html#ga5e6b4ec08cf30c93e573990a52571f78", null ]
];