var group___group___architecture_specific =
[
    [ "JTAG_ASSERT", "group___group___architecture_specific.html#ga6707f2ae6083d3561a2688781f92c889", null ],
    [ "JTAG_DEBUG_BREAK", "group___group___architecture_specific.html#ga85846657c9d154fbafc89af57731f6a7", null ],
    [ "JTAG_DEBUG_POINT", "group___group___architecture_specific.html#ga17adf9c743cced05c37c49fe2e09d4d5", null ],
    [ "JTAG_DISABLE", "group___group___architecture_specific.html#gaf40f6b28050728617f95a45389000fd9", null ],
    [ "JTAG_ENABLE", "group___group___architecture_specific.html#ga4900cf2828678570ead9f5f1109d0048", null ],
    [ "pgm_read_ptr", "group___group___architecture_specific.html#ga5cfc50dc0024c872c38ecef2844114ba", null ],
    [ "STDOUT_ASSERT", "group___group___architecture_specific.html#ga0c7ce564a3209640c458f305de49fee4", null ]
];