var group___group___device___x_m_e_g_a =
[
    [ "INTERNAL_SERIAL_LENGTH_BITS", "group___group___device___x_m_e_g_a.html#ga665f0d58e9e617c5fa69a5247e44cf45", null ],
    [ "INTERNAL_SERIAL_START_ADDRESS", "group___group___device___x_m_e_g_a.html#gaed45efa93872ad34d787e7d62177eb80", null ],
    [ "USB_DEVICE_OPT_LOWSPEED", "group___group___device___x_m_e_g_a.html#ga6b9f18eb9033bc6c924d017225024b3a", null ],
    [ "USE_INTERNAL_SERIAL", "group___group___device___x_m_e_g_a.html#gae91cf5b90df788954090bcbd8bf1bece", null ],
    [ "USB_Device_DisableSOFEvents", "group___group___device___x_m_e_g_a.html#gabf105f978815be892e4342e942d1301a", null ],
    [ "USB_Device_EnableSOFEvents", "group___group___device___x_m_e_g_a.html#ga00fc51da3f7d11381e557b0c9147a01a", null ],
    [ "USB_Device_GetFrameNumber", "group___group___device___x_m_e_g_a.html#gabef6e7fb5514426862890514964ff2f1", null ],
    [ "USB_Device_SendRemoteWakeup", "group___group___device___x_m_e_g_a.html#ga9a9bd80a3bcdcbe266498b1e322a709f", null ]
];