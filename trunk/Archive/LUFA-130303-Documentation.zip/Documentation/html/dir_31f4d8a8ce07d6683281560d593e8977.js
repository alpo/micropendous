var dir_31f4d8a8ce07d6683281560d593e8977 =
[
    [ "AVR8", "dir_f156e91554d44626e27906f9c2a8b7f1.html", "dir_f156e91554d44626e27906f9c2a8b7f1" ],
    [ "UC3", "dir_eeca526c4bee4f3d3f2f31f960ea5c3d.html", "dir_eeca526c4bee4f3d3f2f31f960ea5c3d" ],
    [ "XMEGA", "dir_4f5a3c96cd88e69d70251fdd3daf414b.html", "dir_4f5a3c96cd88e69d70251fdd3daf414b" ],
    [ "ConfigDescriptors.h", "_config_descriptors_8h.html", "_config_descriptors_8h" ],
    [ "Device.h", "_device_8h.html", "_device_8h" ],
    [ "DeviceStandardReq.h", "_device_standard_req_8h.html", "_device_standard_req_8h" ],
    [ "Endpoint.h", "_endpoint_8h.html", "_endpoint_8h" ],
    [ "EndpointStream.h", "_endpoint_stream_8h.html", "_endpoint_stream_8h" ],
    [ "Events.h", "_events_8h.html", "_events_8h" ],
    [ "Host.h", "_host_8h.html", "_host_8h" ],
    [ "HostStandardReq.h", "_host_standard_req_8h.html", "_host_standard_req_8h" ],
    [ "OTG.h", "_o_t_g_8h.html", null ],
    [ "Pipe.h", "_pipe_8h.html", "_pipe_8h" ],
    [ "PipeStream.h", "_pipe_stream_8h.html", "_pipe_stream_8h" ],
    [ "StdDescriptors.h", "_std_descriptors_8h.html", "_std_descriptors_8h" ],
    [ "StdRequestType.h", "_std_request_type_8h.html", "_std_request_type_8h" ],
    [ "USBController.h", "_u_s_b_controller_8h.html", "_u_s_b_controller_8h" ],
    [ "USBInterrupt.h", "_u_s_b_interrupt_8h.html", null ],
    [ "USBMode.h", "_u_s_b_mode_8h.html", "_u_s_b_mode_8h" ],
    [ "USBTask.h", "_u_s_b_task_8h.html", "_u_s_b_task_8h" ]
];