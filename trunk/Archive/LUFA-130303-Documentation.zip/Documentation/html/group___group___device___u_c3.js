var group___group___device___u_c3 =
[
    [ "INTERNAL_SERIAL_LENGTH_BITS", "group___group___device___u_c3.html#ga665f0d58e9e617c5fa69a5247e44cf45", null ],
    [ "INTERNAL_SERIAL_START_ADDRESS", "group___group___device___u_c3.html#gaed45efa93872ad34d787e7d62177eb80", null ],
    [ "USB_DEVICE_OPT_FULLSPEED", "group___group___device___u_c3.html#ga1cca5875d1fb87cdf8263429b2a77e20", null ],
    [ "USB_DEVICE_OPT_HIGHSPEED", "group___group___device___u_c3.html#ga0fa5ec2c05769c27ab62c39e9d88b871", null ],
    [ "USB_DEVICE_OPT_LOWSPEED", "group___group___device___u_c3.html#ga6b9f18eb9033bc6c924d017225024b3a", null ],
    [ "USE_INTERNAL_SERIAL", "group___group___device___u_c3.html#gae91cf5b90df788954090bcbd8bf1bece", null ],
    [ "USB_Device_DisableSOFEvents", "group___group___device___u_c3.html#gabf105f978815be892e4342e942d1301a", null ],
    [ "USB_Device_EnableSOFEvents", "group___group___device___u_c3.html#ga00fc51da3f7d11381e557b0c9147a01a", null ],
    [ "USB_Device_GetFrameNumber", "group___group___device___u_c3.html#gabef6e7fb5514426862890514964ff2f1", null ],
    [ "USB_Device_SendRemoteWakeup", "group___group___device___u_c3.html#ga9a9bd80a3bcdcbe266498b1e322a709f", null ]
];