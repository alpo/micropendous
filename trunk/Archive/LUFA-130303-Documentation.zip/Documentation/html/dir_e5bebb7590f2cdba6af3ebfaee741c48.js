var dir_e5bebb7590f2cdba6af3ebfaee741c48 =
[
    [ "AudioClassDevice.h", "_audio_class_device_8h.html", "_audio_class_device_8h" ],
    [ "CDCClassDevice.h", "_c_d_c_class_device_8h.html", "_c_d_c_class_device_8h" ],
    [ "HIDClassDevice.h", "_h_i_d_class_device_8h.html", "_h_i_d_class_device_8h" ],
    [ "MassStorageClassDevice.h", "_mass_storage_class_device_8h.html", "_mass_storage_class_device_8h" ],
    [ "MIDIClassDevice.h", "_m_i_d_i_class_device_8h.html", "_m_i_d_i_class_device_8h" ],
    [ "RNDISClassDevice.h", "_r_n_d_i_s_class_device_8h.html", "_r_n_d_i_s_class_device_8h" ]
];