var group___group___board_info___s_t_a_n_g_e___i_s_p =
[
    [ "BOARD_HAS_BUTTONS", "group___group___board_info___s_t_a_n_g_e___i_s_p.html#ga533c886382f90af8e9be1f3b95ae52fb", null ],
    [ "BOARD_HAS_LEDS", "group___group___board_info___s_t_a_n_g_e___i_s_p.html#ga0091c5126d848d3d0c962d11156700cc", null ]
];