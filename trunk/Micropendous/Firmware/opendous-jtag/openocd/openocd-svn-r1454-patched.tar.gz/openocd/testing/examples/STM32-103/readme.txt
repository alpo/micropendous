Olimex STM32-p103 board.

main.elf is a file that can be programmed to flash for
testing purposes(e.g. test GDB load performance).

http://www.olimex.com/dev/stm32-p103.html