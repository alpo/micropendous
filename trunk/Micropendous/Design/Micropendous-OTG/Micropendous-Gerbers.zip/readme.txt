File Format: Gerber RS-274-X
Plot Origin: Absolute

	Micropendous-SoldP_Front.gtp	: Top/Front Layer Solder Paste

	Micropendous-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Micropendous-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Micropendous-Front.gtl		: Top/Front Copper Layer
	Micropendous-Back.gbl		: Bottom/Back Copper Layer
	Micropendous-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask

	Micropendous-PCB_Edges.gto	: PCB Edge Outline


Drill File: Micropendous.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 293
	Notes:  - No axis mirroring and only standard vias
