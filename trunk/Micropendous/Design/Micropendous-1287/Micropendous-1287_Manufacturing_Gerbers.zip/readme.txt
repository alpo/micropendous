File Format: Gerber RS-274-X
Plot Origin: Absolute
Gerber Files:
	Micropendous-1287-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Micropendous-1287-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Micropendous-1287-Front.gtl		: Top/Front Copper Layer
	Micropendous-1287-Back.gbl		: Bottom/Back Copper Layer
	Micropendous-1287-Mask_Back.gbs		: Bottom/Back Layer Green Solder Mask
	Micropendous-1287-SilkS_Back.gbo	: Bottom/Back Layer White Silkscreen
	Micropendous-1287-PCB_Edges.gbr		: PCB Edge Outline

	Micropendous-1287-SoldP_Front.gbp	: Top/Front Layer Solder Paste Stencil
	Micropendous-1287-SoldP_Back.gbp	: Bottom/Back Layer Solder Paste Stencil


Drill File: Micropendous-1287.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 453
	Notes:  - No axis mirroring and only standard vias


Design Notes:
	- Design Size (X*Y): 3" x 1"
	- Design Detail: 8mil-8mil-20mil Trace-Clearance-Minimum_Drill
	- Micropendous-1287-Drill_Sheet.pho Gerber shows all drill locations
