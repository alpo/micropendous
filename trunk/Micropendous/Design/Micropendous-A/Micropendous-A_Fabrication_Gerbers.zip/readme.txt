File Format: Gerber RS-274-X
Plot Origin: Absolute

	Micropendous-A-SoldP_Front.gtp	: Top/Front Solder Paste Stencil

	Micropendous-A-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Micropendous-A-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Micropendous-A-Front.gtl	: Top/Front Copper Layer
	Micropendous-A-Back.gbl		: Bottom/Back Copper Layer
	Micropendous-A-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	Micropendous-A-PCB_Edges.gbr	: PCB Edge Outline

Drill File: Micropendous-A.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Leading
	Type : ASCII
	Drill Holes (Pads and Vias): 174
	Notes:  - No axis mirroring and only standard vias
		- Micropendous-A-Drill_Map.pho shows drill locations
