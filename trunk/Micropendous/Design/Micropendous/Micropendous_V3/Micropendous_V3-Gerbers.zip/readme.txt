File Format: Gerber RS-274-X
Plot Origin: Absolute

	Micropendous_V3-SoldP_Front.gtp	: Top/Front Solder Paste Stencil

	Micropendous_V3-SilkS_Front.gto	: Top/Front Layer White Silkscreen
	Micropendous_V3-Mask_Front.gts	: Top/Front Layer Green Solder Mask
	Micropendous_V3-Front.gtl	: Top/Front Copper Layer
	Micropendous_V3-Back.gbl	: Bottom/Back Copper Layer
	Micropendous_V3-Mask_Back.gbs	: Bottom/Back Layer Green Solder Mask
	Micropendous_V3-PCB_Edges.oln	: PCB Edge Outline

Drill File: Micropendous.drl
	Excellon
	Units: Inches
	M.N (Precision) -> 2.3
	Mode (Drill Origin) : Absolute
	Zero Supression : Keep Zeros
	Type : ASCII
	Drill Holes (Pads and Vias): 346
	Notes:	- No axis mirroring and only standard vias
		- All holes are plated
		- Micropendous_V3-Drill_Map.pho shows drill locations
